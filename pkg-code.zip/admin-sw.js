/**
 * Maventech Admin — service worker.
 *
 * Responsibilities:
 *   1. Cache the admin shell + assets for offline-friendly reloads.
 *   2. Periodic background poll for new admin events (orders, leads,
 *      reviews, emails, installs, sales, templates) — when running
 *      installed as a PWA we surface them as native OS notifications.
 *   3. Click-to-deep-link: tapping a notification opens the right
 *      admin tab.
 *
 * Real Web Push (VAPID) is intentionally NOT used — the admin is a
 * single-user product and a periodic background sync is enough.
 */
const CACHE_NAME = 'maventech-admin-v15';
const CORE_ASSETS = [
  '/admin-manifest.json',
  '/assets/css/style.css',
  '/assets/vendor/bootstrap.min.css',
  '/assets/vendor/bootstrap.bundle.min.js',
  '/assets/vendor/bootstrap-icons.min.css',
  '/assets/vendor/flatpickr.min.css',
  '/assets/vendor/flatpickr-airbnb.css',
  '/assets/vendor/flatpickr.min.js',
  '/assets/vendor/chart.umd.min.js',
  '/app-icon.php?size=192',
  '/app-icon.php?size=512',
];

self.addEventListener('install', (event) => {
  // Per-asset precache: cache.addAll() is atomic — one bad URL would wipe
  // out the ENTIRE precache. Promise.allSettled keeps every good asset.
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => Promise.allSettled(
        CORE_ASSETS.map((u) =>
          cache.add(u).catch((e) => console.warn('[admin-sw] precache skipped', u, e && e.message))
        )
      ))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Network-first for admin HTML so we never serve stale data after login;
// stale-while-revalidate for static asset GETs.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith('.css') || url.pathname.endsWith('.js') ||
      url.pathname.startsWith('/assets/') || url.pathname.startsWith('/uploads/')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(event.request);
        const fetched = fetch(event.request).then((resp) => {
          if (resp && resp.status === 200) cache.put(event.request, resp.clone());
          return resp;
        }).catch(() => cached);
        return cached || fetched;
      })
    );
  }
});

// ---------------------------------------------------------------------
// Notification poll — runs every ~30 s when the PWA is in the
// background.  Each unread notification turns into a system toast.
// ---------------------------------------------------------------------
const POLL_URL = '/admin.php?ajax=notif_poll';

// Volume Licensing was removed from the whole site. As a final, device-side
// safety net, NEVER display any notification that mentions volume / business
// pricing — even if an old cached server somehow still sends one. This runs
// on the phone/desktop itself, independent of server-side PHP code.
function __isVolumeNotif(title, body, link) {
  const hay = ((title || '') + ' ' + (body || '') + ' ' + (link || '')).toLowerCase();
  return hay.indexOf('volume') !== -1
      || hay.indexOf('business pricing') !== -1
      || hay.indexOf('view=volume') !== -1;
}
// One place decides how a notification looks/feels, so push and the poll
// fallback behave identically.
//  · distinct vibration per event (Android) — sale = long double buzz,
//    failed payment = triple, chat = short double, install = single long
//  · chat → inline "Reply" box straight on the notification (Android / Windows)
//  · money events stay on screen until tapped
const VIBE = {
  sale: [120, 60, 120, 60, 420], order: [120, 60, 120, 60, 420],
  payment_failed: [300, 100, 300, 100, 300],
  chat: [140, 70, 140], lead: [140, 70, 140],
  install: [450],
};
function leadIdFrom(data) {
  if (data && data.lead_id) return parseInt(data.lead_id, 10) || 0;
  const m = /[?&]autochat=(\d+)/.exec((data && data.link) || '');
  return m ? parseInt(m[1], 10) : 0;
}
function buildOptions(title, body, link, type, id, extra) {
  const leadId = leadIdFrom(Object.assign({ link }, extra || {}));
  const opts = {
    body: body || '',
    icon: '/app-icon.php?size=192',
    badge: '/app-icon.php?size=192',
    tag: 'mv-admin-' + (id || Date.now()),
    renotify: true,
    silent: false,
    vibrate: VIBE[type] || [200, 90, 200],
    requireInteraction: ['sale', 'order', 'payment_failed'].indexOf(type || '') !== -1,
    data: { link: link || '/admin.php', type: type || 'info', id, leadId },
  };
  const canAct = self.Notification && 'actions' in Notification.prototype && (Notification.maxActions || 0) >= 2;
  if (canAct && type === 'chat' && leadId) {
    opts.actions = [
      { action: 'reply', type: 'text', title: 'Reply', placeholder: 'Type your reply…' },
      { action: 'open', title: 'Open chat' },
    ];
  }
  return opts;
}

async function pollForNewNotifications() {
  try {
    const lastTs = await getLastTs();
    const url = POLL_URL + (lastTs ? '&since=' + encodeURIComponent(lastTs) : '');
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) return;
    const data = await res.json();
    if (!data) return;
    // App-icon badge even while the page isn't open.
    try {
      if ('setAppBadge' in navigator && typeof data.unread === 'number') {
        if (data.unread > 0) navigator.setAppBadge(data.unread); else navigator.clearAppBadge();
      }
    } catch (e) {}
    if (!data.items || !data.items.length) return;
    const newest = data.items[0].created_at;
    await setLastTs(newest);
    if (self.Notification && Notification.permission !== 'granted') return;
    // Real push is active on this device → the server already rang it. Only the badge is synced here.
    try { if (await self.registration.pushManager.getSubscription()) return; } catch (e) {}
    for (const n of data.items) {
      if (__isVolumeNotif(n.title, n.body, n.link)) continue; // suppress volume
      await self.registration.showNotification(n.title, buildOptions(n.title, n.body, n.link, n.type, n.id));
    }
  } catch (e) { /* silent — admin will retry next interval */ }
}

self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'maventech-admin-poll') {
    event.waitUntil(pollForNewNotifications());
  }
});

// Tab → SW polling fallback (when periodicsync isn't available).
self.addEventListener('message', (event) => {
  if (event.data === 'admin-poll') {
    event.waitUntil(pollForNewNotifications());
  }
});

// ---------------------------------------------------------------------
// Real Web Push (VAPID) — server pushes the instant a new order/lead/chat
// arrives, so a fully-closed/backgrounded PWA on a phone still rings.
// ---------------------------------------------------------------------
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) {
    try { data = { title: event.data.text() }; } catch (e2) { data = {}; }
  }
  const title = data.title || 'New activity';
  // Device-side kill-switch: drop volume/business-pricing pushes entirely.
  if (__isVolumeNotif(title, data.body, data.link)) {
    event.waitUntil(pollForNewNotifications().catch(() => {}));
    return;
  }
  const options = buildOptions(title, data.body, data.link, data.type, data.id, data);
  event.waitUntil(
    self.registration.showNotification(title, options).then(() => {
      // Keep the launcher badge in sync when a push lands.
      return pollForNewNotifications().catch(() => {});
    })
  );
});

// Browser rotated the subscription — silently re-subscribe with the same key.
self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil((async () => {
    try {
      const res = await fetch('/admin.php?ajax=vapid_pubkey', { credentials: 'include' });
      const j = await res.json();
      if (!j || !j.key) return;
      const appKey = urlBase64ToUint8Array(j.key);
      const sub = await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: appKey });
      await fetch('/admin.php?ajax=push_subscribe', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub),
      });
    } catch (e) { /* silent */ }
  })());
});

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

// Click → inline reply (Android/Windows "Reply" box), or open the right admin
// page. If the admin app is already open we hand the link to it (no reload).
async function sendQuickReply(leadId, text) {
  const res = await fetch('/ajax/chat-admin.php', {
    method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'send', lead_id: leadId, message: text }),
  });
  const j = await res.json().catch(() => null);
  return !!(j && j.ok);
}
self.addEventListener('notificationclick', (event) => {
  const d = event.notification.data || {};
  let link = d.link || '/admin.php';
  event.notification.close();
  if (event.action === 'reply') {
    const text = (event.reply || '').trim();
    if (!text || !d.leadId) return;
    event.waitUntil(sendQuickReply(d.leadId, text).then((ok) => self.registration.showNotification(
      ok ? 'Reply sent ✓' : 'Reply not sent',
      { body: ok ? ('"' + text.slice(0, 80) + '"') : 'Tap to open the chat and send it there.',
        icon: '/app-icon.php?size=192', badge: '/app-icon.php?size=192', tag: 'mv-reply-' + d.leadId,
        silent: ok, vibrate: ok ? [] : [200, 80, 200], data: { link: link + '&reply=1', leadId: d.leadId, type: 'chat' } }
    )).catch(() => {}));
    return;
  }
  if (d.type === 'chat' && d.leadId && link.indexOf('reply=1') === -1) link += (link.indexOf('?') === -1 ? '?' : '&') + 'reply=1';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      for (const w of wins) {
        if (w.url.includes('/admin.php')) {
          w.focus();
          // Let the open page handle it: opens the chat window in place when it can.
          w.postMessage({ type: 'mv-open', link, leadId: d.leadId || 0 });
          return;
        }
      }
      return self.clients.openWindow(link);
    })
  );
});

// Tiny IDB helper to remember the most-recent notification timestamp.
function idb() {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('mv-admin', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('kv');
    open.onsuccess = () => resolve(open.result);
    open.onerror   = () => reject(open.error);
  });
}
async function getLastTs() {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('kv', 'readonly').objectStore('kv').get('lastTs');
    tx.onsuccess = () => resolve(tx.result || '');
    tx.onerror   = () => resolve('');
  });
}
async function setLastTs(ts) {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('kv', 'readwrite').objectStore('kv');
    tx.put(ts, 'lastTs');
    tx.transaction.oncomplete = resolve;
    tx.transaction.onerror    = resolve;
  });
}
