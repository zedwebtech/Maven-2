<?php
// Download endpoint for the beginner-friendly PPC Master Plan workbook.
$f = __DIR__ . '/Maventech_PPC_Master_Plan.xlsx';
if (!is_file($f)) { http_response_code(404); exit('not found'); }
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Maventech_PPC_Master_Plan.xlsx"');
header('Content-Length: ' . filesize($f));
header('Cache-Control: no-store');
readfile($f);
