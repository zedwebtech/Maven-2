<?php
/**
 * /privacy  →  canonical Privacy Policy trust page.
 *
 * Agent-readiness "trust anchor pages" audits probe /privacy directly and
 * expect a real page (HTTP 200, >=500 chars) — not a redirect or 404. We serve
 * the existing, fully-maintained Privacy Policy content (DB page slug
 * "privacy-policy", ~3.4k chars) IN PLACE at /privacy so the endpoint returns
 * 200 with no redirect hop, while /privacy-policy keeps working as before.
 *
 * Force the canonical to the clean /privacy URL so page.php does not reflect
 * the internal ?slug= param into indexable markup (single canonical trust URL).
 */
require_once __DIR__ . '/includes/functions.php';
$canonicalUrl = site_url() . '/privacy';
$_GET['slug'] = 'privacy-policy';
require __DIR__ . '/page.php';
