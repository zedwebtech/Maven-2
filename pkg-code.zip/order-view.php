<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/email.php';
require_once __DIR__ . '/includes/recovery.php';
require_once __DIR__ . '/includes/regions.php';
ensure_admin();
$admin = require_admin();
$pdo = db();

$id = (int)($_GET['id'] ?? 0);
$o = $pdo->prepare('SELECT * FROM orders WHERE id=?');
$o->execute([$id]); $o = $o->fetch();
if (!$o) { http_response_code(404); die('Order not found'); }

// Resend or status update
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (($_POST['action'] ?? '')==='resend_email') {
        // RESEND EMAIL — rebuilt.
        // ROOT CAUSE of the old bug: this called fulfill_order($id, true), whose
        // admin override FORCE-FLIPPED any non-paid order (incl. REFUNDED) back
        // to status='paid' and could consume a fresh license key — and it always
        // reported success even when SMTP sent nothing. Now we simply RE-SEND the
        // exact email the customer last received (same subject + body) to the
        // current or admin-supplied address. Pure resend: never changes the order
        // status, never burns a key. Success is confirmed by an actual new
        // email_outbox row (send_email always writes one), so the message is honest.
        $resendTo = trim((string)($_POST['resend_email_to'] ?? ''));
        $target   = (string)$o['email'];
        if ($resendTo !== '' && filter_var($resendTo, FILTER_VALIDATE_EMAIL)) {
            $target = $resendTo;
            if (strtolower($resendTo) !== strtolower((string)$o['email'])) {
                $pdo->prepare('UPDATE orders SET email=? WHERE id=?')->execute([$resendTo, $id]);
                $o['email'] = $resendTo;
            }
        }
        $maxBefore = (int)$pdo->query('SELECT COALESCE(MAX(id),0) FROM email_outbox WHERE order_id='.(int)$id)->fetchColumn();
        $errText = '';
        $lastQ = $pdo->prepare("SELECT * FROM email_outbox WHERE order_id=? AND recipient IS NOT NULL AND recipient<>'' ORDER BY created_at DESC LIMIT 1");
        $lastQ->execute([$id]);
        $last = $lastQ->fetch(PDO::FETCH_ASSOC);
        if ($last && trim((string)$last['html']) !== '') {
            try {
                send_email($target, (string)$last['subject'], (string)$last['html'], $id, (string)($last['template_code'] ?? 'order_delivery'), 0, [], true);
            } catch (Throwable $e) { $errText = $e->getMessage(); @error_log('[resend_email] '.$errText); }
        } else {
            // No prior customer email on record → generate the right one for the
            // order's current state, WITHOUT disturbing a refunded/voided status.
            $snapS = (string)$o['status']; $snapP = (string)($o['payment_status'] ?? '');
            try {
                if ($snapS === 'paid' || $snapP === 'succeeded') {
                    $pdo->prepare('UPDATE orders SET fulfilled=0 WHERE id=?')->execute([$id]);
                    fulfill_order($id, true);
                    if (in_array($snapS, ['refunded','voided','declined','cancelled'], true)) {
                        $pdo->prepare('UPDATE orders SET status=?, payment_status=? WHERE id=?')->execute([$snapS, $snapP, $id]);
                    }
                } else {
                    $fresh = $pdo->prepare('SELECT * FROM orders WHERE id=?'); $fresh->execute([$id]);
                    mv_send_abandoned_cart_email($fresh->fetch(PDO::FETCH_ASSOC) ?: $o);
                }
            } catch (Throwable $e) { $errText = $e->getMessage(); @error_log('[resend_email fallback] '.$errText); }
        }
        // Honest outcome based on the row(s) actually created (live SMTP sends
        // immediately, so the row is already 'sent' or 'failed').
        $newQ = $pdo->prepare('SELECT status, note FROM email_outbox WHERE order_id=? AND id>? AND recipient=? ORDER BY id DESC LIMIT 1');
        $newQ->execute([$id, $maxBefore, $target]);
        $nr = $newQ->fetch(PDO::FETCH_ASSOC);
        if ($errText !== '') {
            $msg = 'Email could NOT be sent to '.$target.' — '.$errText;
        } elseif (!$nr) {
            $msg = 'Email could NOT be sent — check your SMTP settings in Email Activity';
        } else {
            $nst = strtolower((string)$nr['status']);
            if (in_array($nst, ['failed','bounced','error'], true)) {
                $msg = 'Email could NOT be delivered to '.$target.(!empty($nr['note']) ? ' — '.$nr['note'] : ' — check the address or your SMTP settings');
            } elseif (in_array($nst, ['sent','delivered'], true)) {
                $msg = 'Email sent to '.$target.' ✓';
            } else {
                $msg = 'Email queued for '.$target.' — it will go out on the next send cycle';
            }
        }
        header('Location: order-view.php?id='.$id.'&msg='.rawurlencode($msg)); exit;
    }
    if (($_POST['action'] ?? '')==='resend_one') {
        // Resend ONE specific email from the thread (by its outbox id). Two modes:
        //  • "Resend"          → same recipient, subject and body as the original.
        //  • "Edit & Resend"   → optional corrected recipient / subject / body.
        // Never touches order status or license keys.
        $eid = (int)($_POST['email_id'] ?? 0);
        $resendTo = trim((string)($_POST['resend_email_to'] ?? ''));
        $editSubject = array_key_exists('resend_subject', $_POST) ? trim((string)$_POST['resend_subject']) : null;
        $editBody    = array_key_exists('resend_body', $_POST) ? (string)$_POST['resend_body'] : null;
        $src = $pdo->prepare('SELECT * FROM email_outbox WHERE id=? AND order_id=?');
        $src->execute([$eid, $id]);
        $row = $src->fetch(PDO::FETCH_ASSOC);
        $msg = 'Email could NOT be resent — original message not found';
        if ($row) {
            $target = (string)$row['recipient'];
            if ($resendTo !== '' && filter_var($resendTo, FILTER_VALIDATE_EMAIL)) {
                $target = $resendTo;
                // If the corrected address is the order's customer, persist it so
                // future emails go to the right place too.
                if (strtolower($resendTo) !== strtolower((string)$o['email'])
                    && strtolower((string)$row['recipient']) === strtolower((string)$o['email'])) {
                    $pdo->prepare('UPDATE orders SET email=? WHERE id=?')->execute([$resendTo, $id]);
                    $o['email'] = $resendTo;
                }
            }
            $subject = ($editSubject !== null && $editSubject !== '') ? $editSubject : (string)$row['subject'];
            // Body: if the admin edited it as plain text, wrap line breaks into HTML.
            if ($editBody !== null && trim($editBody) !== '') {
                $looksHtml = stripos($editBody, '<') !== false && stripos($editBody, '>') !== false;
                $body = $looksHtml ? $editBody : nl2br(htmlspecialchars($editBody, ENT_QUOTES, 'UTF-8'));
            } else {
                $body = trim((string)$row['html']) !== '' ? (string)$row['html'] : '<p>Re-sending your previous email.</p>';
            }
            $maxBefore = (int)$pdo->query('SELECT COALESCE(MAX(id),0) FROM email_outbox WHERE order_id='.(int)$id)->fetchColumn();
            $errText = '';
            try {
                send_email($target, $subject, $body, $id, (string)($row['template_code'] ?? 'order_delivery'), 0, [], true);
            } catch (Throwable $e) { $errText = $e->getMessage(); @error_log('[resend_one] '.$errText); }
            // Report the ACTUAL outcome. On a live server with SMTP configured,
            // send_email() queues then sends immediately, so the new row is
            // already 'sent' or 'failed' — never claim success on a failure.
            $new = $pdo->prepare('SELECT status, note FROM email_outbox WHERE order_id=? AND id>? AND recipient=? ORDER BY id DESC LIMIT 1');
            $new->execute([$id, $maxBefore, $target]);
            $nr = $new->fetch(PDO::FETCH_ASSOC);
            if ($errText !== '') {
                $msg = 'Email could NOT be resent to '.$target.' — '.$errText;
            } elseif (!$nr) {
                $msg = 'Email could NOT be resent — check your SMTP settings in Email Activity';
            } else {
                $nst = strtolower((string)$nr['status']);
                if (in_array($nst, ['failed','bounced','error'], true)) {
                    $msg = 'Email could NOT be delivered to '.$target.(!empty($nr['note']) ? ' — '.$nr['note'] : ' — check the address or your SMTP settings');
                } elseif (in_array($nst, ['sent','delivered'], true)) {
                    $msg = 'Email sent to '.$target.' ✓';
                } else {
                    $msg = 'Email queued for '.$target.' — it will go out on the next send cycle';
                }
            }
        }
        header('Location: order-view.php?id='.$id.'&msg='.rawurlencode($msg).'#thread'); exit;
    }
    if (($_POST['action'] ?? '')==='update_status') {
        // Lifecycle is limited to the 4 states admins actually use: paid,
        // refunded, voided, declined. payment_status is kept coherent so the
        // badges + gateway log read correctly.
        $ns = strtolower(trim((string)($_POST['status'] ?? '')));
        $payMap = ['paid'=>'succeeded','refunded'=>'refunded','voided'=>'voided','declined'=>'failed'];
        if (!isset($payMap[$ns])) { header('Location: order-view.php?id='.$id); exit; }
        $pdo->prepare('UPDATE orders SET status=?, payment_status=? WHERE id=?')->execute([$ns, $payMap[$ns], $id]);
        if ($ns==='paid') fulfill_order($id);
        header('Location: order-view.php?id='.$id.'&msg=Status+updated'); exit;
    }
    if (($_POST['action'] ?? '')==='admin_cancel_order') {
        // Cancel + invalidate the retry link (Checkout Hardening patch).
        $pdo->prepare('UPDATE orders SET admin_cancelled=1, status="cancelled", payment_status=COALESCE(NULLIF(payment_status,"succeeded"),"cancelled") WHERE id=?')->execute([$id]);
        try {
            if (function_exists('admin_notify')) {
                admin_notify('order',
                    'Order cancelled by admin — ' . (string)$o['order_number'],
                    'Retry link invalidated. No key was released.',
                    '/order-view.php?id=' . $id);
            }
        } catch (Throwable $e) { /* best-effort */ }
        header('Location: order-view.php?id='.$id.'&msg=Order+cancelled+%E2%80%93+retry+link+invalidated'); exit;
    }
    if (($_POST['action'] ?? '')==='deliver_keys') {
        // Admin manually delivers a license KEY and/or a PRE-ACTIVATED
        // download link (license embedded in the URL) for a (backordered)
        // order, optionally changes the customer email, then re-sends the
        // real key-delivery email with exactly what was ticked.
        $newEmail = trim((string)($_POST['cust_email'] ?? ''));
        if ($newEmail !== '' && filter_var($newEmail, FILTER_VALIDATE_EMAIL) && $newEmail !== $o['email']) {
            $pdo->prepare('UPDATE orders SET email=? WHERE id=?')->execute([$newEmail, $id]);
            $o['email'] = $newEmail;
        }
        $sendKey  = !empty($_POST['send_key']);
        $sendLink = !empty($_POST['send_link']);
        if (!$sendKey && !$sendLink) {
            header('Location: order-view.php?id='.$id.'&msg='.urlencode('Tick at least one — license key and/or pre-activated download link')); exit;
        }
        $dlUrl    = $sendLink ? trim((string)($_POST['download_url'] ?? '')) : '';
        if ($sendLink && !filter_var($dlUrl, FILTER_VALIDATE_URL)) {
            header('Location: order-view.php?id='.$id.'&msg='.urlencode('Enter a valid pre-activated download URL (include https://)')); exit;
        }
        if ($sendKey) {
            $oiList = $pdo->prepare('SELECT id, product_slug FROM order_items WHERE order_id=?');
            $oiList->execute([$id]);
            foreach ($oiList->fetchAll() as $oi) {
                $k = trim((string)($_POST['key_'.$oi['id']] ?? ''));
                if ($k === '') continue;
                $ex = $pdo->prepare('SELECT id FROM license_keys WHERE order_id=? AND product_slug=? LIMIT 1');
                $ex->execute([$id, $oi['product_slug']]);
                $exId = $ex->fetchColumn();
                if ($exId) {
                    $pdo->prepare('UPDATE license_keys SET license_key=?, status="sold", assigned_at=NOW() WHERE id=?')->execute([$k, $exId]);
                } else {
                    $pdo->prepare('INSERT INTO license_keys (product_slug, license_key, status, order_id, region, assigned_at) VALUES (?,?,"sold",?,?,NOW())')
                        ->execute([$oi['product_slug'], $k, $id, $o['region'] ?: 'US']);
                }
            }
        }
        $pdo->prepare('UPDATE orders SET fulfilled=0 WHERE id=?')->execute([$id]);
        fulfill_order($id, true, $dlUrl, $sendKey);
        $what = ($sendKey && $dlUrl !== '') ? 'License key + pre-activated download link sent'
              : ($dlUrl !== '' ? 'Pre-activated download link sent (license key hidden)' : 'License key sent');
        header('Location: order-view.php?id='.$id.'&msg='.urlencode($what.' to '.$o['email'])); exit;
    }
}

$items = $pdo->prepare('SELECT oi.*, p.image, p.category, p.platform
  FROM order_items oi LEFT JOIN products p ON p.slug=oi.product_slug WHERE oi.order_id=?');
$items->execute([$id]); $items = $items->fetchAll();

$keys = $pdo->prepare('SELECT lk.*, oi.product_slug, oi.name AS product_name
  FROM license_keys lk JOIN order_items oi ON oi.product_slug=lk.product_slug AND oi.order_id=lk.order_id
  WHERE lk.order_id=?');
$keys->execute([$id]); $keys = $keys->fetchAll();
$keyMap = []; foreach ($keys as $k) $keyMap[$k['product_slug']][] = $k;

$em = $pdo->prepare('SELECT * FROM email_outbox WHERE order_id=? ORDER BY created_at DESC');
$em->execute([$id]); $emRows = $em->fetchAll();
$lastEmail = $emRows[0] ?? null;
// "Preview email exactly as customer received it" must show an email that was
// actually sent TO THE CUSTOMER — not the internal Payment-Ops / failed-payment
// alert (which is addressed to the ops inbox). Pick the most recent outbox row
// whose recipient is the order's own email.
$custEmailLc = strtolower(trim((string)($o['email'] ?? '')));
$lastCustomerEmail = null;
if ($custEmailLc !== '') {
    foreach ($emRows as $__r) {
        if (strtolower(trim((string)($__r['recipient'] ?? ''))) === $custEmailLc) { $lastCustomerEmail = $__r; break; }
    }
}

$tl = json_decode($o['timeline'] ?? 'null', true) ?: [];

// ---- Clean, honest email status for THIS customer -------------------------
// SMTP sends mark status='sent' but leave delivered_at NULL, so we treat any
// 'sent'/'delivered' customer email as Delivered (using delivered_at or the
// send time). Opens come from the tracking pixel and are SCORED by
// includes/email-tracking.php: automated fetches (Gmail prefetch bot, Apple
// Mail privacy proxy, security scanners) never count — only a real open by the
// customer turns anything green.
require_once __DIR__ . '/includes/order-open-state.php';
$openState = mv_order_open_state($o, $emRows);
$custSent   = $openState['cust_sent'];
$custSentAt = $openState['cust_sent_at'];
// Hydrate the timeline from the honest status so "Email Delivered" no longer
// shows "pending" forever just because SMTP didn't write delivered_at.
if ($custSent) {
    $tl['email_sent']      = $tl['email_sent']      ?? $custSentAt;
    $tl['email_delivered'] = $tl['email_delivered'] ?? $custSentAt;
}
// "Customer Opened Email" tracks the LATEST customer email only: sending a new
// key email resets it to gray until the customer actually opens THAT email.
unset($tl['email_opened']);
if ($openState['latest_opened']) $tl['email_opened'] = $openState['latest_opened_at'];

$pageTitle = 'Order #'.$o['order_number'].' · Admin';
$adminActive = 'orders';
include __DIR__ . '/includes/admin-shell.php';
?>
<style>
/* Per-email open log under the "Customer Opened Email" timeline node:
   green = the customer really opened it · gray = delivered, not opened yet */
.tl-openlog{list-style:none;margin:6px 0 0;padding:0;}
.tl-openlog li{display:flex;flex-wrap:wrap;align-items:center;gap:2px 6px;font-size:11px;line-height:1.5;padding:4px 8px;margin-top:4px;border-radius:7px;transition:background-color .3s,border-color .3s;}
.tl-openlog li.is-open{background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.25);}
.tl-openlog li.is-open i{color:#10b981;}
.tl-openlog li.is-unopened{background:rgba(148,163,184,.10);border:1px solid rgba(148,163,184,.35);}
.tl-openlog li.is-unopened i{color:#94a3b8;}
.tl-openlog li i{flex:0 0 auto;font-size:11px;}
.tl-openlog-subj{flex:1 1 0;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;color:#047857;}
.tl-openlog li.is-unopened .tl-openlog-subj{color:#64748b;}
[data-bs-theme="dark"] .tl-openlog li.is-open .tl-openlog-subj{color:#6ee7b7;}
.tl-openlog-meta{flex:1 1 100%;color:#64748b;font-weight:600;white-space:normal;}
.tl-openlog-auto{display:inline-block;color:#94a3b8;font-weight:500;}
.tl-live{font-size:10px;color:#64748b;font-weight:600;display:inline-flex;align-items:center;gap:4px;}
.tl-live .dot{width:6px;height:6px;border-radius:50%;background:#10b981;animation:tlPulse 1.6s ease-in-out infinite;}
@keyframes tlPulse{0%,100%{opacity:.35}50%{opacity:1}}

/* Email Thread — stack action buttons below the message on small screens so
   they stop crowding/overlapping the subject line */
@media (max-width: 575.98px){
  .thread-row{flex-wrap:wrap;}
  .thread-row > div:last-child{
    flex:1 1 100% !important; width:100%;
    flex-direction:row !important; flex-wrap:wrap !important;
    align-items:stretch !important; justify-content:flex-start !important;
    gap:6px !important; margin-top:8px; padding-top:8px;
    border-top:1px dashed var(--border);
  }
  .thread-row > div:last-child > a.btn,
  .thread-row > div:last-child > button.btn,
  .thread-row > div:last-child > form{flex:1 1 calc(50% - 6px); margin:0;}
  .thread-row > div:last-child .btn{width:100% !important;}
}
</style>


<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <div>
    <a href="javascript:void(0)" onclick="if(document.referrer && document.referrer.indexOf(location.host) !== -1){history.back();} else {location.href='admin.php?tab=orders';}" class="text-decoration-none small" data-testid="back-btn"><i class="bi bi-arrow-left"></i> Back</a>
    <h1 class="h4 fw-bold mb-0 mt-1" data-testid="order-title">Order #<?= esc($o['order_number']) ?>
      <?php $oMode = $o['gw_mode'] ?? 'live'; if ($oMode === 'test'): ?>
        <span class="badge ms-2" data-testid="order-mode-badge" style="background:linear-gradient(135deg,#f59e0b,#ea580c);color:#fff;font-size:11px;letter-spacing:1.2px;vertical-align:middle;"><i class="bi bi-eyedropper me-1"></i>TEST</span>
      <?php else: ?>
        <span class="badge ms-2" data-testid="order-mode-badge" style="background:rgba(16,185,129,.12);color:#10b981;font-size:11px;letter-spacing:1.2px;vertical-align:middle;border:1px solid rgba(16,185,129,.35);"><i class="bi bi-broadcast me-1"></i>LIVE</span>
      <?php endif; ?>
    </h1>
    <small class="text-muted">Placed <?= esc(date('M j, Y H:i', strtotime($o['created_at']))) ?> · Region <?= esc($o['region']) ?></small>
  </div>
  <div class="d-flex gap-2">
    <a href="dispute-evidence.php?id=<?= (int)$id ?>" class="btn btn-dark btn-sm doc-preview-btn" data-doc-title="Proof of Fulfillment — Order #<?= esc($o['order_number']) ?>" data-testid="dispute-evidence-btn" title="Preview the proof-of-fulfillment PDF — session proof, invoice &amp; delivery log — then download if you need it">
      <i class="bi bi-shield-fill-check me-1"></i> Proof of Fulfillment
    </a>
    <a href="email-thread-proof.php?id=<?= (int)$id ?>" class="btn btn-soft-green btn-sm doc-preview-btn" data-doc-title="Email Thread Proof — Order #<?= esc($o['order_number']) ?>" data-testid="email-thread-proof-btn" title="Preview a PDF of every email this customer received — subject, delivered/opened status &amp; content preview, in thread order">
      <i class="bi bi-envelope-paper-fill me-1"></i> Email Thread Proof
    </a>
    <a href="order-doc.php?id=<?= (int)$id ?>&doc=communication" class="btn btn-soft-blue btn-sm doc-preview-btn" data-doc-title="Customer Communication — Order #<?= esc($o['order_number']) ?>" data-testid="customer-communication-btn" title="Preview a PDF of every email ever sent to this customer's address — license delivery, order confirmation, activation check-ins, newsletters — with status, opens and dates">
      <i class="bi bi-chat-left-text-fill me-1"></i> Customer Communication
    </a>
    <a href="order-doc.php?id=<?= (int)$id ?>&doc=invoice" class="btn btn-soft-gray btn-sm doc-preview-btn" data-doc-title="Invoice — Order #<?= esc($o['order_number']) ?>" data-testid="invoice-btn" title="Preview the invoice issued to the customer for this order">
      <i class="bi bi-receipt me-1"></i> Invoice
    </a>
    <a href="order-doc.php?id=<?= (int)$id ?>&doc=email-logs" class="btn btn-sm doc-preview-btn" style="background:#ede9fe;color:#5b21b6;border:1px solid #ddd6fe;" data-doc-title="Email Logs — Order #<?= esc($o['order_number']) ?>" data-testid="email-logs-btn" title="Preview the email tracking PDF — recipient, status, tracking ID and every open event with IP, location, ISP, device and mail client (dispute evidence)">
      <i class="bi bi-activity me-1"></i> Email Logs
    </a>
    <a href="order-docs.php?id=<?= (int)$id ?>" class="btn btn-primary btn-sm" data-testid="download-all-docs-btn" title="One click — downloads a ZIP with Proof of Fulfillment, Email Thread Proof, Invoice, Receipt, Customer Communication and Email Logs for this customer">
      <i class="bi bi-download me-1"></i> Download all documents
    </a>
    <form method="post" class="d-inline d-flex gap-1 align-items-center">
      <input type="hidden" name="action" value="resend_email">
      <input type="email" name="resend_email_to" class="form-control form-control-sm" placeholder="Send to…" style="width:190px;" value="<?= esc($o['email']) ?>" data-testid="resend-email-to" title="Leave as-is to resend to the customer, or type a different address">
      <button class="btn btn-soft-blue btn-sm" data-testid="resend-email-btn"><i class="bi bi-envelope me-1"></i> Resend Email</button>
    </form>
    <form method="post" class="d-inline">
      <input type="hidden" name="action" value="update_status">
      <select name="status" class="form-select form-select-sm" onchange="this.form.submit()" style="width:130px;" data-testid="order-status-select">
        <?php
          $stRaw = strtolower((string)($o['status'] ?? '')); $psRaw = strtolower((string)($o['payment_status'] ?? ''));
          if      ($stRaw==='refunded') $stSel='refunded';
          elseif  ($stRaw==='voided')   $stSel='voided';
          elseif  ($stRaw==='declined') $stSel='declined';
          elseif  ($stRaw==='paid' || $stRaw==='delivered' || $psRaw==='succeeded') $stSel='paid';
          else    $stSel='declined';
          foreach (['paid'=>'Paid','refunded'=>'Refunded','voided'=>'Voided','declined'=>'Declined'] as $sv=>$sl): ?>
          <option value="<?= $sv ?>" <?= $stSel===$sv?'selected':'' ?>><?= $sl ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
</div>

<?php
// ---------------------------------------------------------------------------
// Payment status panel — surfaces the granular gateway state introduced by
// the Checkout Payment & License Delivery Hardening patch: attempts,
// gateway code + human message, admin_cancelled flag, retry link.
// ---------------------------------------------------------------------------
$ps       = (string)($o['payment_status'] ?? '');
$psAttempt = (int)($o['payment_attempts'] ?? 0);
$psCode   = (string)($o['payment_error_code'] ?? '');
$psMsg    = (string)($o['payment_error_message'] ?? '');
$adminCancelled = (int)($o['admin_cancelled'] ?? 0) === 1;
$recoverySent = (int)($o['recovery_email_sent'] ?? 0) === 1;
if ($ps !== '' || $psAttempt > 0 || $adminCancelled || $recoverySent):
  require_once __DIR__ . '/includes/recovery.php';
  $retryLink = mv_build_resume_link($o);
  $psColor = ['succeeded'=>['#065f46','#d1fae5'],'failed'=>['#7f1d1d','#fee2e2'],'pending'=>['#78350f','#fef3c7'],'abandoned'=>['#78350f','#fef3c7'],'cancelled'=>['#334155','#e2e8f0']][$ps] ?? ['#334155','#e2e8f0'];
?>
<div class="card mb-3" data-testid="admin-payment-status-panel" style="border-radius:12px;border:1px solid #e2e8f0;">
  <div class="card-body">
    <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
      <span style="font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#64748b;font-weight:700;">Payment status</span>
      <?php if ($ps !== ''): ?>
        <span class="badge" style="background:<?= $psColor[1] ?>;color:<?= $psColor[0] ?>;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;" data-testid="payment-status-badge"><?= strtoupper(esc($ps)) ?></span>
      <?php endif; ?>
      <?php if (($o['status'] ?? '') === 'refunded'): ?>
        <span class="badge" style="background:#dbeafe;color:#1e40af;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;" data-testid="order-refunded-badge"><i class="bi bi-arrow-counterclockwise me-1"></i>REFUNDED</span>
      <?php elseif (($o['status'] ?? '') === 'voided'): ?>
        <span class="badge" style="background:#fef3c7;color:#92400e;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;" data-testid="order-voided-badge"><i class="bi bi-slash-circle me-1"></i>VOIDED</span>
      <?php elseif (($o['status'] ?? '') === 'declined'): ?>
        <span class="badge" style="background:#fee2e2;color:#991b1b;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;" data-testid="order-declined-badge"><i class="bi bi-x-octagon me-1"></i>DECLINED</span>
      <?php endif; ?>
      <?php if ($psAttempt > 0): ?>
        <span class="text-muted small">Attempts: <strong data-testid="payment-attempts"><?= $psAttempt ?></strong></span>
      <?php endif; ?>
      <?php if ($adminCancelled): ?>
        <span class="badge" style="background:#fee2e2;color:#7f1d1d;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;" data-testid="admin-cancelled-badge">RETRY LINK INVALIDATED</span>
      <?php endif; ?>
      <?php if ($recoverySent): ?>
        <span class="badge" style="background:#dbeafe;color:#1e3a8a;font-weight:700;font-size:12px;padding:5px 10px;border-radius:8px;">Recovery email sent</span>
      <?php endif; ?>
    </div>
    <?php if ($psMsg !== ''): ?>
      <div class="mb-2" style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 12px;color:#7f1d1d;font-size:13px;line-height:1.5;">
        <strong>Last decline:</strong> <span data-testid="payment-error-message"><?= esc($psMsg) ?></span>
        <?php if ($psCode !== ''): ?><span class="text-muted"> · <code><?= esc($psCode) ?></code></span><?php endif; ?>
      </div>
    <?php endif; ?>
    <?php if (!$adminCancelled && ($o['status'] ?? '') !== 'paid'): ?>
      <div class="small text-muted">
        Retry link (never expires — cancel to invalidate):
        <a href="<?= esc($retryLink) ?>" target="_blank" rel="noopener" data-testid="admin-retry-link" style="word-break:break-all;"><?= esc($retryLink) ?></a>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if (!empty($_GET['msg'])): ?><div class="alert alert-success py-2 small"><?= esc($_GET['msg']) ?></div><?php endif; ?>

<?php if (($o['delivery_status'] ?? 'delivered') === 'pending' && in_array((string)($o['status'] ?? ''), ['paid', 'delivered'], true)): ?>
  <div class="alert alert-warning d-flex align-items-center gap-2 py-2" data-testid="order-pending-banner">
    <i class="bi bi-clock-history fs-5"></i>
    <div class="small">
      <strong>Delivery pending.</strong> At least one item had no license key in stock, so the customer's confirmation email shows that item as "delivered within 30 min – 1 hour" (any in-stock keys were sent right away). Enter the missing key below to send the updated key-delivery email to <strong><?= esc($o['email']) ?></strong>.
    </div>
  </div>
<?php endif; ?>

<?php
// ---- Payment Gateway Log: every raw charge attempt (bank vs our-side) ----
$gwLogs = [];
$custEmail = strtolower(trim((string)($o['email'] ?? '')));
try {
    // All charge attempts by THIS CUSTOMER (matched on their email across every
    // order they've placed) — newest first — so you see their full payment
    // history, not just this one order.
    $gs = $pdo->prepare("SELECT t.id AS tid, t.gateway, t.transaction_id, t.amount, t.currency, t.status, t.raw_response, t.created_at, o.order_number, o.id AS oid
                           FROM transaction_logs t JOIN orders o ON o.id = t.order_id
                          WHERE LOWER(o.email) = ? ORDER BY t.created_at DESC, t.id DESC");
    $gs->execute([$custEmail]);
    $gwLogs = $gs->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $gwLogs = []; }

// Card actually used on the LATEST direct-gateway attempt of THIS order.
// Older builds logged a repeat attempt under the PREVIOUS card (stale order row
// fallback) while orders.card_* was refreshed to the new card right after the
// attempt — so for the newest declined row, the card on file IS the card used.
// Display-only correction for rows written before the fix; new rows carry the
// right card themselves.
$__lastTid = 0; $__cardOnFile = ['brand' => '', 'last4' => ''];
try {
    $__lt = $pdo->prepare("SELECT id, status, gateway FROM transaction_logs WHERE order_id = ? ORDER BY id DESC LIMIT 1");
    $__lt->execute([(int)$o['id']]);
    $__ltRow = $__lt->fetch(PDO::FETCH_ASSOC) ?: [];
    if ($__ltRow && (string)($o['payment_method'] ?? 'card') === 'card'
        && !in_array(strtolower((string)($__ltRow['gateway'] ?? '')), ['stripe', 'paypal'], true)
        && !in_array(strtolower((string)($__ltRow['status'] ?? '')), ['succeeded', 'success', 'paid', 'captured', 'completed', 'test'], true)
        && trim((string)($o['card_last4'] ?? '')) !== '') {
        $__lastTid = (int)$__ltRow['id'];
        $__cardOnFile = ['brand' => (string)($o['card_brand'] ?? ''), 'last4' => (string)($o['card_last4'] ?? '')];
    }
} catch (Throwable $e) {}
$__attemptCard = function (array $raw, int $tid) use ($__lastTid, $__cardOnFile): array {
    $brand = trim((string)($raw['card_brand'] ?? '')); $last4 = preg_replace('/\D/', '', (string)($raw['card_last4'] ?? ''));
    if ($tid > 0 && $tid === $__lastTid && $__cardOnFile['last4'] !== '' && $last4 !== $__cardOnFile['last4']) {
        return ['brand' => $__cardOnFile['brand'] ?: $brand, 'last4' => $__cardOnFile['last4']];
    }
    return ['brand' => $brand, 'last4' => $last4];
};

// De-duplicate LEGACY rows: older code sometimes wrote TWO transaction_logs for
// a single declined attempt (a bare "Failed" + a detailed "Bank declined"), so
// orders placed before the fix still show the decline twice. Collapse rows that
// share the same order + gateway transaction ref, keeping the most informative
// one (the row whose raw_response carries the real bank reason).
if ($gwLogs) {
    $byRef = []; $deduped = [];
    foreach ($gwLogs as $log) {
        $ref = trim((string)($log['transaction_id'] ?? ''));
        $st  = strtolower((string)($log['status'] ?? ''));
        if ($ref === '' || $st === 'succeeded') { $deduped[] = $log; continue; }
        $key = (int)($log['oid'] ?? 0) . '|' . $ref;
        if (!isset($byRef[$key])) {
            $byRef[$key] = count($deduped);
            $deduped[] = $log;
        } else {
            $ix = $byRef[$key];
            if (strlen(trim((string)($log['raw_response'] ?? ''))) > strlen(trim((string)($deduped[$ix]['raw_response'] ?? '')))) {
                $deduped[$ix] = $log; // richer raw = the real "Bank declined" detail
            }
        }
    }
    $gwLogs = $deduped;
}

// Plain-English interpreter for a raw gateway response.
$mvGwExplain = function(array $log): array {
    $raw = json_decode((string)($log['raw_response'] ?? ''), true) ?: [];
    $status = strtolower((string)($log['status'] ?? ''));
    // Pull the gateway's own message/code across NMI / Authorize.Net / Stripe shapes.
    $code = (string)($raw['response_code'] ?? $raw['responseCode'] ?? $raw['code'] ?? $raw['error_code'] ?? '');
    $msg  = trim((string)($raw['responsetext'] ?? $raw['response_text'] ?? $raw['message'] ?? $raw['error_message'] ?? ($raw['errors'][0]['errorText'] ?? '')));
    $refid = (string)($raw['transactionid'] ?? $raw['refid'] ?? $log['transaction_id'] ?? '');
    if ($status === 'succeeded' || $code === '100' || $code === '1') {
        return ['tone'=>'success', 'who'=>'Approved', 'text'=>'Payment approved by the bank' . ($refid ? ' (ref ' . $refid . ')' : '') . '.'];
    }
    $m = strtolower($msg);
    // Our-side / config causes vs genuine bank declines.
    if ($code === 'invalid_amount' || strpos($m,'invalid amount') !== false) {
        $who = 'Gateway — amount'; $tone = 'warn';
        $text = 'The gateway rejected the amount ("' . ($msg ?: 'Invalid amount') . '"). If this order is over your NMI account\'s Maximum Ticket Amount, ask NMI to raise it — this is an account setting, not the card.';
    } elseif (in_array($code, ['invalid_token','invalid_expiry','network','exception','not_configured'], true)) {
        // Stopped BEFORE the bank answered — this one IS on our side / the connection.
        $who = 'Store check'; $tone = 'warn';
        $text = match ($code) {
            'invalid_token'  => 'The secure card token from the checkout form was invalid or expired — the card never reached the bank. The customer was asked to re-enter the card.',
            'invalid_expiry' => 'The expiry date typed at checkout was not a real MM/YY — the card never reached the bank. The customer was asked to correct it.',
            'network'        => 'We could not reach the card processor (connection timeout) — the retry first checks whether the charge already went through, so nobody is charged twice.',
            'not_configured' => 'The gateway key is missing in Settings — nothing was sent to the bank.',
            default          => 'A processing error on our side stopped this attempt before it reached the bank' . ($msg ? ': "' . $msg . '"' : '') . '.',
        };
    } elseif ($code === '300' && (strpos($m,'avs') !== false || strpos($m,'cvv') !== false || strpos($m,'duplicate') !== false || strpos($m,'reject') !== false || strpos($m,'fraud') !== false || strpos($m,'currency') !== false || strpos($m,'amount') !== false)) {
        // Gateway-level rule (merchant account setting), not the issuing bank.
        $who = 'Gateway rule'; $tone = 'warn';
        $text = 'Rejected by a setting in your NMI account ("' . $msg . '") — not by the customer\'s bank and not by the store. Check NMI → Options → Security / Fraud.';
    } elseif (strpos($m,'declin')!==false || strpos($m,'insufficient')!==false || strpos($m,'do not honor')!==false || strpos($m,'expired')!==false || strpos($m,'pick up')!==false || in_array($code,['200','201','202','203','204','220','221','222','223','240','300'],true)) {
        $who = 'Bank declined'; $tone = 'danger';
        $text = 'The customer\'s bank declined the card' . ($msg ? ': "' . $msg . '"' : '') . ($refid ? ' (ref ' . $refid . ')' : '') . '. This is on the card/bank side, not the store.';
    } elseif ($code === 'auth_failed' || strpos($m,'authentication')!==false || strpos($m,'api')!==false || strpos($m,'gateway')!==false) {
        $who = 'Gateway config'; $tone = 'warn';
        $text = 'Gateway connection/authentication issue' . ($msg ? ': "' . $msg . '"' : '') . '. Check the gateway API key/status in Settings.';
    } else {
        $who = 'Failed'; $tone = 'danger';
        $text = ($msg ?: 'Payment not completed') . ($refid ? ' (ref ' . $refid . ')' : '') . ($code ? ' [code ' . $code . ']' : '');
    }
    return ['tone'=>$tone, 'who'=>$who, 'text'=>$text];
};
$mvToneCss = ['success'=>['#16a34a','#dcfce7'], 'danger'=>['#dc2626','#fee2e2'], 'warn'=>['#b45309','#fef3c7']];
?>
<?php if (!empty($gwLogs)): ?>
<div class="card border-0 shadow-sm mb-3" data-testid="gateway-log-panel">
  <div class="card-body">
    <h6 class="fw-bold mb-3"><i class="bi bi-list-check text-primary me-2"></i>Payment Gateway Log
      <span class="text-muted fw-normal" style="font-size:12px;">— every attempt by <strong data-testid="gw-log-customer"><?= esc($o['name'] ?: $custEmail) ?></strong> (<?= esc($custEmail) ?>), in plain English</span></h6>
    <div class="d-flex flex-column gap-2">
      <?php if (($o['status'] ?? '') === 'refunded'): ?>
        <div class="d-flex align-items-start gap-2 p-2 rounded" style="background:#dbeafe;outline:2px solid #1e40af;" data-testid="gw-log-refunded">
          <span class="badge rounded-pill" style="background:#1e40af;color:#fff;white-space:nowrap;">Refunded</span>
          <div class="small" style="color:#0f172a;">This order was <strong>refunded</strong>. The original charge below was approved by the bank; the funds have since been returned to the customer.</div>
        </div>
      <?php elseif (($o['status'] ?? '') === 'voided'): ?>
        <div class="d-flex align-items-start gap-2 p-2 rounded" style="background:#fef3c7;outline:2px solid #b45309;" data-testid="gw-log-voided">
          <span class="badge rounded-pill" style="background:#b45309;color:#fff;white-space:nowrap;">Voided</span>
          <div class="small" style="color:#0f172a;">The charge on this order was <strong>voided</strong> on the gateway before settlement — no funds were captured from the customer.</div>
        </div>
      <?php elseif (($o['status'] ?? '') === 'declined'): ?>
        <div class="d-flex align-items-start gap-2 p-2 rounded" style="background:#fee2e2;outline:2px solid #991b1b;" data-testid="gw-log-declined">
          <span class="badge rounded-pill" style="background:#991b1b;color:#fff;white-space:nowrap;">Declined</span>
          <div class="small" style="color:#0f172a;">The customer's payment was <strong>declined</strong> and the order was not completed. See the attempt history below; any email the customer received is in the Email Activity timeline.</div>
        </div>
      <?php endif; ?>
      <?php foreach ($gwLogs as $i => $log): $ex = $mvGwExplain($log); [$fg,$bg] = $mvToneCss[$ex['tone']] ?? ['#334155','#f1f5f9']; $isThis = ((int)($log['oid'] ?? 0) === (int)$o['id']);
            $rawA = json_decode((string)($log['raw_response'] ?? ''), true) ?: [];
            $ac = $__attemptCard($rawA, (int)($log['tid'] ?? 0));
            $cardUsed = $ac['brand'] . ($ac['last4'] !== '' ? ' •••• ' . $ac['last4'] : '');
            $gwCode = (string)($rawA['response_code'] ?? $rawA['responseCode'] ?? '');
            $avsMap = ['Y'=>'address + ZIP match','X'=>'address + 9-digit ZIP match','A'=>'address matches, ZIP does not','Z'=>'ZIP matches, address does not','W'=>'9-digit ZIP matches, address does not','N'=>'no match','U'=>'address not checked by bank','R'=>'address check unavailable (not a mismatch)','S'=>'not supported by bank','E'=>'error','G'=>'non-US card (no address check)','B'=>'address match (intl.)','0'=>'not checked'];
            $cvvMap = ['M'=>'match','N'=>'NO match','P'=>'not processed','S'=>'not on card','U'=>'issuer unable to check'];
            $avs = strtoupper(trim((string)($rawA['avsresponse'] ?? ''))); $cvv = strtoupper(trim((string)($rawA['cvvresponse'] ?? '')));
            // One short, plain reason per declined attempt — and whose "no" it was.
            $why = '';
            if ($ex['who'] === 'Bank declined') {
                $why = match (true) {
                    $gwCode === '201' => 'Do Not Honor — the customer\'s bank refused the card. Nothing on our side blocked it; the customer should call their bank or use another card.',
                    $gwCode === '202' => 'Insufficient funds — the customer needs another card.',
                    $gwCode === '204' => 'The bank does not allow online purchases on this card.',
                    $gwCode === '240' => 'The bank wants to speak to the cardholder first.',
                    in_array($gwCode, ['250','251','252','253'], true) => 'Card flagged by the bank (lost / stolen) — do not retry it.',
                    default => 'Refused by the customer\'s bank. Nothing on our side blocked it.',
                };
            }
      ?>
        <div class="d-flex align-items-start gap-2 p-2 rounded" style="background:<?= $bg ?>;<?= $isThis ? 'outline:2px solid '.$fg.';' : '' ?>" data-testid="gw-log-row-<?= $i ?>">
          <span class="badge rounded-pill" style="background:<?= $fg ?>;color:#fff;white-space:nowrap;"><?= esc($ex['who']) ?></span>
          <div class="small" style="color:#0f172a;">
            <div><?= esc($ex['text']) ?></div>
            <div class="text-muted" style="font-size:11px;">
              <?php if (!empty($log['order_number'])): ?>
                <a href="order-view.php?id=<?= (int)$log['oid'] ?>" style="color:inherit;"><?= esc($log['order_number']) ?></a><?= $isThis ? ' <strong>(this order)</strong>' : '' ?> ·
              <?php endif; ?>
              <?= esc(strtoupper((string)($log['gateway'] ?: 'gateway'))) ?> ·
              <?= esc($log['currency'] ?: 'USD') ?> <?= esc(number_format((float)$log['amount'], 2)) ?> ·
              <?= esc($log['created_at']) ?>
            </div>
            <?php if (trim($cardUsed) !== '' || $gwCode !== '' || $avs !== '' || $cvv !== ''): ?>
            <div class="d-flex flex-wrap gap-1 mt-1" data-testid="gw-log-facts-<?= $i ?>" style="font-size:11px;">
              <?php if (trim($cardUsed) !== ''): ?><span class="badge rounded-pill" style="background:#fff;color:#0f172a;border:1px solid #cbd5e1;font-weight:600;"><i class="bi bi-credit-card-2-front me-1"></i><?= esc(trim($cardUsed)) ?></span><?php endif; ?>
              <?php if (!empty($log['transaction_id']) && strpos((string)$log['transaction_id'], 'TEST_') !== 0): ?><span class="badge rounded-pill" style="background:#fff;color:#334155;border:1px solid #cbd5e1;font-weight:600;" title="Search this ID in your gateway's Transaction Report">Gateway ref <?= esc((string)$log['transaction_id']) ?></span><?php endif; ?>
              <?php if ($gwCode !== ''): ?><span class="badge rounded-pill" style="background:#fff;color:#334155;border:1px solid #cbd5e1;font-weight:600;">Gateway code <?= esc($gwCode) ?></span><?php endif; ?>
              <?php if ($avs !== ''): ?><span class="badge rounded-pill" style="background:#fff;color:<?= in_array($avs,['N','E'],true) ? '#b91c1c' : '#334155' ?>;border:1px solid #cbd5e1;font-weight:600;">AVS <?= esc($avs) ?> — <?= esc($avsMap[$avs] ?? 'see gateway') ?></span><?php endif; ?>
              <?php if ($cvv !== ''): ?><span class="badge rounded-pill" style="background:#fff;color:<?= $cvv === 'N' ? '#b91c1c' : '#334155' ?>;border:1px solid #cbd5e1;font-weight:600;">CVV <?= esc($cvv) ?> — <?= esc($cvvMap[$cvv] ?? 'see gateway') ?></span><?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if ($why !== ''): ?>
              <div class="mt-2 small" style="color:#0f172a;" data-testid="gw-log-why-<?= $i ?>"><i class="bi bi-info-circle me-1" style="color:#b45309;"></i><strong>Reason:</strong> <?= esc($why) ?></div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="text-muted mt-2" style="font-size:11px;">Green = bank approved · Red = bank/card declined (not our code) · Amber = gateway/account setting to check. Each row is one request we sent to the gateway and the gateway's own answer — the <em>Gateway ref</em> is the gateway's transaction ID, so you can look up every attempt in your gateway's Transaction Report (search by ID, not by card — a different card in an earlier attempt will not show under a card search).</div>
  </div>
</div>
<?php endif; ?>

<div class="row g-3">
  <!-- LEFT: Customer + Purchase + Payment -->
  <div class="col-lg-8">
    <div class="card-e p-4 mb-3" data-testid="customer-info">
      <h6 class="fw-bold mb-3"><i class="bi bi-person text-primary me-2"></i>Customer Information</h6>
      <div class="row g-2 small">
        <?php $fx = !empty($o['forensics']) ? (json_decode((string)$o['forensics'], true) ?: []) : []; ?>
        <div class="col-6 col-md-4"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Full Name</div><div class="fw-semibold"><?= esc($o['first_name'].' '.$o['last_name']) ?></div></div>
        <div class="col-6 col-md-4"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Email</div><div class="fw-semibold"><?= esc($o['email']) ?></div></div>
        <div class="col-6 col-md-4"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Phone</div><div class="fw-semibold"><?= esc($o['phone'] ?: '—') ?></div></div>
        <?php if (!empty($o['company_name'])): ?>
        <div class="col-12 col-md-4" data-testid="customer-company"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Company</div><div class="fw-semibold"><i class="bi bi-building me-1 text-secondary"></i><?= esc($o['company_name']) ?></div></div>
        <?php endif; ?>
        <div class="col-12 col-md-<?= !empty($o['company_name']) ? '8' : '12' ?>"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Billing Address</div>
          <div class="fw-semibold"><?= esc($o['address']) ?><?= $o['address2'] ? ', ' . esc($o['address2']) : '' ?>, <?= esc($o['city']) ?>, <?= esc($o['state']) ?> <?= esc($o['zip']) ?> · <?= esc($o['country'] ?: $o['billing_country'] ?: '—') ?></div>
        </div>
        <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">IP Address</div><div class="fw-semibold" data-testid="customer-ip"><?= esc(($fx['ip'] ?? '') ?: ($o['ip_address'] ?: '—')) ?></div></div>
        <?php if ($fx): ?>
          <?php
            $fxLoc = trim(implode(', ', array_filter([($fx['geo_city'] ?? ''), trim(($fx['geo_state'] ?? '') . ' ' . ($fx['geo_zip'] ?? '')), ($fx['geo_country'] ?? '')])));
            $fxDev = trim(implode(' · ', array_filter([($fx['device'] ?? ''), ($fx['os'] ?? ''), ($fx['browser'] ?? '')])));
            $fxNet = trim(implode(' — ', array_filter(array_unique([($fx['isp'] ?? ''), ($fx['org'] ?? '')]))));
          ?>
          <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Device</div><div class="fw-semibold" data-testid="customer-device"><i class="bi bi-<?= ($fx['device'] ?? '') === 'Mobile' ? 'phone' : (($fx['device'] ?? '') === 'Tablet' ? 'tablet' : 'laptop') ?> me-1 text-secondary"></i><?= esc($fxDev ?: '—') ?></div></div>
          <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">IP Location</div><div class="fw-semibold" data-testid="customer-geo"><i class="bi bi-geo-alt-fill me-1 text-secondary"></i><?= esc($fxLoc ?: '—') ?></div></div>
          <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Network / ISP</div><div class="fw-semibold" data-testid="customer-isp"><i class="bi bi-wifi me-1 text-secondary"></i><?= esc($fxNet ?: '—') ?></div></div>
          <?php if (!empty($fx['timezone'])): ?>
          <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Timezone</div><div class="fw-semibold"><?= esc($fx['timezone']) ?></div></div>
          <?php endif; ?>
        <?php endif; ?>
        <?php
          // Render a clickable Stripe Dashboard link when we have a PI id.
          // Honours STRIPE_LIVE_MODE (test PI ids start with pi_test_… on test mode).
          $piId = (string)($o['payment_intent_id'] ?? '');
          if ($piId !== '' && function_exists('stripe_enabled') && stripe_enabled()):
            $isTest = strpos((string)STRIPE_SECRET_KEY, 'sk_test_') === 0;
            $stripeUrl = 'https://dashboard.stripe.com/' . ($isTest ? 'test/' : '') . 'payments/' . urlencode($piId);
        ?>
        <div class="col-6 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Stripe Payment</div>
          <a href="<?= esc($stripeUrl) ?>" target="_blank" rel="noopener" class="fw-semibold text-decoration-none" data-testid="stripe-dashboard-link"><i class="bi bi-box-arrow-up-right me-1"></i>View on Stripe Dashboard →</a>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="card-e p-4 mb-3" data-testid="purchase-info">
      <h6 class="fw-bold mb-3"><i class="bi bi-box-seam text-primary me-2"></i>Purchase Information</h6>
      <?php foreach ($items as $it):
        $assigned = $keyMap[$it['product_slug']] ?? []; ?>
        <div class="d-flex gap-3 mb-3 pb-3 border-bottom">
          <?php if ($it['image']): ?><img src="<?= esc($it['image']) ?>" style="width:64px;height:64px;object-fit:contain;background:var(--bg);border-radius:8px;padding:6px;"><?php endif; ?>
          <div class="flex-grow-1">
            <div class="fw-bold"><?= esc($it['name']) ?></div>
            <div class="small text-muted"><?= esc($it['platform']) ?> · <?= esc($it['category']) ?> · Qty <?= (int)$it['qty'] ?> · <?= region_money((float)$it['price']) ?></div>
            <?php foreach ($assigned as $k): ?>
              <div class="mt-2"><span class="text-muted small">License Key:</span>
                <code style="background:var(--blue-soft);color:var(--brand-dk);padding:3px 10px;border-radius:6px;letter-spacing:1.2px;font-size:12.5px;"><?= esc($k['license_key']) ?></code>
                <span class="s-badge <?= $k['status']==='sold'?'paid':'queued' ?> ms-2"><?= esc($k['status']) ?></span>
              </div>
            <?php endforeach; ?>
            <?php if (!$assigned): ?><div class="mt-2 small text-muted">No key assigned yet.</div><?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
      <div class="row small">
        <div class="col-6 col-md-3"><span class="text-muted">Purchase Date:</span><br><strong><?= esc(date('M j, Y H:i', strtotime($o['created_at']))) ?></strong></div>
        <div class="col-6 col-md-3"><span class="text-muted">Region:</span><br><strong><?= esc($o['region']) ?></strong></div>
        <div class="col-6 col-md-3"><span class="text-muted">Quantity:</span><br><strong><?= array_sum(array_column($items,'qty')) ?> item(s)</strong></div>
        <div class="col-6 col-md-3"><span class="text-muted">Total:</span><br><strong style="color:var(--green);font-size:16px;"><?= region_money((float)$o['total']) ?></strong></div>
      </div>
    </div>

    <div class="card-e p-4 mb-3" data-testid="deliver-keys-card">
      <h6 class="fw-bold mb-3"><i class="bi bi-key-fill text-primary me-2"></i>Deliver License Key / Pre-activated Link
        <?php
          // "Delivered" must reflect a SUCCESSFUL payment + actual fulfilment.
          // Previously the badge defaulted to "Delivered" whenever delivery_status
          // was empty — so failed/declined/pending-payment orders wrongly showed
          // "Delivered". Gate on payment success first.
          $ovPaidOk  = in_array(($o['status'] ?? ''), ['paid', 'delivered'], true)
                       || (($o['payment_status'] ?? '') === 'succeeded');
          $ovDstat   = (string)($o['delivery_status'] ?? '');
        ?>
        <?php if (!$ovPaidOk): ?>
          <span class="s-badge ms-2" style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;" data-testid="delivery-status-badge">Not delivered — payment not completed</span>
        <?php elseif ($ovDstat === 'pending'): ?>
          <span class="s-badge queued ms-2" data-testid="delivery-status-badge">Pending</span>
        <?php else: ?>
          <span class="s-badge delivered ms-2" data-testid="delivery-status-badge">Delivered</span>
        <?php endif; ?>
      </h6>
      <form method="post" data-testid="deliver-keys-form">
        <input type="hidden" name="action" value="deliver_keys">
        <div class="mb-3">
          <label class="form-label small text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Customer email <span class="text-secondary text-lowercase">(edit to resend to a different address)</span></label>
          <input type="email" name="cust_email" value="<?= esc($o['email']) ?>" class="form-control form-control-sm" required data-testid="deliver-email-input">
        </div>

        <div class="mb-3">
          <label class="form-label small text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">What should the customer receive?</label>
          <div class="d-flex flex-column gap-2">
            <label class="border rounded p-2 d-flex align-items-start gap-2 mb-0" style="cursor:pointer;">
              <input type="checkbox" class="form-check-input mt-1" name="send_key" id="ov_send_key" value="1" checked onchange="ovToggleDelivery()" data-testid="ov-send-key">
              <span><strong class="small">License key</strong><br><small class="text-muted">Classic delivery — the customer enters the key to activate.</small></span>
            </label>
            <label class="border rounded p-2 d-flex align-items-start gap-2 mb-0" style="cursor:pointer;">
              <input type="checkbox" class="form-check-input mt-1" name="send_link" id="ov_send_link" value="1" onchange="ovToggleDelivery()" data-testid="ov-send-link">
              <span><strong class="small">Pre-activated download link</strong><br><small class="text-muted">The email clearly tells the customer the license key is <strong>already enabled in the link</strong> — click to download, install, and it activates automatically.</small></span>
            </label>
          </div>
          <div class="form-text">Tick <strong>both</strong> to send the key <em>and</em> the pre-activated link together in one email.</div>
        </div>

        <div id="ov_key_fields">
        <?php foreach ($items as $it):
          $existingKey = $keyMap[$it['product_slug']][0]['license_key'] ?? ''; ?>
          <div class="mb-3">
            <label class="form-label small fw-semibold mb-1"><i class="bi bi-box-seam me-1 text-secondary"></i><?= esc($it['name']) ?></label>
            <input type="text" name="key_<?= (int)$it['id'] ?>" value="<?= esc($existingKey) ?>" class="form-control form-control-sm" style="font-family:monospace;letter-spacing:1px;" placeholder="Enter license key — e.g. XXXXX-XXXXX-XXXXX-XXXXX-XXXXX" data-testid="deliver-key-input-<?= (int)$it['id'] ?>">
          </div>
        <?php endforeach; ?>
        </div>

        <div class="mb-3" id="ov_link_field" style="display:none;">
          <label class="form-label small fw-semibold mb-1"><i class="bi bi-link-45deg me-1 text-success"></i>Pre-activated download URL</label>
          <input type="url" name="download_url" id="ov_download_url" class="form-control form-control-sm" placeholder="https://…" data-testid="deliver-url-input">
          <div class="form-text">The customer gets a green <strong>"Download Now — License Included"</strong> button opening this link, with a crystal-clear note that the license installs automatically — no key entry needed.</div>
        </div>

        <button class="btn btn-primary btn-sm" data-testid="deliver-keys-submit" onclick="return ovValidateDeliver();"><i class="bi bi-send-fill me-1"></i>Send to Customer</button>
        <small class="text-muted ms-2">Sends the full delivery email and marks the order delivered.</small>
      </form>
      <script>
        function ovToggleDelivery() {
          document.getElementById('ov_key_fields').style.display = document.getElementById('ov_send_key').checked ? '' : 'none';
          document.getElementById('ov_link_field').style.display = document.getElementById('ov_send_link').checked ? '' : 'none';
        }
        function ovValidateDeliver() {
          var sk = document.getElementById('ov_send_key').checked;
          var sl = document.getElementById('ov_send_link').checked;
          if (!sk && !sl) { alert('Tick at least one option — license key and/or pre-activated download link.'); return false; }
          if (sl && !(document.getElementById('ov_download_url').value || '').trim()) { alert('Enter the pre-activated download URL first.'); return false; }
          return confirm('Send the selected delivery to the customer at the email shown above?');
        }
      </script>
    </div>

    <div class="card-e p-4 mb-3" data-testid="payment-info">
      <h6 class="fw-bold mb-3"><i class="bi bi-credit-card text-primary me-2"></i>Payment Information</h6>
      <?php
        // A debit/credit card entered on OUR checkout and processed by PayPal
        // (Advanced Card Fields) is shown EXACTLY like an NMI card payment —
        // same card visual, BIN + last 4, expiry, CVV status, funding, country.
        $__ppFs = (string)($o['paypal_funding_source'] ?? '');
        $__viaPayPalCard = $o['payment_method'] === 'paypal' && $__ppFs === 'card_direct';
      ?>
      <div class="row g-2 small">
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Gateway</div><div class="fw-semibold" data-testid="ov-gateway"><?= $__viaPayPalCard ? 'Debit / Credit Card <span class="text-muted fw-normal">· processed by PayPal</span>' : esc(ucfirst($o['payment_method'])) ?></div></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Status</div><span class="s-badge <?= esc($o['status']) ?>"><?= esc($o['status']) ?></span></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Currency</div><div class="fw-semibold"><?= esc($o['currency']) ?></div></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Billing Country</div><div class="fw-semibold"><?= esc($o['billing_country'] ?: $o['country'] ?: '—') ?></div></div>
        <div class="col-12 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Transaction ID</div><div class="fw-semibold"><code><?= esc($o['transaction_id'] ?: '—') ?></code></div></div>
        <div class="col-12 col-md-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Card Statement Name</div><div class="fw-semibold"><?= esc($o['card_statement_name'] ?: statement_name_for($o['payment_method'])) ?></div></div>
      </div>

      <?php if ($o['payment_method'] === 'card' || $__viaPayPalCard):
        $brandLogo = ['Visa'=>'visa','Mastercard'=>'mastercard','Amex'=>'amex','American Express'=>'amex','Discover'=>'discover'][$o['card_brand']] ?? null;
        // Friendly cardholder name (uppercase, embossed look like a real card)
        $cardholder = trim(strtoupper($o['first_name'] . ' ' . $o['last_name']));
        // Risk-level styling for Stripe Radar score.
        $rLevel = (string)($o['risk_level'] ?? '');
        $rScore = isset($o['risk_score']) && $o['risk_score'] !== null ? (int)$o['risk_score'] : null;
        $riskColors = [
          'normal'   => ['#d1fae5','#047857','Normal'],
          'elevated' => ['#fef3c7','#92400e','Elevated'],
          'highest'  => ['#fee2e2','#b91c1c','Highest'],
          'not_assessed' => ['#e2e8f0','#475569','Not assessed'],
        ];
        [$rBg,$rFg,$rLabel] = $riskColors[$rLevel] ?? ['#e2e8f0','#475569', ($rLevel ?: '—')];
        // ISO-2 → emoji flag for issuing country.
        $flag = '';
        if (!empty($o['card_country']) && strlen($o['card_country']) === 2) {
            $cc = strtoupper($o['card_country']);
            $flag = chr(0xF0) . chr(0x9F) . chr(0x87) . chr(0xA6 + ord($cc[0]) - ord('A'))
                  . chr(0xF0) . chr(0x9F) . chr(0x87) . chr(0xA6 + ord($cc[1]) - ord('A'));
        }
        // Issuing bank — PayPal returns it with the BIN details; otherwise derive
        // it from the stored BIN (cached, best-effort).
        $issuerBank = $__viaPayPalCard ? trim((string)($o['paypal_funding_bank_name'] ?? '')) : '';
        if ($issuerBank === '' && !empty($o['card_bin'])) {
            require_once __DIR__ . '/includes/bin_lookup.php';
            $issuerBank = (string)(mv_bin_lookup((string)$o['card_bin'])['bank'] ?? '');
        }
      ?>
        <hr class="my-3">
        <div class="d-flex align-items-center gap-3 mb-2">
          <i class="bi bi-credit-card-2-front" style="font-size:24px;color:var(--brand);"></i>
          <strong>Card Details</strong>
          <?php if ($__viaPayPalCard): ?>
            <span class="px-2 py-1" style="background:#eff6ff;color:#1d4ed8;border-radius:999px;font-size:11px;font-weight:700;" data-testid="ov-card-via-paypal"><i class="bi bi-paypal me-1"></i>Processed by PayPal</span>
          <?php endif; ?>
          <span class="text-muted small ms-2" data-testid="card-pci-note"><i class="bi bi-shield-lock"></i> PCI-allowed subset · full PAN &amp; CVV are not stored</span>
          <?php if ($rLevel !== ''): ?>
            <span class="ms-auto px-2 py-1" style="background:<?= esc($rBg) ?>;color:<?= esc($rFg) ?>;border-radius:999px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;" data-testid="risk-badge" title="Stripe Radar risk assessment">
              <i class="bi bi-shield-exclamation me-1"></i>Risk: <?= esc($rLabel) ?><?= $rScore !== null ? ' · ' . $rScore : '' ?>
            </span>
          <?php endif; ?>
        </div>
        <div class="d-flex gap-3 flex-wrap align-items-stretch">
          <!-- Card visual — light theme, clear brand + cardholder -->
          <div data-testid="card-visual" style="background:linear-gradient(135deg,#ffffff 0%,#eff6ff 55%,#e0f2fe 100%);color:#0f172a;border:1px solid #dbeafe;border-radius:16px;padding:20px 22px;min-width:340px;max-width:400px;position:relative;overflow:hidden;box-shadow:0 10px 26px rgba(2,6,23,.12);">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <div style="font-size:10px;letter-spacing:2px;color:#64748b;text-transform:uppercase;font-weight:700;">Card on File</div>
                <div style="font-size:16px;color:#1d4ed8;margin-top:3px;font-weight:800;letter-spacing:.3px;"><?= esc(brand_name()) ?></div>
              </div>
              <div class="text-end">
                <?php if ($brandLogo): ?>
                  <img src="assets/images/payments/<?= esc($brandLogo) ?>.svg" alt="<?= esc($o['card_brand']) ?>" style="height:30px;opacity:1;">
                <?php else: ?>
                  <div style="font-weight:800;color:#0f172a;letter-spacing:1px;font-size:15px;"><?= esc($o['card_brand'] ?: 'CARD') ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div style="margin:18px 0 12px;width:40px;height:29px;background:linear-gradient(135deg,#fde68a,#f59e0b);border-radius:6px;box-shadow:inset 0 0 0 1px rgba(180,120,10,.35);"></div>
            <div style="font-family:'Courier New',monospace;font-size:19px;font-weight:700;letter-spacing:2.5px;margin:0 0 16px;color:#0f172a;">
              <?php $ccBinV = trim((string)($o['card_bin'] ?? '')); $ccL4V = trim((string)($o['card_last4'] ?? '')); ?>
              <?= $ccL4V !== '' ? ($ccBinV !== '' ? esc($ccBinV).'•• •••• '.esc($ccL4V) : '•••• •••• •••• '.esc($ccL4V)) : '•••• •••• •••• ----' ?>
            </div>
            <div class="d-flex justify-content-between align-items-end">
              <div>
                <div style="font-size:9px;letter-spacing:1.5px;color:#64748b;font-weight:700;">CARDHOLDER</div>
                <div style="font-family:'Courier New',monospace;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#0f172a;font-size:13px;"><?= esc($cardholder ?: 'NAME ON FILE') ?></div>
              </div>
              <div class="text-end">
                <div style="font-size:9px;letter-spacing:1.5px;color:#64748b;font-weight:700;">EXP</div>
                <div style="font-family:'Courier New',monospace;font-weight:700;color:#0f172a;font-size:13px;"><?= esc($o['card_exp'] ?: '--/--') ?></div>
              </div>
            </div>
          </div>
          <div class="flex-grow-1 row g-2 small align-content-center">
            <?php
              $ccBinG = trim((string)($o['card_bin'] ?? ''));
              $ccL4G  = trim((string)($o['card_last4'] ?? ''));
              $ccNumG = $ccL4G !== '' ? ($ccBinG !== '' ? $ccBinG.'******'.$ccL4G : '••••••******'.$ccL4G) : '—';
              $cvvG   = trim((string)($o['card_cvv_status'] ?? ''));
            ?>
            <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">CC Number</div><div class="fw-semibold font-monospace" data-testid="ov-cc-number"><?= esc($ccNumG) ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">CC Type</div><div class="fw-semibold text-capitalize" data-testid="ov-cc-type"><?= esc($o['card_brand'] ?: ($o['card_type'] ?: '—')) ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">CVV Status</div><div class="fw-semibold" data-testid="ov-cvv-status"><?= esc($cvvG !== '' ? $cvvG : '—') ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">CC Expiration</div><div class="fw-semibold" data-testid="ov-cc-exp"><?= esc($o['card_exp'] ?: '—') ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Last 4</div><div class="fw-semibold">•••• <?= esc($o['card_last4'] ?: '—') ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Funding</div><div class="fw-semibold text-capitalize" data-testid="ov-funding"><?= esc($o['card_funding'] ?: 'unknown') ?></div></div>
            <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Issuing Country</div><div class="fw-semibold" data-testid="ov-issuing-country"><?= $flag ?> <?= esc($o['card_country'] ?: '—') ?></div></div>
            <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Issuing Bank</div><div class="fw-semibold" data-testid="ov-issuing-bank"><?= esc($issuerBank ?: '—') ?></div></div>
          </div>
        </div>

        <?php
          // ---- Card trail: every payment attempt on this order (Mastercard ••4444 declined → Visa ••4242 approved) ----
          // Reads the PCI-safe brand+last4 embedded in transaction_logs.raw_response.
          $attempts = [];
          try {
              $__tl = $pdo->prepare("SELECT id, status, raw_response, created_at FROM transaction_logs WHERE order_id = ? ORDER BY id ASC");
              $__tl->execute([(int)$o['id']]);
              foreach (($__tl->fetchAll() ?: []) as $__r) {
                  $raw = json_decode((string)($__r['raw_response'] ?? ''), true);
                  if (!is_array($raw)) $raw = [];
                  $st = strtolower((string)($__r['status'] ?? ''));
                  $ok = in_array($st, ['succeeded','success','paid','captured','completed','test'], true);
                  $ac = $__attemptCard($raw, (int)($__r['id'] ?? 0));
                  $attempts[] = [
                      'ok'     => $ok,
                      'brand'  => $ac['brand'],
                      'last4'  => $ac['last4'],
                      'reason' => (string)($raw['error_message'] ?? ($raw['decline_reason'] ?? '')),
                      'at'     => (string)($__r['created_at'] ?? ''),
                  ];
              }
          } catch (Throwable $e) { $attempts = []; }
          $__hasFail = false; foreach ($attempts as $a) { if (!$a['ok']) { $__hasFail = true; break; } }
          if (count($attempts) >= 2 || ($__hasFail && count($attempts) >= 1)):
        ?>
        <div class="mt-3" data-testid="card-trail">
          <div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;margin-bottom:8px;"><i class="bi bi-clock-history me-1"></i>Payment attempts (card trail)</div>
          <div class="d-flex flex-column gap-2">
            <?php foreach ($attempts as $i => $a):
              $brandTxt = $a['brand'] !== '' ? $a['brand'] : 'Card';
              $l4Txt    = $a['last4'] !== '' ? '&bull;&bull;'.esc($a['last4']) : '';
              $badgeBg  = $a['ok'] ? '#dcfce7' : '#fee2e2';
              $badgeFg  = $a['ok'] ? '#15803d' : '#b91c1c';
              $badgeTx  = $a['ok'] ? 'Approved' : 'Declined';
              $ic       = $a['ok'] ? 'bi-check-circle-fill' : 'bi-x-circle-fill';
            ?>
              <div class="d-flex align-items-center gap-2 flex-wrap" style="font-size:13px;" data-testid="card-trail-row">
                <span class="text-muted" style="width:18px;font-weight:700;"><?= $i+1 ?>.</span>
                <span class="fw-semibold"><?= esc($brandTxt) ?> <?= $l4Txt ?></span>
                <span style="display:inline-flex;align-items:center;gap:4px;background:<?= $badgeBg ?>;color:<?= $badgeFg ?>;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;padding:2px 8px;border-radius:999px;"><i class="bi <?= $ic ?>"></i><?= $badgeTx ?></span>
                <?php if (!$a['ok'] && $a['reason'] !== ''): ?><span class="text-muted">— <?= esc($a['reason']) ?></span><?php endif; ?>
                <?php if ($a['at'] !== ''): ?><span class="text-muted ms-auto" style="font-size:11px;"><?= esc(date('M j, g:ia', strtotime($a['at']))) ?></span><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>


      <?php elseif ($o['payment_method'] === 'paypal'):
        $fs = $o['paypal_funding_source'] ?: 'paypal_balance';
        $fsMap = [
          'paypal_balance' => ['PayPal Balance',        'wallet2',          '#003087', 'Paid directly from PayPal balance.'],
          'pay_later'      => ['PayPal Pay Later',      'calendar-event',   '#0070BA', 'Buy now, pay in 4 interest-free installments.'],
          'paypal_credit'  => ['PayPal Credit',         'credit-card',      '#0070BA', 'PayPal Credit line of credit (deferred interest).'],
          'bank'           => ['Bank Account (linked)', 'bank',             '#10b981', 'Funded from a bank account attached to PayPal.'],
          'card'           => ['Card (linked)',         'credit-card-2-front','#3b82f6','Funded from a card saved inside the PayPal wallet.'],
          'card_direct'    => ['Card (guest checkout)', 'credit-card-2-front','#3b82f6','Debit/credit card entered on our checkout, processed by PayPal Advanced Card Processing (no PayPal account).'],
          'venmo'          => ['Venmo',                 'wallet',           '#3D95CE', 'Paid via Venmo (PayPal-owned).'],
        ];
        [$fsLabel,$fsIcon,$fsColor,$fsDesc] = $fsMap[$fs] ?? ['Unknown source','question-circle','#64748b','Funding source not returned by PayPal.'];
      ?>
        <hr class="my-3">
        <div class="d-flex align-items-center gap-3 mb-3">
          <i class="bi bi-paypal" style="font-size:24px;color:#003087;"></i>
          <strong>PayPal Payment Details</strong>
        </div>
        <div class="d-flex gap-3 flex-wrap align-items-stretch">
          <!-- PayPal funding card -->
          <div style="background:linear-gradient(135deg,#003087 0%,#0070BA 100%);color:#fff;border-radius:14px;padding:18px 22px;min-width:300px;position:relative;overflow:hidden;">
            <div style="display:flex;align-items:center;gap:8px;font-size:18px;font-weight:800;letter-spacing:.3px;">
              <span style="font-style:italic;color:#fff;">Pay</span><span style="font-style:italic;color:#facc15;">Pal</span>
            </div>
            <div style="font-size:11px;letter-spacing:2px;color:#cbd5e1;text-transform:uppercase;margin-top:14px;">Funding Source</div>
            <div style="margin-top:6px;display:flex;align-items:center;gap:10px;">
              <div style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.15);display:inline-flex;align-items:center;justify-content:center;">
                <i class="bi bi-<?= esc($fsIcon) ?>" style="font-size:18px;"></i>
              </div>
              <div>
                <div style="font-size:15px;font-weight:700;"><?= esc($fsLabel) ?></div>
                <?php if (($fs==='card' || $fs==='card_direct') && $o['paypal_funding_card_brand']): ?>
                  <div style="font-size:12px;color:#cbd5e1;">
                    <?= esc($o['paypal_funding_card_brand']) ?> ending •••• <?= esc($o['paypal_funding_card_last4']) ?>
                  </div>
                <?php elseif ($fs==='bank' && $o['paypal_funding_bank_name']): ?>
                  <div style="font-size:12px;color:#cbd5e1;"><?= esc($o['paypal_funding_bank_name']) ?></div>
                <?php elseif ($fs==='paypal_credit' && $o['paypal_funding_card_last4']): ?>
                  <div style="font-size:12px;color:#cbd5e1;">
                    Backing card: <?= esc($o['paypal_funding_card_brand'] ?: 'Card') ?> ••<?= esc($o['paypal_funding_card_last4']) ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
            <div style="font-size:11px;color:#cbd5e1;margin-top:14px;line-height:1.5;"><?= esc($fsDesc) ?></div>
          </div>
          <div class="flex-grow-1 row g-2 small align-content-center">
            <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Funding Source</div><div class="fw-semibold"><?= esc($fsLabel) ?></div></div>
            <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Payer Email</div><div class="fw-semibold"><?= esc($o['paypal_payer_email'] ?: '—') ?></div></div>
            <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Payer ID</div><div class="fw-semibold"><code><?= esc($o['paypal_payer_id'] ?: '—') ?></code></div></div>
            <?php if ($fs==='card' || $fs==='card_direct' || $fs==='paypal_credit'): ?>
              <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Funding Card</div><div class="fw-semibold"><?= esc($o['paypal_funding_card_brand'] ?: '—') ?></div></div>
              <div class="col-6"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Last 4</div><div class="fw-semibold">•••• <?= esc($o['paypal_funding_card_last4'] ?: '—') ?></div></div>
            <?php endif; ?>
            <?php if ($fs==='bank'): ?>
              <div class="col-12"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Bank</div><div class="fw-semibold"><?= esc($o['paypal_funding_bank_name'] ?: '—') ?></div></div>
            <?php endif; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div class="card-e p-4 mb-3" data-testid="fulfillment-info">
      <h6 class="fw-bold mb-3"><i class="bi bi-truck text-primary me-2"></i>Fulfillment Information</h6>
      <div class="row g-2 small">
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">License Key Delivery</div>
          <?php
            $lkPaid      = in_array(($o['status'] ?? ''), ['paid','delivered'], true) || (($o['payment_status'] ?? '') === 'succeeded');
            $lkDstat     = (string)($o['delivery_status'] ?? '');
            $lkFulfilled = (int)($o['fulfilled'] ?? 0) === 1;
            $lkDelivered = $lkPaid && $lkFulfilled && $lkDstat !== 'pending';
          ?>
          <?php if (!$lkPaid): ?>
            <span class="s-badge queued">Not delivered</span>
          <?php elseif ($lkDelivered): ?>
            <span class="s-badge delivered">Delivered</span>
          <?php else: ?>
            <span class="s-badge queued">Pending</span>
          <?php endif; ?></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Email to Customer</div>
          <?php if ($custSent): ?>
            <span class="s-badge delivered" data-testid="email-delivery-status">Delivered</span>
            <div class="text-muted" style="font-size:10px;"><?= esc(date('M j, Y H:i', strtotime((string)$custSentAt))) ?></div>
          <?php else: ?>
            <span class="s-badge queued" data-testid="email-delivery-status">Not sent yet</span>
          <?php endif; ?></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Customer Opened</div>
          <div id="custOpenedBadge"><?= mv_render_open_badge($openState) ?></div></div>
        <div class="col-6 col-md-3"><div class="text-muted text-uppercase" style="font-size:10px;letter-spacing:1px;">Install Guide</div>
          <span class="s-badge <?= $custSent?'delivered':'queued' ?>">Embedded</span></div>
      </div>
      <?php if ($lastCustomerEmail): ?>
        <a href="email-view.php?id=<?= (int)$lastCustomerEmail['id'] ?>" target="_blank" class="btn btn-soft-gray btn-sm mt-3" data-testid="preview-customer-email"><i class="bi bi-eye me-1"></i> Preview email exactly as customer received it</a>
      <?php endif; ?>

      <?php if ($emRows): ?>
      <hr class="my-3">
      <div class="d-flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
        <h6 class="fw-bold mb-0"><i class="bi bi-envelope-paper text-primary me-2"></i>Email Thread <span class="text-muted fw-normal">(<?= count($emRows) ?>)</span></h6>
        <span class="text-muted" style="font-size:11px;">Newest first · every message for this order, across all payment attempts</span>
      </div>
      <?php
        // Split counts for the filter tabs + count emails that did NOT reach the customer.
        $__cCount = 0; $__aCount = 0; $__failCount = 0;
        foreach ($emRows as $__r) {
          $__isCust = ($custEmailLc !== '' && strtolower(trim((string)($__r['recipient'] ?? ''))) === $custEmailLc);
          if ($__isCust) $__cCount++; else $__aCount++;
          $__s = strtolower((string)($__r['status'] ?? ''));
          if (strpos($__s,'fail')!==false || strpos($__s,'bounce')!==false || strpos($__s,'invalid')!==false || strpos($__s,'reject')!==false || in_array($__s,['error','undelivered'],true)) $__failCount++;
        }
      ?>
      <?php if ($__failCount > 0): ?>
        <div class="alert alert-danger d-flex align-items-center gap-2 py-2 px-3 mb-2" style="font-size:12.5px;" data-testid="thread-bounce-banner">
          <i class="bi bi-exclamation-octagon-fill"></i>
          <div><strong><?= (int)$__failCount ?> email<?= $__failCount===1?'':'s' ?> did not reach the customer</strong> (bounced / failed). Fix the address if needed and hit <strong>Resend</strong> on each flagged email below so the customer gets it.</div>
        </div>
      <?php endif; ?>
      <div class="btn-group btn-group-sm mb-2" role="group" data-testid="thread-filter-tabs">
        <button type="button" class="btn btn-primary thread-filter-btn active" data-filter="both" data-testid="thread-filter-both">Both (<?= count($emRows) ?>)</button>
        <button type="button" class="btn btn-outline-primary thread-filter-btn" data-filter="customer" data-testid="thread-filter-customer">Customer (<?= $__cCount ?>)</button>
        <button type="button" class="btn btn-outline-primary thread-filter-btn" data-filter="admin" data-testid="thread-filter-admin">Admin / Internal (<?= $__aCount ?>)</button>
      </div>
      <div class="email-thread" id="thread" data-testid="order-email-thread" style="border:1px solid var(--border);border-radius:12px;overflow:hidden;">
        <?php
          // Newest → oldest: the most recent email (e.g. the approval / key
          // delivery) sits on top, above the earlier decline — so you read the
          // latest status first and can scroll down through the full history.
          $thread = $emRows; // already ORDER BY created_at DESC
          foreach ($thread as $ix => $row):
            $isCustomer = ($custEmailLc !== '' && strtolower(trim((string)($row['recipient'] ?? ''))) === $custEmailLc);
            $whoKey = $isCustomer ? 'customer' : 'admin';
            $who   = $isCustomer ? 'Customer' : 'Admin / Internal';
            $wcol  = $isCustomer ? '#065f46' : '#7c3aed';
            $wbg   = $isCustomer ? '#d1fae5' : '#ede9fe';
            $st    = (string)($row['status'] ?? '');
            $when  = !empty($row['created_at']) ? date('M j, Y g:i A', strtotime($row['created_at'])) : '';
            $stLc  = strtolower($st);
            $isFailed = in_array($stLc, ['failed','bounced','error','invalid','undelivered','bounce','rejected'], true)
                        || strpos($stLc, 'fail') !== false || strpos($stLc, 'bounce') !== false
                        || strpos($stLc, 'invalid') !== false || strpos($stLc, 'reject') !== false;
            $rowBg = $isFailed ? 'background:rgba(239,68,68,.07);' : ($isCustomer ? '' : 'background:rgba(124,58,237,.04);');
        ?>
          <div class="thread-row" data-who="<?= $whoKey ?>" style="display:flex;gap:12px;align-items:flex-start;padding:11px 13px;border-bottom:1px solid var(--border);<?= $isFailed ? 'border-left:4px solid #ef4444;' : '' ?><?= $rowBg ?>">
            <span style="flex:0 0 auto;margin-top:2px;font-weight:800;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;color:<?= $wcol ?>;background:<?= $wbg ?>;padding:3px 8px;border-radius:999px;white-space:nowrap;"><?= $who ?></span>
            <div style="flex:1 1 auto;min-width:0;">
              <div class="fw-semibold text-truncate" style="font-size:13px;"><?= esc($row['subject'] ?: '(no subject)') ?></div>
              <div class="text-muted" style="font-size:11px;">
                <i class="bi bi-arrow-right-short"></i><?= esc($row['recipient'] ?: '—') ?>
                <?php if ($when): ?> · <?= esc($when) ?><?php endif; ?>
                <?php if ($isFailed): ?>
                  · <span class="s-badge" style="font-size:9.5px;padding:1px 6px;background:#fee2e2;color:#991b1b;font-weight:800;">NOT DELIVERED<?= $st!=='' ? ' · '.esc($st) : '' ?></span>
                <?php elseif ($st !== ''): ?>
                  · <span class="s-badge <?= $st==='sent'?'delivered':esc($st) ?>" style="font-size:9.5px;padding:1px 6px;"><?= $st==='sent'?'delivered':esc($st) ?></span>
                <?php endif; ?>
                <span class="thread-open-note" data-email-id="<?= (int)$row['id'] ?>"><?= mv_render_thread_open_note($openState, (int)$row['id']) ?></span>
              </div>
              <?php if ($isFailed): ?>
                <div style="font-size:11px;color:#b91c1c;font-weight:600;margin-top:3px;"><i class="bi bi-exclamation-triangle-fill me-1"></i>This email did not reach the customer. Check the address and resend →</div>
              <?php endif; ?>
            </div>
            <div style="flex:0 0 auto;display:flex;flex-direction:column;gap:4px;align-items:flex-end;">
              <a href="email-view.php?id=<?= (int)$row['id'] ?>" target="_blank" class="btn btn-soft-gray btn-sm py-0 px-2" style="font-size:11px;" data-testid="thread-view-<?= (int)$row['id'] ?>"><i class="bi bi-eye"></i> View</a>
              <button type="button" class="btn btn-sm py-0 px-2 w-100 mv-track-btn" style="font-size:11px;white-space:nowrap;background:#ede9fe;color:#5b21b6;border:1px solid #ddd6fe;" data-email-id="<?= (int)$row['id'] ?>" data-testid="thread-tracking-<?= (int)$row['id'] ?>" title="Tracking details — opens with IP, location, device and mail client"><i class="bi bi-activity"></i> Tracking</button>
              <form method="post" class="m-0" onsubmit="return confirm('Resend this email to <?= esc($row['recipient'] ?: $o['email']) ?>?');">
                <input type="hidden" name="action" value="resend_one">
                <input type="hidden" name="email_id" value="<?= (int)$row['id'] ?>">
                <button class="btn <?= $isFailed ? 'btn-danger' : 'btn-soft-amber' ?> btn-sm py-0 px-2 w-100" style="font-size:11px;white-space:nowrap;" data-testid="thread-resend-<?= (int)$row['id'] ?>" title="Resend exactly as-is to the same address"><i class="bi bi-arrow-repeat"></i> Resend</button>
              </form>
              <button type="button" class="btn btn-soft-gray btn-sm py-0 px-2 w-100" style="font-size:11px;white-space:nowrap;" data-testid="thread-editresend-toggle-<?= (int)$row['id'] ?>" onclick="var f=document.getElementById('resend-form-<?= (int)$row['id'] ?>');f.style.display=f.style.display==='block'?'none':'block';" title="Edit the address, subject or message, then resend"><i class="bi bi-pencil-square"></i> Edit &amp; Resend</button>
            </div>
          </div>
          <form method="post" id="resend-form-<?= (int)$row['id'] ?>" class="thread-resend-form" data-who="<?= $whoKey ?>" style="<?= $isFailed ? 'display:block;' : 'display:none;' ?>padding:10px 13px;border-bottom:1px solid var(--border);background:rgba(245,158,11,.06);">
            <input type="hidden" name="action" value="resend_one">
            <input type="hidden" name="email_id" value="<?= (int)$row['id'] ?>">
            <div class="fw-semibold mb-2" style="font-size:11.5px;color:#92400e;"><i class="bi bi-pencil-square me-1"></i>Edit &amp; Resend — change anything below, then send</div>
            <div class="row g-2">
              <div class="col-md-6">
                <label class="text-muted" style="font-size:10px;">Send to</label>
                <input type="email" name="resend_email_to" class="form-control form-control-sm" style="font-size:12px;" value="<?= esc($row['recipient'] ?: $o['email']) ?>" data-testid="thread-resend-email-<?= (int)$row['id'] ?>" required>
              </div>
              <div class="col-md-6">
                <label class="text-muted" style="font-size:10px;">Subject</label>
                <input type="text" name="resend_subject" class="form-control form-control-sm" style="font-size:12px;" value="<?= esc($row['subject']) ?>" data-testid="thread-resend-subject-<?= (int)$row['id'] ?>">
              </div>
              <div class="col-12">
                <label class="text-muted" style="font-size:10px;">Message <span class="text-muted">(leave blank to send the original email unchanged)</span></label>
                <textarea name="resend_body" rows="4" class="form-control form-control-sm" style="font-size:12px;" placeholder="Leave empty to resend the exact original message, or type a new message here…" data-testid="thread-resend-body-<?= (int)$row['id'] ?>"></textarea>
              </div>
            </div>
            <div class="d-flex gap-2 mt-2">
              <button class="btn btn-primary btn-sm py-1 px-3" style="font-size:12px;" data-testid="thread-resend-submit-<?= (int)$row['id'] ?>"><i class="bi bi-send me-1"></i>Send edited email</button>
              <button type="button" class="btn btn-soft-gray btn-sm py-1 px-3" style="font-size:12px;" onclick="document.getElementById('resend-form-<?= (int)$row['id'] ?>').style.display='none';">Cancel</button>
            </div>
          </form>
        <?php endforeach; ?>
      </div>
      <div class="text-muted text-center py-3 d-none" id="threadEmptyMsg" data-testid="thread-empty" style="font-size:12px;">No messages in this view.</div>
      <script>
      (function(){
        var btns = document.querySelectorAll('.thread-filter-btn');
        var rows = document.querySelectorAll('.thread-row');
        var empty = document.getElementById('threadEmptyMsg');
        function apply(f){
          var shown = 0, last = null;
          document.querySelectorAll('.thread-resend-form').forEach(function(frm){ frm.style.display = 'none'; });
          rows.forEach(function(r){
            var ok = (f === 'both') || (r.getAttribute('data-who') === f);
            r.style.display = ok ? 'flex' : 'none';
            if (ok) { shown++; last = r; }
            r.style.borderBottom = '1px solid var(--border)';
          });
          if (last) last.style.borderBottom = 'none';
          if (empty) empty.classList.toggle('d-none', shown !== 0);
        }
        btns.forEach(function(b){
          b.addEventListener('click', function(){
            btns.forEach(function(x){ x.classList.remove('active','btn-primary'); x.classList.add('btn-outline-primary'); });
            b.classList.add('active','btn-primary'); b.classList.remove('btn-outline-primary');
            apply(b.getAttribute('data-filter'));
          });
        });
        apply('both');
      })();
      </script>
      <?php endif; ?>
    </div>
  </div>

  <!-- RIGHT: Order Timeline -->
  <div class="col-lg-4">
    <div class="card-e p-4 sticky-top" style="top: 90px;">
      <h6 class="fw-bold mb-3 d-flex align-items-center justify-content-between"><span><i class="bi bi-clock-history text-primary me-2"></i>Order Timeline</span>
        <span class="tl-live" id="tlLive" title="Open status refreshes automatically — it turns green the moment the customer opens the email" data-testid="timeline-live"><span class="dot"></span>live</span></h6>
      <ul class="timeline" data-testid="order-timeline">
        <?php
        $stages = [
          ['order_created',     'Order Created',         'cart-check'],
          ['payment_completed', 'Payment Completed',     'credit-card-2-back-fill'],
          ['license_assigned',  'License Key Assigned',  'key-fill'],
          ['email_sent',        'Confirmation Email Sent','envelope-check'],
          ['email_delivered',   'Email Delivered',       'inbox-fill'],
          ['email_opened',      'Customer Opened Email', 'envelope-open'],
        ];
        // "Email Delivered" falls back to the newest email's SMTP timestamp.
        if ($lastEmail && $lastEmail['delivered_at']) $tl['email_delivered'] = $tl['email_delivered'] ?? $lastEmail['delivered_at'];
        foreach ($stages as [$key,$label,$icon]):
          $done = !empty($tl[$key]);
          $isOpenNode = ($key === 'email_opened');
        ?>
          <li class="<?= $done?'done':'' ?>" <?= $isOpenNode ? 'id="tlOpenNode" data-testid="timeline-email-opened"' : '' ?>>
            <div class="ttitle"><i class="bi bi-<?= $icon ?> me-1" style="color: <?= $done?'#10b981':'#94a3b8' ?>;"></i><?= esc($label) ?></div>
            <div class="tdate"><?php
              if ($done) echo esc(date('M j, Y H:i', strtotime($tl[$key])));
              elseif ($isOpenNode && $custSent) echo 'Not opened yet — waiting for the customer';
              else echo '— pending —';
            ?></div>
            <?php if ($isOpenNode): ?>
              <ul class="tl-openlog" id="tlOpenLog" data-testid="timeline-open-log"><?= mv_render_open_log($openState) ?></ul>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>

<script>
// Live open tracking: poll the server so the "Customer Opened Email" node, the
// per-email log, the Fulfillment badge and the thread rows flip from gray to
// green the moment the customer's open is recorded — no reload needed.
(function(){
  var sig = <?= json_encode($openState['sig']) ?>;
  var orderId = <?= (int)$id ?>;
  var node = document.getElementById('tlOpenNode');
  function apply(j){
    if (!j || !j.ok || j.sig === sig) return;
    sig = j.sig;
    if (node) {
      node.classList.toggle('done', !!j.latest_opened);
      var ic = node.querySelector('.ttitle i'); if (ic) ic.style.color = j.latest_opened ? '#10b981' : '#94a3b8';
      var td = node.querySelector('.tdate'); if (td) td.textContent = j.node_date;
    }
    var log = document.getElementById('tlOpenLog'); if (log) log.innerHTML = j.log_html;
    var badge = document.getElementById('custOpenedBadge'); if (badge) badge.innerHTML = j.badge_html;
    Object.keys(j.rows || {}).forEach(function(id){
      var el = document.querySelector('.thread-open-note[data-email-id="' + id + '"]'); if (el) el.innerHTML = j.rows[id];
    });
  }
  function tick(){
    if (document.hidden) return;
    fetch('ajax/order-open-status.php?id=' + orderId, {credentials:'same-origin', cache:'no-store'})
      .then(function(r){ return r.json(); }).then(apply).catch(function(){});
  }
  setInterval(tick, 15000);
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) tick(); });
})();
</script>

<?php include __DIR__ . '/includes/email-tracking-modal.php'; ?>

<!-- Document preview: every document button opens here first; nothing is
     downloaded until the admin clicks "Download PDF". -->
<div class="modal fade" id="docPreviewModal" tabindex="-1" aria-labelledby="docPreviewTitle" data-testid="doc-preview-modal">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-fullscreen-md-down" style="max-width:1120px;">
    <div class="modal-content" style="height:92vh;border-radius:14px;overflow:hidden;">
      <div class="modal-header py-2 flex-wrap gap-2">
        <h6 class="modal-title fw-bold mb-0 text-truncate" id="docPreviewTitle" style="max-width:100%;"><i class="bi bi-file-earmark-pdf-fill text-danger me-2"></i><span id="docPreviewTitleText">Document</span></h6>
        <div class="d-flex gap-2 ms-auto align-items-center">
          <a id="docPreviewOpen" href="#" class="btn btn-light btn-sm" target="_blank" rel="noopener" data-testid="doc-preview-open-tab"><i class="bi bi-box-arrow-up-right me-1"></i>Open in new tab</a>
          <a id="docPreviewDownload" href="#" class="btn btn-primary btn-sm" data-testid="doc-preview-download"><i class="bi bi-download me-1"></i>Download PDF</a>
          <button type="button" class="btn-close ms-1" data-bs-dismiss="modal" aria-label="Close" data-testid="doc-preview-close"></button>
        </div>
      </div>
      <div class="modal-body p-0 position-relative" style="background:#3f4347;">
        <div id="docPreviewLoading" class="position-absolute top-50 start-50 translate-middle text-white small text-center" data-testid="doc-preview-loading"><div class="spinner-border spinner-border-sm me-2" role="status"></div>Preparing preview…</div>
        <iframe id="docPreviewFrame" title="Document preview" style="width:100%;height:100%;border:0;visibility:hidden;" data-testid="doc-preview-frame"></iframe>
      </div>
      <div class="modal-footer py-1 justify-content-start text-muted" style="font-size:11.5px;">
        <i class="bi bi-info-circle me-1"></i>Preview only — nothing is saved to your computer until you click <strong class="mx-1">Download PDF</strong>. If the preview stays blank on a phone, use “Open in new tab”.
      </div>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function(){
  var modalEl = document.getElementById('docPreviewModal'); if (!modalEl || typeof bootstrap === 'undefined') return;
  document.body.appendChild(modalEl); // escape the admin shell's stacking context so the modal sits above the sticky top bar
  var frame = document.getElementById('docPreviewFrame'), ttl = document.getElementById('docPreviewTitleText'),
      dl = document.getElementById('docPreviewDownload'), op = document.getElementById('docPreviewOpen'), ld = document.getElementById('docPreviewLoading');
  var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
  frame.addEventListener('load', function(){ if (frame.getAttribute('src') && frame.getAttribute('src') !== 'about:blank') { ld.style.display = 'none'; frame.style.visibility = 'visible'; } });
  document.querySelectorAll('.doc-preview-btn').forEach(function(a){
    a.addEventListener('click', function(e){
      if (e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1) return; // let power users open in a tab
      e.preventDefault();
      var href = a.getAttribute('href');
      var viewUrl = href + (href.indexOf('?') >= 0 ? '&' : '?') + 'view=1';
      ttl.textContent = a.getAttribute('data-doc-title') || a.textContent.trim();
      dl.setAttribute('href', href);
      op.setAttribute('href', viewUrl);
      ld.style.display = ''; frame.style.visibility = 'hidden'; frame.setAttribute('src', 'about:blank');
      modal.show();
      setTimeout(function(){ frame.setAttribute('src', viewUrl); }, 60);
    });
  });
  modalEl.addEventListener('hidden.bs.modal', function(){ frame.setAttribute('src', 'about:blank'); });
});
</script>

<?php include __DIR__ . '/includes/admin-shell-end.php'; ?>
