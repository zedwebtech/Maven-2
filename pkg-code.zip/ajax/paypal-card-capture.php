<?php
/**
 * ajax/paypal-card-capture.php
 *
 * Captures a PayPal order created for the inline "pay by card" (Card Fields)
 * flow, then settles OUR order — money-safe:
 *   • paid ONLY when PayPal's capture status === COMPLETED (order.status is
 *     COMPLETED even for a DECLINED card, so it is never trusted) AND the
 *     captured amount + currency equal the order total;
 *   • PENDING captures (PayPal review / eCheck) are held — not paid, not
 *     fulfilled — and the buyer is told exactly why;
 *   • declines return the exact processor / issue reason (JSON) for the UI
 *     and are recorded on the order for the admin.
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email.php';      // fulfill_order()
require_once __DIR__ . '/../includes/recovery.php';   // mv_mark_payment_failed()
require_once __DIR__ . '/../includes/gateways/paypal-api.php';

header('Content-Type: application/json');

$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
$orderNumber    = trim((string)($in['order'] ?? ($_POST['order'] ?? '')));
$paypalOrderId  = trim((string)($in['orderID'] ?? ($_POST['orderID'] ?? '')));
$liabilityShift = strtoupper(trim((string)($in['liabilityShift'] ?? '')));

if ($orderNumber === '' || !preg_match('/^[A-Z0-9\-]{6,}$/i', $paypalOrderId)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'status' => 'INVALID', 'error' => 'Invalid payment reference. Please refresh the page and try again.']);
    exit;
}

$pdo  = db();
$stmt = $pdo->prepare('SELECT * FROM orders WHERE order_number = ? LIMIT 1');
$stmt->execute([$orderNumber]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$order) { http_response_code(404); echo json_encode(['ok' => false, 'status' => 'INVALID', 'error' => 'Order not found. Please refresh the page and try again.']); exit; }

$orderId = (int)$order['id'];

// Already paid (double-submit / refresh) — success is idempotent.
if (in_array((string)($order['payment_status'] ?? ''), ['succeeded', 'paid'], true)
    || (string)($order['status'] ?? '') === 'paid') {
    echo json_encode(['ok' => true, 'status' => 'COMPLETED', 'order' => $orderNumber]);
    exit;
}

// The PayPal order id must match the one stashed (PP:<id>) when the order was
// created, so a tampered orderID can never settle a foreign order.
$stored   = (string)($order['transaction_id'] ?? '');
$expected = str_starts_with($stored, 'PP:') ? substr($stored, 3) : '';
if ($expected === '' || !hash_equals($expected, $paypalOrderId)) {
    http_response_code(409);
    echo json_encode(['ok' => false, 'status' => 'INVALID', 'error' => 'Payment reference mismatch. Please refresh the page and try again.']);
    exit;
}

$mode = (string)($order['gw_mode'] ?? '') ?: (setting_get('gw_mode', 'test') === 'live' ? 'live' : 'test');
$mode = ($mode === 'live') ? 'live' : 'test';

// No 3-D Secure pre-check from our side (store policy: simple 2D checkout —
// the issuer decides). Capture directly; the exact processor reason is
// surfaced to the buyer if PayPal/the bank decline.
try {
    $cap = paypal_capture_order($paypalOrderId, $mode);
} catch (Throwable $e) {
    @error_log('[paypal-card-capture] ' . $e->getMessage());
    $cap = ['ok' => false, 'pending' => false, 'status' => 'ERROR', 'capture_id' => '', 'code' => 'EXCEPTION',
            'error' => 'We could not confirm the payment with PayPal. Please wait a moment and try again — check your email for a receipt before re-entering your card.'];
}
if ($liabilityShift !== '' && !empty($cap['card']) && is_array($cap['card'])) {
    $cap['card']['liability_shift'] = $cap['card']['liability_shift'] ?: $liabilityShift;
}

if (!empty($cap['ok'])) {
    $settle = paypal_settle_order($order, $cap, 'card_fields');
    if (!empty($settle['ok'])) {
        echo json_encode(['ok' => true, 'status' => 'COMPLETED', 'order' => $orderNumber, 'capture_id' => (string)($settle['capture_id'] ?? '')]);
        exit;
    }
    // Captured but amount/currency did not match — held for review, never fulfilled.
    $_SESSION['mv_resume_order_id'] = $orderId;
    http_response_code(409);
    echo json_encode(['ok' => false, 'status' => 'REVIEW', 'code' => (string)($settle['code'] ?? 'AMOUNT_MISMATCH'), 'retry' => false,
                      'error' => (string)($settle['error'] ?? 'The payment needs manual review. Please contact support — do not pay again.')]);
    exit;
}

// Not completed — record the exact reason, keep the order resumable, inform the buyer.
// Payer-account issues read oddly for a CARD payment: reword in card terms.
$__cardWords = [
    'PAYER_ACCOUNT_LOCKED_OR_CLOSED' => 'PayPal\'s risk system declined this card payment (issuer account reported locked or closed). No charge was made — approve the payment with your bank, then retry, or use another card.',
    'PAYER_ACCOUNT_RESTRICTED'       => 'PayPal\'s risk system declined this card payment (restricted). No charge was made — approve the payment with your bank, then retry, or use another card.',
    'PAYER_CANNOT_PAY'               => 'This card could not be used for this payment. No charge was made — approve the payment with your bank, then retry, or use another card.',
    'TRANSACTION_REFUSED'            => 'The payment processor refused this card payment. No charge was made — approve the payment with your bank, then retry, or use another card.',
];
if (isset($__cardWords[(string)($cap['code'] ?? '')])) $cap['error'] = $__cardWords[(string)$cap['code']];
paypal_record_not_paid($order, $cap, $paypalOrderId, 'card_fields');
$_SESSION['mv_resume_order_id'] = $orderId;
$pending = !empty($cap['pending']);
http_response_code($pending ? 202 : 402);
echo json_encode([
    'ok'     => false,
    'status' => $pending ? 'PENDING' : (string)($cap['status'] ?? 'DECLINED'),
    'code'   => (string)($cap['code'] ?? ''),
    'label'  => (string)($cap['label'] ?? ''),
    'retry'  => !$pending && !in_array((string)($cap['code'] ?? ''), ['NETWORK', 'EXCEPTION', 'AMOUNT_MISMATCH'], true),
    'order'  => $orderNumber,
    'error'  => (string)($cap['error'] ?? 'The card payment could not be completed. Nothing was charged — please try again.'),
], JSON_UNESCAPED_SLASHES);
