<?php
// Admin-side live chat endpoint.
// - thread:  return the full conversation for a lead + online status
// - send:    post a message from admin to the customer
// - unread:  return total unread customer messages (for sidebar badge + toast)
require_once __DIR__ . '/../includes/functions.php';
$admin = require_admin_json();
header('Content-Type: application/json; charset=utf-8');

// A DB hiccup (e.g. a column that hasn't migrated yet on a fresh deploy) must
// NEVER return a 500 HTML page — the chat UI can only parse JSON, otherwise it
// hangs on "Loading conversation…".  These handlers turn any uncaught error
// into a clean JSON response.
set_exception_handler(function ($e) {
    if (!headers_sent()) { http_response_code(200); header('Content-Type: application/json; charset=utf-8'); }
    echo json_encode(['ok' => false, 'error' => 'Server error — please refresh and try again.']);
});
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR], true)) {
        echo json_encode(['ok' => false, 'error' => 'Server error — please refresh and try again.']);
    }
});

$in = json_decode(file_get_contents('php://input'), true) ?: ($_POST ?: $_GET);
$action = $in['action'] ?? 'thread';
$pdo = db();
// Make queries throw so our per-query fallbacks (below) can catch a missing
// column and degrade gracefully instead of fataling.
try { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); } catch (Throwable $e) {}
// Belt-and-suspenders: make sure the chat columns exist on this DB right now.
if (function_exists('chat_schema_migrate')) { try { chat_schema_migrate(); } catch (Throwable $e) {} }

function _is_online(?string $lastSeen, ?int $ageSeconds = null): bool {
    // Prefer the DB-computed age (timezone-proof): on shared hosts PHP's
    // default timezone often differs from MySQL's, which made
    // `time() - strtotime($lastSeen)` wildly wrong and showed every
    // customer as offline.  When $ageSeconds is supplied (via
    // TIMESTAMPDIFF in the query) we trust it; otherwise fall back.
    if ($ageSeconds !== null) return $ageSeconds >= 0 && $ageSeconds <= 120;
    if (!$lastSeen) return false;
    return (time() - strtotime($lastSeen)) <= 120; // 2-minute window (fallback)
}

// ---- Quick replies (saved chat templates, shared by the whole team) ----
// Zero-DDL: stored as JSON in settings.chat_quick_replies.  Placeholders
// {name} / {agent} / {brand} are resolved client-side when inserted.
function _quick_replies_load(): array {
    $raw = (string)setting_get('chat_quick_replies', '');
    $list = $raw !== '' ? (json_decode($raw, true) ?: []) : [];
    if (!$list && $raw === '') {
        $brand = (string)(company_info()['name'] ?? brand_name());
        $list = [
            ['id'=>'q1','title'=>'Greeting',        'text'=>"Hi {name}, thanks for reaching out to {brand}! I'm {agent} — I'm looking into this for you right now."],
            ['id'=>'q2','title'=>'Order number',    'text'=>"Could you share your order number (it starts with #MV) and the email used at checkout so I can pull up your order?"],
            ['id'=>'q3','title'=>'Key delivery',    'text'=>"Your license key is delivered by email within 15–30 minutes of payment. Please also check Spam/Promotions — if it's not there, I'll resend it right away."],
            ['id'=>'q4','title'=>'Activation help', 'text'=>"To activate: open any Office app → Account → Activate (or Change Product Key), paste the key exactly as sent, then restart the app. Let me know what message you see if it fails."],
            ['id'=>'q5','title'=>'Wrap up',         'text'=>"Glad I could help, {name}! If anything else comes up, just reply here or email us anytime. Have a great day 😊"],
        ];
        setting_set('chat_quick_replies', json_encode($list, JSON_UNESCAPED_UNICODE));
    }
    return array_values(array_filter($list, fn($q) => is_array($q) && trim((string)($q['text'] ?? '')) !== ''));
}
if ($action === 'quick_list') {
    echo json_encode(['ok'=>true, 'items'=>_quick_replies_load()]); exit;
}
if ($action === 'quick_save') {
    $title = mb_substr(trim((string)($in['title'] ?? '')), 0, 60, 'UTF-8');
    $text  = mb_substr(trim((string)($in['text'] ?? '')), 0, 1500, 'UTF-8');
    $id    = preg_replace('/[^a-z0-9]/', '', strtolower((string)($in['id'] ?? '')));
    if ($text === '') { echo json_encode(['ok'=>false,'error'=>'Reply text is required']); exit; }
    if ($title === '') $title = mb_substr($text, 0, 28, 'UTF-8') . (mb_strlen($text, 'UTF-8') > 28 ? '…' : '');
    $list = _quick_replies_load();
    $found = false;
    foreach ($list as &$q) {
        if ($id !== '' && (string)$q['id'] === $id) { $q['title'] = $title; $q['text'] = $text; $found = true; }
    }
    unset($q);
    if (!$found) { $id = 'q' . substr(bin2hex(random_bytes(4)), 0, 8); $list[] = ['id'=>$id, 'title'=>$title, 'text'=>$text]; }
    if (count($list) > 40) { echo json_encode(['ok'=>false,'error'=>'Limit of 40 quick replies reached']); exit; }
    setting_set('chat_quick_replies', json_encode(array_values($list), JSON_UNESCAPED_UNICODE));
    echo json_encode(['ok'=>true, 'id'=>$id, 'items'=>array_values($list)]); exit;
}
if ($action === 'quick_delete') {
    $id = preg_replace('/[^a-z0-9]/', '', strtolower((string)($in['id'] ?? '')));
    $list = array_values(array_filter(_quick_replies_load(), fn($q) => (string)$q['id'] !== $id));
    setting_set('chat_quick_replies', json_encode($list, JSON_UNESCAPED_UNICODE));
    echo json_encode(['ok'=>true, 'items'=>$list]); exit;
}

if ($action === 'send') {
    $leadId = (int)($in['lead_id'] ?? 0);
    $msg    = trim($in['message'] ?? '');
    if (!$leadId || $msg === '') { echo json_encode(['ok'=>false,'error'=>'invalid']); exit; }

    // The agent's display identity (name + department) for the "joined" notice.
    $agentName = trim((string)($admin['name'] ?? '')) ?: (string)($admin['username'] ?? 'Support');
    $agentDept = trim((string)($admin['department'] ?? ''));

    // "Agent joined" notice — best-effort. The agent_name column may not exist
    // yet on a freshly-deployed DB; never let that block the real message.
    try {
        $cur = $pdo->prepare('SELECT agent_name FROM chat_leads WHERE id=?');
        $cur->execute([$leadId]);
        $assigned = trim((string)($cur->fetchColumn() ?: ''));
        if ($assigned === '') {
            $joinMsg = '👋 ' . $agentName . ($agentDept !== '' ? ' (' . $agentDept . ')' : '')
                     . ' has joined the chat. You\'re now connected with our team — how can we help?';
            // System notice — never emailed (relayed_at pre-set).
            try {
                $pdo->prepare('INSERT INTO chat_messages (lead_id, sender, message, relayed_at) VALUES (?,?,?,NOW())')
                    ->execute([$leadId, 'admin', $joinMsg]);
            } catch (Throwable $e) {
                $pdo->prepare('INSERT INTO chat_messages (lead_id, sender, message) VALUES (?,?,?)')
                    ->execute([$leadId, 'admin', $joinMsg]);
            }
            $pdo->prepare('UPDATE chat_leads SET agent_name=?, assigned_to=? WHERE id=?')
                ->execute([$agentName, (int)($admin['id'] ?? 0) ?: null, $leadId]);
        }
    } catch (Throwable $e) { /* agent_name column missing — skip the join notice */ }

    // The actual message — ALWAYS runs (this is what was failing on deploy).
    $pdo->prepare('INSERT INTO chat_messages (lead_id, sender, message) VALUES (?,?,?)')
        ->execute([$leadId, 'admin', mb_substr($msg, 0, 2000, 'UTF-8')]);
    $msgId = (int)$pdo->lastInsertId();
    // Sending implies done typing — clear the beacon immediately.
    try { $pdo->prepare('UPDATE chat_leads SET typing_admin_at = NULL WHERE id=?')->execute([$leadId]); } catch (Throwable $e) {}
    // Customer offline → deliver the reply to their email (bundled + debounced).
    $relayed = false;
    try { require_once __DIR__ . '/../includes/chat-relay.php'; $relayed = chat_relay_lead($leadId); }
    catch (Throwable $e) { @error_log('[chat-admin relay] ' . $e->getMessage()); }
    echo json_encode(['ok'=>true,'id'=>$msgId,'relayed'=>$relayed]);
    exit;
}

// Typing beacon — admin is composing.  JS pings ~every 2s while
// the textarea has focus + non-empty content.  Customer-side poller
// surfaces this within 1 tick as "● Admin is typing…".
if ($action === 'typing') {
    $leadId = (int)($in['lead_id'] ?? 0);
    if (!$leadId) { echo json_encode(['ok'=>false]); exit; }
    $on = !empty($in['typing']);
    $pdo->prepare('UPDATE chat_leads SET typing_admin_at = ' . ($on ? 'NOW()' : 'NULL') . ' WHERE id=?')
        ->execute([$leadId]);
    echo json_encode(['ok'=>true]); exit;
}

// Presence — bulk online/offline map for the Leads tab so chat-pill
// colours flip green → metallic-gray within a single polling tick
// once the customer leaves / idles for 2 min.  Accepts a list of lead
// IDs; returns only the rows that have changed visible since last
// page-load.  120-sec threshold matches the table's server-side check.
if ($action === 'presence') {
    $ids = array_slice(array_map('intval', $in['lead_ids'] ?? []), 0, 200);
    if (!$ids) { echo json_encode(['ok'=>true,'presence'=>[]]); exit; }
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT id, last_seen, TIMESTAMPDIFF(SECOND, last_seen, NOW()) AS seen_age FROM chat_leads WHERE id IN ($ph)");
    $stmt->execute($ids);
    $out = [];
    foreach ($stmt as $r) {
        $age = $r['seen_age'] === null ? null : (int)$r['seen_age'];
        $online = _is_online($r['last_seen'], $age);
        $out[] = ['id'=>(int)$r['id'], 'online'=>$online, 'last_seen'=>$r['last_seen']];
    }
    echo json_encode(['ok'=>true, 'presence'=>$out]); exit;
}

if ($action === 'unread') {
    require_once __DIR__ . '/../includes/chat-unread.php';
    echo json_encode(mv_chat_admin_unread($pdo));
    exit;
}

if ($action === 'mark_all_read') {
    // One-click silence: mark every unread customer message as read and every
    // unopened callback lead as seen, so the new-chat alarm stops immediately.
    // Genuine NEW messages arriving afterwards will re-trigger it.
    try { $pdo->exec("UPDATE chat_messages SET read_at=NOW() WHERE sender='customer' AND read_at IS NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("UPDATE chat_leads SET admin_seen_at=NOW() WHERE admin_seen_at IS NULL"); } catch (Throwable $e) {}
    echo json_encode(['ok'=>true, 'unread'=>0, 'alarm'=>0]);
    exit;
}

if ($action === 'widget') {
    // Compact feed for the floating staff chat widget: recent leads (with
    // last message + unread count) and upcoming/pending install schedules.
    $leads = $pdo->query("
        SELECT l.id, l.name, l.email, l.phone, l.last_seen, l.requested_product,
          TIMESTAMPDIFF(SECOND, l.last_seen, NOW()) AS seen_age,
          (SELECT m.message FROM chat_messages m WHERE m.lead_id=l.id ORDER BY m.id DESC LIMIT 1) AS last_message,
          (SELECT m.sent_at FROM chat_messages m WHERE m.lead_id=l.id ORDER BY m.id DESC LIMIT 1) AS last_at,
          (SELECT COUNT(*) FROM chat_messages m WHERE m.lead_id=l.id AND m.sender='customer' AND m.read_at IS NULL) AS unread
        FROM chat_leads l
        WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.lead_id=l.id)
           OR l.callback_requested=1
           OR (l.requested_product IS NOT NULL AND l.requested_product <> '')
           OR (l.email IS NOT NULL AND l.email <> '')
        ORDER BY COALESCE((SELECT MAX(m.id) FROM chat_messages m WHERE m.lead_id=l.id),0) DESC, l.id DESC
        LIMIT 40
    ")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($leads as &$ld) {
        $ld['id'] = (int)$ld['id'];
        $ld['unread'] = (int)$ld['unread'];
        $ld['online'] = _is_online($ld['last_seen'], $ld['seen_age'] === null ? null : (int)$ld['seen_age']);
    }
    unset($ld);

    $installs = [];
    try {
        // Show ALL pending/confirmed installs (those needing attention),
        // soonest first — no date cut-off, so a pending call never silently
        // disappears from the console.
        $rows = $pdo->query("SELECT id, customer_name, customer_phone, order_number, scheduled_utc, status
                             FROM proassist_schedules
                             WHERE status IN ('pending','confirmed')
                             ORDER BY scheduled_utc ASC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $ist = '';
            try { $u = new DateTime((string)$r['scheduled_utc'], new DateTimeZone('UTC')); $u->setTimezone(new DateTimeZone('Asia/Kolkata')); $ist = $u->format('D, M j · g:i A') . ' IST'; }
            catch (Throwable $e) {}
            $installs[] = [
                'id' => (int)$r['id'], 'name' => $r['customer_name'], 'phone' => $r['customer_phone'],
                'order' => $r['order_number'], 'when' => $ist, 'status' => $r['status'],
            ];
        }
    } catch (Throwable $e) { $installs = []; }

    $totalUnread = (int)$pdo->query("
        SELECT COUNT(*) FROM chat_leads l
        WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.lead_id=l.id AND m.sender='customer' AND m.read_at IS NULL)
           OR (l.callback_requested=1 AND l.admin_seen_at IS NULL)
    ")->fetchColumn();
    echo json_encode(['ok'=>true, 'leads'=>$leads, 'installs'=>$installs, 'unread'=>$totalUnread]);
    exit;
}

// thread (default)
$leadId = (int)($in['lead_id'] ?? 0);
if (!$leadId) { echo json_encode(['ok'=>false,'error'=>'lead_id required']); exit; }
try {
    $lead = $pdo->prepare('SELECT id, name, email, phone, last_seen, typing_customer_at, client_ip, email_relay_at, TIMESTAMPDIFF(SECOND, last_seen, NOW()) AS seen_age, TIMESTAMPDIFF(SECOND, typing_customer_at, NOW()) AS typing_age FROM chat_leads WHERE id=?');
    $lead->execute([$leadId]); $leadRow = $lead->fetch();
} catch (Throwable $e) {
    $lead = $pdo->prepare('SELECT id, name, email, phone, last_seen, typing_customer_at, TIMESTAMPDIFF(SECOND, last_seen, NOW()) AS seen_age, TIMESTAMPDIFF(SECOND, typing_customer_at, NOW()) AS typing_age FROM chat_leads WHERE id=?');
    $lead->execute([$leadId]); $leadRow = $lead->fetch();
    if ($leadRow) { $leadRow['client_ip'] = null; $leadRow['email_relay_at'] = null; }
}
if (!$leadRow) { echo json_encode(['ok'=>false,'error'=>'not found']); exit; }
// While the admin has this thread open, keep delivering un-seen replies to
// the customer's inbox if they have gone offline (debounced inside).
try { require_once __DIR__ . '/../includes/chat-relay.php'; chat_relay_lead($leadId); } catch (Throwable $e) { @error_log("[chat-admin thread relay] " . $e->getMessage()); }
// Messages — try with attachment columns; if they don't exist yet on this DB
// (fresh deploy that hasn't migrated), fall back to the base columns so the
// conversation still loads instead of erroring.
try {
    $msgs = $pdo->prepare('SELECT id, sender, message, attachment_url, attachment_type, attachment_name, sent_at, read_at, relayed_at FROM chat_messages WHERE lead_id=? ORDER BY id ASC LIMIT 500');
    $msgs->execute([$leadId]);
    $messageRows = $msgs->fetchAll();
} catch (Throwable $e) {
    $msgs = $pdo->prepare('SELECT id, sender, message, sent_at FROM chat_messages WHERE lead_id=? ORDER BY id ASC LIMIT 500');
    $msgs->execute([$leadId]);
    $messageRows = $msgs->fetchAll();
}
// Mark customer messages as read — unless this is a background "peek" poll
// from a minimised chat window (the admin has not actually seen them yet).
if (empty($in['peek'])) {
    try { $pdo->prepare("UPDATE chat_messages SET read_at=NOW() WHERE lead_id=? AND sender='customer' AND read_at IS NULL")->execute([$leadId]); } catch (Throwable $e) {}
    // Mark the lead as seen by an admin (best-effort — column may be missing).
    try { $pdo->prepare("UPDATE chat_leads SET admin_seen_at=NOW() WHERE id=? AND admin_seen_at IS NULL")->execute([$leadId]); } catch (Throwable $e) {}
}
// Surface the customer's typing state so the admin chat panel can show
// "● Customer is typing…" within one polling tick.
$customerIsTyping = $leadRow['typing_customer_at']
    && $leadRow['typing_age'] !== null && (int)$leadRow['typing_age'] >= 0 && (int)$leadRow['typing_age'] <= 5;
echo json_encode([
    'ok' => true,
    'lead' => [
        'id'             => (int)$leadRow['id'],
        'name'           => $leadRow['name'],
        'email'          => $leadRow['email'],
        'phone'          => $leadRow['phone'],
        'last_seen'      => $leadRow['last_seen'],
        'online'         => _is_online($leadRow['last_seen'], $leadRow['seen_age'] === null ? null : (int)$leadRow['seen_age']),
        'customer_typing'=> $customerIsTyping,
        'ip'             => (string)($leadRow['client_ip'] ?? ''),
        'email_relay_at' => $leadRow['email_relay_at'] ?? null,
    ],
    'messages' => $messageRows,
]);
