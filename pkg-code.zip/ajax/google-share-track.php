<?php
/*
 * Marks a customer review as "shared on Google" (google_shared_at) so the
 * nudge email is never sent to someone who already clicked through.
 * Accepts JSON: { token: <request_token> } OR { order: <order_number> }.
 * Write-only, idempotent, no data returned.
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/google-nudge.php';
header('Content-Type: application/json');

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$token = trim((string)($in['token'] ?? ''));
$order = trim((string)($in['order'] ?? ''));

$pdo = db();
mv_gn_ensure_cols($pdo);
$ok = false;
try {
    if ($token !== '') {
        $st = $pdo->prepare('UPDATE customer_reviews SET google_shared_at = COALESCE(google_shared_at, NOW()) WHERE request_token = ?');
        $st->execute([$token]);
        $ok = $st->rowCount() >= 0;
    } elseif ($order !== '') {
        $st = $pdo->prepare('UPDATE customer_reviews cr JOIN orders o ON o.id = cr.order_id
                                SET cr.google_shared_at = COALESCE(cr.google_shared_at, NOW())
                              WHERE o.order_number = ?');
        $st->execute([$order]);
        $ok = $st->rowCount() >= 0;
    }
} catch (Throwable $e) { @error_log('[google-share-track] ' . $e->getMessage()); }

echo json_encode(['ok' => (bool)$ok]);
