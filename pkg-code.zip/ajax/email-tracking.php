<?php
// Admin-only: tracking details + open events + content for one email (popup).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pdf.php';
require_once __DIR__ . '/../includes/email-tracking.php';
require_admin();
header('Content-Type: application/json');
$id = (int)($_GET['id'] ?? 0);
$t = $id > 0 ? mv_email_tracking_data($id) : null;
if (!$t) { http_response_code(404); echo json_encode(['ok' => false, 'error' => 'Email not found']); exit; }
$t['content_url'] = 'email-view.php?id=' . $id;
echo json_encode(['ok' => true] + $t, JSON_UNESCAPED_SLASHES);
