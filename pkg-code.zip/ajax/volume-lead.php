<?php
/**
 * Volume Licensing Request lead capture (the "Contact Sales" banner modal).
 * Kept deliberately SEPARATE from the Contact Us page so volume enquiries land
 * cleanly in Admin → Lead Management → Volume Licensing (filtered by subject
 * 'Volume Licensing Request').
 *
 * Anti-spam: the existing honeypot gate is kept, plus a per-IP throttle
 * (up to 5 requests / 24h, then blocked).
 *
 * Email routing:
 *   - Customer gets the branded "we got your message" acknowledgement
 *     (template customer_service_ack → NEVER CC'd to the store).
 *   - The store gets a dedicated admin notification on its company email
 *     + the global Admin→SMTP CC (template volume_request_admin).
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');

// Volume Licensing has been PERMANENTLY REMOVED from the site (per owner
// request — it was the source of endless fake/bot leads). This endpoint now
// rejects every request outright: no lead is stored, no email sent, no admin
// notification created. Kept only so old cached pages / bots get a clean 410.
http_response_code(410);
echo json_encode(['ok' => false, 'error' => 'Volume licensing is no longer available.']);
exit;

$name     = trim($_POST['name']     ?? '');
$email     = trim($_POST['email']    ?? '');
$company  = trim($_POST['company']  ?? '');
$phone    = trim($_POST['phone']    ?? '');
$licenses = trim($_POST['licenses'] ?? '');
$message  = trim($_POST['message']  ?? '');
$honeypot = trim($_POST['mv_hp']    ?? '');   // hidden field — only bots fill it

// Honeypot — silently accept so bots don't learn they were blocked.
if ($honeypot !== '') { echo json_encode(['ok' => true]); exit; }

// Smart anti-bot gate (all silent-drop so bots can't adapt):
//  1. signed capture token must be present + genuine  (mv_captcha_age)
//  2. genuine human behaviour: dwell + real keystrokes / taps / focus
//  3. single-use token — a replayed token is the classic flood vector
$capTok = is_string($_POST['mv_cap'] ?? null) ? $_POST['mv_cap'] : null;
$capAge = mv_captcha_age($capTok);
if ($capAge === null
    || !mv_behavior_ok($_POST['mv_bh'] ?? null, $capAge)
    || mv_looks_like_spam([$name, $company, $message])
    || !mv_captcha_claim_once($capTok)) {
    echo json_encode(['ok' => true]); // pretend success; store nothing, notify no one
    exit;
}

// Volume requests never need a link — any URL is a bot. Silently drop.
if (preg_match('~https?://|www\.~i', $name . ' ' . $company . ' ' . $message)) { echo json_encode(['ok' => true]); exit; }

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen(preg_replace('/\D/', '', $phone)) < 6) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Please enter your name, a valid email address, and your phone number.']);
    exit;
}

// Per-IP throttle — up to 5 volume requests / 24h, then block.
if (form_rate_limit_hit('volume', 5, 24)) {
    http_response_code(429);
    echo json_encode(['ok' => false, 'error' => 'You have reached the request limit from your network. Please email us directly or try again later.']);
    exit;
}

// Reject typo / undeliverable domains before saving the lead.
if (function_exists('email_address_deliverable')) {
    $deliv = email_address_deliverable($email);
    if (!$deliv['ok'] && in_array($deliv['reason'] ?? '', ['no_mx', 'invalid_syntax'], true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => $deliv['detail'] ?: 'That email address looks undeliverable — please double-check the spelling.']);
        exit;
    }
}

// Fold Company + licence count into the saved message so the admin sees them
// (support_messages has no dedicated columns for them).
$meta = [];
if ($company  !== '') $meta[] = 'Company: ' . $company;
if ($licenses !== '') $meta[] = 'Number of licenses: ' . $licenses;
$fullMsg = $message !== '' ? $message : 'Volume licensing enquiry';
if ($meta) $fullMsg = implode("\n", $meta) . "\n\n" . $fullMsg;

save_support_message([
    'name'    => $name,
    'email'   => strtolower($email),
    'phone'   => $phone,
    'subject' => 'Volume Licensing Request',
    'message' => $fullMsg,
    'source'  => 'volume',
]);

// Customer acknowledgement — delivered to the customer only (no CC).
try {
    send_customer_service_ack(strtolower($email), $name, 'Volume Licensing Request', $fullMsg, 'volume');
} catch (Throwable $e) {
    @error_log('[volume ack] ' . $e->getMessage());
}

// Admin notification — company email + global CC.
try {
    $co        = function_exists('company_info') ? company_info() : [];
    $companyTo = trim((string)setting_get('smtp_from_email', setting_get('smtp_username', '')));
    if ($companyTo === '') $companyTo = trim((string)($co['email'] ?? ''));
    if ($companyTo === '') $companyTo = trim((string)setting_get('company_email', setting_get('contact_email', '')));
    if ($companyTo === '') $companyTo = brand_email();
    if ($companyTo !== '' && filter_var($companyTo, FILTER_VALIDATE_EMAIL)) {
        $brand = $co['name'] ?? brand_name();
        $e     = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
        $row   = function (string $k, string $v) use ($e) {
            if (trim($v) === '') return '';
            return '<tr><td style="padding:6px 0;color:#64748b;width:140px;">' . $e($k) . '</td>'
                 . '<td style="padding:6px 0;font-weight:600;">' . $e($v) . '</td></tr>';
        };
        $msgE = nl2br($e($message !== '' ? $message : '(no message provided)'));
        $html = '<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:620px;margin:0 auto;color:#0f172a">'
            . '<div style="background:#0f172a;padding:18px 22px;border-radius:10px 10px 0 0;color:#fff;">'
            . '<div style="font-size:11px;letter-spacing:.12em;font-weight:800;text-transform:uppercase;color:#60a5fa;">' . $e($brand) . ' — Volume Licensing</div>'
            . '<div style="font-size:19px;font-weight:800;margin-top:4px;">New volume / business pricing request</div></div>'
            . '<div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 10px 10px;padding:22px;line-height:1.55;">'
            . '<table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:14px;">'
            . $row('From', $name)
            . '<tr><td style="padding:6px 0;color:#64748b;">Email</td><td style="padding:6px 0;"><a href="mailto:' . $e(strtolower($email)) . '" style="color:#2563eb;text-decoration:none;">' . $e(strtolower($email)) . '</a></td></tr>'
            . $row('Company', $company)
            . $row('Phone', $phone)
            . $row('Number of licenses', $licenses)
            . '</table>'
            . '<div style="font-weight:700;margin-bottom:4px;">Message</div>'
            . '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 14px;font-size:13px;color:#334155;">' . $msgE . '</div>'
            . '<p style="margin:16px 0 0;font-size:12px;color:#94a3b8;">Reply directly to this email to respond to ' . $e($name) . '.</p>'
            . '</div></div>';
        send_email($companyTo, '[Volume Licensing] New request — ' . $name, $html, null, 'volume_request_admin', 0, [], false, ['name' => $name, 'reply_to' => strtolower($email)]);
    }
} catch (Throwable $e) {
    @error_log('[volume admin email] ' . $e->getMessage());
}

// NOTE: Volume Licensing leads intentionally do NOT create an activity-bell
// notification (per user request — the bell was flooded with fake volume
// alerts). Genuine requests still land in Admin → Lead Management → Volume
// Licensing (with its own unread badge) and the admin email above is sent.

echo json_encode(['ok' => true]);
