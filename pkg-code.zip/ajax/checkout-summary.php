<?php
/**
 * Returns the rendered checkout-summary HTML. Called by main.js after
 * any cart mutation (coupon apply / qty change / item remove) so we can
 * refresh ONLY the right-column summary in place, leaving the customer's
 * filled-in Contact / Billing / Card details intact on the left.
 */
require_once __DIR__ . '/../includes/functions.php';

// Empty cart → 204 so the client can decide what to do (typically redirect home).
$items = cart_items();
if (!$items) {
    http_response_code(204);
    exit;
}

// Mirror the same totals computation used by /checkout.php so the
// refreshed summary always matches what the server would render on a
// full reload.
// ProAssist add-on: read from the SESSION (same source as checkout.php) so any
// in-place summary refresh (coupon / qty / remove / undo) stays consistent with
// the real order state. A `pro` query param can still force it on for legacy links.
$proAssist  = (!empty($_SESSION['proassist']) || (($_GET['pro'] ?? '') === '1'));
if (function_exists('proassist_enabled') && !proassist_enabled()) $proAssist = false;
$subtotal   = cart_subtotal();
$savings    = 0;
foreach ($items as $i) {
    if ($i['original_price'] && $i['original_price'] > $i['price']) {
        $savings += ($i['original_price'] - $i['price']) * $i['qty'];
    }
}
$couponCode = $_SESSION['coupon'] ?? null;
$couponPct  = $couponCode ? (int)($_SESSION['coupon_pct'] ?? (coupons()[$couponCode] ?? 20)) : 0;
$discount   = $couponCode ? round($subtotal * $couponPct / 100, 2) : 0.0;
$total      = $subtotal - $discount + ($proAssist ? proassist_price() : 0);

$fxCountry = preg_match('/^[A-Za-z]{2}$/', (string)($_GET['cc'] ?? '')) ? strtoupper((string)$_GET['cc']) : '';
$GLOBALS['MV_CHECKOUT_MODE'] = true; // amounts in the CHARGE currency, exactly like checkout.php
include __DIR__ . '/../includes/checkout-summary-partial.php';
