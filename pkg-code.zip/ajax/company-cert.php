<?php
// AJAX endpoint: upload the company's Articles of Registration document
// (shown on About Us / footer). Admin-only. Stores under /uploads/legal/
// and returns its public host-relative URL.
require_once __DIR__ . '/../includes/functions.php';
require_admin();

header('Content-Type: application/json');

if (empty($_FILES['cert']) || $_FILES['cert']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'No document uploaded']);
    exit;
}

$f = $_FILES['cert'];
if ($f['size'] > 10 * 1024 * 1024) {
    http_response_code(413);
    echo json_encode(['ok' => false, 'error' => 'Document must be under 10 MB']);
    exit;
}

$mime = mime_content_type($f['tmp_name']);
$allowed = [
    'application/pdf' => 'pdf',
    'image/jpeg'      => 'jpg',
    'image/png'       => 'png',
    'image/webp'      => 'webp',
];
if (!isset($allowed[$mime])) {
    http_response_code(415);
    echo json_encode(['ok' => false, 'error' => 'Only PDF, JPG, PNG and WEBP files are allowed']);
    exit;
}

$dir = __DIR__ . '/../uploads/legal';
if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Upload directory unavailable']);
    exit;
}

$name = 'articles-' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
$dest = $dir . '/' . $name;
if (!move_uploaded_file($f['tmp_name'], $dest)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Failed to save file']);
    exit;
}

$relUrl = 'uploads/legal/' . $name;

// Store a HOST-RELATIVE path (not an absolute URL) so it resolves correctly
// across preview → production hosts, exactly like the company logo.
setting_set('company_reg_certificate_url', $relUrl);

echo json_encode([
    'ok'   => true,
    'url'  => $relUrl,
    'rel'  => $relUrl,
    'name' => $f['name'],
    'ext'  => $allowed[$mime],
]);
