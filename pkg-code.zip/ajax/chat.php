<?php
// Ask AI chat endpoint.
// Uses OpenAI if OPENAI_API_KEY is set in config.php, otherwise returns a contact fallback.
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$message = trim($in['message'] ?? '');
$sessionId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $in['session_id'] ?? ''), 0, 64);

if ($message === '') {
    echo json_encode(['reply' => 'Please type a message.']);
    exit;
}

// Save a lead row if the message contains an email or phone number
$email = null;
$phone = null;
if (preg_match('/[\w.+-]+@[\w-]+\.[\w.]+/', $message, $m)) $email = $m[0];
if (preg_match('/\+?[\d][\d\s().-]{7,}\d/', $message, $m)) $phone = $m[0];
if ($email || $phone) {
    // Only create a lead if this session doesn't already have one — otherwise
    // a mid-conversation message containing an email/phone would spawn a
    // duplicate lead row for a customer who already submitted the chat form.
    $has = 0;
    if ($sessionId !== '') {
        $chk = db()->prepare('SELECT COUNT(*) FROM chat_leads WHERE session_id=?');
        $chk->execute([$sessionId]);
        $has = (int)$chk->fetchColumn();
    }
    if ($has === 0) {
        $stmt = db()->prepare('INSERT INTO chat_leads (session_id, email, phone, message) VALUES (?, ?, ?, ?)');
        $stmt->execute([$sessionId, $email, $phone, $message]);
        try { db()->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([client_ip(), (int)db()->lastInsertId()]); } catch (Throwable $e) {}
    }
}

if (OPENAI_API_KEY === '') {
    // Customer typed a question but the live AI is offline.  Per product
    // requirement: do NOT spit out the full "phone + email + hours" greeting
    // here — that long auto-reply only fires once on lead-form submission.
    // Instead, reassure the customer that a human agent is being looped in,
    // and signal the admin side (chat-customer.php relay already creates
    // an unread chat_messages row, which lights up the topbar bell badge +
    // plays the new audio chime on the admin shell).
    echo json_encode([
        'reply' => "Hold on a moment — let me connect you with a live person. One of our agents has just been notified and will reply right here.",
        'fallback' => true,
        'route_to_human' => true,
    ]);
    exit;
}

// Keep short conversation history in session
if (!isset($_SESSION['chat_history'])) $_SESSION['chat_history'] = [];
$_SESSION['chat_history'][] = ['role' => 'user', 'content' => $message];
$_SESSION['chat_history'] = array_slice($_SESSION['chat_history'], -10);

$system = 'You are Max, a friendly sales assistant for ' . brand_legal() . ', an independent third-party reseller (not affiliated with Microsoft) of original Microsoft software product keys (Office 2024/2021/2019 for PC & Mac, Windows 10/11, Project, Visio) and antivirus product keys (Bitdefender, McAfee). '
    . 'Keep answers brief and helpful. Licenses are one-time purchases (perpetual) with digital delivery by email in digital delivery. '
    . 'If the customer shows buying interest or needs support, politely ask for their name, email and phone (one at a time), and offer our toll-free number ' . SITE_PHONE . ' (' . SITE_HOURS . ').';

$payload = json_encode([
    'model' => OPENAI_MODEL,
    'messages' => array_merge([['role' => 'system', 'content' => $system]], $_SESSION['chat_history']),
    'max_tokens' => 400,
]);

$ch = curl_init(rtrim(OPENAI_BASE_URL, '/') . '/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_API_KEY],
    CURLOPT_TIMEOUT => 30,
]);
$res = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

if ($err || !$res) {
    error_log('OpenAI chat request failed: ' . ($err ?: 'empty response'));
    echo json_encode(['reply' => 'Sorry, I could not reach the assistant right now. Please call ' . SITE_PHONE . ' or email ' . brand_email() . '.']);
    exit;
}

$data = json_decode($res, true);
$reply = $data['choices'][0]['message']['content'] ?? ('Sorry, something went wrong. Please call ' . SITE_PHONE . '.');
$_SESSION['chat_history'][] = ['role' => 'assistant', 'content' => $reply];
echo json_encode(['reply' => $reply]);
