<?php
// After "Verify you're human" the customer picks how we should help:
//   {choice:'callback'} → lead flagged CALLBACK, admin e-mail "Callback requested",
//                         bell + phone push (type 'lead') with phone + issue.
//   {choice:'chat'}     → admin e-mail "Customer Enquiry", bell + phone push
//                         (type 'chat') that opens the live thread (autochat).
// Idempotent: a second click never sends a second e-mail / notification.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');
$in     = json_decode(file_get_contents('php://input'), true) ?: [];
$choice = ($in['choice'] ?? '') === 'callback' ? 'callback' : 'chat';
$leadId = (int)($in['lead_id'] ?? 0);
$token  = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['chat_token'] ?? '')), 0, 64);
if ($leadId <= 0) $leadId = (int)($_SESSION['lead_id'] ?? 0);
if ($leadId <= 0) { http_response_code(400); echo json_encode(['ok' => false, 'error' => 'No lead on record — please send your details first.']); exit; }

$pdo  = db();
$st   = $pdo->prepare('SELECT * FROM chat_leads WHERE id = ? LIMIT 1');
$st->execute([$leadId]);
$lead = $st->fetch(PDO::FETCH_ASSOC);
if (!$lead) { http_response_code(404); echo json_encode(['ok' => false, 'error' => 'Lead not found.']); exit; }
// Ownership: the per-browser chat token issued at lead creation (session fallback).
$ownsBySession = (int)($_SESSION['lead_id'] ?? 0) === $leadId;
$ownsByToken   = $token !== '' && !empty($lead['chat_token']) && hash_equals((string)$lead['chat_token'], $token);
if (!$ownsByToken && !$ownsBySession) { http_response_code(403); echo json_encode(['ok' => false, 'error' => 'Session mismatch.']); exit; }

$already = !empty($lead['lead_choice']);
try {
    $pdo->prepare('UPDATE chat_leads SET lead_choice = ?, lead_choice_at = NOW(), callback_requested = ?, status = "new", last_seen = NOW() WHERE id = ?')
        ->execute([$choice, $choice === 'callback' ? 1 : 0, $leadId]);
} catch (Throwable $e) {
    $pdo->prepare('UPDATE chat_leads SET callback_requested = ?, last_seen = NOW() WHERE id = ?')->execute([$choice === 'callback' ? 1 : 0, $leadId]);
}
if ($already) { echo json_encode(['ok' => true, 'choice' => $choice, 'repeat' => true]); exit; }

$name  = trim((string)($lead['name'] ?? '')) ?: 'Customer';
$email = (string)($lead['email'] ?? '');
$phone = (string)($lead['phone'] ?? '');
$issue = trim((string)($lead['message'] ?? ''));
if (in_array($issue, ['Chat form contact', 'Callback requested via chat form'], true)) $issue = '';
$co    = company_info();
$base  = rtrim(site_url(), '/');
$link  = $base . '/admin.php?tab=leads&autochat=' . $leadId;
$when  = date('M j, Y · g:i A');
$h     = static fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

$adminEmail = function_exists('mv_notify_recipient') ? mv_notify_recipient('chat') : '';
if ($adminEmail === '') $adminEmail = defined('ADMIN_EMAIL') ? ADMIN_EMAIL : ($co['email'] ?? '');

$issueHtml = $issue !== ''
    ? '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-left:4px solid #2563eb;border-radius:10px;padding:14px 18px;margin:0 0 22px;">'
      . '<div style="font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;color:#1d4ed8;margin-bottom:6px;">Issue / how can we help</div>'
      . '<div style="font-size:14px;color:#0f172a;line-height:1.6;">' . nl2br($h($issue)) . '</div></div>'
    : '';
$contactRows = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:22px;">'
    . '<tr><td style="padding:14px 18px;font-size:13px;color:#475569;line-height:1.7;">'
    . '<div><span style="display:inline-block;width:78px;color:#94a3b8;font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;">Name</span> <strong style="color:#0f172a;">' . $h($name) . '</strong></div>'
    . '<div><span style="display:inline-block;width:78px;color:#94a3b8;font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;">Phone</span> <a href="tel:' . $h($phone) . '" style="color:#1d4ed8;text-decoration:none;font-weight:700;">' . $h($phone) . '</a></div>'
    . '<div><span style="display:inline-block;width:78px;color:#94a3b8;font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;">Email</span> <a href="mailto:' . $h($email) . '" style="color:#1d4ed8;text-decoration:none;">' . $h($email) . '</a></div>'
    . '<div><span style="display:inline-block;width:78px;color:#94a3b8;font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;">When</span> ' . $h($when) . '</div>'
    . '<div><span style="display:inline-block;width:78px;color:#94a3b8;font-size:11px;letter-spacing:.5px;text-transform:uppercase;font-weight:700;">Verified</span> <span style="color:#059669;font-weight:700;">&#10003; Human check passed</span></div>'
    . '</td></tr></table>';

if ($choice === 'callback') {
    $headerBg = 'linear-gradient(135deg,#92400e 0%,#d97706 100%)'; $kicker = 'Callback request · Live chat'; $title = '&#128222; Please call ' . $h($name);
    $intro = '<strong style="color:#0f172a;">' . $h($name) . '</strong> verified they are human and asked to be <strong>called back</strong> on the number below.';
    $cta = 'Open lead &amp; call notes'; $subject = '[CHAT LEAD] Callback requested — ' . $name; $tpl = 'admin_lead_callback';
} else {
    $headerBg = 'linear-gradient(135deg,#1e3a8a 0%,#2563eb 100%)'; $kicker = 'New lead · Live chat'; $title = 'Customer Enquiry';
    $intro = '<strong style="color:#0f172a;">' . $h($name) . '</strong> verified they are human and chose to <strong>continue on live chat</strong>. They are waiting for a reply right now.';
    $cta = 'Open the chat'; $subject = '[CHAT LEAD] Customer Enquiry — ' . $name; $tpl = 'admin_lead_alert';
}
$logo = email_brand_logo_src();
$body = '<!doctype html><html><body style="margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#1f2937;">'
    . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f1f5f9;padding:32px 0;"><tr><td align="center">'
    . '<table width="580" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 6px 24px rgba(15,23,42,.08);">'
    . '<tr><td style="background:' . $headerBg . ';padding:24px 30px;color:#fff;"><table cellpadding="0" cellspacing="0" border="0"><tr>'
    . '<td valign="middle" width="64"><img src="' . $h($logo) . '" alt="' . $h($co['name'] ?? '') . '" height="56" style="display:block;height:56px;width:auto;max-width:180px;border-radius:12px;"></td>'
    . '<td valign="middle" style="padding-left:14px;"><div style="font-size:11px;letter-spacing:2.5px;text-transform:uppercase;opacity:.9;font-weight:700;">' . $kicker . '</div>'
    . '<div style="font-size:22px;font-weight:800;margin-top:4px;">' . $title . '</div></td></tr></table></td></tr>'
    . '<tr><td style="padding:28px 30px 18px;"><p style="margin:0 0 18px;font-size:15px;color:#334155;line-height:1.55;">' . $intro . '</p>'
    . $issueHtml . $contactRows
    . '<div style="text-align:center;margin:24px 0 8px;"><a href="' . $h($link) . '" style="display:inline-block;padding:13px 32px;background:#0f172a;color:#fff;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;">' . $cta . ' &rarr;</a></div>'
    . '</td></tr>'
    . '<tr><td style="background:#0f172a;padding:18px 30px;color:#94a3b8;font-size:11.5px;line-height:1.55;text-align:center;"><div style="color:#e2e8f0;font-weight:700;font-size:13px;margin-bottom:6px;">' . $h($co['name'] ?? '') . '</div>Admin notification &middot; Lead ID #' . (int)$leadId . '</td></tr>'
    . '</table></td></tr></table></body></html>';

try {
    if ($adminEmail) send_email($adminEmail, $subject, $body, null, $tpl, 0, [], false, ['name' => $name, 'reply_to' => $email]);
} catch (Throwable $e) { @error_log('[lead-choice email] ' . $e->getMessage()); }

try {
    if (function_exists('admin_notify')) {
        $short = $issue !== '' ? mb_substr($issue, 0, 120) : '';
        if ($choice === 'callback') {
            admin_notify('lead', '📞 Callback requested — ' . $name, trim($phone . ($short !== '' ? ' · ' . $short : '')), '/admin.php?tab=leads&autochat=' . $leadId);
        } else {
            admin_notify('chat', 'New chat — ' . $name, $short !== '' ? $short : 'Customer is waiting on live chat', '/admin.php?tab=leads&autochat=' . $leadId);
        }
    }
} catch (Throwable $e) { @error_log('[lead-choice notify] ' . $e->getMessage()); }

echo json_encode(['ok' => true, 'choice' => $choice]);
