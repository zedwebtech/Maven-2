<?php
// Customer picked "Request a callback" on the post-send choice card.
// Flags the existing chat lead so it shows as a CALLBACK request in Lead
// Management, and nudges the admin inbox (Gmail "+chat" label).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$leadId = (int)($in['lead_id'] ?? 0);
$token  = substr(preg_replace('/[^a-f0-9]/', '', (string)($in['chat_token'] ?? '')), 0, 64);

if ($leadId <= 0) { $leadId = (int)($_SESSION['lead_id'] ?? 0); }
if ($leadId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'No lead on record — please send your details first.']);
    exit;
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM chat_leads WHERE id = ? LIMIT 1');
$stmt->execute([$leadId]);
$lead = $stmt->fetch();
if (!$lead) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Lead not found.']);
    exit;
}
// Verify ownership via the chat token issued at lead creation (fallback to
// the session lead id when the token wasn't persisted client-side).
if ($token !== '' && !empty($lead['chat_token']) && !hash_equals((string)$lead['chat_token'], $token)
    && (int)($_SESSION['lead_id'] ?? 0) !== $leadId) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Session mismatch.']);
    exit;
}

$pdo->prepare('UPDATE chat_leads SET callback_requested = 1, status = "new", last_seen = NOW() WHERE id = ?')
    ->execute([$leadId]);

// Admin nudge — short, routed to the Gmail "+chat" label.
try {
    $adminEmail = function_exists('mv_notify_recipient') ? mv_notify_recipient('chat') : '';
    if ($adminEmail === '') $adminEmail = defined('ADMIN_EMAIL') ? ADMIN_EMAIL : '';
    if ($adminEmail) {
        $co    = company_info();
        $base  = rtrim(site_url(), '/');
        $link  = $base . '/admin.php?tab=leads&autochat=' . $leadId;
        $nm    = htmlspecialchars((string)($lead['name'] ?? 'Customer'), ENT_QUOTES, 'UTF-8');
        $ph    = htmlspecialchars((string)($lead['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
        $em    = htmlspecialchars((string)($lead['email'] ?? ''), ENT_QUOTES, 'UTF-8');
        $html  = '<div style="font-family:Segoe UI,Helvetica,Arial,sans-serif;max-width:560px;margin:0 auto;color:#0f172a">'
            . '<div style="background:#92400e;padding:16px 20px;border-radius:10px 10px 0 0;color:#fff;font-weight:800;font-size:18px;">&#128222; Callback requested</div>'
            . '<div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 10px 10px;padding:20px;line-height:1.6;font-size:14px;">'
            . '<p style="margin:0 0 14px;"><strong>' . $nm . '</strong> asked to be called back.</p>'
            . '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 16px;font-size:13px;">'
            . 'Phone: <a href="tel:' . $ph . '" style="color:#1d4ed8;text-decoration:none;">' . $ph . '</a><br>'
            . 'Email: <a href="mailto:' . $em . '" style="color:#1d4ed8;text-decoration:none;">' . $em . '</a></div>'
            . '<div style="text-align:center;margin-top:18px;"><a href="' . $link . '" style="display:inline-block;background:#0f172a;color:#fff;text-decoration:none;padding:11px 24px;border-radius:999px;font-weight:700;font-size:13.5px;">Open in Lead Management &rarr;</a></div>'
            . '</div></div>';
        send_email($adminEmail, '[CHAT LEAD] Callback requested — ' . (string)($lead['name'] ?? 'Customer'), $html, null, 'admin_lead_callback', 0, [], false, ['name' => (string)($lead['name'] ?? 'Customer'), 'reply_to' => (string)($lead['email'] ?? '')]);
    }
} catch (Throwable $e) { @error_log('[lead-callback] ' . $e->getMessage()); }

echo json_encode(['ok' => true]);
