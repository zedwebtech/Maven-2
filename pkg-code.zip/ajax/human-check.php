<?php
// Chat lead form → "Verify you're human" endpoint.
//   POST {action:'challenge'}                              → {ok, c, sig, prefix, nibble}
//   POST {action:'verify', c, sig, nonce, session_id, website} → {ok, token}
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/human-check.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$action = (string)($in['action'] ?? ($_GET['action'] ?? 'challenge'));

if ($action === 'verify') {
    $r = mv_hc_verify($in);
    if (empty($r['ok'])) {
        http_response_code($r['error'] === 'too_fast' ? 425 : 400);
        $msg = [
            'too_fast'  => 'Please take a moment and tap Verify again.',
            'expired'   => 'This check expired — tap Verify again.',
        ][$r['error']] ?? 'We could not verify this browser. Please try again.';
        echo json_encode(['ok' => false, 'error' => $msg, 'code' => $r['error']]);
        exit;
    }
    echo json_encode(['ok' => true, 'token' => $r['token'], 'expires' => $r['expires']]);
    exit;
}

echo json_encode(['ok' => true] + mv_hc_challenge());
