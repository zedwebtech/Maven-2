<?php
// Lead capture from the chat widget form (name/email/phone + callback choice).
// On every new submission, also email the admin with subject
// "Customer Enquiry — {name}" so they can pick up the conversation in
// Lead Management even if they're not actively watching the dashboard.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$sessionId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $in['session_id'] ?? ''), 0, 64);
$first = trim((string)($in['first_name'] ?? ''));
$last  = trim((string)($in['last_name'] ?? ''));
$name  = trim($first . ' ' . $last) ?: trim((string)($in['name'] ?? ''));
$name  = mb_substr(preg_replace('/\s+/', ' ', $name), 0, 80);
$email = trim($in['email'] ?? '');
$phone = trim($in['phone'] ?? '');
$issue = trim((string)($in['issue'] ?? $in['message'] ?? ''));
$issue = mb_substr($issue, 0, 2000);
$callback = !empty($in['callback_requested']);

// ---- "Verify you're human" gate (includes/human-check.php) -------------
// Every lead must carry a human_token minted for THIS browser + session after
// the signed challenge / dwell-time / proof-of-work check. Scripted posts that
// hit this file directly (the flood of fake chats) stop right here — no lead,
// no e-mail, no bell.
require_once __DIR__ . '/../includes/human-check.php';
$humanToken = (string)($in['human_token'] ?? '');
if (trim((string)($in['website'] ?? '')) !== '' || !mv_hc_token_valid($humanToken, $sessionId)) {
    http_response_code(403);
    @error_log('[lead.php human-gate] blocked lead without valid human token from ' . client_ip());
    echo json_encode(['ok' => false, 'error' => 'Please tap "Verify you\'re human" first, then send.', 'code' => 'human_required']);
    exit;
}
$__limit = mv_hc_ip_over_limit(db(), client_ip());
if ($__limit !== '') {
    http_response_code(429);
    $__co = company_info();
    echo json_encode(['ok' => false, 'error' => 'Too many chat requests from your network right now. Please call us' . (!empty($__co['phone']) ? ' at ' . $__co['phone'] : '') . ' or try again later.', 'code' => $__limit]);
    exit;
}

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($phone) < 7) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Please provide your name, a valid email and phone number.']);
    exit;
}
// A question/sentence typed into the name boxes must never become the lead's
// name ("what mac operating system does this work on" showed up as a customer).
if (preg_match('/[?!@]/u', $name) || preg_match('/\d{3,}/', $name) || count(preg_split('/\s+/u', $name)) > 4 || mb_strlen($name) > 60) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Please put only your name in the name boxes — type your question in the "What do you need help with?" box.']);
    exit;
}

// Catch typo domains / missing MX records BEFORE saving the lead so we
// don't pile up un-reachable contacts in the CRM.  Matches the same
// hardening applied to checkout + notify-stock.
require_once __DIR__ . '/../includes/mailer.php';
if (function_exists('email_address_deliverable')) {
    $deliv = email_address_deliverable($email);
    if (!$deliv['ok'] && in_array($deliv['reason'], ['no_mx','invalid_syntax'], true)) {
        http_response_code(400);
        echo json_encode([
            'ok'    => false,
            'error' => $deliv['detail'] ?: 'That email address looks undeliverable — please double-check the spelling.',
            'reason'=> $deliv['reason'],
        ]);
        exit;
    }
}

$pdo = db();
$leadMsg = $issue !== '' ? $issue : ($callback ? 'Callback requested via chat form' : 'Chat form contact');

// Idempotent per session: if a lead already exists for this browser session,
// UPDATE it instead of inserting a new row. This prevents duplicate rows when
// the Send button double-fires (inline onclick + delegated CSP-safe handler)
// or the customer resubmits the form. Only a brand-new lead emails the admin.
$existing = null;
if ($sessionId !== '') {
    $q = $pdo->prepare('SELECT id, chat_token FROM chat_leads WHERE session_id=? ORDER BY id DESC LIMIT 1');
    $q->execute([$sessionId]);
    $existing = $q->fetch(PDO::FETCH_ASSOC) ?: null;
}
$clientIp = client_ip();
if ($existing) {
    $leadId = (int)$existing['id'];
    $token  = ($existing['chat_token'] ?? '') !== '' ? $existing['chat_token'] : bin2hex(random_bytes(16));
    $pdo->prepare('UPDATE chat_leads SET name=?, email=?, phone=?, callback_requested=?, message=?, chat_token=?, last_seen=NOW() WHERE id=?')
        ->execute([$name, $email, $phone, $callback ? 1 : 0, $leadMsg, $token, $leadId]);
    try { $pdo->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([$clientIp, $leadId]); } catch (Throwable $e) {}
    $isNewLead = false;
} else {
    $stmt = $pdo->prepare('INSERT INTO chat_leads (session_id, name, email, phone, callback_requested, message) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$sessionId, $name, $email, $phone, $callback ? 1 : 0, $leadMsg]);
    $leadId = (int)$pdo->lastInsertId();
    $token  = bin2hex(random_bytes(16));
    $pdo->prepare('UPDATE chat_leads SET chat_token=?, last_seen=NOW() WHERE id=?')->execute([$token, $leadId]);
    try { $pdo->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([$clientIp, $leadId]); } catch (Throwable $e) {}
    try { $pdo->prepare('UPDATE chat_leads SET human_verified_at=NOW() WHERE id=?')->execute([$leadId]); } catch (Throwable $e) {}
    $isNewLead = true;
}
$_SESSION['lead_id'] = $leadId;

// Seed the customer's pre-chat issue as the FIRST chat message so the admin
// sees exactly what they need help with the instant they click "Open Chat"
// (and it counts as an unread CUSTOMER message, which drives the bell, the
// Chat-tab badge and the new-chat alarm even when no callback was requested).
if ($isNewLead && $issue !== '') {
    try {
        $pdo->prepare("INSERT INTO chat_messages (lead_id, sender, message) VALUES (?, 'customer', ?)")
            ->execute([$leadId, $issue]);
    } catch (Throwable $e) { @error_log('[lead.php seed issue] ' . $e->getMessage()); }
}

// The admin e-mail + bell/push now fire from ajax/lead-choice.php once the
// customer picks "Request a call back" or "Continue with chat" — so the team
// is told exactly what the customer wants, and silent/abandoned forms never
// ring anyone. (The lead itself is already saved and visible in Lead Management.)

echo json_encode(['ok' => true, 'lead_id' => $leadId, 'chat_token' => $token]);
