<?php
// AJAX endpoint (admin-only): generate a company logo with AI and adopt it as
// the Company Info logo — the same setting the Upload button writes, so the
// result flows to the favicon, PWA icons, emails, share card and PDFs.
//   action=generate  description, style   → draft PNG (transparent, trimmed, ≤512px)
//   action=use       token                → promote the draft to uploads/company/logo-*.png
// Uses the gpt-image-1 images endpoint through the same credentials/base URL
// as product images (includes/product-image.php) — plain cURL, cPanel-safe.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/product-image.php';
require_admin();

header('Content-Type: application/json');
@set_time_limit(160);

$dir = dirname(__DIR__) . '/uploads/company';
if (!is_dir($dir)) @mkdir($dir, 0775, true);
$action = (string)($_POST['action'] ?? '');

$fail = function (string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
};

function mv_logo_ai_prompt(string $company, string $style, string $desc): string
{
    $company = trim($company) !== '' ? trim($company) : 'the company';
    $initial = mb_strtoupper(mb_substr(preg_replace('/^[^\p{L}\p{N}]+/u', '', $company), 0, 1));
    $styles = [
        'mark'     => 'a single abstract geometric symbol or emblem that suggests software, technology and trust; symbol only — no letters, no words',
        'monogram' => 'a bold letter mark built from the initial "' . $initial . '" set inside or fused with a simple geometric shape; no other letters or words',
        'wordmark' => 'the company name "' . $company . '" as a custom typographic wordmark, spelled exactly as written (every letter present, nothing cut off), with at most one small accent detail',
        'badge'    => 'a compact simple icon paired with the company name "' . $company . '" spelled exactly as written (every letter present, nothing cut off), arranged as one balanced horizontal lock-up',
    ];
    $what = $styles[$style] ?? $styles['mark'];
    $desc = trim(preg_replace('/\s+/', ' ', $desc));
    return 'Professional flat vector logo for a company named "' . $company . '": ' . $what . '.'
        . ($desc !== '' ? ' Creative direction from the owner: ' . $desc . '.' : '')
        . ' Clean modern design, two or three flat brand colours, strong simple silhouette that stays legible at favicon size,'
        . ' perfectly centred with generous even margins, fully transparent background.'
        . ' Flat solid shapes only: no mockups, no 3D, no photo, no shadow of any kind (no drop shadow, no ground shadow, no reflection, no glow),'
        . ' no frame, no watermark, no extra text.';
}

/* Trim transparent padding (4% margin), cap the longest side at 512px, PNG. */
function mv_logo_ai_postprocess(string $bin): string
{
    $im = @imagecreatefromstring($bin);
    if (!$im) return $bin;
    imagealphablending($im, false); imagesavealpha($im, true);
    $w = imagesx($im); $h = imagesy($im);
    $x0 = $w; $y0 = $h; $x1 = -1; $y1 = -1;
    for ($y = 0; $y < $h; $y += 2) for ($x = 0; $x < $w; $x += 2) {
        if (((imagecolorat($im, $x, $y) >> 24) & 0x7F) < 110) {
            if ($x < $x0) $x0 = $x; if ($x > $x1) $x1 = $x; if ($y < $y0) $y0 = $y; if ($y > $y1) $y1 = $y;
        }
    }
    if ($x1 < 0) { $x0 = 0; $y0 = 0; $x1 = $w - 1; $y1 = $h - 1; }
    $cw = $x1 - $x0 + 1; $ch = $y1 - $y0 + 1;
    $m = (int)round(max($cw, $ch) * 0.04);
    $sx = max(0, $x0 - $m); $sy = max(0, $y0 - $m);
    $sw = min($w - $sx, $cw + 2 * $m); $sh = min($h - $sy, $ch + 2 * $m);
    $scale = min(1, 512 / max($sw, $sh));
    $dw = max(1, (int)round($sw * $scale)); $dh = max(1, (int)round($sh * $scale));
    $out = imagecreatetruecolor($dw, $dh);
    imagealphablending($out, false); imagesavealpha($out, true);
    imagefilledrectangle($out, 0, 0, $dw, $dh, imagecolorallocatealpha($out, 0, 0, 0, 127));
    imagecopyresampled($out, $im, 0, 0, $sx, $sy, $dw, $dh, $sw, $sh);
    ob_start(); imagepng($out, null, 6); $png = (string)ob_get_clean();
    imagedestroy($im); imagedestroy($out);
    return $png !== '' ? $png : $bin;
}

if ($action === 'generate') {
    [$key, $base] = mv_product_image_creds();
    if ($key === '') $fail('No AI key configured — add it under API Keys & Settings.', 422);

    foreach (glob($dir . '/ai-draft-*.png') ?: [] as $old) { if (filemtime($old) < time() - 86400) @unlink($old); }

    $company = (string)(company_info()['name'] ?? '');
    $style   = (string)($_POST['style'] ?? 'mark');
    $desc    = mb_substr((string)($_POST['description'] ?? ''), 0, 300);
    // Text styles get a landscape canvas (room for the whole name) and high
    // quality (crisper lettering); symbol styles stay square + medium.
    $textStyle = in_array($style, ['wordmark', 'badge'], true);
    $payload = json_encode([
        'model' => 'gpt-image-1', 'prompt' => mv_logo_ai_prompt($company, $style, $desc),
        'size' => $textStyle ? '1536x1024' : '1024x1024', 'n' => 1, 'quality' => $textStyle ? 'high' : 'medium',
        'background' => 'transparent', 'output_format' => 'png',
    ]);
    $ch = curl_init(rtrim($base, '/') . '/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 140, CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $key],
        CURLOPT_POSTFIELDS => $payload,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    if ($resp === false || $code < 200 || $code >= 300) {
        $msg = 'Image service error (' . ($code ?: 'network') . ')';
        $j = json_decode((string)$resp, true);
        if (isset($j['error']['message'])) {
            $m = (string)$j['error']['message'];
            $msg = preg_match('/budget|quota|insufficient/i', $m) ? 'Universal Key budget exceeded — top up in Profile → Universal Key → Add Balance.' : $m;
        } elseif ($cerr !== '') { $msg = $cerr; }
        $fail($msg, 502);
    }
    $j   = json_decode((string)$resp, true);
    $b64 = (string)($j['data'][0]['b64_json'] ?? '');
    $bin = $b64 !== '' ? base64_decode($b64) : (string)@file_get_contents((string)($j['data'][0]['url'] ?? ''));
    if ($bin === '' || !@imagecreatefromstring($bin)) $fail('No image was returned by the AI — please try again.', 502);

    $token = bin2hex(random_bytes(6));
    $file  = $dir . '/ai-draft-' . $token . '.png';
    if (file_put_contents($file, mv_logo_ai_postprocess($bin)) === false) $fail('uploads/company is not writable on this server.', 500);
    echo json_encode(['ok' => true, 'token' => $token, 'url' => 'uploads/company/ai-draft-' . $token . '.png?t=' . time()]);
    exit;
}

if ($action === 'use') {
    $token = (string)($_POST['token'] ?? '');
    if (!preg_match('/^[a-f0-9]{12}$/', $token)) $fail('Invalid draft.');
    $draft = $dir . '/ai-draft-' . $token . '.png';
    if (!is_file($draft)) $fail('That draft has expired — generate again.', 404);
    $name = 'logo-' . bin2hex(random_bytes(4)) . '.png';
    if (!@rename($draft, $dir . '/' . $name)) $fail('Failed to save the logo.', 500);
    foreach (glob($dir . '/ai-draft-*.png') ?: [] as $old) @unlink($old);
    $rel = 'uploads/company/' . $name;      // host-relative, like the Upload endpoint
    setting_set('company_logo', $rel);
    echo json_encode(['ok' => true, 'url' => $rel, 'rel' => $rel]);
    exit;
}

$fail('Unknown action.');
