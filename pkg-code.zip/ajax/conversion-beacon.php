<?php
// Public endpoint — the thank-you page calls this AFTER the Google Ads
// conversion tag actually executes in the shopper's browser (gtag
// event_callback) OR reports that it never fired (blocked by an
// ad-blocker / consent / a GTM mis-map). This is what powers the real
// "Conversion Tracking Health" verdict in the admin — it distinguishes
// "tag rendered on the receipt" (server-side self-check) from "tag
// genuinely fired in the browser and reached Google" (this beacon).
//
// Zero-DDL: everything is stored in a single rolling JSON `settings` row
// (ads_conversion_beacons) plus a few flat summary keys for quick reads.
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

// Read JSON body (navigator.sendBeacon sends a Blob) with a $_POST fallback.
$raw = file_get_contents('php://input');
$in  = [];
if ($raw !== '' && $raw !== false) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) $in = $decoded;
}
if (!$in) $in = $_POST;

$orderNo = trim((string)($in['order'] ?? ''));
$status  = ($in['status'] ?? '') === 'blocked' ? 'blocked' : 'fired';

if ($orderNo === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'missing order']);
    exit;
}

// Anti-spoof / anti-inflation: only accept beacons for a REAL paid order.
try {
    $stmt = db()->prepare("SELECT id, status FROM orders WHERE order_number = ? LIMIT 1");
    $stmt->execute([$orderNo]);
    $ord = $stmt->fetch();
} catch (Throwable $e) {
    $ord = false;
}
if (!$ord || ($ord['status'] ?? '') !== 'paid') {
    http_response_code(202);
    echo json_encode(['ok' => false, 'error' => 'not a paid order']);
    exit;
}

$now = date('Y-m-d H:i:s');

// Load the rolling event log.
$log = json_decode((string)setting_get('ads_conversion_beacons', ''), true);
if (!is_array($log) || !isset($log['events']) || !is_array($log['events'])) {
    $log = ['events' => []];
}

// Dedupe by order number. A 'fired' confirmation is final; a later 'blocked'
// for the same order is ignored. A 'blocked' entry is upgraded to 'fired' if
// the tag fires on a retry/refresh.
$idx = null;
foreach ($log['events'] as $i => $ev) {
    if (($ev['o'] ?? '') === $orderNo) { $idx = $i; break; }
}
$changed = false;
if ($idx === null) {
    $log['events'][] = ['t' => $now, 'o' => $orderNo, 's' => $status];
    $changed = true;
} else {
    $existing = $log['events'][$idx]['s'] ?? '';
    if ($existing === 'blocked' && $status === 'fired') {
        $log['events'][$idx]['s'] = 'fired';
        $log['events'][$idx]['t'] = $now;
        $changed = true;
    }
    // fired→anything and blocked→blocked: no-op (already recorded).
}

if ($changed) {
    // Keep only the most recent 200 events (rolling window).
    if (count($log['events']) > 200) {
        $log['events'] = array_slice($log['events'], -200);
    }
    setting_set('ads_conversion_beacons', json_encode($log));

    // Flat summary keys for a cheap admin read (no JSON parse needed for these).
    if ($status === 'fired') {
        if (setting_get('ads_conversion_client_first_at', '') === '') {
            setting_set('ads_conversion_client_first_at', $now);
        }
        setting_set('ads_conversion_client_last_at', $now);
        setting_set('ads_conversion_client_last_order', $orderNo);
        setting_set('ads_conversion_client_count', (string)((int)setting_get('ads_conversion_client_count', '0') + 1));
    } else {
        setting_set('ads_conversion_blocked_last_at', $now);
        setting_set('ads_conversion_blocked_last_order', $orderNo);
        setting_set('ads_conversion_blocked_count', (string)((int)setting_get('ads_conversion_blocked_count', '0') + 1));
    }
}

echo json_encode(['ok' => true, 'status' => $status, 'recorded' => $changed]);
