<?php
/**
 * AJAX endpoint: verify payment-gateway CREDENTIALS with a real API call.
 * Admin-only. Used by Admin → API / Payment Gateway → "Verify credentials".
 *
 * WHY: PayPal Advanced (inline) Card Fields only render when a browser
 * client-token can be generated, which needs valid REST credentials for the
 * selected mode. Sandbox keys pass but a wrong/truncated LIVE Client ID or
 * Secret fails silently at checkout (the card fields just don't appear). This
 * endpoint surfaces the real PayPal / NMI response so the operator knows —
 * BEFORE going live — whether their keys actually authenticate.
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/gateways/paypal-api.php';
require_admin_json();

header('Content-Type: application/json');

/** Raw PayPal OAuth probe for a mode — returns [ok, http, error, desc]. */
function _gv_paypal_oauth(string $mode): array {
    $cid = trim((string)setting_get('gw_paypal_client_id_' . $mode, ''));
    $sec = trim((string)setting_get('gw_paypal_secret_' . $mode, ''));
    if ($cid === '' || $sec === '') {
        return ['ok' => false, 'configured' => false, 'error' => 'No ' . strtoupper($mode) . ' Client ID / Secret saved.'];
    }
    $ch = curl_init(paypal_api_base($mode) . '/v1/oauth2/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $cid . ':' . $sec,
        CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
        CURLOPT_TIMEOUT => 25, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $j = json_decode($body, true) ?: [];
    if ($http === 200 && !empty($j['access_token'])) {
        // Also confirm a browser client-token (needed for inline card fields).
        $ct = paypal_client_token($mode);
        return [
            'ok' => true, 'configured' => true,
            'client_token' => $ct !== '',
            'acdc' => paypal_acdc_eligible($mode),
            'client_id_len' => strlen($cid), 'secret_len' => strlen($sec),
        ];
    }
    return [
        'ok' => false, 'configured' => true, 'http' => $http,
        'error' => (string)($j['error'] ?? 'auth_failed'),
        'desc'  => (string)($j['error_description'] ?? 'PayPal rejected these credentials.'),
        'client_id_len' => strlen($cid), 'secret_len' => strlen($sec),
    ];
}

/** Lightweight NMI key probe — a malformed sale so no charge occurs; we only
 *  read whether NMI recognises the security key. */
function _gv_nmi_probe(string $mode): array {
    $key = trim((string)setting_get('gw_nmi_security_key_' . $mode, ''));
    if ($key === '') return ['ok' => false, 'configured' => false, 'error' => 'No ' . strtoupper($mode) . ' NMI security key saved.'];
    $endpoint = trim((string)setting_get('gw_nmi_endpoint', '')) ?: 'https://secure.nmi.com/api/transact.php';
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => http_build_query(['type' => 'validate', 'security_key' => $key]),
        CURLOPT_TIMEOUT => 25, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    curl_close($ch);
    parse_str($body, $r);
    $txt = strtolower((string)($r['responsetext'] ?? ''));
    // "authentication failed" / "api key not found" => bad key. Anything else
    // (e.g. missing card fields) means the key itself authenticated.
    $badKey = (strpos($txt, 'authentication failed') !== false) || (strpos($txt, 'api key not found') !== false);
    return [
        'ok' => !$badKey, 'configured' => true,
        'key_recognised' => !$badKey,
        'nmi_response' => (string)($r['responsetext'] ?? 'no response'),
    ];
}

$in   = json_decode(file_get_contents('php://input'), true) ?: [];
$mode = ($in['mode'] ?? setting_get('gw_mode', 'test')) === 'live' ? 'live' : 'test';

$out = [
    'ok'   => true,
    'mode' => $mode,
    'paypal' => _gv_paypal_oauth($mode),
];
if ((string)setting_get('gw_card_provider_type', '') === 'nmi') {
    $out['nmi'] = _gv_nmi_probe($mode);
}

// Human-readable verdict per gateway.
$msgs = [];
$pp = $out['paypal'];
if (!($pp['configured'] ?? false)) {
    $msgs[] = 'PayPal (' . strtoupper($mode) . '): not configured — ' . ($pp['error'] ?? '');
} elseif ($pp['ok']) {
    $msgs[] = 'PayPal (' . strtoupper($mode) . '): credentials valid ✓ (Client ID ' . $pp['client_id_len'] . ' chars · Secret ' . $pp['secret_len'] . ' chars)';
    if (empty($pp['client_token'])) {
        $msgs[] = 'PayPal (' . strtoupper($mode) . '): a browser client-token could NOT be generated — inline card fields will not appear.';
    } elseif ($pp['acdc'] === false) {
        $msgs[] = 'PayPal (' . strtoupper($mode) . '): inline card fields NOT active yet — PayPal\'s SDK still reports "branded card only" for this Client ID. If "Advanced Credit and Debit Card Payments" is ticked under Features on developer.paypal.com, PayPal\'s CDN can keep the old copy for up to 3 hours — re-run this check later. Until then customers pay by card via the PayPal button (guest card on PayPal\'s page).';
    } elseif ($pp['acdc'] === true) {
        $msgs[] = 'PayPal (' . strtoupper($mode) . '): Advanced Card Fields enabled — inline card box ready ✓';
    } else {
        $msgs[] = 'PayPal (' . strtoupper($mode) . '): could not read card-field eligibility from the PayPal SDK (network) — open the checkout to confirm.';
    }
} else {
    $msgs[] = 'PayPal (' . strtoupper($mode) . '): INVALID credentials — PayPal says "' . ($pp['desc'] ?? $pp['error'] ?? 'auth failed') .
        '". Re-copy the full ' . strtoupper($mode) . ' Client ID & Secret from developer.paypal.com (Secret length saved = ' . ($pp['secret_len'] ?? 0) . ' chars).';
}
if (isset($out['nmi'])) {
    $nmi = $out['nmi'];
    if (!($nmi['configured'] ?? false)) $msgs[] = 'NMI (' . strtoupper($mode) . '): no security key saved.';
    elseif ($nmi['ok']) $msgs[] = 'NMI (' . strtoupper($mode) . '): security key recognised ✓';
    else $msgs[] = 'NMI (' . strtoupper($mode) . '): key rejected — "' . ($nmi['nmi_response'] ?? '') . '".';
}
$out['messages'] = $msgs;

echo json_encode($out, JSON_UNESCAPED_SLASHES);
