<?php
// Admin-only live refresh for the order page: current open state of every
// email sent to this order's customer (polled so the timeline turns green the
// moment the customer really opens the email — no page reload needed).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/order-open-state.php';
require_admin();
header('Content-Type: application/json');
header('Cache-Control: no-store');

$id = (int)($_GET['id'] ?? 0);
$pdo = db();
$oq = $pdo->prepare('SELECT id, email FROM orders WHERE id=?');
$oq->execute([$id]);
$o = $oq->fetch(PDO::FETCH_ASSOC);
if (!$o) { http_response_code(404); echo json_encode(['ok' => false, 'error' => 'Order not found']); exit; }

$em = $pdo->prepare('SELECT id, recipient, subject, status, created_at, delivered_at, opened_at, opened_count FROM email_outbox WHERE order_id=? ORDER BY created_at DESC');
$em->execute([$id]);
$st = mv_order_open_state($o, $em->fetchAll(PDO::FETCH_ASSOC));

$rows = [];
foreach ($st['log'] as $l) $rows[(string)$l['id']] = mv_render_thread_open_note($st, (int)$l['id']);

echo json_encode([
    'ok'            => true,
    'sig'           => $st['sig'],
    'latest_opened' => $st['latest_opened'],
    'node_date'     => $st['latest_opened']
        ? date('M j, Y H:i', strtotime((string)$st['latest_opened_at']))
        : ($st['cust_sent'] ? 'Not opened yet — waiting for the customer' : '— pending —'),
    'log_html'      => mv_render_open_log($st),
    'badge_html'    => mv_render_open_badge($st),
    'rows'          => $rows,
], JSON_UNESCAPED_SLASHES);
