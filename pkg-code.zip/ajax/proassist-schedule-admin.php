<?php
// ProAssist install-call schedule — admin actions endpoint.
// Allowed: update_status (pending/confirmed/done/missed/cancelled),
// update_notes (free-text note from the specialist).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email.php';  // send_email() for the confirm reminder
require_admin_json();  // 403 JSON for non-admins — status changes must be staff-only

header('Content-Type: application/json');

$in     = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$action = $in['action'] ?? '';
$pdo    = db();

$validStatus = ['pending','confirmed','done','missed','cancelled'];

if ($action === 'update_status') {
    $id     = (int)($in['id'] ?? 0);
    $status = (string)($in['status'] ?? '');
    if (!$id || !in_array($status, $validStatus, true)) {
        echo json_encode(['ok' => false, 'error' => 'Invalid input']);
        exit;
    }
    $st = $pdo->prepare("UPDATE proassist_schedules SET status=? WHERE id=?");
    $st->execute([$status, $id]);
    $statusChanged = $st->rowCount() > 0;
    if (!$statusChanged) {
        // No row changed — either the id doesn't exist or it's already at this
        // status. Confirm existence so a bogus id can't return a false success.
        $chk = $pdo->prepare("SELECT COUNT(*) FROM proassist_schedules WHERE id=?");
        $chk->execute([$id]);
        if ((int)$chk->fetchColumn() === 0) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'error' => 'Schedule not found']);
            exit;
        }
    }
    echo json_encode(['ok' => true, 'status' => $status]);

    // Customer reminder: when the specialist CONFIRMS the install time, email
    // the customer their scheduled call details. Only fire on a REAL transition
    // into 'confirmed' (statusChanged) so a repeat click never re-sends it.
    if ($status === 'confirmed' && $statusChanged) {
        try {
            $row = $pdo->prepare('SELECT customer_name, customer_email, scheduled_at, scheduled_utc, tz, order_number FROM proassist_schedules WHERE id=? LIMIT 1');
            $row->execute([$id]);
            $s = $row->fetch();
            if ($s && filter_var((string)$s['customer_email'], FILTER_VALIDATE_EMAIL)) {
                $tz = (string)($s['tz'] ?: 'America/New_York');
                try {
                    $utc  = new DateTime((string)$s['scheduled_utc'], new DateTimeZone('UTC'));
                    $when = (clone $utc)->setTimezone(new DateTimeZone($tz))->format('l, F j, Y');
                } catch (Throwable $e) {
                    $when = date('l, F j, Y', strtotime((string)$s['scheduled_at']));
                }
                $brand  = brand_name();
                // Support phone pulled from Admin → Company Info so it always
                // reflects the latest number (SITE_PHONE resolves from it).
                $phone  = trim((string) setting_get('company_phone', '')) ?: (defined('SITE_PHONE') ? SITE_PHONE : '');
                $name   = htmlspecialchars((string)($s['customer_name'] ?: 'there'), ENT_QUOTES, 'UTF-8');
                $whenE  = htmlspecialchars($when, ENT_QUOTES, 'UTF-8');
                $ordE   = htmlspecialchars((string)$s['order_number'], ENT_QUOTES, 'UTF-8');
                $subject = 'Your ProAssist installation is confirmed — ' . $when;
                $html = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#0f172a">'
                    . '<div style="background:#1d4ed8;padding:18px 22px;border-radius:10px 10px 0 0"><div style="color:#bfdbfe;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase">' . $brand . ' — ProAssist</div><div style="color:#fff;font-size:20px;font-weight:800;margin-top:4px">Your installation call is confirmed &#10003;</div></div>'
                    . '<div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 10px 10px;padding:24px;line-height:1.6;font-size:14px">'
                    . '<p style="margin:0 0 12px">Hi ' . $name . ', great news — your ProAssist Premium Installation for Order #' . $ordE . ' is confirmed.</p>'
                    . '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px 16px;margin:6px 0 16px"><div style="font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.06em;font-weight:700">Your installation day</div><div style="font-size:17px;font-weight:800;color:#1d4ed8;margin-top:4px">' . $whenE . '</div></div>'
                    . '<p style="margin:0 0 6px">Our specialist will call you on this day to complete your setup. Please keep your phone handy — we\'ll confirm the exact time with you.</p>'
                    . ($phone ? '<p style="margin:10px 0 0;font-size:13px;color:#475569">Need to reschedule? Call us at <strong>' . htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') . '</strong> or reply in your order chat.</p>' : '')
                    . '</div></div>';
                if (function_exists('send_email')) send_email((string)$s['customer_email'], $subject, $html, null, 'proassist_confirmed', 0);
            }
        } catch (Throwable $e) { @error_log('[proassist confirm email] ' . $e->getMessage()); }
    }
    exit;
}

if ($action === 'update_notes') {
    $id    = (int)($in['id'] ?? 0);
    $notes = mb_substr(trim((string)($in['notes'] ?? '')), 0, 2000, 'UTF-8');
    if (!$id) {
        echo json_encode(['ok' => false, 'error' => 'Invalid id']);
        exit;
    }
    $pdo->prepare("UPDATE proassist_schedules SET notes=? WHERE id=?")
        ->execute([$notes, $id]);
    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action']);
