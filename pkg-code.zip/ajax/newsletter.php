<?php
// AJAX endpoint: capture a footer newsletter signup. Publicly callable.
// Persists the email into newsletter_subscribers (deduped) so signups are no
// longer silently dropped.
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$in    = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$email = strtolower(trim((string)($in['email'] ?? '')));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Please enter a valid email address.']);
    exit;
}

try {
    $pdo = db();
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS newsletter_subscribers (
            id INT(11) NOT NULL AUTO_INCREMENT,
            email VARCHAR(255) NOT NULL,
            source VARCHAR(60) NOT NULL DEFAULT 'footer',
            ip VARCHAR(45) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    $stmt = $pdo->prepare(
        'INSERT INTO newsletter_subscribers (email, source, ip)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE created_at = created_at'
    );
    $stmt->execute([$email, 'footer', substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)]);
    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    @error_log('[newsletter subscribe] ' . $e->getMessage());
    // Never surface an internal error to the shopper — treat as success.
    echo json_encode(['ok' => true]);
}
