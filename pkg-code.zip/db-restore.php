<?php
/**
 * Database restore helper — imports /database.sql (from the full zip) into the
 * live database WITHOUT ever deleting or overwriting existing rows.
 *
 * The shipped database.sql is merge-safe: no DROP TABLE, CREATE TABLE IF NOT
 * EXISTS, INSERT IGNORE. This page refuses to run any file that is not.
 *
 * HOW TO USE: log into the admin panel, then visit /db-restore.php, check the
 * before/after row counts, click "Restore missing data". Safe to run repeatedly.
 */
require_once __DIR__ . '/includes/functions.php';

$u = function_exists('current_user') ? current_user() : null;
if (!($u && ($u['role'] ?? '') === 'admin')) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Forbidden — please log into the admin panel first, then reload this page.");
}
header('Content-Type: text/html; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
if (empty($_SESSION['mv_dbr_tok'])) $_SESSION['mv_dbr_tok'] = bin2hex(random_bytes(16));
$tok = $_SESSION['mv_dbr_tok'];

$sqlPath = __DIR__ . '/database.sql';
$tables  = ['orders', 'order_items', 'products', 'users', 'settings', 'email_outbox', 'admin_notifications',
            'support_messages', 'chat_leads', 'chat_messages', 'email_templates', 'blog_posts', 'customer_subscriptions'];

function dbr_counts(array $tables): array {
    $out = [];
    foreach ($tables as $t) {
        try { $out[$t] = (int)db()->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); }
        catch (Throwable $e) { $out[$t] = null; }
    }
    return $out;
}
function dbr_statements(string $path): Generator {
    $fh = fopen($path, 'r'); $buf = '';
    while (($line = fgets($fh)) !== false) {
        if ($buf === '' && (preg_match('/^\s*(--|$)/', $line) || str_starts_with($line, '/*M!999999'))) continue;
        $buf .= $line;
        if (preg_match('/;\s*$/', $line)) { yield trim($buf); $buf = ''; }
    }
    if (trim($buf) !== '') yield trim($buf);
    fclose($fh);
}

$fileOk = is_file($sqlPath);
$unsafe = [];
$fileTables = [];
$fileRows = [];
if ($fileOk) {
    foreach (dbr_statements($sqlPath) as $st) {
        if (preg_match('/^(DROP\s+TABLE|TRUNCATE|DELETE\s+FROM|DROP\s+DATABASE|ALTER\s+TABLE\s+`?\w+`?\s+DROP)/i', $st)) $unsafe[] = substr($st, 0, 80);
        if (preg_match('/^CREATE\s+TABLE\s+`/i', $st)) $unsafe[] = 'CREATE TABLE without IF NOT EXISTS: ' . substr($st, 0, 60);
        if (preg_match('/^CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`([^`]+)`/i', $st, $m)) $fileTables[] = $m[1];
        if (preg_match('/^INSERT\s+IGNORE\s+INTO\s+`([^`]+)`\s+VALUES\s*(.*)$/is', $st, $m)) {
            $fileRows[$m[1]] = ($fileRows[$m[1]] ?? 0) + max(1, preg_match_all('/^\(/m', $m[2]), substr_count($m[2], '),(') + 1);
        } elseif (preg_match('/^INSERT\s+INTO/i', $st)) $unsafe[] = 'plain INSERT (would fail on duplicates): ' . substr($st, 0, 60);
    }
}
$before = dbr_counts($tables);
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && hash_equals($tok, (string)($_POST['tok'] ?? ''))) {
    if (($_POST['do'] ?? '') === 'delete_file' && $fileOk) {
        @unlink($sqlPath);
        header('Location: db-restore.php?deleted=1'); exit;
    }
    if (($_POST['do'] ?? '') === 'restore' && $fileOk && !$unsafe) {
        @set_time_limit(0); @ignore_user_abort(true); @ini_set('memory_limit', '512M');
        $pdo = db(); $ok = 0; $err = 0; $errors = []; $t0 = microtime(true);
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach (dbr_statements($sqlPath) as $st) {
            try { $pdo->exec($st); $ok++; }
            catch (Throwable $e) { $err++; if (count($errors) < 10) $errors[] = $e->getMessage() . ' — ' . substr($st, 0, 90); }
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        $result = ['ok' => $ok, 'err' => $err, 'errors' => $errors, 'secs' => round(microtime(true) - $t0, 1), 'after' => dbr_counts($tables)];
    }
}
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Database restore — Maventech</title>
<style>
body{font:15px/1.5 system-ui,Segoe UI,Arial;background:#0f1b33;color:#e5e7eb;margin:0;padding:32px 16px}
.wrap{max-width:860px;margin:0 auto}.card{background:#172447;border:1px solid #27365f;border-radius:14px;padding:22px 24px;margin-bottom:18px}
h1{font-size:22px;margin:0 0 6px}h2{font-size:16px;margin:0 0 10px;color:#9fb7ff}table{width:100%;border-collapse:collapse;font-size:14px}
td,th{padding:7px 10px;border-bottom:1px solid #27365f;text-align:left}th{color:#9fb7ff;font-weight:600}td.num{text-align:right;font-variant-numeric:tabular-nums}
.ok{color:#4ade80}.bad{color:#f87171}.muted{color:#94a3b8}.btn{display:inline-block;background:#1a73e8;color:#fff;border:0;border-radius:999px;padding:10px 22px;font-weight:600;cursor:pointer;font-size:15px}
.btn.gray{background:#334155}.btn:disabled{opacity:.5;cursor:not-allowed}.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:700}
.pill.ok{background:rgba(74,222,128,.15)}.pill.bad{background:rgba(248,113,113,.15)}code{background:#0b1430;padding:2px 6px;border-radius:6px}
</style></head><body><div class="wrap">
<div class="card"><h1>Database restore</h1>
<p class="muted">Imports <code>database.sql</code> from the site root into your live database. It only <strong>adds missing tables and rows</strong> — it never deletes, drops or overwrites anything that is already there. Safe to run more than once.</p>
<?php if (!empty($_GET['deleted'])): ?><p class="ok">database.sql has been deleted from the server.</p><?php endif; ?>
</div>

<div class="card"><h2>1 · File check</h2>
<?php if (!$fileOk): ?>
  <p class="bad">database.sql was not found in the site root. Upload the full zip and extract it first (or the restore was already finished and the file deleted).</p>
<?php else: ?>
  <p>File: <code>database.sql</code> · <?= $h(number_format(filesize($sqlPath) / 1048576, 1)) ?> MB · dated <?= $h(date('Y-m-d H:i', filemtime($sqlPath))) ?> · <?= count($fileTables) ?> tables inside</p>
  <?php if ($unsafe): ?>
    <p><span class="pill bad">BLOCKED</span> This file contains destructive statements and will NOT be imported:</p>
    <ul class="bad"><?php foreach (array_slice($unsafe, 0, 8) as $s): ?><li><code><?= $h($s) ?></code></li><?php endforeach; ?></ul>
  <?php else: ?>
    <p><span class="pill ok">MERGE-SAFE</span> No DROP / TRUNCATE / DELETE. All tables use <code>CREATE TABLE IF NOT EXISTS</code>, all data uses <code>INSERT IGNORE</code>.</p>
  <?php endif; ?>
<?php endif; ?>
</div>

<div class="card"><h2>2 · Row counts</h2>
<table><tr><th>Table</th><th class="num">In database.sql</th><th class="num">Live now</th><?php if ($result): ?><th class="num">After restore</th><th class="num">Added</th><?php endif; ?></tr>
<?php foreach ($tables as $t): $b = $before[$t]; $a = $result['after'][$t] ?? null; ?>
<tr><td><?= $h($t) ?></td><td class="num muted"><?= isset($fileRows[$t]) ? number_format($fileRows[$t]) : '—' ?></td>
<td class="num"><?= $b === null ? '<span class="bad">missing</span>' : number_format($b) ?></td>
<?php if ($result): ?><td class="num"><?= $a === null ? '<span class="bad">missing</span>' : number_format($a) ?></td>
<td class="num <?= ($a ?? 0) - ($b ?? 0) > 0 ? 'ok' : 'muted' ?>">+<?= number_format(max(0, ($a ?? 0) - ($b ?? 0))) ?></td><?php endif; ?></tr>
<?php endforeach; ?></table>
<p class="muted" style="margin-top:10px">"Live now" never goes down after a restore — rows that already exist are kept exactly as they are.</p>
</div>

<?php if ($result): ?>
<div class="card"><h2>3 · Result</h2>
<p><span class="pill <?= $result['err'] ? 'bad' : 'ok' ?>"><?= $result['err'] ? 'FINISHED WITH ERRORS' : 'DONE' ?></span>
<?= number_format($result['ok']) ?> statements applied<?= $result['err'] ? ', ' . $result['err'] . ' failed' : '' ?> in <?= $h($result['secs']) ?>s.</p>
<?php if ($result['errors']): ?><ul class="bad"><?php foreach ($result['errors'] as $e): ?><li><?= $h($e) ?></li><?php endforeach; ?></ul><?php endif; ?>
<form method="post" style="margin-top:12px"><input type="hidden" name="tok" value="<?= $h($tok) ?>"><input type="hidden" name="do" value="delete_file">
<button class="btn gray" type="submit" onclick="return confirm('Delete database.sql from the server? Your database keeps everything — this only removes the import file.')">Delete database.sql from server (recommended)</button></form>
</div>
<?php elseif ($fileOk && !$unsafe): ?>
<div class="card"><h2>3 · Run</h2>
<form method="post"><input type="hidden" name="tok" value="<?= $h($tok) ?>"><input type="hidden" name="do" value="restore">
<button class="btn" type="submit">Restore missing data</button>
<span class="muted" style="margin-left:12px">Takes a few seconds. Keep this tab open until the result appears.</span></form>
</div>
<?php endif; ?>
<p class="muted"><a href="admin.php" style="color:#9fb7ff">← Back to admin</a></p>
</div></body></html>
