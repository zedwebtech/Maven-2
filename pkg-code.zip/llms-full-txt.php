<?php
/**
 * /llms-full.txt — the EXPANDED AI / LLM context document (llmstxt.org spec).
 *
 * Where /llms.txt is a curated *index* (links + one-line product blurbs), this
 * companion inlines the FULL content of every key resource — company facts,
 * the complete product catalogue with specs + descriptions, every policy
 * (refund / return / shipping / payment / privacy / terms), activation &
 * installation guides, FAQs and blog bodies — so a generative engine can
 * ingest the entire store in a single fetch without following links.
 *
 * Served at /llms-full.txt and /.well-known/llms-full.txt via router.php.
 *
 * FAST PATH: the AI Auto-Blogger rebuilds and caches this file to
 * /llms-full.txt once per 24h (gated by `seo_bot_last_llms_full_txt_at`).
 * When that cache is fresh we serve it verbatim so heavy hits are instant;
 * otherwise we render live from the DB (and links are always sanitised).
 */
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: public, max-age=3600');

$cachePath = __DIR__ . '/llms-full.txt';
$lastAi    = (string)setting_get('seo_bot_last_llms_full_txt_at', '');
if ($lastAi && is_readable($cachePath)) {
    $ageH = (time() - strtotime($lastAi)) / 3600;
    if ($ageH <= 25) {
        $cached = (string)file_get_contents($cachePath);
        // Only trust the cache if it still carries the required agent guidance.
        if (stripos($cached, 'When to use') !== false) {
            header('X-LLMs-Source: ai-auto-blogger');
            header('X-LLMs-Generated-At: ' . $lastAi);
            echo function_exists('mv_llms_sanitize_links') ? mv_llms_sanitize_links($cached) : $cached;
            exit;
        }
    }
}

header('X-LLMs-Source: live-template-full');
require_once __DIR__ . '/includes/llms-full-builder.php';
echo mv_build_llms_full_txt();
