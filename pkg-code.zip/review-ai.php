<?php
// AI-powered review comment generator — uses Emergent LLM key (OpenAI-compatible).
// Default: single suggestion. With ?count=3 returns three varied suggestions
// (customers can pick the one that best matches their experience).
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json');

$rating  = max(1, min(5, (int)($_GET['rating'] ?? 5)));
$product = trim($_GET['product'] ?? 'this product');
$count   = max(1, min(3, (int)($_GET['count'] ?? 1)));

// Per-rating fallback library (3 variations per rating). Used when no API key
// is configured or when the LLM call fails — so the customer ALWAYS sees
// suggestions and the UX never breaks.
$fallback = [
    1 => [
        "{$product} didn't meet my expectations — activation was a hassle.",
        "Disappointed with {$product}. The license was slow to arrive.",
        "Not what I hoped for. {$product} had activation issues.",
    ],
    2 => [
        "{$product} works, but setup was more fiddly than it should be.",
        "Product's fine, though delivery and activation felt clunky.",
        "{$product} got there eventually — instructions could be clearer.",
    ],
    3 => [
        "{$product} is okay. Does the job, decent value.",
        "Reasonable experience — activation worked and it runs fine now.",
        "Average overall, but a fair price for what you get.",
    ],
    4 => [
        "Great experience — key worked instantly and setup was easy. Recommend.",
        "Really pleased. Fast delivery and activated on the first try.",
        "Smooth purchase, painless setup, and better value than retail.",
    ],
    5 => [
        "Purchase was easy and smooth — key arrived in minutes and worked perfectly. Highly recommend!",
        "Five stars! Instant delivery, flawless activation, top-notch service.",
        "Couldn't be happier — fast, easy, and everything just worked.",
    ],
];

function ai_pool(int $rating, string $product, int $count): array {
    if (!OPENAI_API_KEY) return [];
    $prompt = $count > 1
        ? "Write $count distinct, authentic customer product reviews for the software product \"$product\". Each review must be SHORT — 1 to 2 sentences, maximum ~25 words, casual and to the point (e.g. 'Purchase was quick and smooth, key worked instantly. Highly recommend.'). The customer rated it $rating out of 5 stars. Match the tone to the rating (1=disappointed, 3=mixed, 5=enthusiastic). First-person voice. No markdown, no numbering. Return ONLY a JSON array of strings, like [\"review1\", \"review2\", \"review3\"]."
        : "Write ONE short, authentic customer product review for the software product \"$product\". Keep it SHORT — 1 to 2 sentences, maximum ~25 words, casual and to the point (e.g. 'Easy, smooth purchase and the key activated right away. Would buy again.'). The customer rated it $rating out of 5 stars. Match the tone to the rating: 1=disappointed, 3=mixed, 5=enthusiastic. No markdown. First-person voice. Return ONLY the review text, no quotes.";

    $ch = curl_init(rtrim(OPENAI_BASE_URL, '/') . '/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST          => true,
        CURLOPT_HTTPHEADER    => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_API_KEY],
        CURLOPT_POSTFIELDS    => json_encode([
            'model'       => OPENAI_MODEL,
            'messages'    => [['role'=>'user','content'=>$prompt]],
            'temperature' => 0.85,
            'max_tokens'  => $count > 1 ? 220 : 80,
        ]),
        CURLOPT_TIMEOUT       => 25,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if (!$resp || $code < 200 || $code >= 300) return [];
    $d    = json_decode($resp, true);
    $text = trim($d['choices'][0]['message']['content'] ?? '');
    if ($text === '') return [];
    if ($count === 1) return [$text];
    // Try parse JSON array; strip code fences if any
    $clean = preg_replace('/^```(?:json)?\s*|\s*```$/m', '', $text);
    $arr   = json_decode($clean, true);
    if (is_array($arr)) {
        $arr = array_values(array_filter(array_map('trim', $arr)));
        if (count($arr) >= 1) return array_slice($arr, 0, $count);
    }
    return [];
}

$pool = ai_pool($rating, $product, $count);
$source = 'ai';
if (count($pool) < $count) {
    // Top up from fallback library
    $needed = $count - count($pool);
    $bag    = $fallback[$rating] ?? $fallback[5];
    foreach (array_slice($bag, 0, $needed) as $item) $pool[] = $item;
    $source = $pool && count($pool) > 0 && empty($pool[0]) ? 'fallback' : (count($pool) > 0 ? 'mixed' : 'fallback');
    if (!OPENAI_API_KEY) $source = 'fallback';
}

if ($count === 1) {
    echo json_encode(['comment' => $pool[0] ?? $fallback[$rating][0], 'source' => $source]);
} else {
    echo json_encode(['suggestions' => array_values($pool), 'source' => $source]);
}
