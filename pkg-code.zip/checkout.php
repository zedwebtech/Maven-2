<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/email.php';
require_once __DIR__ . '/includes/mailer.php';
require_once __DIR__ . '/includes/stripe.php';
require_once __DIR__ . '/includes/recovery.php';
require_once __DIR__ . '/includes/gateways/factory.php';
// QA-FIX (testing agent): stripe_create_session_with_recovery() lives in
// includes/gateways/stripe.php, which factory.php does not eagerly load —
// without this require the Stripe card path fatals (500) at line ~830.
require_once __DIR__ . '/includes/gateways/stripe.php';
// CHECKOUT MODE: format_price() renders in the actual CHARGE currency here (USD
// when the shopper's local currency isn't gateway-live), while the rest of the
// site keeps showing local currency. The "≈ approx local" note explains it.
$GLOBALS['MV_CHECKOUT_MODE'] = true;
$pageTitle = 'Secure Checkout | ' . brand_name();

// ---------------------------------------------------------------------------
// RESUME LINK: /checkout.php?resume=<order_number>&sig=<hmac>
// Restores cart + captured contact from a prior order row (never creates a
// new order — spec: retry re-uses the same order). Refuses when the order
// was admin-cancelled or has already been paid.
// ---------------------------------------------------------------------------
$__resumeOrder    = null;  // used later to render "resumed" banner + reuse this row on submit
$__resumeError    = '';
if (!empty($_GET['resume']) && !empty($_GET['sig'])) {
    $resumeNum = trim((string)$_GET['resume']);
    $resumeSig = trim((string)$_GET['sig']);
    if (mv_verify_resume_signature($resumeNum, $resumeSig)) {
        try {
            $__pdo = db();
            $__q = $__pdo->prepare('SELECT * FROM orders WHERE order_number = ? LIMIT 1');
            $__q->execute([$resumeNum]);
            $__row = $__q->fetch();
            if ($__row) {
                if ((int)($__row['admin_cancelled'] ?? 0) === 1) {
                    $__resumeError = 'This order has been cancelled by the store. Please start a new checkout or contact support.';
                } elseif (($__row['status'] ?? '') === 'paid') {
                    // Already paid — redirect straight to the success page.
                    header('Location: order-success.php?order=' . urlencode($resumeNum));
                    exit;
                } else {
                    // Rehydrate the session cart from stored order_items so the
                    // customer never has to re-add products after a decline.
                    $__ai = $__pdo->prepare('SELECT product_slug, qty FROM order_items WHERE order_id = ?');
                    $__ai->execute([(int)$__row['id']]);
                    $__cart = [];
                    foreach (($__ai->fetchAll() ?: []) as $__it) {
                        // Skip synthetic ProAssist / subscription lines.
                        $sl = (string)$__it['product_slug'];
                        if (str_starts_with($sl, 'proassist-') || str_starts_with($sl, 'sub-')) continue;
                        $__cart[$sl] = ($__cart[$sl] ?? 0) + (int)$__it['qty'];
                    }
                    if ($__cart) $_SESSION['cart'] = $__cart;
                    // Touch activity so the abandoned sweep resets.
                    try { $__pdo->prepare('UPDATE orders SET last_activity_at = NOW() WHERE id = ?')->execute([(int)$__row['id']]); }
                    catch (Throwable $e) { /* best-effort */ }
                    $__resumeOrder = $__row;
                    $_SESSION['mv_resume_order_id'] = (int)$__row['id'];
                }
            } else {
                $__resumeError = 'We couldn\'t find that checkout. Please add your items again.';
            }
        } catch (Throwable $e) {
            $__resumeError = 'We couldn\'t reload your checkout. Please try again.';
        }
    } else {
        $__resumeError = 'That retry link is not valid. Please add your items again or contact support.';
    }
}

// ---------------------------------------------------------------------------
// CANCEL RETURN from Stripe hosted checkout:
//   /checkout.php?cancel=1&session_id={CHECKOUT_SESSION_ID}
// Look up the real last_payment_error via Stripe API, tag the order,
// rehydrate cart, fire failed-payment emails, then render inline banner.
// ---------------------------------------------------------------------------
$__declineBanner = '';   // rendered near the top of the form
$__declineOrder  = null;
if (!empty($_GET['cancel']) && !empty($_GET['session_id'])) {
    $__sid = trim((string)$_GET['session_id']);
    try {
        $__pdo = db();
        // Find the pending order by stripe_session_id.
        $__q = $__pdo->prepare('SELECT * FROM orders WHERE stripe_session_id = ? LIMIT 1');
        $__q->execute([$__sid]);
        $__row = $__q->fetch();
        if ($__row && ($__row['status'] ?? '') !== 'paid') {
            $__gw = mv_gateway('stripe');
            $__verify = $__gw ? $__gw->verifyPayment($__sid) : ['status'=>'unknown','error_code'=>'','error_message'=>'Payment was not completed.','transaction_id'=>''];
            // Even if Stripe still reports 'pending' on cancel_url (session
            // may not have expired yet), we treat this as a failure event
            // so the customer gets an email + banner.
            $__code = (string)$__verify['error_code'];
            $__msg  = (string)$__verify['error_message'];
            // Sanitise raw API / configuration errors that shouldn't be
            // shown to the customer (leaks internal state). Only pass
            // through recognised payment-decline codes; otherwise use the
            // friendly generic message.
            $__isSafeMsg = ($__code !== '' && $__code !== 'unknown');
            if (!$__isSafeMsg
                || stripos($__msg, 'not configured') !== false
                || stripos($__msg, 'api key') !== false
                || stripos($__msg, 'stripe error') !== false) {
                $__msg = 'Payment was cancelled or your card was declined. Nothing was charged — you can retry the payment.';
                if ($__code === '') $__code = 'checkout_cancelled';
            }
            if ($__msg === '') $__msg = 'Payment was cancelled or your card was declined. Please try again.';
            mv_mark_payment_failed($__row, [
                'code'           => $__code !== '' ? $__code : 'checkout_cancelled',
                'message'        => $__msg,
                'transaction_id' => (string)$__verify['transaction_id'],
            ]);
            // Rehydrate cart from order_items so the customer doesn't lose their selection.
            $__ai = $__pdo->prepare('SELECT product_slug, qty FROM order_items WHERE order_id = ?');
            $__ai->execute([(int)$__row['id']]);
            $__cart = [];
            foreach (($__ai->fetchAll() ?: []) as $__it) {
                $sl = (string)$__it['product_slug'];
                if (str_starts_with($sl, 'proassist-') || str_starts_with($sl, 'sub-')) continue;
                $__cart[$sl] = ($__cart[$sl] ?? 0) + (int)$__it['qty'];
            }
            if ($__cart) $_SESSION['cart'] = $__cart;
            $__declineOrder  = $__row;
            $_SESSION['mv_resume_order_id'] = (int)$__row['id'];
            $__declineBanner = $__msg;
        } elseif ($__row && ($__row['status'] ?? '') === 'paid') {
            // Race: webhook already marked paid — send them to success page.
            header('Location: order-success.php?order=' . urlencode((string)$__row['order_number']));
            exit;
        }
    } catch (Throwable $e) {
        @error_log('[checkout cancel handler] ' . $e->getMessage());
        $__declineBanner = 'Your payment could not be completed. Please try again.';
    }
}

/* Region-aware checkout address formats. The visible address form (country
   default, phone dial code, state/province/county label + options, postal
   label + placeholder + validation) adapts to the shopper's selected region
   so an Australian buyer sees "State/Territory" + "Postcode", a Canadian sees
   "Province" + "Postal Code", etc. — instead of the US ZIP/State layout for
   everyone. Single source of truth, shared by the form render, the server-side
   validation and the client-side JS (json_encoded below). */
$REGION_FORMS = [
    'US' => ['country'=>'US','dial'=>'+1','flag'=>'🇺🇸','region_label'=>'State','region_required'=>true,
        'regions'=>['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY','DC','Other'],
        'region_names'=>['AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California','CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','FL'=>'Florida','GA'=>'Georgia','HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa','KS'=>'Kansas','KY'=>'Kentucky','LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland','MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota','MS'=>'Mississippi','MO'=>'Missouri','MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire','NJ'=>'New Jersey','NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota','OH'=>'Ohio','OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island','SC'=>'South Carolina','SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont','VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming','DC'=>'District of Columbia','Other'=>'Other'],
        'postal_label'=>'ZIP Code','postal_ph'=>'90210','postal_re'=>'^\\d{5}(-\\d{4})?$','postal_err'=>'US ZIP must be 5 digits (e.g. 90210).'],
    'CA' => ['country'=>'CA','dial'=>'+1','flag'=>'🇨🇦','region_label'=>'Province','region_required'=>true,
        'regions'=>['AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT'],
        'region_names'=>['AB'=>'Alberta','BC'=>'British Columbia','MB'=>'Manitoba','NB'=>'New Brunswick','NL'=>'Newfoundland and Labrador','NS'=>'Nova Scotia','NT'=>'Northwest Territories','NU'=>'Nunavut','ON'=>'Ontario','PE'=>'Prince Edward Island','QC'=>'Quebec','SK'=>'Saskatchewan','YT'=>'Yukon'],
        'postal_label'=>'Postal Code','postal_ph'=>'K1A 0B1','postal_re'=>'^[A-Za-z]\\d[A-Za-z] ?\\d[A-Za-z]\\d$','postal_err'=>'Enter a valid Canadian postal code (e.g. K1A 0B1).'],
    'UK' => ['country'=>'UK','dial'=>'+44','flag'=>'🇬🇧','region_label'=>'County','region_required'=>false,
        'regions'=>[],
        'postal_label'=>'Postcode','postal_ph'=>'SW1A 1AA','postal_re'=>'^[A-Za-z]{1,2}\\d[A-Za-z\\d]? ?\\d[A-Za-z]{2}$','postal_err'=>'Enter a valid UK postcode (e.g. SW1A 1AA).'],
    'AU' => ['country'=>'AU','dial'=>'+61','flag'=>'🇦🇺','region_label'=>'State/Territory','region_required'=>true,
        'regions'=>['ACT','NSW','NT','QLD','SA','TAS','VIC','WA'],
        'region_names'=>['ACT'=>'Australian Capital Territory','NSW'=>'New South Wales','NT'=>'Northern Territory','QLD'=>'Queensland','SA'=>'South Australia','TAS'=>'Tasmania','VIC'=>'Victoria','WA'=>'Western Australia'],
        'postal_label'=>'Postcode','postal_ph'=>'2000','postal_re'=>'^\\d{4}$','postal_err'=>'Australian postcode must be 4 digits (e.g. 2000).'],
    'EU' => ['country'=>'EU','dial'=>'+49','flag'=>'🇪🇺','region_label'=>'Region / State','region_required'=>false,
        'regions'=>[],
        'postal_label'=>'Postal Code','postal_ph'=>'10115','postal_re'=>'^.{3,}$','postal_err'=>'Postal code is too short.'],
    'IN' => ['country'=>'IN','dial'=>'+91','flag'=>'🇮🇳','region_label'=>'State','region_required'=>true,
        'regions'=>['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi','Jammu and Kashmir','Ladakh','Lakshadweep','Puducherry'],
        'postal_label'=>'PIN Code','postal_ph'=>'110001','postal_re'=>'^\\d{6}$','postal_err'=>'Indian PIN code must be 6 digits (e.g. 110001).'],
];

/* Full ISO country list for the checkout Country dropdown. Countries not in
   $REGION_FORMS above get a generic form config (free-text State/Region + a
   lenient postal validation). Sorted alphabetically for the dropdown. */
$ALL_COUNTRIES = [
    'US'=>'United States','CA'=>'Canada','UK'=>'United Kingdom','AU'=>'Australia',
    'AF'=>'Afghanistan','AL'=>'Albania','DZ'=>'Algeria','AS'=>'American Samoa','AD'=>'Andorra','AO'=>'Angola','AI'=>'Anguilla','AQ'=>'Antarctica','AG'=>'Antigua and Barbuda','AR'=>'Argentina','AM'=>'Armenia','AW'=>'Aruba','AT'=>'Austria','AZ'=>'Azerbaijan',
    'BS'=>'Bahamas','BH'=>'Bahrain','BD'=>'Bangladesh','BB'=>'Barbados','BY'=>'Belarus','BE'=>'Belgium','BZ'=>'Belize','BJ'=>'Benin','BM'=>'Bermuda','BT'=>'Bhutan','BO'=>'Bolivia','BA'=>'Bosnia and Herzegovina','BW'=>'Botswana','BR'=>'Brazil','IO'=>'British Indian Ocean Territory','BN'=>'Brunei','BG'=>'Bulgaria','BF'=>'Burkina Faso','BI'=>'Burundi',
    'KH'=>'Cambodia','CM'=>'Cameroon','CV'=>'Cape Verde','KY'=>'Cayman Islands','CF'=>'Central African Republic','TD'=>'Chad','CL'=>'Chile','CN'=>'China','CX'=>'Christmas Island','CC'=>'Cocos (Keeling) Islands','CO'=>'Colombia','KM'=>'Comoros','CG'=>'Congo','CD'=>'Congo (DRC)','CK'=>'Cook Islands','CR'=>'Costa Rica','CI'=>"Côte d'Ivoire",'HR'=>'Croatia','CU'=>'Cuba','CW'=>'Curaçao','CY'=>'Cyprus','CZ'=>'Czech Republic',
    'DK'=>'Denmark','DJ'=>'Djibouti','DM'=>'Dominica','DO'=>'Dominican Republic',
    'EC'=>'Ecuador','EG'=>'Egypt','SV'=>'El Salvador','GQ'=>'Equatorial Guinea','ER'=>'Eritrea','EE'=>'Estonia','SZ'=>'Eswatini','ET'=>'Ethiopia',
    'FK'=>'Falkland Islands','FO'=>'Faroe Islands','FJ'=>'Fiji','FI'=>'Finland','FR'=>'France','GF'=>'French Guiana','PF'=>'French Polynesia',
    'GA'=>'Gabon','GM'=>'Gambia','GE'=>'Georgia','DE'=>'Germany','GH'=>'Ghana','GI'=>'Gibraltar','GR'=>'Greece','GL'=>'Greenland','GD'=>'Grenada','GP'=>'Guadeloupe','GU'=>'Guam','GT'=>'Guatemala','GG'=>'Guernsey','GN'=>'Guinea','GW'=>'Guinea-Bissau','GY'=>'Guyana',
    'HT'=>'Haiti','HN'=>'Honduras','HK'=>'Hong Kong','HU'=>'Hungary',
    'IS'=>'Iceland','IN'=>'India','ID'=>'Indonesia','IR'=>'Iran','IQ'=>'Iraq','IE'=>'Ireland','IM'=>'Isle of Man','IL'=>'Israel','IT'=>'Italy',
    'JM'=>'Jamaica','JP'=>'Japan','JE'=>'Jersey','JO'=>'Jordan',
    'KZ'=>'Kazakhstan','KE'=>'Kenya','KI'=>'Kiribati','KW'=>'Kuwait','KG'=>'Kyrgyzstan',
    'LA'=>'Laos','LV'=>'Latvia','LB'=>'Lebanon','LS'=>'Lesotho','LR'=>'Liberia','LY'=>'Libya','LI'=>'Liechtenstein','LT'=>'Lithuania','LU'=>'Luxembourg',
    'MO'=>'Macao','MG'=>'Madagascar','MW'=>'Malawi','MY'=>'Malaysia','MV'=>'Maldives','ML'=>'Mali','MT'=>'Malta','MH'=>'Marshall Islands','MQ'=>'Martinique','MR'=>'Mauritania','MU'=>'Mauritius','YT'=>'Mayotte','MX'=>'Mexico','FM'=>'Micronesia','MD'=>'Moldova','MC'=>'Monaco','MN'=>'Mongolia','ME'=>'Montenegro','MS'=>'Montserrat','MA'=>'Morocco','MZ'=>'Mozambique','MM'=>'Myanmar',
    'NA'=>'Namibia','NR'=>'Nauru','NP'=>'Nepal','NL'=>'Netherlands','NC'=>'New Caledonia','NZ'=>'New Zealand','NI'=>'Nicaragua','NE'=>'Niger','NG'=>'Nigeria','NU'=>'Niue','NF'=>'Norfolk Island','KP'=>'North Korea','MK'=>'North Macedonia','MP'=>'Northern Mariana Islands','NO'=>'Norway',
    'OM'=>'Oman',
    'PK'=>'Pakistan','PW'=>'Palau','PS'=>'Palestine','PA'=>'Panama','PG'=>'Papua New Guinea','PY'=>'Paraguay','PE'=>'Peru','PH'=>'Philippines','PN'=>'Pitcairn','PL'=>'Poland','PT'=>'Portugal','PR'=>'Puerto Rico',
    'QA'=>'Qatar',
    'RE'=>'Réunion','RO'=>'Romania','RU'=>'Russia','RW'=>'Rwanda',
    'BL'=>'Saint Barthélemy','SH'=>'Saint Helena','KN'=>'Saint Kitts and Nevis','LC'=>'Saint Lucia','MF'=>'Saint Martin','PM'=>'Saint Pierre and Miquelon','VC'=>'Saint Vincent and the Grenadines','WS'=>'Samoa','SM'=>'San Marino','ST'=>'São Tomé and Príncipe','SA'=>'Saudi Arabia','SN'=>'Senegal','RS'=>'Serbia','SC'=>'Seychelles','SL'=>'Sierra Leone','SG'=>'Singapore','SX'=>'Sint Maarten','SK'=>'Slovakia','SI'=>'Slovenia','SB'=>'Solomon Islands','SO'=>'Somalia','ZA'=>'South Africa','GS'=>'South Georgia','KR'=>'South Korea','SS'=>'South Sudan','ES'=>'Spain','LK'=>'Sri Lanka','SD'=>'Sudan','SR'=>'Suriname','SJ'=>'Svalbard and Jan Mayen','SE'=>'Sweden','CH'=>'Switzerland','SY'=>'Syria',
    'TW'=>'Taiwan','TJ'=>'Tajikistan','TZ'=>'Tanzania','TH'=>'Thailand','TL'=>'Timor-Leste','TG'=>'Togo','TK'=>'Tokelau','TO'=>'Tonga','TT'=>'Trinidad and Tobago','TN'=>'Tunisia','TR'=>'Turkey','TM'=>'Turkmenistan','TC'=>'Turks and Caicos Islands','TV'=>'Tuvalu',
    'UG'=>'Uganda','UA'=>'Ukraine','AE'=>'United Arab Emirates','UY'=>'Uruguay','UZ'=>'Uzbekistan',
    'VU'=>'Vanuatu','VA'=>'Vatican City','VE'=>'Venezuela','VN'=>'Vietnam','VG'=>'British Virgin Islands','VI'=>'U.S. Virgin Islands',
    'WF'=>'Wallis and Futuna','EH'=>'Western Sahara',
    'YE'=>'Yemen',
    'ZM'=>'Zambia','ZW'=>'Zimbabwe',
];
// Sort by country name (keeping the top-4 primary countries pinned at the top)
$__pinned = ['US','CA','UK','AU'];
$__rest = [];
foreach ($ALL_COUNTRIES as $__cc => $__nm) {
    if (!in_array($__cc, $__pinned, true)) $__rest[$__cc] = $__nm;
}
asort($__rest, SORT_NATURAL | SORT_FLAG_CASE);
$ALL_COUNTRIES = array_merge(
    array_intersect_key($ALL_COUNTRIES, array_flip($__pinned)),
    $__rest
);

/* Return the region-form config for ANY country code — falls back to a
   generic (free-text State/Region + lenient postal) config for countries not
   in $REGION_FORMS. */
$__generic_dial = [
    // Common dial codes so at least the phone prefix defaults sensibly.
    'IN'=>'+91','DE'=>'+49','FR'=>'+33','ES'=>'+34','IT'=>'+39','NL'=>'+31','AE'=>'+971','NZ'=>'+64',
    'BR'=>'+55','MX'=>'+52','JP'=>'+81','CN'=>'+86','SG'=>'+65','MY'=>'+60','PH'=>'+63','KR'=>'+82',
    'ID'=>'+62','TH'=>'+66','VN'=>'+84','PK'=>'+92','BD'=>'+880','LK'=>'+94','TR'=>'+90','SA'=>'+966',
    'ZA'=>'+27','EG'=>'+20','NG'=>'+234','KE'=>'+254','RU'=>'+7','UA'=>'+380','PL'=>'+48','SE'=>'+46',
    'NO'=>'+47','DK'=>'+45','FI'=>'+358','BE'=>'+32','CH'=>'+41','AT'=>'+43','PT'=>'+351','IE'=>'+353',
    'GR'=>'+30','CZ'=>'+420','HU'=>'+36','RO'=>'+40',
];
/* Countries with NO postal-code system (UAE, Hong Kong, Ireland-optional, most of the
   Caribbean/Africa/Pacific …). Requiring a ZIP there blocked real buyers with
   "Zip is required." — the field is optional for them (gateway receives it blank). */
$NO_POSTAL = ['AE','HK','IE','MO','QA','AO','AG','AW','BS','BZ','BJ','BW','BF','BI','CM','CF','KM','CG','CD','CK','CI','DJ','DM','GQ','ER','FJ','GM','GH','GD','GN','GY','KI','LY','MW','ML','MR','NR','NU','KP','PA','RW','KN','LC','ST','SC','SL','SB','SO','SR','SY','TZ','TL','TK','TO','TV','UG','VU','YE','ZW','BO','CW','SX','TD','GA','TG','VG','KY','BM','TC','AI','MS','GI','VA','DO'];
$__region_form_for = function(string $cc) use (&$REGION_FORMS, $__generic_dial, $ALL_COUNTRIES, $NO_POSTAL) {
    $cc = strtoupper($cc);
    if (isset($REGION_FORMS[$cc])) return $REGION_FORMS[$cc] + ['postal_required' => true];
    $noPostal = in_array($cc, $NO_POSTAL, true);
    // Generic fallback for any other country in the ISO list.
    return [
        'country' => $cc,
        'dial' => $__generic_dial[$cc] ?? '+1',
        'flag' => '🌐',
        'region_label' => 'State / Region',
        'region_required' => false,
        'regions' => [],
        'postal_required' => !$noPostal,
        'postal_label' => $noPostal ? 'Postal Code (optional)' : 'Postal / ZIP Code',
        'postal_ph' => $noPostal ? '' : '00000',
        'postal_re' => '^.{0,}$',
        'postal_err' => 'Postal code is too short.',
    ];
};
// Build a full-country JS map so client-side region switching works for any country selected.
$JS_REGION_FORMS = [];
foreach (array_keys($ALL_COUNTRIES) as $__cc) {
    $JS_REGION_FORMS[$__cc] = $__region_form_for($__cc);
}
/* Default billing country = the STOREFRONT the shopper is on (/ca → Canada,
   /uk → United Kingdom, /au → Australia, US site → United States), taken from
   the storefront's display currency — NOT the charge currency, which falls
   back to USD whenever the local currency isn't enabled for charging and used
   to flip the default back to United States on the Canadian site. */
$__curToRegion = ['USD'=>'US','CAD'=>'CA','GBP'=>'UK','AUD'=>'AU','EUR'=>'EU'];
$__activeCur   = current_currency()['code'];
$__storeCur    = local_currency()['code'];
$curRegionCC   = $__curToRegion[$__storeCur] ?? ($__curToRegion[$__activeCur] ?? current_country_code());
if (!isset($REGION_FORMS[$curRegionCC])) $curRegionCC = 'US';
// Currencies this store can actually charge in (USD always + any live extras).
// Used client-side so a country change only reloads for a currency switch that
// will really happen — otherwise it just reshapes the address (no revert/data loss).
$__coLiveCur = ['USD'];
foreach (['CAD','GBP','AUD','EUR'] as $__cc9) { if (function_exists('mv_currency_is_live') && mv_currency_is_live($__cc9)) $__coLiveCur[] = $__cc9; }


// Subscription checkout — when a visitor arrives via /subscribe.php the
// session carries the chosen plan.  We synthesise a single line item from the
// plan and bypass the product cart / coupons / ProAssist entirely.
// Bug-fix (2026-07): the regular product cart ALWAYS takes precedence over a
// lingering sub_plan session so a customer who bought a Protection Hub plan,
// then added a Microsoft Office SKU, doesn't get their Office order hijacked
// by the stale plan.  Only fall into plan-only checkout when the cart is
// completely empty.
$subPlan     = !empty($_SESSION['sub_plan']) ? sub_plan_get((string)$_SESSION['sub_plan']) : null;
$hasCartRow  = !empty(cart_items());
$isSub       = $subPlan && (float)$subPlan['price'] > 0 && (int)$subPlan['active'] === 1 && !$hasCartRow;
if (!$isSub && !empty($_SESSION['sub_plan'])) {
    unset($_SESSION['sub_plan']);
    $subPlan = null;
}

if ($isSub) {
    $planAmt   = round((float)$subPlan['price'], 2);
    $items     = [[
        'slug'           => 'sub-' . $subPlan['slug'],
        'name'           => $subPlan['name'] . ' Plan (' . $subPlan['tenure_label'] . ')',
        'price'          => $planAmt,
        'original_price' => null,
        'qty'            => 1,
        'image'          => (string)($subPlan['icon_image'] ?? ''),
    ]];
    $proAssist = false;
    $subtotal  = $planAmt;
    $savings   = 0;
    $couponCode = null; $couponPct = 0; $discount = 0.0;
    $total     = $planAmt;
    $errors    = [];
} else {
    if (!empty($_SESSION['sub_plan'])) unset($_SESSION['sub_plan']);
    $items = cart_items();
    if (!$items) {
        // The last payment went through (browser lost the confirmation, cart
        // already cleared) — take the buyer to the receipt instead of "cart empty".
        // Covers a GET reload AND a re-POST of the paid form (attempt token bound
        // to a PAID order): never render an odd empty checkout after a real sale.
        $__lastPaid = (string)($_SESSION['mv_last_paid_order'] ?? '');
        if ($__lastPaid === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $__at = substr(preg_replace('/[^a-f0-9]/', '', (string)($_POST['co_attempt'] ?? '')), 0, 32);
            if ($__at !== '' && !empty($_SESSION['mv_attempt_order'][$__at])) {
                try {
                    $__aq = db()->prepare('SELECT order_number FROM orders WHERE id = ? AND status = "paid" LIMIT 1');
                    $__aq->execute([(int)$_SESSION['mv_attempt_order'][$__at]]);
                    $__lastPaid = (string)($__aq->fetchColumn() ?: '');
                } catch (Throwable $e) { $__lastPaid = ''; }
            }
        }
        if ($__lastPaid !== '') {
            unset($_SESSION['mv_last_paid_order']);
            $__succUrl = 'order-success.php?order=' . rawurlencode($__lastPaid);
            if (($_POST['pp_card'] ?? '') === '1') {
                header('Content-Type: application/json');
                echo json_encode(['ok' => false, 'code' => 'ALREADY_PAID', 'order' => $__lastPaid, 'redirect' => $__succUrl,
                                  'error' => 'This order has already been paid — taking you to your receipt.'], JSON_UNESCAPED_SLASHES);
                exit;
            }
            header('Location: ' . $__succUrl);
            exit;
        }
        // If the customer just clicked an invalid / cancelled resume link,
        // send them to the cart with a flash message instead of silently
        // dropping the error.
        if ($__resumeError !== '') {
            $_SESSION['flash_error'] = $__resumeError;
        }
        /* 2026-07 FIX — Semrush "80 outgoing internal links contain nofollow
           attribute". The site-wide mini-cart drawer links to /checkout.php on
           every crawled page. Previously we 302-redirected empty-cart hits to
           /cart.php (which drew the earlier "temporary redirect" flag), and
           then rel="nofollow" was added to work around that (which now draws
           this "internal nofollow" flag). Break the cycle: render an inline
           empty-cart page here so the crawler gets a normal 200 response, the
           drawer link doesn't need nofollow, and the page stays out of the
           index via the pre-existing <meta name="robots" content="noindex,
           nofollow"> tag emitted from includes/header.php. Real users still
           see the same "your cart is empty" outcome, just as a rendered page
           instead of a redirect. */
        $pageTitle = 'Your cart is empty | ' . brand_name();
        $noIndex   = true; // belt-and-suspenders — header.php already noindexes checkout.php
        include __DIR__ . '/includes/header.php';
        ?>
        <div class="container py-5 my-md-4">
          <div class="row justify-content-center">
            <div class="col-lg-7 col-xl-6 text-center">
              <div class="p-4 p-md-5 rounded-4 border bg-body-tertiary" data-testid="checkout-empty-cart">
                <div class="mb-3" style="font-size:3rem;line-height:1;">
                  <i class="bi bi-bag" aria-hidden="true"></i>
                </div>
                <h1 class="h3 fw-bold mb-2">Your cart is empty</h1>
                <p class="text-secondary mb-4">
                  Add a product to your cart before continuing to checkout.
                </p>
                <div class="d-flex flex-wrap gap-2 justify-content-center">
                  <a href="shop.php" class="btn btn-primary rounded-pill px-4" data-testid="checkout-empty-shop">
                    <i class="bi bi-shop me-1"></i>Browse products
                  </a>
                  <a href="cart.php" class="btn btn-outline-secondary rounded-pill px-4" data-testid="checkout-empty-view-cart">
                    <i class="bi bi-cart me-1"></i>View cart
                  </a>
                </div>
                <?php if ($__resumeError !== ''): ?>
                <div class="alert alert-warning small mt-4 mb-0" role="alert" data-testid="checkout-empty-resume-error">
                  <?= esc($__resumeError) ?>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php
        include __DIR__ . '/includes/footer.php';
        exit;
    }
    unset($_SESSION['mv_last_paid_order']); // a new cart = a new purchase
    // ProAssist Premium Installation (paid remote-install + 1-yr support
    // add-on). Opt-in is captured on the cart page and stored in the session;
    // the order flow below bills it, creates the install lead, notifies admin
    // and emails the team.
    $proAssist = !empty($_SESSION['proassist']);
    // When resuming/retrying an existing pending order (e.g. after a declined
    // payment), the session flag is already cleared — re-derive the add-on
    // from the persisted order row so the summary + total stay consistent with
    // what was actually saved/charged.
    if (!$proAssist) {
        $__paRow = $__resumeOrder;
        if (!$__paRow && !empty($_SESSION['mv_resume_order_id'])) {
            try {
                $__paStmt = db()->prepare('SELECT pro_assist FROM orders WHERE id = ? LIMIT 1');
                $__paStmt->execute([(int)$_SESSION['mv_resume_order_id']]);
                $__paRow = $__paStmt->fetch() ?: null;
            } catch (Throwable $e) { $__paRow = null; }
        }
        if ($__paRow && (int)($__paRow['pro_assist'] ?? 0) === 1) $proAssist = true;
    }
    if (!proassist_enabled()) $proAssist = false;  // admin toggled the add-on off
    $subtotal = cart_subtotal();
    // Savings from list prices
    $savings = 0;
    foreach ($items as $i) {
        if ($i['original_price'] && $i['original_price'] > $i['price']) {
            $savings += ($i['original_price'] - $i['price']) * $i['qty'];
        }
    }
    // Coupon (set via ajax/cart.php action=coupon): percent comes from the coupons() map
    $couponCode = $_SESSION['coupon'] ?? null;
    $couponPct = $couponCode ? (int)($_SESSION['coupon_pct'] ?? (coupons()[$couponCode] ?? 20)) : 0;
    $discount = $couponCode ? round($subtotal * $couponPct / 100, 2) : 0.0;
    $total = $subtotal - $discount + ($proAssist ? proassist_price() : 0);
    $errors = [];
}

// Which payment methods are actually AVAILABLE (admin toggle ON and, in LIVE
// mode, real credentials saved). Drives both the rendered UI (never show a
// field the shopper cannot use) and the server-side method guard below.
$__gwModeNow    = setting_get('gw_mode', 'test') === 'live' ? 'live' : 'test';
$_cardEnabled   = card_enabled()   && ($__gwModeNow !== 'live' || card_gateway_configured());
$_paypalEnabled = paypal_enabled() && ($__gwModeNow !== 'live' || paypal_configured('live'));
// PayPal Advanced Card Fields (inline card box) — needs a client id + the admin
// switch "Show card fields under PayPal". When NMI card is OFF but this is ON,
// the checkout shows its own "Pay with Credit/Debit Card" tile powered by PayPal.
$ppClientId  = $_paypalEnabled ? trim((string)setting_get('gw_paypal_client_id_' . $__gwModeNow, '')) : '';
$ppShowCards = setting_get('gw_paypal_show_cards', '1') !== '0';
$ppCardsOn   = ($ppClientId !== '' && $ppShowCards);
$__ppCardTile = (!$_cardEnabled && $_paypalEnabled && $ppCardsOn);

// PayPal v5 CardFields (inline card box) require a server-generated CLIENT
// TOKEN on the SDK <script> tag (data-client-token) to be eligible in LIVE.
// Generate it once and cache in the session for ~9 min so we don't hit PayPal
// on every checkout render. Empty on failure → the JS falls back to the button.
$ppClientToken = '';
if ($ppCardsOn) {
    require_once __DIR__ . '/includes/gateways/paypal-api.php';
    $__ctKey = 'pp_client_token_' . $__gwModeNow;
    if (!empty($_SESSION[$__ctKey]) && (time() - (int)($_SESSION[$__ctKey . '_ts'] ?? 0)) < 540) {
        $ppClientToken = (string)$_SESSION[$__ctKey];
    } else {
        $ppClientToken = paypal_client_token($__gwModeNow);
        if ($ppClientToken !== '') { $_SESSION[$__ctKey] = $ppClientToken; $_SESSION[$__ctKey . '_ts'] = time(); }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // DOUBLE-CHARGE GUARD: every checkout render carries a one-off attempt token
    // that is bound to the order it creates. If the browser lost the success
    // response (network blip) and re-submits the SAME page, the bound order is
    // already PAID → send the buyer to the receipt instead of charging again.
    $__attempt = substr(preg_replace('/[^a-f0-9]/', '', (string)($_POST['co_attempt'] ?? '')), 0, 32);
    if ($__attempt !== '' && !empty($_SESSION['mv_attempt_order'][$__attempt])) {
        try {
            $__aq = db()->prepare('SELECT order_number FROM orders WHERE id = ? AND status = "paid" LIMIT 1');
            $__aq->execute([(int)$_SESSION['mv_attempt_order'][$__attempt]]);
            if ($__paidNum = $__aq->fetchColumn()) {
                $__succUrl = 'order-success.php?order=' . rawurlencode((string)$__paidNum);
                if (($_POST['pp_card'] ?? '') === '1') {
                    header('Content-Type: application/json');
                    echo json_encode(['ok' => false, 'code' => 'ALREADY_PAID', 'order' => (string)$__paidNum, 'redirect' => $__succUrl,
                                      'error' => 'This order has already been paid — taking you to your receipt.'], JSON_UNESCAPED_SLASHES);
                    exit;
                }
                header('Location: ' . $__succUrl);
                exit;
            }
        } catch (Throwable $e) { /* fall through to the normal flow */ }
    }
    $postCC = strtoupper(trim($_POST['country'] ?? 'US'));
    if (!isset($ALL_COUNTRIES[$postCC])) $postCC = 'US';
    $postRF = $__region_form_for($postCC);
    $required = ['email', 'first_name', 'last_name', 'phone', 'address', 'city'];
    if (!array_key_exists('postal_required', $postRF) || !empty($postRF['postal_required'])) $required[] = 'zip';
    if (!empty($postRF['region_required'])) $required[] = 'state';
    foreach ($required as $f) {
        if (trim($_POST[$f] ?? '') === '') $errors[] = ucwords(str_replace('_', ' ', $f)) . ' is required.';
    }
    if (!filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    $method = ($_POST['payment_method'] ?? 'card') === 'paypal' ? 'paypal' : 'card';
    // Reject methods the admin has disabled (defence-in-depth — hides UI AND blocks API spoofing)
    if ($method === 'card'   && !$_cardEnabled)   $errors[] = 'Card payments are currently unavailable. Please choose another method.';
    if ($method === 'paypal' && !$_paypalEnabled) $errors[] = 'PayPal is currently unavailable. Please choose another method.';

    // Server-side mirror of the JS guards in checkout.php — defence-in-depth
    // against API spoofing or JS-disabled browsers.  We can only validate
    // the fields that are actually POSTed; card details (number/exp/cvv) are
    // intentionally not posted (no `name` attr) — they go straight to the
    // gateway's PCI-compliant page, so card validation lives there.
    if (!$errors || count($errors) < 5) {
        // Email — RFC validity already checked, now check deliverability via
        // DNS MX + typo dictionary (same helper the JS hint uses).
        $emailVal = trim($_POST['email'] ?? '');
        if ($emailVal !== '' && filter_var($emailVal, FILTER_VALIDATE_EMAIL)
            && trim($_POST['email_override'] ?? '') !== '1') {
        // Email deliverability is now ADVISORY ONLY — a transient DNS/MX lookup
        // failure on a perfectly valid address must never block a paying
        // customer. RFC-syntax validity (checked above) is the only hard gate;
        // the JS hint still nudges obvious typos before submit.
        // (No $errors added here on purpose.)
        }
        // Billing address: required (non-empty, enforced above) but we do NOT
        // hard-block on a completeness heuristic. These are DIGITAL goods (no
        // shipping), so a legitimate address without an obvious street number
        // must never stop a good payment — let the bank/AVS decide.
        $addrVal = trim($_POST['address'] ?? '');
        // Postal / ZIP: accept any non-empty value. We no longer reject on a
        // per-country format regex — a valid but unusual postal code should
        // never block a customer whose card is good (the gateway does AVS).
        $zipVal     = trim($_POST['zip'] ?? '');
        $countryVal = strtoupper(trim($_POST['country'] ?? 'US'));
        if (!isset($ALL_COUNTRIES[$countryVal])) $countryVal = 'US';
        $rfPost = $__region_form_for($countryVal);
        // Phone length is ADVISORY ONLY — never block a good card over a phone
        // format. (No $errors added.)
        $phoneDigits = preg_replace('/\D/', '', (string)($_POST['phone'] ?? ''));
        // State / province — ADVISORY ONLY. Even if the value isn't in our
        // fixed list, we never block the sale (the gateway/AVS decides); we just
        // store what the customer entered.
        $stateVal = trim($_POST['state'] ?? '');
    }

    // ---- Card gate: runs BEFORE any order row exists --------------------
    // Bots / scanners post the checkout form with no card data at all. The
    // old order of operations inserted the "pending" order first and only
    // then noticed the missing card, leaving ghost pending orders (no last4,
    // no expiry) in Admin → Orders. For the direct-charge gateways (NMI /
    // Authorize.Net / custom) card details are mandatory: either an NMI
    // Collect.js token or a Luhn-valid number + future expiry + CVV must be
    // present, otherwise the request stops here and nothing is written.
    if (!$errors && $method === 'card') {
        $__gateProv   = card_active_provider();
        $__gateDirect = in_array($__gateProv, ['nmi', 'authnet', 'custom'], true);
        if ($__gateDirect && card_gateway_configured()) {
            $__gateTok = ($__gateProv === 'nmi') ? trim((string)($_POST['payment_token'] ?? '')) : '';
            $__gateNum = preg_replace('/\D/', '', (string)($_POST['card_number'] ?? ''));
            $__gateExp = trim((string)($_POST['card_exp'] ?? ''));
            $__gateCvv = preg_replace('/\D/', '', (string)($_POST['card_cvv'] ?? ''));
            if ($__gateTok === '') {
                if ($__gateNum === '' || $__gateExp === '' || $__gateCvv === '') {
                    $errors[] = 'Please enter your card number, expiry date and security code to complete the payment.';
                } else {
                    $__gateErr = mv_validate_card_fields($__gateNum, $__gateExp, $__gateCvv);
                    if ($__gateErr !== '') $errors[] = $__gateErr;
                }
                if ($errors) {
                    @error_log('[checkout card-gate] blocked order creation without valid card details from '
                        . ($_SERVER['REMOTE_ADDR'] ?? '?') . ' (' . substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 80) . ')');
                }
            }
        }
    }

    if ($errors && ($_POST['pp_card'] ?? '') === '1') {
        // Inline PayPal card flow talks JSON — return the exact validation
        // errors instead of the full HTML page (which the JS cannot parse).
        header('Content-Type: application/json');
        http_response_code(422);
        echo json_encode(['ok' => false, 'code' => 'VALIDATION', 'error' => implode(' ', array_unique($errors))], JSON_UNESCAPED_SLASHES);
        exit;
    }
    if (($_POST['pp_card'] ?? '') === '1' && !paypal_configured(stripe_active_mode())) {
        header('Content-Type: application/json');
        http_response_code(503);
        echo json_encode(['ok' => false, 'code' => 'NOT_CONFIGURED', 'error' => 'Card payments via PayPal are not fully configured (PayPal secret missing for ' . strtoupper(stripe_active_mode()) . ' mode). Nothing was charged — please choose another payment method or contact us.'], JSON_UNESCAPED_SLASHES);
        exit;
    }

    if (!$errors) {
        $pdo = db();
        $user = current_user();
        $__phoneNat = trim((string)($_POST['phone'] ?? ''));
        $phoneFull = $__phoneNat !== '' ? trim(($_POST['phone_code'] ?? '+1') . ' ' . $__phoneNat) : ''; // optional field: never store a bare dial code
        $activeMode = stripe_active_mode(); // 'test' or 'live' — captured at order creation

        // RESUME PATH: if the customer arrived via a valid resume link OR
        // came back from Stripe's cancel_url, we already have an orders row.
        // Never create a duplicate — reuse it and just refresh the fields.
        $__resumeId = (int)($_SESSION['mv_resume_order_id'] ?? 0);
        $__reuseOrder = null;
        if ($__resumeId > 0) {
            try {
                $__q = $pdo->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
                $__q->execute([$__resumeId]);
                $__row = $__q->fetch();
                if ($__row && ($__row['status'] ?? '') !== 'paid' && (int)($__row['admin_cancelled'] ?? 0) === 0) {
                    // MONEY-SAFETY: reuse the pending order ONLY if it still matches
                    // the cart the shopper is looking at (same items/qty, same
                    // ProAssist choice, same total in the order's currency). After
                    // a decline the shopper may have added/removed products or
                    // applied a coupon — charging the OLD stored total would bill
                    // an amount they never saw. On any mismatch: fresh order.
                    $__oi = $pdo->prepare('SELECT product_slug, qty FROM order_items WHERE order_id = ?');
                    $__oi->execute([(int)$__row['id']]);
                    $__sigOrder = []; $__orderPA = false;
                    foreach (($__oi->fetchAll() ?: []) as $__it) {
                        $__sl = (string)$__it['product_slug'];
                        if (str_starts_with($__sl, 'proassist-')) { $__orderPA = true; continue; }
                        $__sigOrder[$__sl] = ($__sigOrder[$__sl] ?? 0) + (int)$__it['qty'];
                    }
                    $__sigCart = [];
                    foreach ($items as $__ci) {
                        $__sl = (string)($__ci['slug'] ?? '');
                        $__sigCart[$__sl] = ($__sigCart[$__sl] ?? 0) + (int)($__ci['qty'] ?? 1);
                    }
                    ksort($__sigOrder); ksort($__sigCart);
                    $__rc   = strtoupper((string)($__row['currency'] ?? '')) ?: (string)current_currency()['code'];
                    $__rr   = (float)($GLOBALS['CURRENCIES'][$__rc]['rate'] ?? ($__rc === (string)current_currency()['code'] ? current_currency()['rate'] : 1.0));
                    if (!is_finite($__rr) || $__rr <= 0) $__rr = 1.0;
                    $__expTotal = round($total * $__rr, 2);
                    $__stoTotal = round((float)($__row['total'] ?? 0), 2);
                    $__match = ($__sigOrder === $__sigCart) && ($__orderPA === (bool)$proAssist)
                            && ($__stoTotal <= 0 || abs($__stoTotal - $__expTotal) < 0.011);
                    if ($__match) {
                        $__reuseOrder = $__row;
                    } else {
                        @error_log('[checkout] order ' . ($__row['order_number'] ?? $__resumeId) . ' not reused: cart changed since the last attempt (stored ' . $__rc . ' ' . $__stoTotal . ' vs cart ' . $__expTotal . ')');
                        unset($_SESSION['mv_resume_order_id']);
                    }
                }
            } catch (Throwable $e) { /* fall through */ }
        }

        if ($__reuseOrder) {
            $orderId     = (int)$__reuseOrder['id'];
            $orderNumber = (string)$__reuseOrder['order_number'];
            // Refresh contact / address fields from the current POST so a
            // customer who retries with a fixed address doesn't get the stale
            // one on Stripe or in the delivery email.
            $pdo->prepare('UPDATE orders SET
                email = ?, first_name = ?, last_name = ?, phone = ?,
                address = ?, address2 = ?, country = ?, city = ?, state = ?, zip = ?,
                payment_method = ?, last_activity_at = NOW()
                WHERE id = ?')
                ->execute([
                    trim($_POST['email']), trim($_POST['first_name']), trim($_POST['last_name']),
                    $phoneFull, trim($_POST['address']), trim($_POST['address2'] ?? ''),
                    substr(strtoupper(trim($_POST['country'] ?? 'US')), 0, 2), trim($_POST['city']),
                    trim($_POST['state']), trim($_POST['zip']), $method,
                    $orderId,
                ]);
            // MONEY-SAFETY (RESUME/RETRY PATH): these charge amounts were ONLY
            // computed when CREATING a brand-new order (the else branch below).
            // On a resume/retry (a first decline, or a retry-email link) we land
            // here instead, so $chargeTotal was left UNDEFINED → cast to 0.0 at
            // the charge call → the gateway received a ZERO amount and declined a
            // perfectly good card with "Invalid amount". Compute them here too.
            // Prefer the order's already-stored total (authoritative, in the
            // currency the customer already agreed to); fall back to the live
            // cart conversion only if the stored value is blank.
            $__cur    = current_currency();
            // Charge in the currency the order was CREATED in (stored on the row),
            // even if the shopper switched region between attempts — the stored
            // total is in that currency, so amount + currency always agree.
            $__ccode  = strtoupper((string)($__reuseOrder['currency'] ?? '')) ?: (string)$__cur['code'];
            $__crate  = (float)($GLOBALS['CURRENCIES'][$__ccode]['rate'] ?? ($__cur['rate'] ?? 1.0));
            if (!is_finite($__crate) || $__crate <= 0) $__crate = 1.0;
            $__chargeCurrency = $__ccode;
            $chargeSubtotal = round((float)($__reuseOrder['subtotal'] ?? 0), 2) ?: round($subtotal * $__crate, 2);
            $chargeTotal    = round((float)($__reuseOrder['total']    ?? 0), 2) ?: round($total    * $__crate, 2);
            $chargeDiscount = round($discount * $__crate, 2);
        } else {
            $orderNumber = generate_order_number();
            // MONEY-SAFETY: the cart ($subtotal/$total) is always in USD base and
            // format_price() converts it for DISPLAY. The amount we actually CHARGE
            // and STORE must be in the presentment currency (current_currency()):
            //   • currency OFF / not gateway-live  → presentment = USD, rate 1.0
            //     → we charge the true USD price (NEVER the local-currency number).
            //   • currency ON / gateway-live        → presentment = CAD/GBP/…, so we
            //     charge the CONVERTED amount (e.g. USD 365 → CA$500), matching what
            //     the shopper sees. Both directions are exact — no over/under charge.
            $__cur    = current_currency();
            // Rate guard: `?? 1.0` only catches NULL — a currency row with a
            // blank/0/negative rate would make $chargeTotal 0 and trigger a
            // gateway "invalid amount" for a perfectly good card. Force any
            // non-positive rate back to 1.0 (charge the true USD price) so an
            // internal config gap can NEVER zero-out or corrupt the amount.
            $__crate  = (float) ($__cur['rate'] ?? 1.0);
            if (!is_finite($__crate) || $__crate <= 0) $__crate = 1.0;
            $__chargeCurrency = (string)$__cur['code'];
            $chargeSubtotal = round($subtotal * $__crate, 2);
            $chargeTotal    = round($total * $__crate, 2);
            $chargeDiscount = round($discount * $__crate, 2);
            $stmt = $pdo->prepare('INSERT INTO orders (order_number, email, first_name, last_name, phone, company_name, address, address2, country, city, state, zip, payment_method, currency, subtotal, total, pro_assist, user_id, gw_mode, payment_status, last_activity_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
            $stmt->execute([
                $orderNumber, trim($_POST['email']), trim($_POST['first_name']), trim($_POST['last_name']),
                $phoneFull, '', trim($_POST['address']), trim($_POST['address2'] ?? ''),
                substr(strtoupper(trim($_POST['country'] ?? 'US')), 0, 2), trim($_POST['city']), trim($_POST['state']), trim($_POST['zip']),
                $method, $__cur['code'], $chargeSubtotal, $chargeTotal, $proAssist ? 1 : 0, $user['id'] ?? null, $activeMode, 'pending',
            ]);
            $orderId = (int)$pdo->lastInsertId();
        }
        if ($__attempt !== '') {
            $__map = is_array($_SESSION['mv_attempt_order'] ?? null) ? $_SESSION['mv_attempt_order'] : [];
            $__map[$__attempt] = $orderId;
            $_SESSION['mv_attempt_order'] = array_slice($__map, -20, null, true);
        }
        // Persist a retry_token on first creation so admin views + emails
        // reference a stable value.  We reuse the HMAC (over order_number)
        // so no separate secret / column-lookup is needed at verify time.
        try { $pdo->prepare('UPDATE orders SET retry_token = ? WHERE id = ? AND (retry_token IS NULL OR retry_token = "")')
                ->execute([substr(mv_sign_order_number($orderNumber), 0, 40), $orderId]); }
        catch (Throwable $e) { /* best-effort */ }
        // Mark this order as a subscription purchase so fulfilment runs the
        // subscription path (record + customer ID + certificate) instead of
        // the license-key delivery flow.
        if ($isSub && $subPlan) {
            try { $pdo->prepare('UPDATE orders SET subscription_plan=? WHERE id=?')->execute([$subPlan['slug'], $orderId]); }
            catch (Throwable $e) { /* column self-heals via sub_migrate */ }
        }
        // Capture session metadata for the Sales Detail view (IP, user-agent → device)
        try {
            $clientIp = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
            if (strpos($clientIp, ',') !== false) $clientIp = trim(explode(',', $clientIp)[0]);
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 400);
            /* Change 6 — persist Google click IDs (gclid / gbraid / wbraid) +
               landing URL captured on the first page view (includes/header.php
               stashes them in the session) onto the order row. Stored inside
               the existing `timeline` JSON column (zero-DDL) so they survive as
               a fallback for server-side / offline conversion import even when
               the browser tag is blocked. */
            $__clickIds = $_SESSION['mv_click_ids'] ?? null;
            $__timeline = ['user_agent' => $ua, 'placed_at' => date('c')];
            if (is_array($__clickIds) && $__clickIds) $__timeline['click_ids'] = $__clickIds;
            $__orderRegion = function_exists('mv_region_for_currency') ? mv_region_for_currency((string)($__chargeCurrency ?? ''), active_region_code()) : active_region_code();
            $pdo->prepare("UPDATE orders SET ip_address = ?, timeline = ?, region = ? WHERE id = ?")
                ->execute([$clientIp, json_encode($__timeline), $__orderRegion, $orderId]);
            // Chargeback evidence: device + IP geolocation snapshot
            if (function_exists('mv_capture_order_forensics')) {
                mv_capture_order_forensics((int)$orderId, (string)$clientIp, (string)$ua);
            }
        } catch (Throwable $e) { /* metadata is best-effort */ }
        $itemStmt = $pdo->prepare('INSERT INTO order_items (order_id, product_slug, name, price, qty) VALUES (?,?,?,?,?)');
        // For resumed orders we already have order_items; only insert on fresh orders.
        if (!$__reuseOrder) {
            foreach ($items as $i) {
                $itemStmt->execute([$orderId, $i['slug'], $i['name'], $i['price'], $i['qty']]);
            }
        }

        // NOTE: the admin "new sale/order" bell notification is intentionally
        // NOT fired here (order creation happens BEFORE payment). Firing it now
        // would ring the bell for declined/abandoned checkouts. The bell entry
        // is fired once, only on a CONFIRMED-PAID order, from
        // notify_company_of_sale() inside fulfill_order().
        // ProAssist side-effects (add-on line item, install lead, admin
        // "install" notification + opt-in email) run ONCE per order — only on
        // a fresh order, never on a resumed/retried one, to avoid duplicates.
        if ($proAssist && !$__reuseOrder) {
            $itemStmt->execute([$orderId, 'proassist-premium', 'ProAssist Premium Installation', proassist_price(), 1]);
            // NOTE: ProAssist activation (install lead, welcome chat, pending
            // schedule, admin notify, team email) moved to fulfill_order() ->
            // proassist_activate_on_paid() so it fires ONLY after payment is
            // confirmed. The block below is intentionally disabled here.
            if (false) {
            // Surface this customer in Lead Management so the support team
            // can proactively reach out and schedule the installation call.
            // We treat ProAssist as an inbound "callback requested" lead
            // keyed off the order number + email, so admins can search/
            // chat / assign right from the existing Leads tab.
            try {
                $proName  = trim(trim($_POST['first_name']) . ' ' . trim($_POST['last_name']));
                $proCty   = substr(strtoupper(trim($_POST['country'] ?? 'US')), 0, 2);
                $proMsg   = 'ProAssist Premium Installation requested — Order #' . $orderNumber
                          . ' · Total: ' . current_currency()['code'] . ' ' . number_format($chargeTotal ?? $total, 2)
                          . ' · Schedule the install call within one business day.';
                $proToken = bin2hex(random_bytes(20));
                $pdo->prepare('INSERT INTO chat_leads
                    (session_id, name, email, phone, callback_requested, message, requested_product, country, chat_token)
                    VALUES (?,?,?,?,1,?,?,?,?)')
                    ->execute([
                        session_id(),
                        $proName ?: 'ProAssist customer',
                        trim($_POST['email']),
                        $phoneFull,
                        $proMsg,
                        'ProAssist Premium Installation',
                        $proCty,
                        $proToken,
                    ]);
                // Pre-fill the chat thread with an automated welcome so the
                // customer lands in an "active conversation" the moment they
                // open the widget on order-success.php.  Inserted as
                // sender='admin' so the customer-side poller picks it up and
                // appends it as a bot/agent bubble.
                $proLeadId = (int)$pdo->lastInsertId();
                try { $pdo->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([client_ip(), $proLeadId]); } catch (Throwable $e) {}
                $proFirst  = trim(explode(' ', $proName)[0] ?? '');
                $proWelcome = 'Hi' . ($proFirst ? ' ' . $proFirst : '')
                            . "! Your ProAssist Premium Installation is confirmed \u{2713} for Order #" . $orderNumber . '. '
                            . 'Our specialist will call you on your registered number ' . ($phoneFull ?: 'on file')
                            . ' to schedule and complete your installation. '
                            . "Need us to use a different number? Just reply here with the new number and we'll update it right away.";
                $pdo->prepare('INSERT INTO chat_messages (lead_id, sender, message) VALUES (?,?,?)')
                    ->execute([$proLeadId, 'admin', $proWelcome]);
                // Tell the admin PWA bell: a new ProAssist install must be scheduled.
                admin_notify(
                    'install',
                    'New install to schedule — Order ' . $orderNumber,
                    ($proName ?: 'A customer') . ' purchased ProAssist Premium Installation. Reach out within 1 business hour.',
                    '/admin.php?tab=leads&id=' . $proLeadId
                );
                // Auto-create a PENDING install-schedule row so it lands in
                // Admin → Install Schedule immediately (using the checkout
                // phone). A placeholder slot (next business morning, EST) is
                // set which the specialist adjusts when they call/confirm.
                try {
                    $estTz    = new DateTimeZone('America/New_York');
                    $slotLoc  = new DateTime('tomorrow 10:00', $estTz);
                    $slotAt   = $slotLoc->format('Y-m-d H:i:s');
                    $slotUtc  = (clone $slotLoc)->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
                    $pdo->prepare(
                        'INSERT INTO proassist_schedules
                            (lead_id, order_id, order_number, customer_name, customer_email, customer_phone, scheduled_at, scheduled_utc, tz, status)
                         VALUES (?,?,?,?,?,?,?,?,?,\'pending\')
                         ON DUPLICATE KEY UPDATE
                            order_id=VALUES(order_id), order_number=VALUES(order_number),
                            customer_name=VALUES(customer_name), customer_email=VALUES(customer_email),
                            customer_phone=VALUES(customer_phone)'
                    )->execute([
                        $proLeadId, $orderId, $orderNumber,
                        $proName ?: 'ProAssist customer', trim($_POST['email']), $phoneFull,
                        $slotAt, $slotUtc, 'America/New_York',
                    ]);
                } catch (Throwable $e) { @error_log('[proassist auto-schedule] ' . $e->getMessage()); }
                // Bind the chat token to this browser session so the chat
                // widget on order-success.php auto-connects (no lead form
                // shown — we already have name/email/phone).
                $_SESSION['lead_id']   = $proLeadId;
                $_SESSION['chat_token'] = $proToken;
            } catch (Throwable $e) { /* lead-creation is best-effort */ }

            // Email the company's registered address the moment a customer
            // OPTS IN to ProAssist at checkout (separate from the later
            // "install scheduled" alert).  Recipient resolves from Company
            // Info → support/company email, then ADMIN_EMAIL fallback.
            try {
                $toEmail = trim((string)setting_get('company_support_email', ''));
                if ($toEmail === '') $toEmail = trim((string)setting_get('company_email', ''));
                if ($toEmail === '' && defined('ADMIN_EMAIL')) $toEmail = (string)ADMIN_EMAIL;
                if ($toEmail !== '') {
                    $brand    = brand_name();
                    $siteUrl  = function_exists('site_url') ? rtrim(site_url(), '/') : '';
                    $cName    = htmlspecialchars($proName ?: 'Customer', ENT_QUOTES, 'UTF-8');
                    $cEmail   = htmlspecialchars(trim($_POST['email'] ?? ''), ENT_QUOTES, 'UTF-8');
                    $cPhone   = htmlspecialchars($phoneFull ?? '', ENT_QUOTES, 'UTF-8') ?: '(no phone)';
                    $ordTxt   = htmlspecialchars($orderNumber, ENT_QUOTES, 'UTF-8');
                    $totTxt   = htmlspecialchars(current_currency()['code'] . ' ' . number_format($chargeTotal ?? $total, 2), ENT_QUOTES, 'UTF-8');
                    $adminLnk = $siteUrl . '/admin.php?tab=leads&id=' . (int)($proLeadId ?? 0);
                    $subject  = '[ProAssist] New install request — Order ' . $orderNumber . ' — ' . ($proName ?: $cEmail);
                    $html = <<<HTML
<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:620px;margin:0 auto;color:#0f172a">
  <div style="background:#0f172a;padding:18px 22px;border-radius:10px 10px 0 0;">
    <div style="font-size:11px;letter-spacing:.12em;font-weight:800;text-transform:uppercase;color:#fcd34d;">{$brand} — ProAssist</div>
    <div style="font-size:20px;font-weight:800;color:#fff;margin-top:4px;">New ProAssist install request — action needed</div>
  </div>
  <div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 10px 10px;padding:24px;line-height:1.55;">
    <p style="margin:0 0 14px 0;font-size:14px;">A customer just <strong>opted into ProAssist Premium Installation</strong> at checkout. Reach out within one business hour to schedule the install call.</p>
    <table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 18px 0;">
      <tr><td style="padding:7px 0;color:#64748b;width:140px;">Order</td><td style="padding:7px 0;font-weight:700;">#{$ordTxt}</td></tr>
      <tr><td style="padding:7px 0;color:#64748b;">Order total</td><td style="padding:7px 0;">{$totTxt}</td></tr>
      <tr><td style="padding:7px 0;color:#64748b;">Customer</td><td style="padding:7px 0;">{$cName}</td></tr>
      <tr><td style="padding:7px 0;color:#64748b;">Email</td><td style="padding:7px 0;"><a href="mailto:{$cEmail}" style="color:#2563eb;text-decoration:none;">{$cEmail}</a></td></tr>
      <tr><td style="padding:7px 0;color:#64748b;">Phone</td><td style="padding:7px 0;"><a href="tel:{$cPhone}" style="color:#2563eb;text-decoration:none;">{$cPhone}</a></td></tr>
    </table>
    <a href="{$adminLnk}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:11px 22px;border-radius:8px;font-weight:700;font-size:14px;">Open in admin &rsaquo;</a>
    <p style="margin:22px 0 0 0;font-size:12px;color:#64748b;">Automated notification from {$brand}. Update the recipient in Admin → Company Info.</p>
  </div>
</div>
HTML;
                    send_email($toEmail, $subject, $html, null, 'proassist_optin', 0);
                }
            } catch (Throwable $e) { @error_log('[checkout proassist optin email] ' . $e->getMessage()); }
            } // end if(false) — ProAssist activation moved to fulfill_order()
        }
        // Cart/session cleanup is DEFERRED until after a charge succeeds (or the
        // buyer is redirected to a hosted gateway). This ensures a declined card
        // never empties the basket — the shopper can retry from a full cart.
        $mvClearCart = static function (): void {
            $_SESSION['cart'] = [];
            unset($_SESSION['coupon'], $_SESSION['sub_plan'], $_SESSION['proassist']);
        };

        // Which card gateway PROVIDER is active? (stripe|authnet|nmi|custom)
        // Selecting a provider in Admin → API / Payment Gateway → Card
        // activates it as the real processor for card payments.
        $cardProvider = ($method === 'card') ? card_active_provider() : 'stripe';
        $directCharge = ($method === 'card' && in_array($cardProvider, ['nmi','authnet','custom'], true));

        require_once __DIR__ . '/includes/gateways/paypal-api.php';

        if ($method === 'paypal' && paypal_configured($activeMode)) {
            // -------- Real PayPal Checkout (Orders API v2) --------
            // Create a PayPal order and redirect the buyer to PayPal to approve.
            // The actual capture (and marking the order paid) happens on return
            // in paypal-return.php — we NEVER mark paid before capture COMPLETED.
            $rbase     = rtrim(site_url(), '/');
            $returnUrl = $rbase . '/paypal-return.php?order=' . rawurlencode($orderNumber);
            $cancelUrl = $rbase . '/checkout.php?paypal=cancel';
            // Build a normalised item list so PayPal shows real product
            // names/descriptions on its review screen + the buyer's receipt
            // (fixes the "-" placeholder previously seen in the receipt).
            // Unit prices are converted to the CHARGE currency (same rate as
            // $chargeTotal) and the ProAssist add-on is listed as its own line
            // so item_total always reconciles with the amount actually billed.
            $ppItemsPayload = [];
            foreach ($items as $ii) {
                $ppItemsPayload[] = [
                    'slug'        => (string)($ii['slug'] ?? ''),
                    'name'        => (string)($ii['name'] ?? 'Item'),
                    'description' => (string)($ii['name'] ?? ''),
                    'price'       => round((float)($ii['price'] ?? 0) * $__crate, 2),
                    'qty'         => (int)($ii['qty'] ?? 1),
                    'sku'         => (string)($ii['slug'] ?? ''),
                ];
            }
            if ($proAssist && !$isSub) {
                $ppItemsPayload[] = [
                    'slug'        => 'proassist-premium',
                    'name'        => 'ProAssist Premium Installation',
                    'description' => 'Remote installation + 1 year priority support',
                    'price'       => round(proassist_price() * $__crate, 2),
                    'qty'         => 1,
                    'sku'         => 'proassist-premium',
                ];
            }
            $ppFirst   = (string)($items[0]['name'] ?? 'Order');
            $ppRest    = max(0, count($items) - 1);
            $ppDesc    = 'Order ' . $orderNumber . ' — ' . $ppFirst
                       . ($ppRest > 0 ? ' + ' . $ppRest . ' more item' . ($ppRest > 1 ? 's' : '') : '');
            // RETRY SAFETY: if this order already has a PayPal order and PayPal
            // says it WAS captured (the browser lost the confirmation), settle it
            // now — never create a second PayPal order and charge the buyer twice.
            $__ppHandled = false;
            if ($__reuseOrder && str_starts_with((string)($__reuseOrder['transaction_id'] ?? ''), 'PP:')) {
                $__prev = paypal_reconcile_order(substr((string)$__reuseOrder['transaction_id'], 3), $activeMode);
                if ($__prev !== null && !empty($__prev['ok'])) {
                    $__ppHandled = true;
                    $__settled = paypal_settle_order($__reuseOrder, $__prev, 'retry_reconcile');
                    $__succUrl = 'order-success.php?order=' . rawurlencode($orderNumber);
                    if (($_POST['pp_card'] ?? '') === '1') {
                        header('Content-Type: application/json');
                        echo json_encode(['ok' => false, 'code' => 'ALREADY_PAID', 'order' => $orderNumber, 'redirect' => !empty($__settled['ok']) ? $__succUrl : '',
                            'error' => !empty($__settled['ok']) ? 'This order has already been paid — taking you to your receipt.' : (string)($__settled['error'] ?? '')], JSON_UNESCAPED_SLASHES);
                        exit;
                    }
                    if (!empty($__settled['ok'])) { $mvClearCart(); header('Location: ' . $__succUrl); exit; }
                    $errors[] = (string)($__settled['error'] ?? 'This payment needs manual review — please contact support and do not pay again.');
                }
            }
            if (!$__ppHandled) {
            try {
                $pp = paypal_create_order(
                    (float)$chargeTotal,
                    $__chargeCurrency,
                    $orderNumber,
                    $returnUrl,
                    $cancelUrl,
                    $activeMode,
                    $ppItemsPayload,
                    (float)$chargeSubtotal,
                    (float)$chargeDiscount,
                    $ppDesc,
                    ['card_fields' => (($_POST['pp_card'] ?? '') === '1'),
                     'buyer' => [
                        'first' => trim((string)($_POST['first_name'] ?? '')),
                        'last'  => trim((string)($_POST['last_name'] ?? '')),
                        'email' => trim((string)($_POST['email'] ?? '')),
                     ]]
                );
            } catch (Throwable $e) {
                @error_log('[checkout paypal] ' . $e->getMessage());
                $pp = ['ok'=>false, 'error'=>'A PayPal error occurred. Please try again.'];
            }
            if (!empty($pp['ok'])) {
                // Stash the PayPal order id on our order so the return handler
                // can capture it (prefixed PP: so it is easy to identify).
                $pdo->prepare('UPDATE orders SET transaction_id = ?, last_activity_at = NOW() WHERE id = ?')
                    ->execute(['PP:' . $pp['id'], $orderId]);
                $_SESSION['mv_resume_order_id'] = $orderId;
                // Inline "pay by card as guest" (PayPal CardFields): do NOT redirect
                // or clear the cart yet — return the PayPal order id so the browser
                // CardFields component can submit + capture. Cart clears on capture.
                if (($_POST['pp_card'] ?? '') === '1') {
                    header('Content-Type: application/json');
                    echo json_encode(['ok' => true, 'id' => $pp['id'], 'order' => $orderNumber], JSON_UNESCAPED_SLASHES);
                    exit;
                }
                $mvClearCart();
                header('Location: ' . $pp['approve']);
                exit;
            }
            $_SESSION['mv_resume_order_id'] = $orderId;
            if (($_POST['pp_card'] ?? '') === '1') {
                header('Content-Type: application/json');
                http_response_code(502);
                echo json_encode(['ok' => false, 'error' => (string)($pp['error'] ?? 'PayPal is temporarily unavailable. Please try again.')], JSON_UNESCAPED_SLASHES);
                exit;
            }
            $errors[] = (string)($pp['error'] ?? 'PayPal is temporarily unavailable. Please try again or choose another payment method.');
            } /* !$__ppHandled */
        } elseif ($directCharge && card_gateway_configured() && mv_direct_charge_live_ready($cardProvider, $activeMode)) {
            // -------- Server-side direct charge (NMI / Authorize.Net / Custom) --------
            $orderStmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
            $orderStmt->execute([$orderId]);
            $orderRow = $orderStmt->fetch() ?: [];
            $cardNum = preg_replace('/\D/', '', (string)($_POST['card_number'] ?? ''));
            $cardExp = trim((string)($_POST['card_exp'] ?? ''));
            $cardCvv = preg_replace('/\D/', '', (string)($_POST['card_cvv'] ?? ''));
            // Collect.js (NMI hosted fields): the browser posts ONLY a single-use
            // payment_token + display-safe metadata — never the PAN / expiry / CVV.
            $payToken = ($cardProvider === 'nmi') ? trim((string)($_POST['payment_token'] ?? '')) : '';
            $tokenMeta = $payToken !== '' ? mv_token_card_meta() : ['bin'=>'','last4'=>'','brand'=>'','exp'=>''];
            // Universal card-field validation for the raw direct-charge gateways
            // (NMI classic / Authorize.Net / custom). Hosted flows post a token
            // (NMI Collect.js) or redirect (Stripe), so they skip this.
            $cardValErr = ($payToken === '' && $directCharge) ? mv_validate_card_fields($cardNum, $cardExp, $cardCvv) : '';
            if ($payToken === '' && ($cardNum === '' || $cardExp === '' || $cardCvv === '')) {
                $errors[] = 'Please enter your card number, expiry date and security code to complete the payment.';
                $_SESSION['mv_resume_order_id'] = $orderId;
            } elseif ($cardValErr !== '') {
                $errors[] = $cardValErr;
                $_SESSION['mv_resume_order_id'] = $orderId;
            } else {
                $billing = [
                    'first_name' => trim((string)($_POST['first_name'] ?? '')),
                    'last_name'  => trim((string)($_POST['last_name'] ?? '')),
                    'address1'   => trim((string)($_POST['address'] ?? '')),
                    'city'       => trim((string)($_POST['city'] ?? '')),
                    'state'      => trim((string)($_POST['state'] ?? '')),
                    'zip'        => trim((string)($_POST['zip'] ?? '')),
                    'country'    => mv_gateway_country_code((string)($_POST['country'] ?? 'US')) ?: 'US',
                    'email'      => trim((string)($_POST['email'] ?? '')),
                ];
                try {
                    $charge = mv_card_charge($cardProvider, $orderRow,
                        $payToken !== '' ? ['token'=>$payToken] : ['number'=>$cardNum, 'exp'=>$cardExp, 'cvv'=>$cardCvv],
                        $billing, (float)$chargeTotal, $items);
                } catch (Throwable $e) {
                    @error_log('[checkout ' . $cardProvider . ' charge] ' . $e->getMessage());
                    $charge = ['status'=>'failed','error_code'=>'exception',
                               'error_message'=>'A payment processing error occurred. No charge was made — please try again.',
                               'transaction_id'=>'','auth_code'=>'','raw'=>[]];
                }
                if (($charge['status'] ?? '') === 'succeeded') {
                    // MONEY-SAFE ZONE: the card was charged at the gateway. From
                    // here on, an INTERNAL glitch (DB hiccup, fulfilment error)
                    // must NEVER show the customer an error or lose the sale —
                    // we mark paid best-effort, log a reconciliation alert if
                    // anything trips, and always land the buyer on success.
                    $txnId = (string)($charge['transaction_id'] ?? '');
                    try {
                        if ($payToken !== '') {
                            $last4 = $tokenMeta['last4']; $brand = $tokenMeta['brand'];
                            $cardBin = $tokenMeta['bin']; $expStr = $tokenMeta['exp'];
                        } else {
                            $last4 = substr($cardNum, -4);
                            $brand = mv_detect_card_brand($cardNum);
                            [$expMM, $expYY] = mv_parse_exp($cardExp);
                            $expStr = $expMM . '/' . $expYY;
                            // Capture PCI-safe card metadata for the admin "Credit Card
                            // Information" panel: BIN (first 6) + gateway CVV match status.
                            $cardBin = substr($cardNum, 0, 6);
                        }
                        $chargeRaw = is_array($charge['raw'] ?? null) ? $charge['raw'] : [];
                        $cvvStatus = mv_cvv_status_label((string)(
                            $chargeRaw['cvvresponse'] ?? $chargeRaw['cvvResultCode'] ?? ($charge['cvv_response'] ?? '')
                        ));
                        $pdo->prepare('UPDATE orders SET status = "paid", payment_status = "succeeded", payment_error_code = NULL, payment_error_message = NULL, transaction_id = ?, card_brand = ?, card_last4 = ?, card_bin = ?, card_cvv_status = ?, card_exp = ?, last_activity_at = NOW() WHERE id = ?')
                            ->execute([$txnId, $brand, $last4, $cardBin, $cvvStatus, $expStr, $orderId]);
                    } catch (Throwable $e) {
                        // The charge SUCCEEDED but we could not persist "paid".
                        // Log LOUDLY for reconciliation; do NOT fail the buyer.
                        @error_log('[checkout CRITICAL paid-but-not-persisted] order=' . $orderNumber . ' id=' . $orderId . ' txn=' . $txnId . ' :: ' . $e->getMessage());
                        try {
                            $pdo->prepare('UPDATE orders SET status = "paid", payment_status = "succeeded", transaction_id = ?, last_activity_at = NOW() WHERE id = ?')
                                ->execute([$txnId, $orderId]);
                        } catch (Throwable $e2) { /* already logged above */ }
                    }
                    try {
                        $pdo->prepare('INSERT INTO transaction_logs (order_id, gateway, transaction_id, amount, currency, status, raw_response) VALUES (?,?,?,?,?,?,?)')
                            ->execute([
                                $orderId, $cardProvider, $txnId,
                                (float)($charge['charged_amount'] ?? ($chargeTotal ?? $total)), (string)($charge['charged_currency'] ?? ($__chargeCurrency ?? current_currency()['code'])), 'succeeded',
                                json_encode(array_merge(is_array($charge['raw'] ?? null) ? $charge['raw'] : [], mv_attempt_card_meta_arr()), JSON_UNESCAPED_SLASHES),
                            ]);
                    } catch (Throwable $e) { /* logging is best-effort */ }
                    unset($_SESSION['mv_resume_order_id']);
                    $_SESSION['mv_last_paid_order'] = $orderNumber;
                    try { $mvClearCart(); } catch (Throwable $e) { /* non-critical */ }
                    // Fulfilment is best-effort — order is paid; the success page
                    // + admin can re-deliver if this hiccups. Never 500 a paid buyer.
                    try { mv_safe_fulfill($orderId); }
                    catch (Throwable $e) { @error_log('[checkout fulfil after paid] order=' . $orderNumber . ' :: ' . $e->getMessage()); }
                    header('Location: order-success.php?order=' . urlencode($orderNumber));
                    exit;
                } else {
                    // Declined / error — the SINGLE failure funnel below logs
                    // the attempt (one row), tags the order, rings the admin
                    // bell and emails both the customer + admin. We deliberately
                    // do NOT insert our own transaction_logs row here anymore —
                    // that produced a duplicate "Failed" + "Bank declined" pair
                    // for a single decline.
                    $declineMsg = (string)($charge['error_message'] ?? '') ?: 'Your card was declined by your bank. No charge was made — approve the payment with your bank if asked, then retry.';
                    if (function_exists('mv_mark_payment_failed')) {
                        mv_mark_payment_failed($orderRow, [
                            'code'           => (string)($charge['error_code'] ?? 'declined'),
                            'message'        => $declineMsg,
                            'transaction_id' => (string)($charge['transaction_id'] ?? ''),
                            'gateway'        => $cardProvider,
                            'raw_response'   => json_encode($charge['raw'] ?? [], JSON_UNESCAPED_SLASHES),
                        ] + mv_attempt_card_meta_arr($payToken !== '' ? null : $cardNum));
                    }
                    $_SESSION['mv_resume_order_id'] = $orderId;
                    mv_capture_card_meta($pdo, $orderId); // PCI-safe brand/BIN/last4 so admin sees WHICH card was declined
                    $errors[] = 'Payment declined: ' . $declineMsg;
                }
            }
        } elseif ($method === 'card' && !$directCharge && stripe_enabled()) {
            // Real payment path. The key in use is mode-aware:
            //  · gw_mode='test'  ⇒ sk_test_*  ⇒ Stripe test/sandbox (no real charge)
            //  · gw_mode='live'  ⇒ sk_live_*  ⇒ real funds move
            // We additionally guard against the misconfiguration where the
            // admin flipped to LIVE but only test keys are configured — that
            // would silently send real customers to a sandbox checkout.
            $secretInUse = stripe_active_secret();
            if ($activeMode === 'live' && (str_starts_with($secretInUse, 'sk_test_') || str_contains($secretInUse, 'emergent'))) {
                $errors[] = 'Payment gateway is set to LIVE mode but no live API key is configured. An admin must paste a Stripe sk_live_* key under Admin → API / Payment Gateway → Card → Live keys before real payments can be processed.';
            } else {
                $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $baseUrl = $proto . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/';
                try {
                    $orderStmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
                    $orderStmt->execute([$orderId]);
                    $orderRow = $orderStmt->fetch();
                    // Pass items so Stripe Checkout shows real product names +
                    // descriptions on its hosted page and receipt email
                    // (fixes the "-" placeholder previously shown by gateways).
                    $session = stripe_create_session_with_recovery($orderRow, $baseUrl, $items, (float)$subtotal, (float)$discount);
                    $pdo->prepare('UPDATE orders SET stripe_session_id = ?, payment_status = COALESCE(NULLIF(payment_status, ""), "pending"), last_activity_at = NOW() WHERE id = ?')
                        ->execute([$session['id'], $orderId]);
                    unset($_SESSION['mv_resume_order_id']);
                    $mvClearCart();
                    header('Location: ' . $session['url']);
                    exit;
                } catch (RuntimeException $e) {
                    $errors[] = 'Payment error: ' . $e->getMessage();
                }
            }
        }
        if ($errors === []) {
            if ($activeMode === 'live') {
                // LIVE mode but NO real payment gateway configured for the
                // active provider. We must NEVER fake a successful charge on a
                // live store — show a clear "not configured" error and stop.
                $provLabel = $method === 'paypal' ? 'PayPal' : strtoupper($cardProvider);
                $errors[] = 'Payment gateway not configured. The selected ' . ($method === 'paypal' ? 'PayPal gateway' : $provLabel . ' card gateway') . ' has no live credentials saved — no charge was made. Please contact us to complete your order. (An administrator must configure the live gateway credentials under Admin → API / Payment Gateway.)';
            } else {
                // TEST / sandbox mode (no live gateway contacted). We must
                // STILL behave like a real processor for card payments — a
                // declined or invalid card must be refused and deliver NOTHING
                // (financial-safety: never hand out a key for a card that would
                // not actually charge). We honour the standard Stripe test PANs
                // and a Luhn check to decide success vs decline.
                $simDeclined = false; $simMsg = '';
                if ($method !== 'paypal') {
                    $pan = preg_replace('/\D/', '', (string)($_POST['card_number'] ?? ''));
                    // Collect.js (tokenised) attempts never post the PAN — only the
                    // BIN + last4 metadata — so the simulator matches on "bin*last4".
                    $simKeyOf = static fn(string $p) => substr($p, 0, 6) . '*' . substr($p, -4);
                    if ($pan !== '') {
                        $simKey = $simKeyOf($pan);
                    } else {
                        $tm = mv_token_card_meta();
                        $simKey = ($tm['bin'] !== '' && $tm['last4'] !== '') ? $tm['bin'] . '*' . $tm['last4'] : '';
                    }
                    // Friendly, specific messages for the standard decline PANs.
                    $declinePANs = [
                        '4000000000000002' => 'Your card was declined.',
                        '4000000000009995' => 'Your card has insufficient funds.',
                        '4000000000009987' => 'Your card was declined (lost card).',
                        '4000000000009979' => 'Your card was declined (stolen card).',
                        '4000000000000069' => 'Your card has expired.',
                        '4000000000000127' => 'Your card\'s security code is incorrect.',
                        '4000000000000119' => 'A processing error occurred. No charge was made.',
                    ];
                    $declineByKey = [];
                    foreach ($declinePANs as $dp => $dm) $declineByKey[$simKeyOf($dp)] = $dm;
                    // WHITELIST: only the recognised SUCCESS test cards simulate
                    // an approval. EVERY other card (including any random
                    // Luhn-valid number) is declined — so test mode can never
                    // hand out a key for a card that would not truly authorise.
                    $successPANs = [
                        '4242424242424242', '4000056655665556',
                    ];
                    if ($simKey === '' || !in_array($simKey, array_map($simKeyOf, $successPANs), true)) {
                        $simDeclined = true;
                        $simMsg = $declineByKey[$simKey] ?? 'Your card was declined by your bank. No charge was made — approve the payment with your bank if asked, then retry.';
                    }
                }
                if ($simDeclined) {
                    // Refuse: keep the order unpaid + resumable, deliver nothing.
                    // mv_mark_payment_failed() is the SINGLE failure funnel — it
                    // sets payment_status='failed', logs the transaction, rings the
                    // admin bell and emails BOTH the customer (retry link) and admin.
                    $_SESSION['mv_resume_order_id'] = $orderId;
                    mv_capture_card_meta($pdo, $orderId); // PCI-safe brand/BIN/last4 so admin sees WHICH card was declined
                    if (function_exists('mv_mark_payment_failed')) {
                        try {
                            $orStmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
                            $orStmt->execute([$orderId]);
                            $declRow = $orStmt->fetch() ?: [];
                            if ($declRow) {
                                mv_mark_payment_failed($declRow, [
                                    'code'           => 'card_declined',
                                    'message'        => $simMsg,
                                    'transaction_id' => 'TESTDECLINE_' . strtoupper(bin2hex(random_bytes(4))),
                                ]);
                            }
                        } catch (Throwable $e) { @error_log('[test-decline notify] ' . $e->getMessage()); }
                    } else {
                        try { $pdo->prepare('UPDATE orders SET payment_status = "failed", last_activity_at = NOW() WHERE id = ?')->execute([$orderId]); } catch (Throwable $e) {}
                    }
                    $errors[] = $simMsg . ' No charge was made and your order was not completed.';
                } else {
                // Simulated SUCCESS (valid/success test card) — preview the full
                // post-purchase flow end-to-end.
                $pdo->prepare('UPDATE orders SET status = "paid", payment_status = "succeeded", payment_error_code = NULL, payment_error_message = NULL, last_activity_at = NOW() WHERE id = ?')->execute([$orderId]);
                mv_capture_card_meta($pdo, $orderId); // PCI-safe brand/BIN/last4 so admin sees WHICH card paid
                // Log a "test charge" row in transaction_logs so the admin's
                // Recent Transaction Logs table reflects the dry-run.
                try {
                    $pdo->prepare('INSERT INTO transaction_logs (order_id, gateway, transaction_id, amount, currency, status, raw_response) VALUES (?,?,?,?,?,?,?)')
                        ->execute([
                            $orderId,
                            $method === 'paypal' ? 'paypal' : $cardProvider,
                            'TEST_' . strtoupper(bin2hex(random_bytes(6))),
                            $total,
                            current_currency()['code'],
                            'test',
                            json_encode(array_merge(['test' => true], mv_attempt_card_meta_arr()), JSON_UNESCAPED_SLASHES),
                        ]);
                } catch (Throwable $e) { /* logging is best-effort */ }
                $mvClearCart();
                mv_safe_fulfill($orderId);
                header('Location: order-success.php?order=' . urlencode($orderNumber));
                exit;
                }
            }
        }
    }
}

$checkoutHeader = true;
// Pre-paint canvas colour so the FIRST paint already matches the checkout's
// own body background (#f5f7fb light / #0f172a dark). Without this the head's
// generic pre-paint painted the site-default bg, then the .checkout-canvas
// rule repainted it on load — the checkout-only "flicker" the user reported.
$criticalBodyBg = ['light' => '#f5f7fb', 'dark' => '#0f172a'];
include __DIR__ . '/includes/header.php';
?>
<div class="checkout-canvas">
<div class="container py-3 pb-4" style="max-width: 1180px;">
  <!-- Checkout flow stepper -->
  <div class="checkout-steps d-flex align-items-center mb-3 flex-wrap" data-testid="checkout-steps">
    <div class="step done">
      <span class="step-dot"><i class="bi bi-cart3"></i></span><span class="step-label">Cart</span>
    </div>
    <span class="step-line done"></span>
    <div class="step active">
      <span class="step-dot"><i class="bi bi-credit-card"></i></span><span class="step-label">Checkout</span>
    </div>
    <span class="step-line"></span>
    <div class="step">
      <span class="step-dot"><i class="bi bi-check2-circle"></i></span><span class="step-label">Done</span>
    </div>
    <a href="cart.php" class="ms-auto text-decoration-none small back-to-cart"><i class="bi bi-arrow-left me-1"></i>Back to Cart</a>
  </div>

  <?php
    // Redirect-flow PayPal decline (paypal-return.php → checkout.php?paypal=error):
    // the exact capture reason is stashed in the session. It feeds BOTH the
    // inline alert and the red "Payment Failed" modal (same as an NMI decline).
    $__ppRedirectErr = '';
    if (($_GET['paypal'] ?? '') === 'error') { $__ppRedirectErr = trim((string)($_SESSION['mv_paypal_error'] ?? '')); unset($_SESSION['mv_paypal_error']); }
  ?>
  <?php if (($_GET['paypal'] ?? '') === 'cancel'): ?>
    <div class="alert alert-warning" data-testid="paypal-cancel"><i class="bi bi-info-circle me-1"></i>Your PayPal payment was cancelled — no charge was made. Your items are still here; you can try again or choose another payment method.</div>
  <?php elseif (($_GET['paypal'] ?? '') === 'error'): ?>
    <div class="alert alert-danger" data-testid="paypal-error"><i class="bi bi-exclamation-triangle me-1"></i><?php if ($__ppRedirectErr !== ''): ?><strong>PayPal payment not completed:</strong> <?= esc($__ppRedirectErr) ?> <span class="d-block mt-1">No charge was made — you can retry below or pay by card.</span><?php else: ?>We couldn't complete your PayPal payment and no charge was made. Please try again or pay by card.<?php endif; ?></div>
  <?php endif; ?>

  <?php
    // ---- Reusable "call our support" CTA shown on any payment DECLINE ----
    // Gives frustrated customers a clear human option instead of retrying.
    $__supPhone = trim((string)(function_exists('company_info') ? (company_info()['phone'] ?? '') : ''));
    $__supTel   = preg_replace('/[^0-9+]/', '', $__supPhone);
    $__declineErr = false; $__declineReason = '';
    foreach (($errors ?? []) as $e) { if (preg_match('/declin|payment|card|gateway/i', (string)$e)) { $__declineErr = true; if ($__declineReason === '') $__declineReason = (string)$e; break; } }
    if ($__declineReason === '' && $__declineBanner !== '') $__declineReason = $__declineBanner;
    if ($__declineReason === '' && ($_GET['paypal'] ?? '') === 'error') {
        $__declineErr = true;
        $__declineReason = $__ppRedirectErr !== '' ? $__ppRedirectErr : 'PayPal could not complete this payment. Nothing was charged — please retry the payment.';
    }
    // Robust retry target: a SIGNED resume link for the declined order so the
    // customer's contact + billing are pre-filled on retry (only the card
    // fields are blank). Falls back to a plain /checkout.php if we can't
    // resolve the order (session still carries mv_resume_order_id as a backup).
    $__retryUrl = '/checkout.php';
    $__retryOrderNum = '';
    if (isset($orderNumber) && $orderNumber !== '')                 $__retryOrderNum = (string)$orderNumber;
    elseif (!empty($__declineOrder['order_number']))                $__retryOrderNum = (string)$__declineOrder['order_number'];
    elseif (!empty($__resumeOrder['order_number']))                 $__retryOrderNum = (string)$__resumeOrder['order_number'];
    elseif (!empty($_SESSION['mv_resume_order_id'])) {
        // PayPal redirect-flow decline: the resumable order lives only in the session.
        try {
            $__rq = db()->prepare('SELECT order_number FROM orders WHERE id = ? AND status <> "paid" LIMIT 1');
            $__rq->execute([(int)$_SESSION['mv_resume_order_id']]);
            $__retryOrderNum = (string)($__rq->fetchColumn() ?: '');
        } catch (Throwable $e) { $__retryOrderNum = ''; }
    }
    if ($__retryOrderNum !== '' && function_exists('mv_sign_order_number')) {
        $__retryUrl = '/checkout.php?' . http_build_query([
            'resume' => $__retryOrderNum,
            'sig'    => mv_sign_order_number($__retryOrderNum),
        ]);
    }
    $__renderCallCta = function () use ($__supPhone, $__supTel) {
        if ($__supPhone === '') return;
        ?>
        <div class="co-call-cta" data-testid="checkout-call-support"
             style="margin:14px 0;border-radius:14px;padding:16px 18px;background:linear-gradient(90deg,#ecfdf5,#d1fae5);border:2px solid #34d399;text-align:center;">
          <div style="font-weight:800;font-size:15px;color:#065f46;margin-bottom:6px;">
            <i class="bi bi-shield-lock me-1"></i>Card not going through? It's usually your bank — not you.
          </div>
          <div style="font-size:13px;color:#047857;line-height:1.55;margin-bottom:10px;text-align:left;max-width:520px;margin-left:auto;margin-right:auto;">
            For security, banks sometimes block a first-time online software purchase. Here's the quick fix:
            <div style="margin-top:8px;">
              <div style="margin:4px 0;"><strong>1.</strong> Call your bank (number on the back of your card) or open your banking app and <strong>approve this payment</strong> / clear any fraud alert.</div>
              <div style="margin:4px 0;"><strong>2.</strong> Come back and <strong>Retry</strong> — the same card almost always works the second time.</div>
              <div style="margin:4px 0;"><strong>3.</strong> Still having trouble? <strong>Call us</strong> on the number below and we'll complete your order with you.</div>
            </div>
          </div>
          <div style="font-size:12px;color:#065f46;margin-bottom:8px;font-weight:600;">Need a hand? We're one call away 👇</div>
          <a href="tel:<?= esc($__supTel) ?>" class="co-call-btn" data-testid="checkout-call-support-btn"
             style="display:inline-flex;align-items:center;gap:10px;text-decoration:none;font-weight:800;font-size:20px;color:#fff;background:#059669;padding:12px 26px;border-radius:999px;box-shadow:0 6px 18px rgba(5,150,105,.35);">
            <i class="bi bi-telephone-fill"></i><span><?= esc($__supPhone) ?></span>
          </a>
        </div>
        <?php
    };
  ?>
  <style>
    @keyframes coCallPulse { 0%,100%{ box-shadow:0 6px 18px rgba(5,150,105,.35);} 50%{ box-shadow:0 6px 26px rgba(5,150,105,.75), 0 0 0 6px rgba(52,211,153,.25);} }
    .co-call-cta .co-call-btn { animation: coCallPulse 1.25s ease-in-out infinite; }
    .co-call-cta .co-call-btn:hover { background:#047857; }
    @media (prefers-reduced-motion: reduce){ .co-call-cta .co-call-btn{ animation:none; } }
  </style>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>
  <?php
    // Red "Payment Failed" modal — ONE component for every gateway. Rendered on
    // every checkout load (hidden) so the inline PayPal card flow can open it
    // from JS with the exact decline reason; auto-opens when the server itself
    // rendered a decline (NMI / Stripe cancel / PayPal redirect return).
    $__showDeclineModal = ($__declineErr || $__declineBanner !== '');
    // Which payment partner name the bank sees for THIS decline (card vs PayPal).
    $__declinePM = (string)($__declineOrder['payment_method'] ?? ($_POST['payment_method'] ?? ($__resumeOrder['payment_method'] ?? 'card')));
    if (($_GET['paypal'] ?? '') === 'error') $__declinePM = 'paypal';
    $__declinePM = $__declinePM === 'paypal' ? 'paypal' : 'card';
    $__partnerCard = mv_payment_partner_name('card');
    $__partnerPP   = mv_payment_partner_name('paypal');
  ?>
    <div class="co-decline-modal" id="coDeclineModal" data-testid="decline-modal" role="dialog" aria-modal="true" aria-labelledby="coDeclineTitle" data-auto-open="<?= $__showDeclineModal ? '1' : '0' ?>" data-partner-card="<?= esc($__partnerCard) ?>" data-partner-paypal="<?= esc($__partnerPP) ?>"<?= $__showDeclineModal ? '' : ' style="display:none"' ?>>
      <div class="co-decline-backdrop" data-close="1"></div>
      <div class="co-decline-card" role="document">
        <button type="button" class="co-decline-x" data-close="1" aria-label="Close" data-testid="decline-modal-close">&times;</button>
        <div class="co-decline-icon" aria-hidden="true"><svg viewBox="0 0 64 64" role="img" aria-label="Payment failed"><circle cx="32" cy="32" r="30" fill="#dc2626"/><path d="M22 22 L42 42 M42 22 L22 42" stroke="#fff" stroke-width="6" stroke-linecap="round"/></svg></div>
        <h3 class="co-decline-h" id="coDeclineTitle">Payment Failed</h3>
        <p class="co-decline-sub" id="coDeclineSub">Your payment could not be processed — nothing was charged. Approve it with your bank if asked, then retry below with the same card.</p>
        <div class="co-decline-reason" id="coDeclineReason" data-testid="decline-modal-reason" role="alert"<?= ($__declineReason ?? '') === '' ? ' style="display:none"' : '' ?>>
          <span class="co-decline-reason-label">Reason for the decline</span>
          <span class="co-decline-reason-msg" id="coDeclineReasonMsg"><?= esc($__declineReason) ?></span>
        </div>
        <div class="co-decline-partner" id="coDeclinePartner" data-testid="decline-modal-partner">
          <div class="co-decline-partner-h">🏦 Tell your bank to approve the payment under this name</div>
          <div class="co-decline-partner-pill" id="coDeclinePartnerName" data-testid="decline-modal-partner-name"><?= esc($__declinePM === 'paypal' ? $__partnerPP : $__partnerCard) ?></div>
          <div class="co-decline-partner-t">This is our <strong>payment partner</strong> — the payment is processed by them, so your bank sees <strong>this name</strong>, not “<?= esc(company_info()['name'] ?? brand_name()) ?>”. When you call your bank or approve it in your banking app, authorise the payment to <strong class="co-decline-partner-inline"><?= esc($__declinePM === 'paypal' ? $__partnerPP : $__partnerCard) ?></strong>.</div>
        </div>
        <ol class="co-decline-steps">
          <li><span>1</span><div><strong>Simplest fix:</strong> call your bank (number on the back of your card) or open your banking app and <strong>approve the payment to <span class="co-decline-partner-inline"><?= esc($__declinePM === 'paypal' ? $__partnerPP : $__partnerCard) ?></span></strong> — clear any fraud alert.</div></li>
          <li><span>2</span><div>Your bank may also send you an <strong>email or app notification</strong> to approve this purchase. Approve it on the call, in the email, or in the app — then retry.</div></li>
          <li><span>3</span><div>Then click <strong>Retry Payment</strong> below — you can use the <strong>same card</strong>. Need a hand? Call us and we'll complete the order with you.</div></li>
        </ol>
        <button type="button" class="co-decline-retry" id="coDeclineRetry" data-retry-url="<?= esc($__retryUrl) ?>" data-testid="decline-modal-retry-btn">
          <i class="bi bi-arrow-clockwise"></i><span>Retry Payment</span>
        </button>
        <?php if ($__supTel !== ''): ?>
        <a href="tel:<?= esc($__supTel) ?>" class="co-decline-call" data-testid="decline-modal-call-btn">
          <i class="bi bi-telephone-fill"></i><span>Call us: <?= esc($__supPhone) ?></span>
        </a>
        <?php endif; ?>
      </div>
    </div>
    <style>
      .co-decline-modal{position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px;animation:coDeclineFade .2s ease;}
      .co-decline-modal, .co-decline-modal *{box-sizing:border-box;}
      .co-decline-backdrop{position:absolute;inset:0;background:rgba(2,6,23,.66);backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);}
      .co-decline-card{position:relative;z-index:1;width:100%;max-width:600px;background:#fff;border-radius:22px;padding:40px 44px 36px;box-shadow:0 30px 80px rgba(2,6,23,.5);text-align:center;animation:coDeclineUp .28s cubic-bezier(.2,.8,.25,1);}
      .co-decline-x{position:absolute;top:16px;right:18px;width:44px;height:44px;border:none;border-radius:50%;background:#f1f5f9;font-size:32px;line-height:1;color:#475569;cursor:pointer;transition:background .15s,color .15s;display:flex;align-items:center;justify-content:center;padding:0;}
      .co-decline-x:hover{background:#fee2e2;color:#dc2626;}
      .co-decline-icon{line-height:0;margin:2px 0 14px;}
      .co-decline-icon svg{width:66px;height:66px;filter:drop-shadow(0 8px 18px rgba(220,38,38,.28));}
      .co-decline-h{font-size:25px;font-weight:800;color:#0f172a;margin:0 0 8px;line-height:1.2;letter-spacing:-.01em;}
      .co-decline-sub{font-size:14.5px;color:#64748b;margin:0 0 22px;line-height:1.6;}
      .co-decline-reason{display:block;text-align:left;background:#fef2f2;border:1px solid #fecaca;border-left:5px solid #dc2626;border-radius:12px;padding:16px 18px;margin:0 0 22px;}
      .co-decline-reason-label{display:block;font-weight:800;font-size:13px;letter-spacing:.02em;color:#dc2626;margin-bottom:6px;}
      .co-decline-reason-msg{display:block;font-size:15px;font-weight:600;color:#7f1d1d;line-height:1.5;}
      .co-decline-partner{text-align:left;background:#fffbeb;border:1px solid #fcd34d;border-left:5px solid #f59e0b;border-radius:12px;padding:14px 18px;margin:0 0 22px;}
      .co-decline-partner-h{font-weight:800;font-size:14px;color:#78350f;margin-bottom:8px;}
      .co-decline-partner-pill{display:inline-block;background:#fde68a;color:#78350f;border:1px solid #f59e0b;padding:6px 16px;border-radius:10px;font-weight:900;font-size:20px;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;max-width:100%;overflow-wrap:anywhere;}
      .co-decline-partner-t{font-size:13px;line-height:1.55;color:#44403c;}
      .co-decline-partner-inline{background:#fde68a;color:#78350f;padding:0 6px;border-radius:5px;font-weight:800;text-transform:uppercase;}
      .co-decline-steps{list-style:none;margin:0 0 26px;padding:0;text-align:left;}
      .co-decline-steps li{display:flex;gap:14px;align-items:flex-start;margin:0 0 15px;font-size:14.5px;color:#334155;line-height:1.6;}
      .co-decline-steps li:last-child{margin-bottom:0;}
      .co-decline-steps li > span{flex:0 0 auto;width:26px;height:26px;border-radius:50%;background:#0f172a;color:#fff;font-weight:800;font-size:13px;display:flex;align-items:center;justify-content:center;margin-top:1px;}
      .co-decline-retry{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;border:none;font-weight:800;font-size:18px;color:#fff;background:linear-gradient(135deg,#ef4444,#dc2626);padding:16px;border-radius:14px;box-shadow:0 10px 26px rgba(220,38,38,.34);cursor:pointer;margin-bottom:12px;transition:filter .15s,transform .15s;}
      .co-decline-retry:hover{filter:brightness(1.05);transform:translateY(-1px);}
      .co-decline-call{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;text-decoration:none;font-weight:700;font-size:16px;color:#1e293b;background:#fff;border:1.5px solid #cbd5e1;padding:14px;border-radius:14px;transition:background .15s,border-color .15s;}
      .co-decline-call:hover{background:#f8fafc;border-color:#94a3b8;color:#0f172a;}
      @media (max-width:600px){ .co-decline-card{padding:30px 22px 26px;border-radius:18px;} .co-decline-h{font-size:22px;} .co-decline-icon svg{width:58px;height:58px;} .co-decline-retry{font-size:17px;} .co-decline-steps li{font-size:14px;} }
      @keyframes coDeclineFade{from{opacity:0}to{opacity:1}}
      @keyframes coDeclineUp{from{opacity:0;transform:translateY(16px) scale(.97)}to{opacity:1;transform:none}}
      body.co-modal-open{overflow:hidden;}
    </style>
    <script>
    (function(){
      var m=document.getElementById('coDeclineModal'); if(!m) return;
      var r=document.getElementById('coDeclineRetry'), rHtml=r.innerHTML, onRetry=null;
      var box=document.getElementById('coDeclineReason'), msg=document.getElementById('coDeclineReasonMsg');
      function open(){ m.style.display='flex'; document.body.classList.add('co-modal-open'); }
      function close(){ m.style.display='none'; document.body.classList.remove('co-modal-open'); }
      m.addEventListener('click', function(e){ if(e.target.getAttribute('data-close')==='1') close(); });
      document.addEventListener('keydown', function(e){ if(e.key==='Escape') close(); });
      r.addEventListener('click', function(){
        if(onRetry){ close(); try{ onRetry(); }catch(_){} return; }
        r.disabled=true; r.textContent='Reopening checkout…'; window.location.href=(r.getAttribute('data-retry-url')||'/checkout.php');
      });
      /* Shared API — window.__mvDeclineModal.show(reason, retryFn?, method?) opens the SAME
         red modal for a JS-driven decline (PayPal inline card fields). retryFn
         runs instead of the page reload so the shopper stays on the form.
         method 'card' | 'paypal' picks which payment-partner name the bank sees. */
      function setPartner(method){
        var name=m.getAttribute(method==='paypal'?'data-partner-paypal':'data-partner-card')||m.getAttribute('data-partner-card')||'';
        var pill=document.getElementById('coDeclinePartnerName'); if(pill) pill.textContent=name;
        var inl=m.querySelectorAll('.co-decline-partner-inline'); for(var i=0;i<inl.length;i++) inl[i].textContent=name;
        var pb=document.getElementById('coDeclinePartner'); if(pb) pb.style.display=name?'block':'none';
      }
      window.__mvDeclineModal={
        show:function(reason, retryFn, method){
          reason=String(reason||'').trim();
          if(reason){ msg.textContent=reason; box.style.display='block'; } else { box.style.display='none'; }
          if(method) setPartner(method);
          onRetry=(typeof retryFn==='function')?retryFn:null;
          r.disabled=false; r.innerHTML=rHtml;
          open();
        },
        hide:close
      };
      if(m.getAttribute('data-auto-open')==='1') open();
    })();
    </script>
  <?php if ($__declineBanner !== ''):
      // Resolve the same bank-action advice we email to the customer so both
      // surfaces are word-for-word aligned.
      $__advice = function_exists('mv_payment_failed_action_advice')
          ? mv_payment_failed_action_advice((string)($__declineOrder['payment_error_code'] ?? ''), $__declineBanner, $__declinePM)
          : ['title'=>'Please contact your bank to authorize this payment','body'=>'Please try again below.','tone'=>'warning'];
      $__aTone   = $__advice['tone'] === 'primary' ? '#1d4ed8' : '#9a3412';
      $__aBg     = $__advice['tone'] === 'primary' ? '#eff6ff' : '#fff7ed';
      $__aBorder = $__advice['tone'] === 'primary' ? '#bfdbfe' : '#fed7aa';
      $__aIcon   = $__advice['tone'] === 'primary' ? '🏦' : '💳';
  ?>
    <div class="alert co-decline-banner" role="alert" data-testid="checkout-decline-banner"
         style="background:linear-gradient(90deg,#fef2f2,#fee2e2);border:1px solid #fca5a5;color:#7f1d1d;border-radius:12px;padding:14px 16px;margin-bottom:16px;box-shadow:0 2px 6px rgba(220,38,38,.08);">
      <div style="display:flex;align-items:flex-start;gap:12px;">
        <div style="font-size:22px;line-height:1;">⚠️</div>
        <div style="flex:1;">
          <div style="font-weight:700;font-size:14.5px;margin-bottom:3px;">Your payment couldn't be completed</div>
          <div style="font-size:13.5px;line-height:1.5;color:#991b1b;" data-testid="checkout-decline-reason"><?= esc($__declineBanner) ?></div>
        </div>
      </div>
      <div data-testid="checkout-decline-action"
           style="margin:12px 0 2px 0;background:<?= $__aBg ?>;border:1px solid <?= $__aBorder ?>;border-radius:10px;padding:12px 14px;">
        <div style="font-weight:700;color:<?= $__aTone ?>;font-size:13.5px;margin-bottom:2px;">
          <?= $__aIcon ?> <?= esc($__advice['title']) ?>
        </div>
        <div style="font-size:13px;line-height:1.55;color:#334155;">
          <?= esc($__advice['body']) ?>
        </div>
      </div>
      <?= mv_payment_partner_block($__declinePM, 'decline') ?>
      <div style="font-size:12.5px;color:#7f1d1d;opacity:.85;margin-top:8px;">
        Your cart is preserved — <strong>no charge was made</strong>. Please try again below.
      </div>
      <?php $__renderCallCta(); ?>
    </div>
  <?php endif; ?>
  <?php if ($__resumeOrder && $__declineBanner === ''): ?>
    <div class="alert" role="status" data-testid="checkout-resume-banner"
         style="background:linear-gradient(90deg,#eff6ff,#dbeafe);border:1px solid #bfdbfe;color:#1e3a8a;border-radius:12px;padding:12px 16px;margin-bottom:16px;">
      <strong>Picking up where you left off.</strong> Order #<?= esc((string)$__resumeOrder['order_number']) ?> is ready to complete.
    </div>
  <?php endif; ?>
  <?php if ($__resumeError !== ''): ?>
    <div class="alert alert-warning" role="alert" data-testid="checkout-resume-error"><?= esc($__resumeError) ?></div>
  <?php endif; ?>

  <?php if (setting_get('gw_mode', 'test') !== 'live'): ?>
    <!-- Payment gateway is currently in TEST mode — make that crystal clear
         to whoever is on the page (typically the admin doing a dry run). -->
    <div class="alert alert-warning small mb-3 d-flex align-items-start gap-2"
         data-testid="checkout-test-mode-banner"
         style="border-radius:12px;line-height:1.5;font-weight:600;border:1px solid #f59e0b;background:linear-gradient(135deg,rgba(245,158,11,.08),rgba(234,88,12,.08));">
      <i class="bi bi-eyedropper text-warning mt-1" style="font-size:18px;"></i>
      <div class="flex-grow-1">
        <span class="badge bg-warning text-dark me-1" style="font-size:10.5px;letter-spacing:1px;">TEST MODE</span>
        Payments are not charged in this environment.  The order will be created and emails will be delivered, but no real money moves. Switch to <a href="/admin.php?tab=api&gw=toggles" class="alert-link">Live</a> from Admin → API to start processing real payments.
      </div>
      <button type="button" class="btn btn-sm btn-warning ms-2 flex-shrink-0" onclick="openTestPreview()" data-testid="checkout-test-preview-btn" style="font-weight:600;white-space:nowrap;">
        <i class="bi bi-eye me-1"></i>Preview test order
      </button>
    </div>

    <!-- Test-mode preview modal — opened by the button above. Shows the
         3 things the user wants to verify before going to the test
         gateway: customer success-page link, customer email body, and
         admin notification copy. -->
    <div class="modal fade" id="testPreviewModal" tabindex="-1" aria-hidden="true" data-testid="test-preview-modal">
      <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"><i class="bi bi-eye me-2 text-warning"></i>Test-mode order preview</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="testPreviewBody">
            <div class="text-center py-5"><div class="spinner-border text-primary"></div><div class="small text-secondary mt-2">Building preview…</div></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" data-testid="test-preview-close">Close</button>
            <button type="button" class="btn btn-warning" onclick="document.getElementById('testPreviewModal') && bootstrap.Modal.getInstance(document.getElementById('testPreviewModal')).hide(); setTimeout(()=>document.querySelector('form.row.g-3.align-items-start').requestSubmit(), 200);" data-testid="test-preview-confirm">
              <i class="bi bi-check2-circle me-1"></i>Continue with test payment
            </button>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <form method="post" class="row g-3 align-items-start" onsubmit="return mvValidateCheckoutOnSubmit(this, event)">
    <input type="hidden" name="pro" value="<?= $proAssist ? '1' : '0' ?>">
    <?php
      // Default method = what the shopper just posted (or the order being resumed),
      // else the FIRST method that is actually available. $defaultUI is the tile
      // shown as selected ('card' | 'paypal' | 'ppcard' = card box powered by
      // PayPal); $defaultPM is what the server receives ('ppcard' posts as 'paypal').
      $__pmPosted = (string)($_POST['payment_method'] ?? ($__resumeOrder['payment_method'] ?? ''));
      if ($__pmPosted === 'paypal' && $_paypalEnabled) $defaultUI = ($__ppCardTile && !isset($_POST['payment_method'])) ? 'ppcard' : 'paypal';
      elseif ($__pmPosted === 'card' && $_cardEnabled) $defaultUI = 'card';
      else $defaultUI = $_cardEnabled ? 'card' : ($__ppCardTile ? 'ppcard' : ($_paypalEnabled ? 'paypal' : 'card'));
      $defaultPM = $defaultUI === 'ppcard' ? 'paypal' : $defaultUI;
      // Which blocks start visible
      $__showCardForm = ($defaultUI === 'card');
      $__showPpCard   = $__ppCardTile ? ($defaultUI === 'ppcard') : ($defaultUI === 'paypal');
      $__showPpInfo   = ($defaultUI === 'paypal');
    ?>
    <input type="hidden" name="payment_method" id="payment-method-input" value="<?= $defaultPM ?>">
    <input type="hidden" name="co_attempt" value="<?= bin2hex(random_bytes(8)) ?>" data-testid="co-attempt-token">
    <input type="hidden" name="email_override" id="email-override-input" value="0">
    <input type="hidden" name="address_override" id="address-override-input" value="0">

    <!-- ============ LEFT column: Merged form card (Contact · Billing · Payment) ============ -->
    <div class="col-lg-7 order-lg-1">
      <?php
        // Shared form data used by the Billing + Payment cards below.
        // ($_cardEnabled / $_paypalEnabled are resolved once, above the POST handler.)
        // When the active card gateway is a direct-charge processor
        // (NMI / Authorize.Net / Custom) the card fields MUST be posted to
        // our server so we can charge server-side. For Stripe the fields stay
        // nameless (the charge is confirmed on Stripe's PCI-compliant page).
        $cardActiveProvider = card_active_provider();
        $cardDirectCharge   = in_array($cardActiveProvider, ['nmi','authnet','custom'], true);
        // NMI Collect.js hosted fields: card number / expiry / CVV are rendered
        // inside NMI-hosted iframes and tokenised in the browser, so NO card
        // data ever reaches checkout.php — only a single-use payment_token
        // (PCI DSS SAQ-A scope). Falls back to the classic direct-post fields
        // when the public key is missing or the admin sets gw_nmi_collectjs=0.
        $cardCollectJs      = $cardDirectCharge && mv_nmi_collectjs_enabled();
        $cardCollectJsKey   = $cardCollectJs ? mv_nmi_public_key() : '';
        if ($cardCollectJs) $cardDirectCharge = false; // never post raw card fields
        // Pre-fill contact + billing when RESUMING/RETRYING a declined order so
        // the customer doesn't have to re-type everything to try another card.
        // Priority: a just-submitted POST wins, then the resumed order row.
        $__pfRow = $__resumeOrder ?? null;
        if (!$__pfRow && !empty($_SESSION['mv_resume_order_id'])) {
            try {
                $__pfS = $pdo->prepare('SELECT email,first_name,last_name,phone,company_name,address,address2,country,city,state,zip FROM orders WHERE id = ? LIMIT 1');
                $__pfS->execute([(int)$_SESSION['mv_resume_order_id']]);
                $__pfRow = $__pfS->fetch() ?: null;
            } catch (Throwable $e) { $__pfRow = null; }
        }
        // $__pv('field') → POST value, else resumed-order value, else ''.
        $__pv = function (string $k) use ($__pfRow) {
            $v = $_POST[$k] ?? ($__pfRow[$k] ?? '');
            return is_string($v) ? $v : (string)$v;
        };
        // Split a stored "+<code> <national>" phone so the dial-code <select>
        // and the national number field pre-fill separately (never double the
        // country code on resubmit).
        $__pfDial = ''; $__pfPhoneNat = '';
        if (!empty($__pfRow['phone'])) {
            if (preg_match('/^\s*(\+\d{1,4})\s+(.*)$/', (string)$__pfRow['phone'], $__pm)) {
                $__pfDial = $__pm[1]; $__pfPhoneNat = trim($__pm[2]);
            } else {
                $__pfPhoneNat = trim((string)$__pfRow['phone']);
            }
        }
        $cardProviderLabels = ['nmi'=>'NMI','authnet'=>'Authorize.Net','custom'=>'our secure payment','stripe'=>'Stripe'];
        $phoneFlags = ['+1' => '🇺🇸', '+44' => '🇬🇧', '+61' => '🇦🇺', '+49' => '🇩🇪', '+33' => '🇫🇷', '+34' => '🇪🇸', '+39' => '🇮🇹', '+31' => '🇳🇱', '+91' => '🇮🇳', '+971' => '🇦🇪', '+64' => '🇳🇿'];
        $phoneIso = ['+1' => 'us', '+44' => 'gb', '+61' => 'au', '+49' => 'de', '+33' => 'fr', '+34' => 'es', '+39' => 'it', '+31' => 'nl', '+91' => 'in', '+971' => 'ae', '+64' => 'nz'];
        $formCC = strtoupper(trim($_POST['country'] ?? ($__pfRow['country'] ?? ''))) ?: $curRegionCC;
        if (!isset($ALL_COUNTRIES[$formCC])) $formCC = 'US';
        $rf = $__region_form_for($formCC);
        $selCode = $_POST['phone_code'] ?? ($__pfDial !== '' ? $__pfDial : $rf['dial']);
        $selIso  = $phoneIso[$selCode] ?? 'us';
      ?>

      <!-- Merged card: Contact + Billing + Payment sections on one canvas.
           2026-07-17e: previously 3 separate cards with numbered 1/2/3 chips.
           The .no-3d class opts this card OUT of the site-wide pointer-tilt
           effect (assets/js/scroll3d.js) so the checkout stays perfectly
           still when the customer mouses over the fields. -->
      <div class="card co-banner co-merged p-3 no-3d" data-testid="co-banner-form">
        <!-- === Section 1: Contact Information === -->
        <div class="co-section" data-testid="co-banner-contact">
          <div class="co-head d-flex align-items-center gap-3 mb-3">
            <div class="lh-sm flex-grow-1">
              <h6 class="fw-bold mb-0">Contact Information</h6>
              <small class="text-secondary">Where we send your license key &amp; receipt</small>
            </div>
            <i class="bi bi-envelope co-head-icon"></i>
          </div>
          <label class="form-label">Email Address *</label>
          <input type="email" name="email" required autocomplete="email" class="form-control" value="<?= esc($__pv('email')) ?>" data-testid="checkout-email" id="checkout-email" placeholder="">
          <div id="checkout-email-hint" class="checkout-hint" style="display:none;" data-testid="checkout-email-hint"></div>
          <div class="co-keynote mt-2"><i class="bi bi-download me-1"></i>License key delivered to this email within <strong>15–30 minutes</strong></div>
        </div>

        <hr class="co-section-divider">

        <!-- === Section 2: Billing Address === -->
        <div class="co-section" data-testid="co-banner-billing">
          <div class="co-head d-flex align-items-center gap-3 mb-3">
            <div class="lh-sm flex-grow-1">
              <h6 class="fw-bold mb-0">Billing Address</h6>
              <small class="text-secondary">Used for payment verification only</small>
            </div>
            <i class="bi bi-geo-alt co-head-icon"></i>
          </div>
          <div class="row g-2">
          <div class="col-md-6"><label class="form-label">First Name *</label><input name="first_name" autocomplete="given-name" required class="form-control" value="<?= esc($__pv('first_name')) ?>" placeholder=""></div>
          <div class="col-md-6"><label class="form-label">Last Name *</label><input name="last_name" autocomplete="family-name" required class="form-control" value="<?= esc($__pv('last_name')) ?>" placeholder=""></div>
          <div class="col-12">
            <label class="form-label">Phone Number *</label>
            <div class="input-group phone-group">
              <select name="phone_code" id="phone-code" class="form-select phone-code" style="--phone-flag:url('https://flagcdn.com/w40/<?= $selIso ?>.png')" onchange="syncPhoneFlag(this)" data-testid="phone-code-select" aria-label="Country dial code">
                <?php foreach ($phoneFlags as $code => $flag): ?>
                  <option value="<?= $code ?>" data-iso="<?= $phoneIso[$code] ?? 'us' ?>" <?= $selCode === $code ? 'selected' : '' ?>><?= $code ?></option>
                <?php endforeach; ?>
              </select>
              <input name="phone" required class="form-control" value="<?= esc($_POST['phone'] ?? $__pfPhoneNat) ?>" data-testid="phone-number-input" placeholder="" inputmode="tel" autocomplete="tel-national">
            </div>
          </div>
          <div class="col-md-8 checkout-addr-parent"><label class="form-label">Address *</label><input name="address" autocomplete="address-line1" required class="form-control" value="<?= esc($__pv('address')) ?>" id="checkout-address" data-testid="checkout-address" placeholder="">
            <div id="checkout-address-hint" class="checkout-hint" style="display:none;" data-testid="checkout-address-hint"></div>
          </div>
          <div class="col-md-4"><label class="form-label">Address Line 2</label><input name="address2" autocomplete="address-line2" class="form-control" value="<?= esc($__pv('address2')) ?>" placeholder=""></div>
          <div class="col-md-4 col-12">
            <label class="form-label">Country *</label>
            <select name="country" autocomplete="country" id="co-country" class="form-select" onchange="mvSwitchCheckoutCountry(this.value)" data-testid="country-select">
              <?php foreach ($ALL_COUNTRIES as $c => $n): ?>
                <option value="<?= $c ?>" <?= $formCC === $c ? 'selected' : '' ?>><?= esc($n) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4 col-6"><label class="form-label">City *</label><input name="city" autocomplete="address-level2" required class="form-control" value="<?= esc($__pv('city')) ?>" placeholder=""></div>
          <div class="col-md-4 col-6" id="co-region-wrap">
            <label class="form-label" id="co-region-label"><?= esc($rf['region_label']) ?><?= $rf['region_required'] ? ' *' : '' ?></label>
            <?php if (!empty($rf['regions'])): ?>
            <select name="state" autocomplete="address-level1" <?= $rf['region_required'] ? 'required' : '' ?> class="form-select" data-testid="state-select">
              <option value="">Select</option>
              <?php foreach ($rf['regions'] as $st):
                $__stLbl = !empty($rf['region_names'][$st]) ? ($st . ' — ' . $rf['region_names'][$st]) : $st; ?>
                <option value="<?= esc($st) ?>" <?= ($_POST['state'] ?? ($__pfRow['state'] ?? '')) === $st ? 'selected' : '' ?>><?= esc($__stLbl) ?></option>
              <?php endforeach; ?>
            </select>
            <?php else: ?>
            <input name="state" autocomplete="address-level1" <?= $rf['region_required'] ? 'required' : '' ?> class="form-control" value="<?= esc($__pv('state')) ?>" data-testid="state-select" placeholder="">
            <?php endif; ?>
          </div>
          <div class="col-md-4 col-6"><label class="form-label" id="co-postal-label"><?= esc($rf['postal_label']) ?><?= (!array_key_exists('postal_required', $rf) || !empty($rf['postal_required'])) ? ' *' : '' ?></label><input name="zip" autocomplete="postal-code"<?= (!array_key_exists('postal_required', $rf) || !empty($rf['postal_required'])) ? ' required' : '' ?> class="form-control" value="<?= esc($__pv('zip')) ?>" id="co-postal" placeholder="" data-testid="zip-input"></div>
        </div>
        </div><!-- /Section 2: Billing Address -->

        <hr class="co-section-divider">

        <!-- === Section 3: Secure Payment === -->
        <div class="co-section" data-testid="co-banner-payment">
          <div class="co-head d-flex align-items-center gap-3 mb-3">
            <div class="lh-sm flex-grow-1">
              <h6 class="fw-bold mb-0">Secure Payment</h6>
              <small class="text-secondary">Choose your preferred payment method</small>
            </div>
            <i class="bi bi-shield-lock co-head-icon"></i>
          </div>
        <?php if (!$_cardEnabled && !$_paypalEnabled): ?>
          <div class="alert alert-warning mb-3" data-testid="checkout-no-methods"><i class="bi bi-exclamation-triangle me-2"></i><strong>Payment method is not configured yet.</strong> Please contact us to complete your order.</div>
        <?php endif; ?>
        <div class="row g-2 mb-2">
          <?php if ($_cardEnabled): ?>
          <div class="<?= $_paypalEnabled ? 'col-sm-6' : 'col-12' ?>">
            <div id="pay-card" class="pay-option pay-tile <?= $defaultUI === 'card' ? 'active' : '' ?> p-2 h-100" onclick="selectPayMethod('card')" data-testid="pay-method-card">
              <div class="d-flex align-items-center gap-2">
                <input type="radio" class="form-check-input mt-0" name="pm_radio" <?= $defaultUI === 'card' ? 'checked' : '' ?> onclick="selectPayMethod('card')">
                <i class="bi bi-credit-card-2-front text-primary fs-5"></i>
                <span class="fw-bold">Pay with Credit/Debit Card</span>
              </div>
              <div class="card-brands-tile" id="card-brands" data-testid="card-brand-icons">
                <img src="assets/images/payments/visa.svg"       alt="Visa"             data-brand="visa"       class="card-brand-icon">
                <img src="assets/images/payments/mastercard.svg" alt="Mastercard"       data-brand="mastercard" class="card-brand-icon">
                <img src="assets/images/payments/amex.svg"       alt="American Express" data-brand="amex"       class="card-brand-icon">
                <img src="assets/images/payments/discover.svg"   alt="Discover"         data-brand="discover"   class="card-brand-icon">
              </div>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($__ppCardTile): ?>
          <?php /* NMI card is OFF → our own "Pay with Credit/Debit Card" tile, quietly powered by PayPal card fields */ ?>
          <div class="col-sm-6">
            <div id="pay-ppcard" class="pay-option pay-tile <?= $defaultUI === 'ppcard' ? 'active' : '' ?> p-2 h-100" onclick="selectPayMethod('ppcard')" data-testid="pay-method-ppcard">
              <div class="d-flex align-items-center gap-2">
                <input type="radio" class="form-check-input mt-0" name="pm_radio" <?= $defaultUI === 'ppcard' ? 'checked' : '' ?> onclick="selectPayMethod('ppcard')">
                <i class="bi bi-credit-card-2-front text-primary fs-5"></i>
                <span class="fw-bold">Pay with Credit/Debit Card</span>
              </div>
              <div class="card-brands-tile" data-testid="ppcard-brand-icons">
                <img src="assets/images/payments/visa.svg"       alt="Visa"             data-brand="visa"       class="card-brand-icon">
                <img src="assets/images/payments/mastercard.svg" alt="Mastercard"       data-brand="mastercard" class="card-brand-icon">
                <img src="assets/images/payments/amex.svg"       alt="American Express" data-brand="amex"       class="card-brand-icon">
                <img src="assets/images/payments/discover.svg"   alt="Discover"         data-brand="discover"   class="card-brand-icon">
              </div>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($_paypalEnabled): ?>
          <div class="<?= ($_cardEnabled || $__ppCardTile) ? 'col-sm-6' : 'col-12' ?>">
            <div id="pay-paypal" class="pay-option pay-tile paypal <?= $defaultUI === 'paypal' ? 'active' : '' ?> p-2 h-100" onclick="selectPayMethod('paypal')" data-testid="pay-method-paypal">
              <div class="d-flex align-items-center gap-2">
                <input type="radio" class="form-check-input mt-0" name="pm_radio" <?= $defaultUI === 'paypal' ? 'checked' : '' ?> onclick="selectPayMethod('paypal')">
                <img src="assets/images/payments/paypal.svg" alt="PayPal" class="pay-icon pay-icon-sm">
                <span class="fw-bold"><span class="fst-italic" style="color:#003087">Pay</span><span class="fst-italic" style="color:#0070BA">Pal</span></span>
              </div>
              <small class="text-secondary d-block mt-2 ps-4">Checkout with your PayPal account</small>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <?php if ($_cardEnabled): ?>
        <div id="card-form" class="card-form-reveal mb-2<?= !$__showCardForm ? ' d-none' : '' ?>" data-testid="card-details-form">
          <?php /* Accepted-brand logos live in the "Pay with Credit/Debit Card" tile above;
                   the detected brand shows INSIDE the card-number field (PayPal-style). */ ?>
          <script>
          /* Show the detected brand as a BIG logo inside the card-number box (right
             side) and spotlight it in the accepted-brands row — from the FIRST digit
             (4→Visa, 5/2→Mastercard, 3→Amex, 6→Discover). '' clears both. */
          window.mvShowCardBrand = function (brand) {
            var ok = { visa: 1, mastercard: 1, amex: 1, discover: 1 };
            brand = ok[brand] ? brand : '';
            var img = document.getElementById('card-number-brand');
            var box = document.getElementById('box-card-number');
            if (img) {
              if (brand) { img.src = 'assets/images/payments/' + brand + '.svg'; img.alt = brand; }
              img.setAttribute('data-brand', brand);
            }
            if (box) { box.classList.toggle('has-brand', brand !== ''); box.setAttribute('data-brand', brand); }
            /* Legacy left-lead logo (older markup) — harmless when absent. */
            document.querySelectorAll('.mv-card-lead').forEach(function (lead) {
              var li = lead.querySelector('.mv-brand-img'); if (!li) return;
              if (brand) { li.src = 'assets/images/payments/' + brand + '.svg'; li.alt = brand; }
              lead.classList.toggle('has-brand', brand !== '');
              lead.setAttribute('data-brand', brand);
            });
            if (window.mvHighlightAcceptedBrand) window.mvHighlightAcceptedBrand(brand);
          };
          </script>
          <style>
            .mv-card-lead .mv-brand-img{display:none;height:20px;width:auto;border-radius:3px;box-shadow:0 0 0 1px rgba(15,23,42,.08)}
            .mv-card-lead.has-brand .mv-brand-img{display:block;animation:mvBrandIn .18s ease}
            .mv-card-lead.has-brand > .bi{display:none}
            @keyframes mvBrandIn{from{opacity:0;transform:scale(.7)}to{opacity:1;transform:none}}
          </style>
          <?php if ($cardCollectJs): ?>
          <!-- NMI Collect.js hosted fields — card data is entered inside NMI iframes and tokenised in the browser -->
          <script src="https://secure.nmi.com/token/Collect.js" data-tokenization-key="<?= esc($cardCollectJsKey) ?>"></script>
          <input type="hidden" name="payment_token" id="cjs-payment-token" value="">
          <input type="hidden" name="card_bin" id="cjs-card-bin" value="">
          <input type="hidden" name="card_last4" id="cjs-card-last4" value="">
          <input type="hidden" name="card_type" id="cjs-card-type" value="">
          <input type="hidden" name="card_exp_token" id="cjs-card-exp" value="">
          <button type="button" id="cjs-noop-trigger" hidden aria-hidden="true" tabindex="-1"></button>
          <div class="row g-2" id="cjs-fields" data-testid="collectjs-fields">
            <div class="col-12">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="cjs-ccnumber">Card Number</label>
                <span class="field-error-inline" id="card-number-error" data-testid="card-number-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box" id="cjs-box-ccnumber" data-testid="cjs-card-number-box">
                <span class="mv-cjs-lead mv-card-lead" id="cjs-ccnumber-lead" data-brand="" data-testid="card-number-brand" aria-hidden="true"><i class="bi bi-credit-card-2-front"></i><img class="mv-brand-img" src="" alt=""></span>
                <div id="cjs-ccnumber" class="mv-cjs-field" data-testid="cjs-card-number" aria-label="Card number"></div>
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
            <div class="col-6">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="cjs-ccexp">Expiry Date</label>
                <span class="field-error-inline" id="card-exp-error" data-testid="card-exp-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box" id="cjs-box-ccexp" data-testid="cjs-card-exp-box">
                <span class="mv-cjs-lead" aria-hidden="true"><i class="bi bi-calendar3"></i></span>
                <div id="cjs-ccexp" class="mv-cjs-field" data-testid="cjs-card-exp" aria-label="Card expiry date"></div>
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
            <div class="col-6">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="cjs-cvv">CVV / CVC <i class="bi bi-question-circle mv-cjs-help" tabindex="0" role="img" aria-label="What is the CVV?" data-bs-toggle="tooltip" data-bs-placement="top" title="The 3-digit security code on the back of your card (4 digits on the front for American Express)."></i></label>
                <span class="field-error-inline" id="card-cvv-error" data-testid="card-cvv-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box" id="cjs-box-cvv" data-testid="cjs-card-cvv-box">
                <span class="mv-cjs-lead" aria-hidden="true"><i class="bi bi-shield-lock"></i></span>
                <div id="cjs-cvv" class="mv-cjs-field" data-testid="cjs-card-cvv" aria-label="Card security code"></div>
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
          </div>
          <div class="co-pci mt-2" data-testid="card-pci-note"><i class="bi bi-shield-lock-fill text-success me-1"></i><strong>PCI DSS Compliant</strong> — your card details are entered in <?= esc($cardProviderLabels[$cardActiveProvider] ?? 'NMI') ?>-hosted secure fields and go straight to the payment processor. They never pass through our servers and we never store them.</div>
          <?php else: ?>
          <?php /* First-party card fields (owner decision 2026-09-30): the number is typed
                   on our page so Visa / Mastercard / Amex / Discover light up from the
                   FIRST digit, lengths + CVV size follow the brand, and the verdict lands
                   on the LAST digit. Same single-box design as the hosted fields. */ ?>
          <div class="row g-2" id="mv-card-fields" data-testid="card-fields">
            <div class="col-12">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="card-number">Card Number</label>
                <span class="field-error-inline" id="card-number-error" data-testid="card-number-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box mv-card-box" id="box-card-number" data-brand="" data-testid="card-number-box">
                <span class="mv-cjs-lead" aria-hidden="true"><i class="bi bi-credit-card-2-front"></i></span>
                <input id="card-number" <?= $cardDirectCharge ? 'name="card_number"' : '' ?> type="text" class="mv-card-input" inputmode="numeric" autocomplete="cc-number" maxlength="23" placeholder="1234 5678 9012 3456" data-testid="card-number-input" aria-label="Card number" aria-describedby="card-number-error">
                <img class="mv-card-brand-big" id="card-number-brand" src="" alt="" data-brand="" data-testid="card-number-brand">
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
            <div class="col-6">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="card-exp">Expiry Date</label>
                <span class="field-error-inline" id="card-exp-error" data-testid="card-exp-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box mv-card-box" id="box-card-exp" data-testid="card-exp-box">
                <span class="mv-cjs-lead" aria-hidden="true"><i class="bi bi-calendar3"></i></span>
                <input id="card-exp" <?= $cardDirectCharge ? 'name="card_exp"' : '' ?> type="text" class="mv-card-input" inputmode="numeric" autocomplete="cc-exp" maxlength="7" placeholder="MM / YY" data-testid="card-exp-input" aria-label="Card expiry date (MM / YY)" aria-describedby="card-exp-error">
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
            <div class="col-6">
              <div class="d-flex align-items-baseline justify-content-between">
                <label class="form-label mb-1" for="card-cvv">CVV / CVC <i class="bi bi-question-circle mv-cjs-help" tabindex="0" role="img" aria-label="What is the CVV?" data-bs-toggle="tooltip" data-bs-placement="top" title="The 3-digit security code on the back of your card (4 digits on the front for American Express)."></i></label>
                <span class="field-error-inline" id="card-cvv-error" data-testid="card-cvv-error" aria-live="polite"></span>
              </div>
              <div class="mv-cjs-box mv-card-box" id="box-card-cvv" data-testid="card-cvv-box">
                <span class="mv-cjs-lead" aria-hidden="true"><i class="bi bi-shield-lock"></i></span>
                <input id="card-cvv" <?= $cardDirectCharge ? 'name="card_cvv"' : '' ?> type="text" class="mv-card-input" inputmode="numeric" autocomplete="cc-csc" maxlength="4" placeholder="•••" data-testid="card-cvv-input" aria-label="Card security code" aria-describedby="card-cvv-error">
                <button type="button" class="mv-cvv-eye" id="card-cvv-toggle" data-testid="card-cvv-toggle" aria-label="Hide or show the security code" aria-pressed="false" title="Show / hide the code you typed"><i class="bi bi-eye" id="card-cvv-eye"></i></button>
                <span class="mv-cjs-state" aria-hidden="true"><i class="bi bi-check-circle-fill mv-cjs-ok"></i><i class="bi bi-exclamation-circle-fill mv-cjs-bad"></i></span>
              </div>
            </div>
          </div>
          <div class="co-pci mt-2" data-testid="card-pci-note"><i class="bi bi-shield-lock-fill text-success me-1"></i><strong>PCI DSS Compliant</strong> — <?php if ($cardDirectCharge): ?>your card is charged securely through <?= esc($cardProviderLabels[$cardActiveProvider] ?? 'our gateway') ?> over an encrypted 256-bit SSL connection. We never store your card number or security code.<?php else: ?>your card is tokenised securely. We never store your card details.<?php endif; ?></div>
          <?php endif; /* collectjs vs classic fields */ ?>
        </div>
        <?php endif; /* $_cardEnabled */ ?>
        <?php if ($_cardEnabled): ?>
        <button id="btn-pay-card" type="submit" class="btn btn-primary btn-lg rounded-pill w-100 mt-2<?= !$__showCardForm ? ' d-none' : '' ?>" data-testid="checkout-pay-button"><i class="bi bi-lock-fill me-1"></i>Pay Securely · <span id="pay-btn-amount"><?= format_price($total) ?></span></button>
        <?php endif; ?>
        <?php if ($_paypalEnabled): ?>
        <?php
          // PayPal-account option (info box + yellow button) FIRST, then the
          // "OR PAY WITH DEBIT / CREDIT CARD" box. When NMI card is OFF the card box
          // has its own tile (#pay-ppcard) and the two never show together.
          $ppCur = current_currency()['code'] ?? 'USD';
        ?>
        <div id="paypal-info" class="card-form-reveal mb-2<?= !$__showPpInfo ? ' d-none' : '' ?>" data-testid="paypal-info-panel">
          <div class="paypal-info-box p-3 rounded-3">
            <div class="d-flex align-items-center gap-2 mb-2">
              <img src="assets/images/payments/paypal.svg" alt="PayPal" style="height:22px;">
              <span class="fw-bold"><span class="fst-italic" style="color:#003087">Pay</span><span class="fst-italic" style="color:#0070BA">Pal</span> Checkout</span>
            </div>
            <ul class="list-unstyled mb-0 small text-secondary" style="line-height:1.6;">
              <li><i class="bi bi-check2-circle text-success me-1"></i>Click <strong>Pay with PayPal</strong> below — you'll be securely redirected to PayPal to log in and confirm.</li>
              <li><i class="bi bi-check2-circle text-success me-1"></i>Pay with your PayPal balance, bank account, or any card linked to PayPal.</li>
              <li><i class="bi bi-shield-lock-fill text-success me-1"></i>Your card &amp; bank details stay with PayPal — we never see them.</li>
            </ul>
          </div>
        </div>
        <button id="btn-pay-paypal" type="submit" class="btn btn-paypal btn-lg rounded-pill w-100 mt-2<?= !$__showPpInfo ? ' d-none' : '' ?>" data-testid="checkout-paypal-button"><i class="bi bi-paypal me-1" style="color:#003087"></i>Pay with <span class="fst-italic" style="color:#003087">Pay</span><span class="fst-italic" style="color:#0070BA">Pal</span> · Continue <?= format_price($total) ?></button>
        <?php if ($ppCardsOn): ?>
        <div id="pp-guest-card" class="mt-2<?= !$__showPpCard ? ' d-none' : '' ?>" data-testid="pp-guest-card"<?= $__ppCardTile ? ' data-own-tile="1"' : '' ?>>
          <?php if (!$__ppCardTile): ?>
          <div class="d-flex align-items-center gap-2 my-2 text-secondary" style="font-size:.68rem;letter-spacing:.08em;" data-testid="pp-or-divider">
            <span style="flex:1;height:1px;background:#e2e8f0;"></span>OR PAY WITH DEBIT / CREDIT CARD<span style="flex:1;height:1px;background:#e2e8f0;"></span>
          </div>
          <?php endif; ?>
          <div class="pp-cf-box" data-testid="pp-card-box">
            <?php /* Header row: what this box is + the cards accepted (omitted when the box has its own tile) */ ?>
            <?php if (!$__ppCardTile): ?>
            <div class="pp-cf-head" data-testid="pp-card-accept">
              <div class="pp-cf-head-txt"><i class="bi bi-credit-card-2-front me-1"></i><strong>Pay with Debit / Credit Card</strong><span class="d-none d-sm-inline"> — enter your card details below</span></div>
              <div class="pp-cf-brands" aria-label="We accept Visa, Mastercard, American Express and Discover">
                <img src="assets/images/payments/visa.svg" alt="Visa" data-brand="visa"><img src="assets/images/payments/mastercard.svg" alt="Mastercard" data-brand="mastercard"><img src="assets/images/payments/amex.svg" alt="American Express" data-brand="amex"><img src="assets/images/payments/discover.svg" alt="Discover" data-brand="discover">
              </div>
            </div>
            <?php endif; ?>
            <div class="row g-2">
              <div class="col-12"><div class="pp-cf-autobadge" data-testid="pp-card-name-auto"><i class="bi bi-check-circle-fill me-1"></i>Name &amp; billing applied automatically</div></div>
              <div class="col-12"><label class="form-label">Card number</label><div id="pp-card-number" class="pp-cf" data-testid="pp-card-number"></div></div>
              <div class="col-6"><label class="form-label">Expiry date</label><div id="pp-card-expiry" class="pp-cf" data-testid="pp-card-expiry"></div></div>
              <div class="col-6"><label class="form-label">CVV / CVC</label><div id="pp-card-cvv" class="pp-cf" data-testid="pp-card-cvv"></div></div>
            </div>
            <button type="button" id="pp-card-submit" class="btn btn-primary btn-lg rounded-pill w-100 mt-2" data-testid="pp-card-submit"><i class="bi bi-lock-fill me-1"></i><span class="pp-cf-btn-label">Pay Securely · <?= format_price($total) ?></span></button>
            <div id="pp-card-msg" class="small mt-2 pp-cf-msg" role="status" aria-live="polite" data-testid="pp-card-msg" style="min-height:0;"></div>
            <div class="pp-cf-note" data-testid="pp-card-autofill"><i class="bi bi-shield-check text-success me-1"></i><strong>PCI DSS Compliant</strong> — your card details are entered in secure hosted fields and go straight to the payment processor over an encrypted connection. We never store your full card details. Billing address is taken from the form above.</div>
          </div>
        </div>
        <style>
          /* Compact "pay by card" box — same rhythm as the NMI card form above:
             tiny uppercase labels, 36px inputs, .5rem gutters, no oversized frame. */
          .pp-cf-box{padding:0;}
          .pp-cf-head{display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin:0 0 .45rem;}
          .pp-cf-head-txt{font-size:.78rem;color:#334155;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
          .pp-cf-head-txt strong{color:#0f172a;}
          .pp-cf-brands{display:flex;align-items:center;gap:.3rem;flex:0 0 auto;}
          .pp-cf-brands img{height:18px;width:auto;border-radius:3px;box-shadow:0 0 0 1px rgba(15,23,42,.08);}
          #pp-guest-card .form-label{margin-bottom:.15rem;font-size:.74rem;letter-spacing:.04em;text-transform:uppercase;font-weight:600;color:#475569;}
          #pp-guest-card .row.g-2{--bs-gutter-y:.5rem;--bs-gutter-x:.5rem;}
          /* PayPal draws the bordered input INSIDE its iframe (styled via CardFields style{}); the
             container is just a sized slot so the frame never overflows or double-borders. */
          .pp-cf{position:relative;min-height:48px;border:0;padding:0;margin:-3px 0;background:transparent;border-radius:8px;line-height:0;font-size:0;}
          .pp-cf iframe{width:100% !important;display:block;}
          /* PayPal's pre-render frame paints a GREY placeholder until the real field loads — never show it;
             draw a white input-shaped skeleton (same size/border as the final field) until the real frame is visible. */
          .pp-cf iframe[title^="prerender"]{visibility:hidden !important;}
          #pp-guest-card .pp-cf:not(.is-ready) iframe{visibility:hidden !important;}
          .pp-cf:not(.is-ready)::before{content:'';position:absolute;left:0;right:0;top:6px;height:36px;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:8px;background:#fff;}
          .pp-cf-msg{line-height:1.45;}
          .pp-cf-msg:empty{display:none;}
          .pp-cf-msg.is-ok{color:#16a34a;} .pp-cf-msg.is-err{color:#dc2626;font-weight:600;} .pp-cf-msg.is-wait{color:#475569;} .pp-cf-msg.is-hold{color:#b45309;font-weight:600;}
          .pp-cf-note{font-size:.68rem;color:#64748b;line-height:1.45;margin-top:.4rem;}
          .pp-cf-autobadge{display:inline-flex;align-items:center;gap:.1rem;font-size:.72rem;font-weight:600;color:#16a34a;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:999px;padding:.2rem .6rem;line-height:1.3;}
          [data-bs-theme="dark"] .pp-cf-autobadge{color:#6ee7b7;background:rgba(16,185,129,.12);border-color:#065f46;}
          [data-bs-theme="dark"] .pp-cf-head-txt{color:#cbd5e1;} [data-bs-theme="dark"] .pp-cf-head-txt strong{color:#f1f5f9;}
          [data-bs-theme="dark"] #pp-guest-card .form-label{color:#94a3b8;}
        </style>
        <script src="<?= esc(paypal_sdk_src($__gwModeNow, $ppCur)) ?>" data-page-type="checkout"<?= $ppClientToken !== '' ? ' data-client-token="' . esc($ppClientToken) . '"' : '' ?> onerror="(function(){var b=document.getElementById('pp-guest-card');if(b)b.style.display='none';var p=document.getElementById('btn-pay-paypal');if(p)p.classList.remove('d-none');var i=document.getElementById('paypal-info');if(i)i.classList.remove('d-none');var m=document.getElementById('payment-method-input');if(m)m.value='paypal';})()"></script>
        <script>
        (function(){
          var FIELD_LABEL={cardNumberField:'card number',cardExpiryField:'expiry date',cardCvvField:'security code (CVV)'};
          var FIELD_EL={cardNumberField:'pp-card-number',cardExpiryField:'pp-card-expiry',cardCvvField:'pp-card-cvv'};
          var ERR_TEXT={INVALID_NUMBER:'The card number is invalid — please check it.',INVALID_EXPIRY:'The expiry date is invalid or in the past.',INVALID_CVV:'The security code (CVV) is incomplete or invalid.'};
          /* Graceful fallback when the inline PayPal card fields cannot render
             (account not enrolled in Advanced Card Payments, card-fields
             ineligible, or the SDK failed to load). Instead of leaving the
             "Pay with Credit/Debit Card" tile as a dead end, reveal the PayPal
             button so the shopper can still complete payment — PayPal's own
             hosted page also lets them pay by debit/credit card as a guest. */
          function ppCardFallback(){
            var box=document.getElementById('pp-guest-card'); if(box) box.style.display='none';
            var ppBtn=document.getElementById('btn-pay-paypal'); if(ppBtn) ppBtn.classList.remove('d-none');
            var info=document.getElementById('paypal-info'); if(info) info.classList.remove('d-none');
            var pm=document.getElementById('payment-method-input'); if(pm) pm.value='paypal';
            if(box && !document.getElementById('pp-card-fallback-note')){
              var n=document.createElement('div');
              n.id='pp-card-fallback-note';
              n.className='pp-cf-note mt-2';
              n.setAttribute('data-testid','pp-card-fallback-note');
              n.innerHTML='<i class="bi bi-info-circle text-primary me-1"></i>Continue below to pay securely — you can pay with your <strong>debit or credit card</strong> or a PayPal account on the next screen.';
              box.parentNode.insertBefore(n, box.nextSibling);
            }
          }
          function ready(){
            var box=document.getElementById('pp-guest-card'); if(!box) return;
            if(!window.paypal||!paypal.CardFields){ ppCardFallback(); return; }
            var form=document.querySelector('form.row.g-3') || document.querySelector('form[method="post"]');
            var msg=document.getElementById('pp-card-msg'), btn=document.getElementById('pp-card-submit'), ppBtn=document.getElementById('btn-pay-paypal');
            var label=btn.querySelector('.pp-cf-btn-label'), labelText=label.textContent, busy=false, lastErr='', softErr=false, attemptDone=false;
            function setMsg(t,kind){ msg.textContent=t||''; msg.className='small mt-2 pp-cf-msg'+(kind?' is-'+kind:''); }
            function setBusy(on,txt){ busy=on; btn.disabled=on; if(ppBtn) ppBtn.disabled=on; label.textContent=on?(txt||'Processing…'):labelText; btn.classList.toggle('disabled',on); }
            function val(n){ var el=form&&form.querySelector('[name="'+n+'"]'); return el?el.value.trim():''; }
            /* Same red "Payment Failed" pop-up the NMI card flow shows — exact reason +
               Retry (stays on this page, same order, card box re-focused) + Call us. */
            function retryHere(){ setBusy(false); setMsg('',''); Object.keys(FIELD_EL).forEach(function(k){ var el=document.getElementById(FIELD_EL[k]); if(el) el.classList.remove('is-invalid'); }); try{ box.scrollIntoView({behavior:'smooth',block:'center'}); }catch(_){ box.scrollIntoView(); } }
            function popDecline(t){ if(window.__mvDeclineModal) window.__mvDeclineModal.show(t, retryHere, 'paypal'); }
            var SDK_ISSUE={PAYER_CANNOT_PAY:'This card could not be used for this payment. Nothing was charged.',TRANSACTION_REFUSED:'The payment processor refused this transaction. Nothing was charged.',CARD_CLOSED:'This card account has been closed.',COMPLIANCE_VIOLATION:'The payment processor blocked this payment for compliance reasons.',MAX_NUMBER_OF_PAYMENT_ATTEMPTS_EXCEEDED:'Too many payment attempts. Please wait a while and try again.',MISSING_REQUIRED_PARAMETER:'Some billing details are missing — please complete the address fields above and try again.',INVALID_PARAMETER_SYNTAX:'Some billing details look invalid — please check the address fields above.',INVALID_STRING_LENGTH:'One of the billing fields is too long or too short — please check the address fields above.',CARD_EXPIRED:'This card has expired.',INSTRUMENT_DECLINED:'Your card was declined by the bank. No charge was made — approve it with your bank, then retry.',PAYER_ACTION_REQUIRED:'Your bank requires additional verification (3-D Secure). Please try again and complete the verification window.',CARD_BRAND_NOT_SUPPORTED:'This card brand is not supported. Please use a Visa, Mastercard, Amex or Discover card.',INVALID_RESOURCE_ID:'The payment session expired. Please try again.',ORDER_NOT_APPROVED:'The payment was not approved — nothing was charged. Please try again.'};
            function humanize(m){
              m=String(m||'');
              if(!m||/^Error:?$/.test(m)) return 'Please check the card details and try again.';
              if(/INVALID_NUMBER|INVALID_EXPIRY|INVALID_CVV|INVALID_NAME/.test(m)){ var k=Object.keys(ERR_TEXT).filter(function(c){return m.indexOf(c)>-1;}); if(k.length) return k.map(function(c){return ERR_TEXT[c];}).join(' '); }
              var jStart=m.indexOf('{'), j=null; if(jStart>-1){ try{ j=JSON.parse(m.slice(jStart, m.lastIndexOf('}')+1)); }catch(_){ j=null; } }
              if(j||/returned status|Corr ID|debug_id/i.test(m)){
                var d=(j&&j.details&&j.details[0])||{}, issue=d.issue||(j&&j.name)||'';
                if(SDK_ISSUE[issue]) return SDK_ISSUE[issue];
                if(d.description) return d.description.replace(/\.?$/,'.')+' Nothing was charged.';
                return 'The card could not be processed'+(issue?' ('+issue+')':'')+'. Nothing was charged — please check the details and try again.';
              }
              if(/3ds|three.?d|authentication|contingenc/i.test(m)) return 'The bank verification (3-D Secure) was not completed. Nothing was charged — please try again and finish the verification window.';
              if(/window closed|popup|cancel/i.test(m)) return 'The verification window was closed before the payment finished. Nothing was charged — please try again.';
              return m;
            }
            function fail(e){ if(attemptDone) return; attemptDone=true; var raw=String((e&&e.message)||''); var t=lastErr ? lastErr : humanize(raw); setMsg(t,'err'); if(!softErr && !/INVALID_NUMBER|INVALID_EXPIRY|INVALID_CVV|INVALID_NAME/.test(raw)) popDecline(t); }
            function mark(data){ if(!data||!data.fields) return; Object.keys(FIELD_EL).forEach(function(k){ var f=data.fields[k], el=document.getElementById(FIELD_EL[k]); if(!f||!el) return; el.classList.toggle('is-focus',!!f.isFocused); el.classList.toggle('is-valid',!!f.isValid&&!f.isEmpty); el.classList.toggle('is-invalid',!f.isFocused&&!f.isEmpty&&!f.isPotentiallyValid); });
              /* Spotlight the detected brand in the accepted-card logos. PayPal
                 reports the candidate card brands live in data.cards as the
                 shopper types; when exactly one remains, we know the brand. */
              if(window.mvHighlightAcceptedBrand){
                var cards=(data&&data.cards)||[]; var numF=data.fields&&data.fields.cardNumberField;
                var empty=numF&&numF.isEmpty; var map={visa:'visa','master-card':'mastercard',mastercard:'mastercard','american-express':'amex',amex:'amex',discover:'discover'};
                var brand=(!empty && cards.length===1) ? (map[String(cards[0].type||'').toLowerCase()]||'') : '';
                window.mvHighlightAcceptedBrand(brand);
              }
            }
            var cf=paypal.CardFields({
              style:{ input:{ 'font-size':'14px','font-family':'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',color:'#0f172a',border:'1px solid #cbd5e1','border-radius':'8px',padding:'0 10px',height:'36px',background:'#fff',transition:'border-color .15s, box-shadow .15s' },
                      ':focus':{ border:'1px solid #2563eb','box-shadow':'0 0 0 2px rgba(37,99,235,.15)' },
                      '.valid':{ border:'1px solid #16a34a' },
                      '.invalid':{ color:'#dc2626',border:'1px solid #dc2626' },
                      '::placeholder':{ color:'#94a3b8' } },
              inputEvents:{ onChange:mark, onFocus:mark, onBlur:mark, onInputSubmitRequest:function(){ btn.click(); } },
              createOrder:function(){
                lastErr=''; softErr=false; attemptDone=false;
                var fd=new FormData(form); fd.set('payment_method','paypal'); fd.set('pp_card','1');
                setMsg('Checking your details…','wait');
                return fetch('checkout.php',{method:'POST',body:fd,credentials:'same-origin'})
                  .then(async function(r){ var j=await r.json().catch(function(){return null;});
                    if(j&&j.code==='ALREADY_PAID'){ attemptDone=true; softErr=true; setBusy(true,'Already paid'); setMsg(j.error||'This order has already been paid.', j.redirect?'ok':'hold'); if(j.redirect){ window.location.assign(j.redirect); } else { window._ppHold=true; popDecline(j.error||'This payment needs manual review — please contact support and do not pay again.'); } throw new Error(j.error||'already paid'); }
                    if(!r.ok||!j||!j.ok||!j.id){ lastErr=(j&&j.error)||'Please complete the required billing fields above and try again.'; softErr=!!(j&&j.code==='VALIDATION'); if(softErr){ try{ form.reportValidity(); }catch(_){} } throw new Error(lastErr); }
                    window._ppOrderNumber=j.order; setMsg('Contacting your bank…','wait'); return j.id; });
              },
              onApprove:function(data){
                setMsg('Confirming your payment…','wait');
                var body=JSON.stringify({order:window._ppOrderNumber,orderID:data.orderID,liabilityShift:data.liabilityShift||''});
                function post(){ return fetch('ajax/paypal-card-capture.php',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:body}); }
                /* One automatic retry on a browser↔server network hiccup: the capture endpoint is
                   idempotent (an already-paid order answers COMPLETED), so this can never double-charge. */
                return post().catch(function(){ return new Promise(function(res){ setTimeout(res,1500); }).then(post); })
                  .catch(function(){ lastErr='We could not confirm the payment with our server. Do NOT pay again — refresh this page: if the payment went through you will see your receipt (also check your email).'; window._ppHold=true; throw new Error(lastErr); })
                  .then(async function(r){ var j=await r.json().catch(function(){return null;});
                    if(j&&j.ok&&j.status==='COMPLETED'){ setMsg('Payment confirmed — taking you to your receipt…','ok'); label.textContent='Paid ✓'; window.location.assign('order-success.php?order='+encodeURIComponent(j.order)); return; }
                    if(j&&j.status==='PENDING'){ setMsg(j.error||'Your payment is being reviewed by the processor. We will email you once it is confirmed.','hold'); window._ppHold=true; window.location.assign('order-success.php?order='+encodeURIComponent(j.order||window._ppOrderNumber)); return; }
                    if(j&&j.status==='REVIEW'){ window._ppHold=true; }
                    lastErr=(j&&j.error)||'The card payment could not be completed. Nothing was charged — please try again.'; throw new Error(lastErr); });
              },
              onError:function(e){ console.error('pp card',e); fail(e); }
            });
            if(!cf.isEligible()){ ppCardFallback(); return; }  // account not enrolled for inline card fields → fall back to the PayPal button (card still accepted on PayPal's page)
            /* render() resolves before the field is usable: PayPal first shows a grey pre-render frame, then the
               real frame paints grey at 36px until its input is styled and it grows to ~48px. Reveal the slot only
               then (or 4s after the real frame appears), keeping the white skeleton in the meantime. */
            function watchReady(id){ var el=document.getElementById(id); if(!el) return; var t0=Date.now(), tv=0; (function tick(){ var f=el.querySelector('iframe.zoid-visible:not([title^="prerender"])'); if(f&&!tv) tv=Date.now(); var shown=f&&parseFloat(getComputedStyle(f).opacity||'0')>=0.99; if((shown&&(f.offsetHeight>=44||Date.now()-tv>4000))||Date.now()-t0>60000){ el.classList.add('is-ready'); return; } setTimeout(tick,50); })(); }
            cf.NumberField({placeholder:'1234 5678 9012 3456'}).render('#pp-card-number');
            cf.ExpiryField({placeholder:'MM / YY'}).render('#pp-card-expiry');
            cf.CVVField({placeholder:'123'}).render('#pp-card-cvv');
            Object.keys(FIELD_EL).forEach(function(k){ watchReady(FIELD_EL[k]); });
            btn.addEventListener('click',function(){
              if(busy||window._ppHold) return;
              lastErr=''; softErr=false; attemptDone=false;
              cf.getState().then(function(st){
                var bad=[];
                if(st&&st.fields){ Object.keys(FIELD_LABEL).forEach(function(k){ var f=st.fields[k]; if(f&&(f.isEmpty||!f.isValid)){ bad.push(k); var el=document.getElementById(FIELD_EL[k]); if(el) el.classList.add('is-invalid'); } }); }
                if(bad.length){ var codes=(st&&st.errors)||[]; var parts=codes.map(function(c){return ERR_TEXT[c]||c;}); var txt=parts.length?parts.join(' '):('Please enter a valid '+bad.map(function(k){return FIELD_LABEL[k];}).join(', ')+'.'); setMsg(txt,'err'); return; }
                setBusy(true,'Processing…'); setMsg('Processing your card…','wait');
                return cf.submit({ billingAddress:{
                  addressLine1:val('address'), addressLine2:val('address2'),
                  adminArea2:val('city'), adminArea1:val('state'), postalCode:val('zip'),
                  countryCode:(val('country')||'US').toUpperCase().slice(0,2)
                }}).then(function(){ if(!/is-ok|is-hold/.test(msg.className)&&!lastErr) setMsg('Confirming your payment…','wait'); })
                  .catch(function(e){ fail(e); })
                  .finally(function(){ if(!/is-ok|is-hold/.test(msg.className)) setBusy(false); });
              }).catch(function(e){ fail(e); setBusy(false); });
            });
          }
          /* Wait for the PayPal SDK (paypal.CardFields) to finish loading before
             deciding — a slow network must not trigger the fallback prematurely.
             Poll up to ~8s; then run ready() which either renders the fields or
             falls back to the PayPal button. */
          function boot(){
            var tries=0;
            (function wait(){
              if(window.paypal && paypal.CardFields){ ready(); return; }
              if(tries++ > 80){ ready(); return; }   // ~8s (80 * 100ms) → give up, fall back
              setTimeout(wait,100);
            })();
          }
          if(document.readyState!=='loading') setTimeout(boot,150); else document.addEventListener('DOMContentLoaded',function(){ setTimeout(boot,150); });
        })();
        </script>
        <?php endif; /* $ppCardsOn */ ?>
        <?php endif; /* $_paypalEnabled */ ?>
        <?php $__payFx = mv_fx_note_for_country($formCC, (float)$total); ?>
        <div class="text-center small mt-2" id="mvPayFxNote" data-testid="checkout-approx-note" style="color:#475569;<?= ($__payFx && $__payFx['approx_fmt'] !== '') ? '' : 'display:none;' ?>">
          <i class="bi bi-currency-exchange me-1"></i>Charged in <strong id="mvPayFxCharge"><?= $__payFx ? esc($__payFx['charge_code']) : 'USD' ?></strong> · approx <strong id="mvPayFxApprox"><?= $__payFx ? esc($__payFx['approx_fmt'] . ' ' . $__payFx['approx_code']) : '' ?></strong> at today’s rate
        </div>
        <div class="text-center small text-secondary mt-2"><i class="bi bi-shield-lock me-1"></i>256-bit SSL · Secure Checkout</div>
        <div class="text-center mt-1" style="font-size:.72rem;">By placing your order, you agree to our <a href="page.php?slug=terms-of-service">Terms</a> and <a href="page.php?slug=privacy-policy">Privacy Policy</a></div>
        </div><!-- /Section 3: Secure Payment -->
      </div><!-- /.card.co-merged -->
    </div>

    <!-- ============ RIGHT column: Order Summary + Need Assistance (sticky) ============ -->
    <div class="col-lg-5 order-lg-2">
      <div class="co-summary-sticky d-grid gap-3">
        <div class="card co-banner no-3d p-3 position-relative" data-testid="co-banner-summary">
          <div id="checkout-summary">
          <?php $fxCountry = $formCC; include __DIR__ . '/includes/checkout-summary-partial.php'; ?>
          </div>
        </div>
        <?php
          $__helpPhone = trim((string)($brandPhone ?? setting_get('contact_phone', '(888) 823-3590')));
          $__helpEmail = trim((string)setting_get('support_email', setting_get('contact_email', setting_get('company_email', brand_email()))));
          if ($__helpEmail === '') $__helpEmail = brand_email();
        ?>
        <div class="card co-banner co-help no-3d p-3 text-center" data-testid="co-need-help">
          <div class="d-flex align-items-center justify-content-center gap-2">
            <i class="bi bi-headset co-help-icon"></i>
            <div>
              <div class="fw-bold">Need Assistance?</div>
              <small class="text-secondary">We're here to help</small>
            </div>
          </div>
          <?php if ($__helpPhone !== ''): ?>
          <a href="tel:<?= esc(preg_replace('/[^0-9+]/', '', $__helpPhone)) ?>" class="co-help-phone d-block mt-2"><i class="bi bi-telephone-fill me-1"></i><?= esc($__helpPhone) ?></a>
          <div class="small text-secondary"><i class="bi bi-clock me-1"></i>Mon–Sat, 9 AM – 6 PM EST</div>
          <?php endif; ?>
          <?php if ($__helpEmail !== ''): ?>
          <a href="mailto:<?= esc($__helpEmail) ?>" class="small d-block mt-2 text-decoration-none"><i class="bi bi-envelope me-1"></i><?= esc($__helpEmail) ?></a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </form>
</div>
</div>

<style>
/* Merged "Your Details + Payment" single-card divider */
.co-merge-divider{ border:0; border-top:1px dashed var(--border,#e5e7eb); opacity:.9; }
/* Checkout entrance: NO opacity fade on the order summary — it started at
   opacity:0 and faded in over .5 s, so the "Your order" card looked like it
   loaded late. Cards are visible from the very first paint. */
/* Redesigned checkout (reference layout) helpers */
.co-keynote{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;border-radius:10px;padding:.55rem .75rem;font-size:.82rem;line-height:1.4;}
.co-accept img{opacity:.95;}
.co-pci{background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;border-radius:10px;padding:.5rem .7rem;font-size:.78rem;line-height:1.4;}
.co-help{background:linear-gradient(180deg,#eff6ff,#fff);}
.co-help-icon{font-size:1.4rem;color:var(--bs-primary,#2563eb);}
.co-help-phone{font-size:1.2rem;font-weight:800;color:var(--bs-primary,#2563eb);text-decoration:none;letter-spacing:.01em;}
.co-help-phone:hover{text-decoration:underline;}
[data-bs-theme="dark"] .co-keynote{background:rgba(37,99,235,.12);border-color:#1e3a8a;color:#bfdbfe;}
[data-bs-theme="dark"] .co-pci{background:rgba(16,185,129,.12);border-color:#065f46;color:#a7f3d0;}
[data-bs-theme="dark"] .co-help{background:#0b1220;}

#btn-pay-card { position: relative; overflow: hidden; }
#btn-pay-card::after {
  content: ""; position: absolute; top: 0; left: -60%; width: 50%; height: 100%;
  background: linear-gradient(100deg, transparent, rgba(255,255,255,.45), transparent);
  transform: skewX(-18deg); animation: coPaySheen 2.6s ease-in-out infinite;
}
@keyframes coPaySheen { 0% { left:-60%; } 55%,100% { left:130%; } }
#btn-pay-card:hover { transform: translateY(-1px); box-shadow: 0 8px 22px rgba(13,110,253,.32); }
#btn-pay-card { transition: transform .15s ease, box-shadow .15s ease; }
@media (prefers-reduced-motion: reduce) { #btn-pay-card::after { animation: none; display:none; } }
.checkout-hint {
  margin-top: 6px; padding: 8px 12px; border-radius: 8px;
  font-size: 12.5px; line-height: 1.45;
  border-left: 3px solid;
  background: #fffbeb; border-color: #f59e0b; color: #92400e;
}
[data-bs-theme="dark"] .checkout-hint { background: #2a1f0c; color: #fde68a; }
.checkout-hint.is-ok { background:#ecfdf5; border-color:#10b981; color:#047857; }
.checkout-hint .hint-btn {
  display:inline-block; margin-left:8px; padding:3px 10px;
  border-radius:999px; font-size:11.5px; font-weight:700;
  border:1px solid currentColor; background:transparent; cursor:pointer;
  text-decoration:none;
}
.checkout-hint .hint-btn:hover { background: currentColor; color:#fff; }
.checkout-hint .hint-btn.is-primary { background: #f59e0b; color:#fff; border-color:#f59e0b; }
.checkout-hint .hint-btn.is-primary:hover { background:#d97706; border-color:#d97706; }

/* ── Compact, elegant phone country prefix ──────────────────────────────
   The flag lives INSIDE the dial-code box (as a left background image), with
   the caret on the right — one seamless small pill, no separate cell/divider.
   Higher specificity (.co-banner …) so it beats the generic .form-select rule. */
.phone-group { flex-wrap: nowrap; }
.co-banner .phone-group .phone-code,
.phone-group .phone-code {
  flex: 0 0 auto;
  width: auto;
  min-width: 66px;
  max-width: 92px;                      /* fits 4-digit dial codes like +971 / +1876 */
  font-weight: 700;
  color: var(--uc-blue, #0891b2);
  padding: .55rem 1rem .55rem 32px;     /* left room for flag, right for caret */
  background-image:
    var(--phone-flag, url("https://flagcdn.com/w40/us.png")),
    url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23334155' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
  background-repeat: no-repeat, no-repeat;
  background-position: left .5rem center, right .28rem center;
  background-size: 20px 15px, 9px 7px;
}
.co-banner .phone-group .phone-code { border-right: 0; }
.phone-group .form-control { flex: 1 1 auto; min-width: 0; }
.phone-group:focus-within { box-shadow: 0 0 0 .18rem rgba(6,182,212,.16); border-radius: .65rem; }

/* ── Modern checkout polish (2025-style) ──────────────────────────────── */
.co-banner { border-radius: 20px; }
.co-banner .co-num {
  background: linear-gradient(135deg,#0891b2,#06b6d4);
  color:#fff; box-shadow: 0 6px 16px rgba(6,182,212,.32);
}

/* ── Merged checkout card (2026-07-17e) ─────────────────────────────────
   The three previous cards (Contact / Billing / Payment) are now unified
   inside a single .co-merged card. Section titles remain visible for
   scannability, separated by hair-line dividers. Kills all hover/focus
   transforms so the page stays perfectly still while the customer fills
   in fields — no floating, no tilt, no jitter. */
.co-banner.co-merged { padding: 1.5rem !important; }
.co-banner.co-merged .co-section { padding: .25rem 0; }
.co-banner.co-merged .co-section-divider {
  margin: 1.15rem 0;
  border: 0; border-top: 1px dashed var(--bs-border-color);
  opacity: 1;
}
.co-banner.co-merged .co-head-icon {
  font-size: 1.4rem; color: #06b6d4; opacity: .55;
}
.co-banner.co-merged .co-head h6 { font-size: 1.02rem; }
@media (max-width: 576px) {
  .co-banner.co-merged { padding: 1rem !important; }
  .co-banner.co-merged .co-section-divider { margin: .9rem 0; }
}
/* Kill every animated transform on checkout cards so nothing "floats"
   when the customer clicks / hovers / focuses a field. */
.co-banner.no-3d,
.co-banner.no-3d:hover,
.co-banner.no-3d:focus,
.co-banner.no-3d:focus-within {
  transform: none !important;
  transition: box-shadow .15s ease, border-color .15s ease !important;
}

.co-banner .form-control, .co-banner .form-select {
  border-radius: .7rem; padding: .55rem .8rem; font-size: .92rem;
  border-color: var(--bs-border-color);
  transition: border-color .15s ease, box-shadow .15s ease, background-color .15s ease;
}
.co-banner .form-control:focus, .co-banner .form-select:focus {
  border-color: #06b6d4; box-shadow: 0 0 0 .2rem rgba(6,182,212,.15);
}
.co-banner .form-label {
  font-size: .68rem; font-weight: 700; letter-spacing: .05em;
  text-transform: uppercase; color: var(--bs-secondary-color); margin-bottom: .3rem;
}
.co-banner .row.g-2 { --bs-gutter-y: .9rem; --bs-gutter-x: .9rem; }
/* Payment method tiles — cleaner selectable cards */
.pay-tile {
  border: 1.5px solid var(--bs-border-color); border-radius: 14px;
  cursor: pointer; transition: border-color .15s ease, box-shadow .15s ease, background-color .15s ease;
}
.pay-tile:hover { border-color: rgba(6,182,212,.5); }
.pay-tile.active {
  border-color: #06b6d4; background: rgba(6,182,212,.05);
  box-shadow: 0 0 0 3px rgba(6,182,212,.12);
}
.co-merge-divider { margin: 1.6rem 0; }
/* PayPal info panel (shown when PayPal payment method is selected) */
.paypal-info-box {
  background: linear-gradient(135deg, rgba(0,48,135,.05), rgba(0,112,186,.08));
  border: 1px solid rgba(0,112,186,.25);
}
[data-bs-theme="dark"] .paypal-info-box {
  background: linear-gradient(135deg, rgba(0,48,135,.18), rgba(0,112,186,.22));
  border-color: rgba(0,112,186,.45);
}

/* ============================================================
   COMPACT CHECKOUT — target: fit everything from the top of the
   summary/payment cards to the "Pay Securely" button inside a single
   1080-vh viewport at 100 % zoom (no scroll needed on desktop).
   Achieved by shaving vertical padding / margins on the biggest offenders
   (co-banner cards, section heads, form labels, gap between form rows,
   the merge divider, and the paypal-info panel) — nothing hidden.
   ============================================================ */
.co-banner.p-3 { padding: 1rem !important; }
.co-summary-sticky.p-3 { padding: .9rem !important; }
.co-head { margin-bottom: .5rem !important; }
.co-head h6 { font-size: 1rem; }
.co-head small { font-size: .72rem; }
.co-head .co-num { width: 30px; height: 30px; font-size: .9rem; }
.co-merge-divider { margin: .85rem 0 !important; }
#card-form .form-label,
form .form-label { margin-bottom: .15rem; font-size: .74rem; letter-spacing: .04em; }
form .form-control,
form .form-select { padding: .38rem .65rem; font-size: .88rem; }
form .row.g-2 > * { padding-top: .25rem; padding-bottom: .25rem; }
form .row.g-3 { --bs-gutter-y: .75rem; }
#checkout-summary .card,
.pay-tile { padding: .55rem !important; }
.pay-tile .fw-bold { font-size: .95rem; }
.pay-tile small { font-size: .7rem; }
.paypal-info-box { padding: .75rem !important; }
.paypal-info-box ul { line-height: 1.45 !important; }
#card-form .card-field-hint { min-height: 14px; font-size: .68rem; }
/* Card number wider (fills its col fully). */
#card-number { font-size: 15px; letter-spacing: .04em; }

/* ============================================================
   Accepted card-brand logos UNDER the "Pay with Credit/Debit Card" tile —
   the single "we accept" row (always full colour). The brand the shopper is
   typing is shown INSIDE the card-number field instead (PayPal-style).
   ============================================================ */
.card-brands-tile {
  display: flex; align-items: center; gap: .35rem;
  margin-top: .55rem; padding-left: 1.75rem; /* aligns with the "Card" label after the radio */
}
.card-brands-tile .card-brand-icon {
  height: 20px; width: auto; border-radius: 3px; opacity: 1;
  box-shadow: 0 0 0 1px rgba(15,23,42,.08);
  transition: opacity .18s ease, transform .18s ease, box-shadow .18s ease, filter .18s ease;
}
/* When the shopper's card brand is detected, spotlight that logo and dim the
   others so it is obvious which card they are paying with. Works for the NMI
   tile (#card-brands), the PayPal-card tile and the inline pp-cf-brands row. */
.card-brands-tile.has-detected .card-brand-icon,
.pp-cf-brands.has-detected img {
  opacity: .32; filter: grayscale(.55);
}
.card-brands-tile.has-detected .card-brand-icon.is-detected,
.pp-cf-brands.has-detected img.is-detected {
  opacity: 1; filter: none; transform: scale(1.14);
  box-shadow: 0 0 0 2px var(--zoom-blue,#0B5CFF), 0 4px 10px rgba(11,92,255,.28);
}
.pp-cf-brands img { transition: opacity .18s ease, transform .18s ease, box-shadow .18s ease, filter .18s ease; }

/* Field error rendered INLINE next to the field label (right-aligned in
   the label row) — bold red plain text, no background pill. Only shows
   AFTER the customer has finished typing (see main.js — only fires when
   the card is full-length OR the field is fully wrong). */
.field-error-inline {
  font-size: .75rem;
  font-weight: 700;
  color: #dc2626;
  min-height: 14px;
  line-height: 1.2;
  padding-left: .5rem;
  text-align: right;
  /* Allow the message to wrap so it is ALWAYS fully readable — the old
     nowrap + ellipsis truncated "Invalid expiry date" inside the narrow
     col-6 expiry/CVV columns (customer-reported: "…MM / …"). */
  white-space: normal;
  overflow: visible;
  max-width: 70%;
}
[data-bs-theme="dark"] body:not(.adm) .field-error-inline { color: #fca5a5 !important; }

/* Field-level validity ring (kept minimal — no background icon). */
#card-form .form-control.is-invalid { border-color: #ef4444; background-image: none; padding-right: .65rem; }
#card-form .form-control.is-valid   { border-color: #10b981; background-image: none; padding-right: .65rem; }

/* ============================================================
   Address auto-suggest dropdown (OpenStreetMap Nominatim, proxied
   via /ajax/address-suggest.php). Rendered as an absolutely-positioned
   panel directly under the #checkout-address input.  z-index is high
   enough to sit ABOVE the sibling Country/City/State/Zip row AND above
   the Pay Securely button that renders further down in the same card
   — otherwise the panel gets clipped by the button.
   ============================================================ */
.checkout-addr-parent { position: relative; }
/* Address auto-suggest CSS removed 2026-07-17e — no longer needed. */

/* ============================================================
   CHECKOUT REDESIGN (2026-07) — match reference screenshots.
   Removes the harsh near-black dark-mode background and swaps it
   for a soft slate-navy that matches the reference (light: off-
   white gray, dark: slate-900 navy — NOT pure black).

   Scope: EVERYTHING here is gated on `.checkout-canvas` so no
   other page (product, category, home, admin, blog) can pick
   these overrides up.  `body:has(.checkout-canvas)` is used to
   override the site-wide body background ONLY on this page.
   Modern-browser :has() is baseline (Safari 15.4+, Chrome 105+,
   Firefox 121+); the `.checkout-canvas` wrapper also carries the
   background as a belt-and-suspenders fallback for older engines.
   ============================================================ */

/* — Page canvas — soft off-white gray in light, slate-navy in dark. */
body:has(.checkout-canvas) {
  background: #f5f7fb !important;
  background-image: none !important;
}
[data-bs-theme="dark"] body:has(.checkout-canvas),
body[data-bs-theme="dark"]:has(.checkout-canvas) {
  background: #0f172a !important;
  background-image: none !important;
}
.checkout-canvas {
  background: #f5f7fb;
  min-height: calc(100vh - 64px);
  padding: 8px 0 32px 0;
}
[data-bs-theme="dark"] .checkout-canvas { background: #0f172a; }

/* — Cards on the checkout: white in light, slate-800 in dark.
     Beats the sitewide dark-mode-polish gradient (which used a
     linear-gradient(#243049,#1c2538)) so the checkout cards land on
     a calm, flat colour that reads clean against the navy canvas. */
.checkout-canvas .co-banner,
.checkout-canvas .card.co-banner,
.checkout-canvas #checkout-summary .card {
  background: #ffffff !important;
  background-image: none !important;
  border: 1px solid #e5e7eb !important;
  box-shadow: 0 1px 2px rgba(15,23,42,.04), 0 6px 20px rgba(15,23,42,.05) !important;
  color: #0f172a;
}
[data-bs-theme="dark"] .checkout-canvas .co-banner,
[data-bs-theme="dark"] .checkout-canvas .card.co-banner,
[data-bs-theme="dark"] .checkout-canvas #checkout-summary .card {
  background: #1e293b !important;
  background-image: none !important;
  border-color: #334155 !important;
  color: #f1f5f9;
  box-shadow: 0 1px 2px rgba(0,0,0,.35), 0 8px 24px rgba(0,0,0,.25) !important;
}

/* — Need Assistance card: keep the friendly blue tint in light,
     switch to a soft navy-blue tint in dark (reference matches this). */
.checkout-canvas .co-help {
  background: linear-gradient(180deg,#eff6ff,#ffffff) !important;
  border-color: #dbeafe !important;
}
[data-bs-theme="dark"] .checkout-canvas .co-help {
  background: linear-gradient(180deg,#1e293b,#172033) !important;
  border-color: #334155 !important;
}

/* — Form controls on the checkout — a touch brighter in dark so
     placeholder text is easy to read against the slate card. */
[data-bs-theme="dark"] .checkout-canvas .form-control,
[data-bs-theme="dark"] .checkout-canvas .form-select,
[data-bs-theme="dark"] .checkout-canvas .form-control:focus,
[data-bs-theme="dark"] .checkout-canvas .form-select:focus {
  background-color: #0f172a !important;
  border-color: #334155 !important;
  color: #f1f5f9 !important;
}
[data-bs-theme="dark"] .checkout-canvas .form-control::placeholder {
  color: #64748b !important;
}

/* — Section divider hair-line stays subtle in both modes. */
.checkout-canvas .co-section-divider { border-top-color: #e5e7eb !important; }
[data-bs-theme="dark"] .checkout-canvas .co-section-divider { border-top-color: #334155 !important; }

/* — Section head icons + heading colours mirror the reference. */
.checkout-canvas .co-head h6 { color: #0f172a; }
[data-bs-theme="dark"] .checkout-canvas .co-head h6 { color: #f1f5f9; }
.checkout-canvas .co-head-icon { color: #2563eb !important; opacity: .9 !important; }
[data-bs-theme="dark"] .checkout-canvas .co-head-icon { color: #60a5fa !important; }

/* — Payment method tiles — cleaner outline that pops on both bg colours. */
.checkout-canvas .pay-tile { background: #ffffff !important; border-color: #e5e7eb !important; }
.checkout-canvas .pay-tile.active {
  background: #eff6ff !important;
  border-color: #2563eb !important;
  box-shadow: 0 0 0 3px rgba(37,99,235,.15) !important;
}
[data-bs-theme="dark"] .checkout-canvas .pay-tile {
  background: #0f172a !important; border-color: #334155 !important; color: #cbd5e1 !important;
}
[data-bs-theme="dark"] .checkout-canvas .pay-tile.active {
  background: rgba(37,99,235,.16) !important;
  border-color: #60a5fa !important;
  box-shadow: 0 0 0 3px rgba(96,165,250,.22) !important;
  color: #f1f5f9 !important;
}

/* — Pay button on both themes — match reference solid blue CTA. */
.checkout-canvas #btn-pay-card {
  background: linear-gradient(135deg,#2563eb,#3b82f6) !important;
  border-color: transparent !important;
  color: #ffffff !important;
}
.checkout-canvas #btn-pay-card:hover { filter: brightness(1.06); }

/* — Total + "You save" line colours in the summary card. */
.checkout-canvas #checkout-summary .fw-bold,
.checkout-canvas #checkout-summary h5,
.checkout-canvas #checkout-summary h6 { color: inherit; }
.checkout-canvas #checkout-summary .text-success { color: #16a34a !important; }
[data-bs-theme="dark"] .checkout-canvas #checkout-summary .text-success { color: #4ade80 !important; }

/* — Secondary text throughout: readable on both bg colours. */
.checkout-canvas .text-secondary { color: #64748b !important; }
[data-bs-theme="dark"] .checkout-canvas .text-secondary { color: #94a3b8 !important; }

</style>
<script>
/* Region-aware checkout address form. The PHP $REGION_FORMS config is the
   single source of truth; this mirrors it client-side so changing the Country
   select instantly reshapes the State/Province/County field, its label, the
   Postal/ZIP label + placeholder and the phone dial code — without a reload. */
window.MV_REGION_FORMS = <?= json_encode($JS_REGION_FORMS) ?>;
window.MV_LIVE_CUR = <?= json_encode($__coLiveCur) ?>;
window.MV_CUR_NOW = <?= json_encode($__activeCur) ?>;
<?php
  // Data for the live "You'll be charged … approx …" statement note.
  $__fxRates = [];
  foreach ($GLOBALS['CURRENCIES'] as $__fc => $__fv) { $__fxRates[$__fc] = ['symbol' => (string)$__fv['symbol'], 'rate' => (float)$__fv['rate']]; }
  $__ccCur = [];
  foreach (array_keys($ALL_COUNTRIES) as $__cc2) { $__h = mv_country_home_currency($__cc2); if ($__h !== '') $__ccCur[$__cc2] = $__h; }
?>
window.MV_FX = <?= json_encode($__fxRates) ?>;
window.MV_COUNTRY_CUR = <?= json_encode($__ccCur) ?>;
window.MV_TOTAL_USD = <?= json_encode(round((float)$total, 2)) ?>;
/* Rebuild the statement note for the selected billing country without a reload. */
window.mvUpdateFxNote = function (cc) {
  var box = document.getElementById('mvFxNote'); if (!box) return;
  cc = String(cc || '').toUpperCase();
  var charge = window.MV_CUR_NOW || 'USD', fx = window.MV_FX || {}, home = (window.MV_COUNTRY_CUR || {})[cc] || '';
  if (!cc || (home && home === charge) || !fx[charge]) { box.style.display = 'none'; var p0 = document.getElementById('mvPayFxNote'); if (p0) p0.style.display = 'none'; return; }
  var usd = Number(window.MV_TOTAL_USD || 0);
  var fmt = function (code) { var c = fx[code]; return c ? (c.symbol + (usd * c.rate).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' ' + code) : ''; };
  var set = function (id, t) { var e = document.getElementById(id); if (e) e.textContent = t; };
  set('mvFxCharge', fmt(charge)); set('mvFxChargeName', charge);
  var pay = document.getElementById('mvPayFxNote');
  if (pay) { if (home && fx[home]) { set('mvPayFxCharge', charge); set('mvPayFxApprox', fmt(home)); pay.style.display = ''; } else { pay.style.display = 'none'; } }
  var ap = document.getElementById('mvFxApproxLine'), gl = document.getElementById('mvFxGenericLine');
  if (home && fx[home]) { set('mvFxApprox', fmt(home)); set('mvFxCode', home); if (ap) ap.style.display = ''; if (gl) gl.style.display = 'none'; }
  else { if (ap) ap.style.display = 'none'; if (gl) gl.style.display = ''; }
  box.style.display = '';
};
/* Changing the checkout Country must switch the storefront CURRENCY too, so the
   country selected always matches the currency being charged (e.g. selecting
   Canada shows CA$ prices — never US country with CA$ totals). We reload the
   checkout under that country's region prefix + ?cur= so every price recomputes
   in the matching currency. The cart (session) is preserved across the reload.
   For any OTHER country (rest of the world) we don't have a dedicated
   currency/region-prefix — we just morph the address form in-place so the
   State/Region + Postal fields adapt to the selection without a page reload. */
/* Preserve the shopper's typed billing details across the currency-switch
   page reload that mvSwitchCheckoutCountry triggers for US/CA/UK/AU/EU.
   Card fields are DELIBERATELY never persisted (PII/PCI safety). */
var MV_CO_KEEP = ['email','first_name','last_name','phone','address','address2','city','zip','state','company_name'];
function mvSaveCheckoutFields(){
  try{
    var data={};
    MV_CO_KEEP.forEach(function(n){
      var el=document.querySelector('[name="'+n+'"]');
      if(el && el.value) data[n]=el.value;
    });
    sessionStorage.setItem('mv_co_fields', JSON.stringify(data));
  }catch(e){}
}
function mvRestoreCheckoutFields(){
  try{
    var raw=sessionStorage.getItem('mv_co_fields'); sessionStorage.removeItem('mv_co_fields');
    if(!raw) return;
    var data=JSON.parse(raw)||{};
    Object.keys(data).forEach(function(n){
      var el=document.querySelector('[name="'+n+'"]');
      if(el && !el.value){ el.value=data[n]; if(typeof clearFieldError==='function') clearFieldError(el); }
    });
  }catch(e){}
}
if(document.readyState!=='loading') mvRestoreCheckoutFields(); else document.addEventListener('DOMContentLoaded', mvRestoreCheckoutFields);

function mvSwitchCheckoutCountry(cc) {
  cc = (cc || 'US').toUpperCase();
  var CUR = { US: 'USD', CA: 'CAD', UK: 'GBP', AU: 'AUD', EU: 'EUR' };
  if (Object.prototype.hasOwnProperty.call(CUR, cc)) {
    var cur = CUR[cc];
    var live = window.MV_LIVE_CUR || ['USD'];
    // Only reload to switch pricing when the target currency is one the store
    // actually charges in AND differs from the current one. Otherwise the
    // reload would just bounce back to USD/US and wipe the form — so instead we
    // keep the chosen country selected and reshape the address fields inline.
    if (cur !== window.MV_CUR_NOW && live.indexOf(cur) > -1) {
      var prefix = (cc === 'US') ? '' : '/' + cc.toLowerCase();
      mvSaveCheckoutFields();                     // keep typed billing details across the reload
      window.location.href = prefix + '/checkout.php?cur=' + cur;
      return;
    }
    mvApplyCheckoutRegion(cc);                     // no currency change → reshape address, keep country
    if (window.mvUpdateFxNote) mvUpdateFxNote(cc); // e.g. Canada on the US store → "charged in USD ≈ CA$"
    return;
  }
  // Rest-of-world: just reshape the address fields client-side.
  mvApplyCheckoutRegion(cc);
  if (window.mvUpdateFxNote) mvUpdateFxNote(cc);
}
function mvApplyCheckoutRegion(cc) {
  var rf = window.MV_REGION_FORMS[cc] || window.MV_REGION_FORMS['US'];
  if (!rf) return;
  var wrap = document.getElementById('co-region-wrap');
  if (wrap) {
    var prev = '';
    var prevEl = wrap.querySelector('[name="state"]');
    if (prevEl) prev = prevEl.value;
    var reqAttr = rf.region_required ? ' required' : '';
    var html = '<label class="form-label" id="co-region-label">' + rf.region_label + (rf.region_required ? ' *' : '') + '</label>';
    if (rf.regions && rf.regions.length) {
      html += '<select name="state"' + reqAttr + ' class="form-select" data-testid="state-select"><option value="">Select</option>';
      rf.regions.forEach(function (s) {
        var lbl = (rf.region_names && rf.region_names[s]) ? (s + ' \u2014 ' + rf.region_names[s]) : s;
        html += '<option value="' + s + '"' + (s === prev ? ' selected' : '') + '>' + lbl + '</option>';
      });
      html += '</select>';
    } else {
      html += '<input name="state"' + reqAttr + ' class="form-control" value="' + (prev || '').replace(/\x22/g, '&quot;') + '" data-testid="state-select" placeholder="">';
    }
    wrap.innerHTML = html;
  }
  // --- Postal / ZIP label + placeholder ---
  var postalReq = (rf.postal_required === undefined) ? true : !!rf.postal_required;
  var pl = document.getElementById('co-postal-label');
  if (pl) pl.textContent = rf.postal_label + (postalReq ? ' *' : '');
  var pin = document.getElementById('co-postal');
  if (pin) { pin.setAttribute('placeholder', ''); if (postalReq) pin.setAttribute('required', 'required'); else pin.removeAttribute('required'); }
  // --- Phone dial code + flag ---
  var pc = document.getElementById('phone-code');
  if (pc && rf.dial) {
    for (var i = 0; i < pc.options.length; i++) {
      if (pc.options[i].value === rf.dial) { pc.selectedIndex = i; break; }
    }
    if (typeof syncPhoneFlag === 'function') syncPhoneFlag(pc);
  }
}

/* ============================================================
   Submit-time card validation.  Only runs when the selected payment
   method is "card" (PayPal jumps straight to the PayPal flow).
   Uses the same detectCardBrand()/luhnCheck() helpers exposed by
   assets/js/main.js.  On failure: focuses the offending field, adds
   .is-invalid, and returns false so the form doesn't submit.
   ============================================================ */
function mvValidateCheckoutOnSubmit(form, ev) {
  var pm = (document.getElementById('payment-method-input') || {}).value || 'card';
  if (pm !== 'card') return true; // PayPal path skips card checks
  if (window.MV_COLLECTJS || window.__mvCardUI) return true; // hosted fields / first-party controller validate themselves
  var num  = document.getElementById('card-number');
  var exp  = document.getElementById('card-exp');
  var cvv  = document.getElementById('card-cvv');
  if (!num) return true; // Card form not on page (edge case)
  var digits = (num.value || '').replace(/\D/g, '');
  var info   = (typeof detectCardBrand === 'function') ? detectCardBrand(digits) : { brand: '', len: [16], cvv: 3 };
  var okLuhn = (typeof luhnCheck === 'function') ? luhnCheck(digits) : true;
  var maxL   = info.len[info.len.length - 1] || 16;

  function fail(el, msg) {
    if (el) { el.classList.add('is-invalid'); el.focus(); }
    var toast = document.getElementById('mv-card-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'mv-card-toast';
      toast.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:9999;background:#ef4444;color:#fff;padding:.7rem 1.1rem;border-radius:12px;font-size:.9rem;font-weight:600;box-shadow:0 12px 30px rgba(239,68,68,.35);animation:aaSlide .3s ease;';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    clearTimeout(window.__mvCardToastT);
    window.__mvCardToastT = setTimeout(function () { if (toast) toast.remove(); }, 3500);
    if (ev && ev.preventDefault) ev.preventDefault();
    return false;
  }

  if (!digits.length)            return fail(num, 'Please enter your card number.');
  // Accept ANY 13–19 digit card that passes Luhn — do NOT block unknown card
  // brands (JCB, UnionPay, Maestro, etc.) or enforce a brand-specific length.
  // If the card is good, let the processor/bank make the decision.
  if (digits.length < 13 || digits.length > 19) return fail(num, 'Invalid card number');
  if (!okLuhn)                   return fail(num, 'Invalid card number');
  var eDig = ((exp && exp.value) || '').replace(/\D/g, '');
  if (eDig.length < 4)           return fail(exp, 'Please enter the card expiry (MM/YY).');
  var mm = parseInt(eDig.slice(0,2), 10), yy = parseInt(eDig.slice(2,4), 10);
  if (eDig.length === 3) { mm = parseInt(eDig.slice(0,1),10); yy = parseInt(eDig.slice(1,3),10); }
  else if (eDig.length >= 6) { mm = parseInt(eDig.slice(0,2),10); yy = parseInt(eDig.slice(-2),10); }
  if (mm < 1 || mm > 12)         return fail(exp, 'Expiry month must be 01-12.');
  var now = new Date(), cy = now.getFullYear() % 100;
  // Clock-skew tolerant: only reject a date clearly >1 year in the past so a
  // wrong device clock never blocks a good card — the bank rejects real expiries.
  if (yy < cy - 1)               return fail(exp, 'Card is expired.');
  var cvvVal  = (cvv && cvv.value) || '';
  if (!/^\d{3,4}$/.test(cvvVal)) return fail(cvv, 'Invalid CVV');
  return true;
}
window.mvValidateCheckoutOnSubmit = mvValidateCheckoutOnSubmit;

/* ============================================================
   Highlight the shopper's detected card brand inside the accepted-brand
   logo rows ("Pay with Credit/Debit Card" tile + inline pp-cf-brands),
   dimming the others. Called by both the NMI Collect.js lookUpCallback and
   the PayPal CardFields onChange handler. Pass '' to clear the highlight.
   ============================================================ */
window.mvHighlightAcceptedBrand = function (brand) {
  var ok = { visa: 1, mastercard: 1, amex: 1, discover: 1 };
  brand = ok[brand] ? brand : '';
  document.querySelectorAll('.card-brands-tile, .pp-cf-brands').forEach(function (row) {
    row.classList.toggle('has-detected', brand !== '');
    row.querySelectorAll('img[data-brand]').forEach(function (ic) {
      ic.classList.toggle('is-detected', brand !== '' && ic.getAttribute('data-brand') === brand);
    });
  });
};
</script>
<style>
  /* NMI Collect.js hosted fields — exactly ONE visible box per field.
     The visible box is OUR wrapper (.mv-cjs-box). The NMI iframe inside it is
     border-less + outline-less using ONLY Collect.js allow-listed properties
     (border-width/-style, outline-style/-width …). Collect.js silently drops
     shorthands such as `border`, `outline`, `width`, `box-sizing`, which is why
     the browser's default focus ring used to show as dark lines inside the box. */
  .mv-cjs-box{position:relative;display:block;height:calc(2.725rem + 2px);border:1px solid var(--zoom-line,#E4E8EE);border-radius:10px;background:#fff;overflow:hidden;transition:border-color .15s ease,box-shadow .15s ease}
  .mv-cjs-box:hover{border-color:rgba(11,92,255,.35)}
  .mv-cjs-box.is-focus{border-color:var(--zoom-blue,#0B5CFF);box-shadow:0 0 0 4px var(--uc-ring,rgba(11,92,255,.28))}
  .mv-cjs-box.is-invalid{border-color:#ef4444}
  .mv-cjs-box.is-invalid.is-focus{box-shadow:0 0 0 4px rgba(239,68,68,.16)}
  .mv-cjs-box.is-valid{border-color:#10b981}
  .mv-cjs-box.is-valid.is-focus{box-shadow:0 0 0 4px rgba(16,185,129,.16)}
  /* Icons are overlays (pointer-events:none) so the WHOLE box is clickable — the
     hosted iframe spans the full width; text is inset via Collect.js padding. */
  .mv-cjs-lead{position:absolute;left:0;top:0;bottom:0;width:40px;display:flex;align-items:center;justify-content:center;color:var(--zoom-blue,#0B5CFF);font-size:1rem;pointer-events:none;transition:color .15s ease;z-index:1}
  .mv-cjs-box.is-invalid .mv-cjs-lead{color:#ef4444}
  .mv-cjs-field{display:block;width:100%;height:100%;margin:0;padding:0;border:0;background:transparent}
  .mv-cjs-field iframe{display:block;width:100% !important;height:100% !important;border:0 !important;margin:0;padding:0;vertical-align:top;background:transparent}
  .mv-cjs-state{position:absolute;right:0;top:0;bottom:0;width:36px;display:flex;align-items:center;justify-content:center;font-size:.95rem;pointer-events:none;z-index:1}
  .mv-cjs-state .bi{display:none;opacity:0;transform:scale(.6);transition:opacity .15s ease,transform .15s ease}
  .mv-cjs-box.is-valid .mv-cjs-ok{display:inline-block;opacity:1;transform:none;color:#10b981}
  .mv-cjs-box.is-invalid .mv-cjs-bad{display:inline-block;opacity:1;transform:none;color:#ef4444}
  .mv-cjs-help{display:inline-block;font-size:.78rem;line-height:0;color:#94a3b8;cursor:help;vertical-align:-.12em;margin-left:.15rem}
  .mv-cjs-help:hover,.mv-cjs-help:focus{color:var(--zoom-blue,#0B5CFF);outline:none}
  /* Dark theme: the secure fields match every other checkout input
     (#0f172a surface, #334155 border, light ink). Chrome paints a cross-origin
     iframe on an OPAQUE canvas when its colour scheme differs from ours, so the
     hosted <input> itself is given the same opaque dark background via
     Collect.js customCss (see configure()) — the iframe can never show white. */
  [data-bs-theme="dark"] .mv-cjs-box{background:#0f172a;border-color:#334155}
  [data-bs-theme="dark"] .mv-cjs-box:hover{border-color:rgba(96,165,250,.55)}
  [data-bs-theme="dark"] .mv-cjs-box.is-focus{border-color:#60a5fa;box-shadow:0 0 0 4px rgba(96,165,250,.28)}
  [data-bs-theme="dark"] .mv-cjs-box.is-valid{border-color:#10b981}
  [data-bs-theme="dark"] .mv-cjs-box.is-invalid{border-color:#ef4444}
  [data-bs-theme="dark"] .mv-cjs-lead{color:#60a5fa}
  [data-bs-theme="dark"] .mv-cjs-box.is-invalid .mv-cjs-lead{color:#f87171}
  /* Card-number status line under the field: green when verified, red when invalid
     (the dark-mode rule above forces every field message red, so re-assert green). */
  .field-error-inline.is-ok{color:#10b981 !important;}
  [data-bs-theme="dark"] body:not(.adm) .field-error-inline.is-ok{color:#34d399 !important;}
  /* ---- First-party card inputs (owner decision 2026-09-30): same box design,
          real <input>s so the brand lights up from the FIRST digit. ---- */
  .mv-card-box .mv-card-input{position:absolute;inset:0;width:100%;height:100%;margin:0;padding:0 44px 0 40px;border:0;outline:0;box-shadow:none;background:transparent;color:#131619;font:500 15px/1 Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;letter-spacing:.03em;border-radius:10px;-webkit-appearance:none;appearance:none}
  .mv-card-box .mv-card-input:focus{outline:0;box-shadow:none}
  .mv-card-box .mv-card-input::placeholder{color:#9aa3b2;font-weight:400;letter-spacing:.02em}
  .mv-card-box.has-brand .mv-card-input#card-number{padding-right:96px}
  .mv-card-box .mv-card-input#card-cvv{padding-right:76px}
  .mv-card-box.is-invalid .mv-card-input{color:#b91c1c}
  [data-bs-theme="dark"] .mv-card-box .mv-card-input{color:#f1f5f9}
  [data-bs-theme="dark"] .mv-card-box .mv-card-input::placeholder{color:#64748b}
  [data-bs-theme="dark"] .mv-card-box.is-invalid .mv-card-input{color:#fca5a5}
  /* Big brand logo inside the number field (right side, left of the state icon). */
  .mv-card-brand-big{position:absolute;right:40px;top:50%;height:26px;width:auto;transform:translateY(-50%) scale(.6);opacity:0;border-radius:4px;box-shadow:0 0 0 1px rgba(15,23,42,.08);pointer-events:none;z-index:1;transition:opacity .18s ease,transform .18s ease}
  .mv-card-box.has-brand .mv-card-brand-big{opacity:1;transform:translateY(-50%) scale(1)}
  /* CVV show/hide eye sits left of the state icon. */
  .mv-cvv-eye{position:absolute;right:36px;top:0;bottom:0;width:34px;display:flex;align-items:center;justify-content:center;border:0;background:transparent;color:#94a3b8;font-size:.95rem;cursor:pointer;z-index:2;padding:0}
  .mv-cvv-eye:hover,.mv-cvv-eye:focus-visible{color:var(--zoom-blue,#0B5CFF);outline:none}
  [data-bs-theme="dark"] .mv-cvv-eye{color:#64748b}
  [data-bs-theme="dark"] .mv-cvv-eye:hover,[data-bs-theme="dark"] .mv-cvv-eye:focus-visible{color:#60a5fa}
  /* Bootstrap's .form-control autofill/validation chrome must not leak in. */
  .mv-card-box .mv-card-input:-webkit-autofill{-webkit-text-fill-color:#131619;box-shadow:0 0 0 1000px #fff inset}
  [data-bs-theme="dark"] .mv-card-box .mv-card-input:-webkit-autofill{-webkit-text-fill-color:#f1f5f9;box-shadow:0 0 0 1000px #0f172a inset}
</style>
<?php if ($cardCollectJs): ?>
<script>
/* ============================================================
   NMI Collect.js — hosted card fields + browser-side tokenisation.
   Card number / expiry / CVV live inside NMI iframes; on Pay we call
   CollectJS.startPaymentRequest(), receive a single-use payment_token
   (+ display-safe BIN / last4 / brand / exp) and submit the form with
   ONLY the token. Raw card data never touches checkout.php.
   ============================================================ */
window.MV_COLLECTJS = true;
(function(){
  var pending = false;
  var errEls = { ccnumber: 'card-number-error', ccexp: 'card-exp-error', cvv: 'card-cvv-error' };
  var boxEls = { ccnumber: 'cjs-box-ccnumber', ccexp: 'cjs-box-ccexp', cvv: 'cjs-box-cvv' };
  var friendlyMsg = {
    ccnumber: 'Invalid card number',
    ccexp:    'Invalid expiry date',
    cvv:      'Invalid security code'
  };
  // Sanity-check the tokenised expiry (MMYY). NMI's hosted field marks a
  // 4-digit year like "12 / 1954" valid because it keeps only the last two
  // digits (→ 2054), so guard against BOTH a past date and an implausibly
  // far-future one (> current year + 19) at Pay time.
  function expOk(exp) {
    exp = String(exp || '').replace(/\D/g, '');
    if (exp.length !== 4) return false;
    var mm = parseInt(exp.slice(0, 2), 10);
    var yy = parseInt(exp.slice(2, 4), 10);
    if (mm < 1 || mm > 12) return false;
    var now = new Date(), curY = now.getFullYear(), curM = now.getMonth() + 1;
    var full = 2000 + yy;
    if (full < curY || (full === curY && mm < curM)) return false; // expired
    if (full > curY + 19) return false;                            // implausibly far out
    return true;
  }
  // Per-field LIVE state. NMI's hosted iframe posts an "nmi-input" message to
  // the parent on EVERY keystroke ({empty, isValid}) and "focus"/"blur"
  // messages; validationCallback itself only fires on success or on a blur
  // error. Rules (owner decision):
  //   • green "✓ Card verified"  → number is complete + valid (Luhn) AND the
  //     shopper paused for 450 ms (or left the field) — so a 13-digit prefix
  //     that happens to pass Luhn never flashes green mid-typing, and green is
  //     dropped the instant another digit makes the number invalid again;
  //   • red "Invalid card number" → only after LEAVING the field with a wrong
  //     value, or on Pay — never while still typing;
  //   • empty field → neutral (Pay reveals "required").
  var NMI_ORIGIN = 'https://secure.nmi.com';
  var fstate = {
    ccnumber: { valid: false, empty: true, focused: false, touched: false },
    ccexp:    { valid: false, empty: true, focused: false, touched: false },
    cvv:      { valid: false, empty: true, focused: false, touched: false }
  };
  var okTimer = {};
  var payTried = false; // after a Pay attempt, an EMPTY field shows "… required" instead of staying silent
  var requiredMsg = { ccnumber: 'Card number required', ccexp: 'Expiry date required', cvv: 'Security code required' };
  function paint(field, cls, msg) {
    var e = document.getElementById(errEls[field] || '');
    if (e) {
      if (cls === 'is-invalid' && msg) { e.textContent = msg; e.classList.remove('is-ok'); }
      else if (cls === 'is-valid' && field === 'ccnumber') { e.textContent = '\u2713 Card verified'; e.classList.add('is-ok'); }
      else { e.textContent = ''; e.classList.remove('is-ok'); }
    }
    var b = document.getElementById(boxEls[field] || '');
    if (b) { b.classList.toggle('is-invalid', cls === 'is-invalid'); b.classList.toggle('is-valid', cls === 'is-valid'); }
  }
  function render(field) {
    var st = fstate[field]; if (!st) return;
    clearTimeout(okTimer[field]);
    if (st.empty) { if (payTried && !st.focused) paint(field, 'is-invalid', requiredMsg[field]); else paint(field, ''); return; }
    if (st.valid) {
      if (!st.focused) { paint(field, 'is-valid'); return; }
      paint(field, '');
      okTimer[field] = setTimeout(function () {
        if (fstate[field].valid && !fstate[field].empty) paint(field, 'is-valid');
      }, 450);
      return;
    }
    if (!st.focused && st.touched) paint(field, 'is-invalid', friendlyMsg[field]);
    else paint(field, '');
  }
  function setFocus(field, on) {
    var st = fstate[field]; if (!st) return;
    var b = document.getElementById(boxEls[field] || '');
    if (b) b.classList.toggle('is-focus', !!on);
    st.focused = !!on;
    if (on) { if (!st.valid) paint(field, ''); }          // hide any red while editing
    else { if (!st.empty) st.touched = true; render(field); } // reveal verdict on leave
  }
  function showAllErrors() {
    payTried = true;
    var firstBad = null;
    for (var f in fstate) {
      clearTimeout(okTimer[f]);
      fstate[f].focused = false; fstate[f].touched = true;
      if (fstate[f].valid && !fstate[f].empty) paint(f, 'is-valid');
      else { paint(f, 'is-invalid', fstate[f].empty ? requiredMsg[f] : friendlyMsg[f]); if (!firstBad) firstBad = document.getElementById(boxEls[f]); }
    }
    return firstBad;
  }
  // Used by the form's submit validator: paints every hosted-field verdict and
  // returns the first invalid box (or null when all three are good).
  window.__mvCjsInvalidEl = function () { return window.__mvCjsReady ? showAllErrors() : null; };
  // Live keystroke + focus/blur feed straight from the hosted iframes.
  window.addEventListener('message', function (ev) {
    if (ev.origin !== NMI_ORIGIN) return;
    var d = ev.data || {}; var field = d.elementId; var st = fstate[field];
    if (!st) return;
    if (d.action === 'nmi-input') {
      st.empty = !!d.empty; st.valid = !!d.isValid && !st.empty; st.touched = st.touched || !st.empty;
      if (field === 'ccnumber' && st.empty && window.mvHighlightAcceptedBrand) mvHighlightAcceptedBrand('');
      render(field);
    } else if (d.action === 'focus') {
      setFocus(field, true);
    } else if (d.action === 'blur') {
      if (typeof d.empty === 'boolean') { st.empty = d.empty; if (d.empty) st.valid = false; }
      setFocus(field, false);
    }
  });
  function setErr(field, msg) { /* legacy shim kept for safety */ paint(field, msg ? 'is-invalid' : '', msg); }
  function reset() { pending = false; window.__mvRestoreSubmitBtns && window.__mvRestoreSubmitBtns(); }
  function toast(msg) {
    if (typeof showToast === 'function') showToast('<i class="bi bi-exclamation-triangle me-1"></i> ' + msg);
  }
  function configure() {
    if (typeof CollectJS === 'undefined') { setTimeout(configure, 150); return; }
    var dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    // Theme-matched ink + surface INSIDE the hosted iframe. The background is
    // deliberately OPAQUE: Chrome renders a cross-origin iframe on an opaque
    // canvas when its colour scheme differs from the parent, so a transparent
    // input on a dark page showed white behind light text (the invisible-digits
    // bug). Painting the input itself #0f172a makes the field read like every
    // other dark checkout input with bright, legible digits.
    var ink   = dark ? '#f1f5f9' : '#131619';
    var surf  = dark ? '#0f172a' : '#ffffff';
    var ph    = dark ? '#64748b' : '#9aa3b2';
    var bad   = dark ? '#fca5a5' : '#b91c1c';
    /* Collect.js only honours an allow-list of CSS properties (no `border`,
       `outline`, `width`, `box-sizing` shorthands — they are silently dropped).
       Everything below is allow-listed, so the inner input is guaranteed to be
       border-less and outline-less in EVERY state; our .mv-cjs-box wrapper is
       the one and only visible box. */
    var noChrome = {
      'border-width': '0', 'border-style': 'none', 'border-radius': '0',
      'outline-style': 'none', 'outline-width': '0', 'outline-color': 'transparent',
      'box-shadow': 'none', 'background-color': surf,
      'margin-top': '0', 'margin-bottom': '0'
    };
    function css(extra) { var o = {}; for (var k in noChrome) o[k] = noChrome[k]; for (var j in extra) o[j] = extra[j]; return o; }
    // clientHeight = the wrapper's inner CSS height (border excluded, unaffected by
    // the desktop :root zoom, which Chrome also applies inside the iframe).
    var fieldH = (document.getElementById('cjs-box-ccnumber') || {}).clientHeight || 41;
    CollectJS.configure({
      variant: 'inline',
      paymentSelector: '#cjs-noop-trigger',
      styleSniffer: false,
      googleFont: 'Inter:400,500,600',
      customCss: css({
        'height': fieldH + 'px', 'line-height': fieldH + 'px', 'padding': '0 44px 0 40px',
        'font-size': '15px', 'font-weight': '500', 'letter-spacing': '.03em',
        'font-family': 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
        'color': ink, 'transition': 'color .15s ease'
      }),
      placeholderCss: { 'color': ph, 'font-weight': '400', 'letter-spacing': '.02em' },
      focusCss:   css({ 'color': ink }),
      invalidCss: css({ 'color': bad }),
      validCss:   css({ 'color': ink }),
      lookUpCallback: function (r) {
        // NMI's BIN lookup confirms the brand once the number validates — light
        // up that logo in the accepted-cards row (the in-field logo is drawn by
        // NMI itself from the very first digit via enableCardBrandPreviews).
        var map = { visa:'visa', mastercard:'mastercard', master:'mastercard', amex:'amex', americanexpress:'amex', discover:'discover' };
        var brand = map[String((r && r.type) || '').toLowerCase().replace(/[^a-z]/g, '')] || '';
        if (window.mvHighlightAcceptedBrand) mvHighlightAcceptedBrand(brand);
      },
      fields: {
        // enableCardBrandPreviews → NMI renders the Visa / Mastercard / Amex /
        // Discover logo INSIDE the secure field from the FIRST digit typed (the
        // digits live in NMI's iframe, so only NMI can detect the brand that early).
        ccnumber: { selector: '#cjs-ccnumber', title: 'Card number', placeholder: '1234 5678 9012 3456', enableCardBrandPreviews: true },
        ccexp:    { selector: '#cjs-ccexp',    title: 'Expiry date', placeholder: 'MM / YY' },
        cvv:      { display: 'show', selector: '#cjs-cvv', title: 'Security code', placeholder: '•••' }
      },
      timeoutDuration: 15000,
      timeoutCallback: function () {
        reset();
        toast('The secure card fields did not respond. Please check your card details and try again.');
      },
      validationCallback: function (field, status, message) {
        // Fallback feed (fires on success and on blur-error); the live
        // "nmi-input" message listener above already tracks every keystroke.
        var st = fstate[field]; if (!st) return;
        var isEmpty = !status && !!message && /empty/i.test(message);
        st.empty = isEmpty; st.valid = !!status; if (status || !isEmpty) st.touched = true;
        if (field === 'ccnumber' && isEmpty && window.mvHighlightAcceptedBrand) mvHighlightAcceptedBrand('');
        render(field);
        if (pending && !status) { reset(); toast('Please fix the highlighted card field before continuing.'); }
      },
      fieldsAvailableCallback: function () {
        document.querySelectorAll('.mv-cjs-box').forEach(function (b) {
          var f = b.querySelector('iframe');
          if (!f) return;
          var field = (b.id || '').replace('cjs-box-', '');
          f.addEventListener('focus', function(){ setFocus(field, true); });
          f.addEventListener('blur',  function(){ setFocus(field, false); });
        });
        window.__mvCjsReady = true;
      },
      callback: function (r) {
        var form = document.querySelector('form[method="post"]');
        if (!r || !r.token || !form) { reset(); toast('We could not secure your card details. Please try again.'); return; }
        var c = r.card || {}, masked = String(c.number || '');
        var digitsOnly = masked.replace(/\D/g, '');
        // Final expiry guard — NMI accepts odd 4-digit years (e.g. 12/1954 → 2054);
        // block past / implausible dates here so they can never be submitted.
        if (!expOk(c.exp)) {
          reset();
          fstate.ccexp.valid = false; fstate.ccexp.empty = false; fstate.ccexp.touched = true; fstate.ccexp.focused = false;
          paint('ccexp', 'is-invalid', friendlyMsg.ccexp);
          var ex = document.getElementById('cjs-ccexp'); if (ex && ex.scrollIntoView) ex.scrollIntoView({ behavior: 'smooth', block: 'center' });
          toast('Please enter a valid card expiry date.');
          return;
        }
        document.getElementById('cjs-payment-token').value = r.token;
        document.getElementById('cjs-card-bin').value   = c.bin || digitsOnly.slice(0, 6);
        document.getElementById('cjs-card-last4').value = (masked.match(/(\d{4})\s*$/) || ['',''])[1];
        document.getElementById('cjs-card-type').value  = c.type || '';
        document.getElementById('cjs-card-exp').value   = c.exp || '';
        pending = false;
        form.submit();
      }
    });
  }
  window.__mvCjsStart = function () {
    if (pending) return;
    if (typeof CollectJS === 'undefined' || !window.__mvCjsReady) {
      reset(); toast('The secure card fields are still loading — please wait a second and try again.'); return;
    }
    pending = true;
    showAllErrors(); // reveal red on any incomplete field the shopper never focused
    try { CollectJS.startPaymentRequest(); }
    catch (e) { reset(); toast('We could not start the secure payment. Please try again.'); }
  };
  if (document.readyState !== 'loading') configure();
  else document.addEventListener('DOMContentLoaded', configure, { once: true });
})();
</script>
<?php elseif ($_cardEnabled ?? false): ?>
<script>
/* ============================================================
   First-party card fields controller (owner decision 2026-09-30).
   • Brand (Visa / Mastercard / Amex / Discover) detected from the FIRST digit →
     big logo in the field + accepted-brands row highlight.
   • Brand-aware formatting + lengths: Amex 15 (4-6-5, CVV 4), Mastercard 16,
     Visa / Discover 16 (19 accepted), CVV 3.
   • Verdict on the LAST digit: green "✓ Card verified" (Luhn OK) or red
     "Invalid card number" — never mid-typing. Leaving a half-typed field → red.
   • Expiry is strictly MM / YY (auto-formatted, 4 digits max): month 01–12 and
     not in the past — nothing else.
   • Empty fields stay quiet until Pay → "… required".
   ============================================================ */
window.__mvCardUI = true;
(function () {
  var BRANDS = {
    visa:       { lens: [16, 19], primary: 16, cvv: 3 },
    mastercard: { lens: [16],     primary: 16, cvv: 3 },
    amex:       { lens: [15],     primary: 15, cvv: 4 },
    discover:   { lens: [16, 19], primary: 16, cvv: 3 },
    '':         { lens: [16, 19], primary: 16, cvv: 3 }
  };
  var F = {
    number: { input: 'card-number', box: 'box-card-number', err: 'card-number-error', bad: 'Invalid card number',  req: 'Card number required' },
    exp:    { input: 'card-exp',    box: 'box-card-exp',    err: 'card-exp-error',    bad: 'Invalid expiry date',  req: 'Expiry date required' },
    cvv:    { input: 'card-cvv',    box: 'box-card-cvv',    err: 'card-cvv-error',    bad: 'Invalid security code', req: 'Security code required' }
  };
  var payTried = false;
  var $ = function (id) { return document.getElementById(id); };
  var digitsOf = function (v) { return String(v || '').replace(/\D/g, ''); };

  // Brand from the first digit(s). Only what we can be sure of: a lone "2" or "3"
  // waits for the 2nd digit (22–27 → Mastercard, 34/37 → Amex).
  function brandOf(d) {
    if (!d) return '';
    if (d[0] === '4') return 'visa';
    if (d[0] === '5') return 'mastercard';
    if (d[0] === '6') return 'discover';
    if (/^2[2-7]/.test(d)) return 'mastercard';
    if (/^3[47]/.test(d)) return 'amex';
    return '';
  }
  function luhn(d) {
    var sum = 0, alt = false;
    for (var i = d.length - 1; i >= 0; i--) { var n = +d[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; }
    return d.length > 0 && sum % 10 === 0;
  }
  function paint(key, cls, msg) {
    var f = F[key], e = $(f.err), b = $(f.box);
    if (e) {
      if (cls === 'is-invalid') { e.textContent = msg || f.bad; e.classList.remove('is-ok'); }
      else if (cls === 'is-valid' && key === 'number') { e.textContent = '\u2713 Card verified'; e.classList.add('is-ok'); }
      else { e.textContent = ''; e.classList.remove('is-ok'); }
    }
    if (b) { b.classList.toggle('is-invalid', cls === 'is-invalid'); b.classList.toggle('is-valid', cls === 'is-valid'); }
  }

  // ---- Card number -------------------------------------------------------
  function numberState() {
    var d = digitsOf(($('card-number') || {}).value);
    var brand = brandOf(d), spec = BRANDS[brand];
    var maxLen = spec.lens[spec.lens.length - 1];
    var complete = spec.lens.indexOf(d.length) !== -1;            // at a valid length for the brand
    var verdictNow = d.length === spec.primary || d.length === maxLen; // the "last digit" moments
    return { d: d, brand: brand, spec: spec, maxLen: maxLen, complete: complete, verdictNow: verdictNow, valid: complete && luhn(d) };
  }
  function formatNumber(d, brand) {
    if (brand === 'amex') return d.replace(/^(\d{1,4})(\d{0,6})(\d{0,5}).*$/, function (_, a, b, c) { return [a, b, c].filter(Boolean).join(' '); });
    return d.replace(/(\d{4})(?=\d)/g, '$1 ');
  }
  function onNumberInput() {
    var el = $('card-number'); if (!el) return;
    var d = digitsOf(el.value), brand = brandOf(d), spec = BRANDS[brand];
    d = d.slice(0, spec.lens[spec.lens.length - 1]);
    var formatted = formatNumber(d, brand);
    if (el.value !== formatted) el.value = formatted;
    if (window.mvShowCardBrand) mvShowCardBrand(brand);
    var st = numberState();
    if (!st.d.length)      paint('number', payTried ? 'is-invalid' : '', F.number.req);
    else if (st.valid)     paint('number', 'is-valid');   // last digit + Luhn OK → green
    else if (st.verdictNow) paint('number', 'is-invalid'); // brand length reached but wrong → red right now
    else                   paint('number', '');           // still typing → silent (a rare 19-digit Visa/Discover may continue past 16)
    syncCvvRules();
  }
  function onNumberBlur() {
    var st = numberState();
    if (!st.d.length) { paint('number', payTried ? 'is-invalid' : '', F.number.req); return; }
    paint('number', st.valid ? 'is-valid' : 'is-invalid');
  }

  // ---- Expiry: strictly MM / YY -------------------------------------------
  function onExpInput(ev) {
    var el = $('card-exp'); if (!el) return;
    var deleting = ev && ev.inputType && ev.inputType.indexOf('delete') === 0;
    var raw = el.value, d = digitsOf(raw);
    if (deleting && d.length === 2 && /\/$/.test(raw)) d = d.slice(0, 1); // backspace over the auto " / " also removes the month's last digit
    if (d.length >= 1 && d[0] > '1') d = '0' + d;                       // "3" → "03"
    if (d.length >= 2 && parseInt(d.slice(0, 2), 10) > 12) d = '0' + d[0] + d.slice(1); // "13" → "01/3"
    d = d.slice(0, 4);
    var out = d.length > 2 ? d.slice(0, 2) + ' / ' + d.slice(2)
            : d.length === 2 ? ((deleting && !/\s$/.test(raw)) ? d : d + ' / ')
            : d;
    if (el.value !== out) el.value = out;
    if (!d.length) { paint('exp', payTried ? 'is-invalid' : '', F.exp.req); return; }
    if (d.length < 4) { paint('exp', ''); return; }                    // still typing
    paint('exp', expValid(d) ? 'is-valid' : 'is-invalid');             // last digit → verdict
  }
  function expValid(d) {
    if (d.length !== 4) return false;
    var mm = parseInt(d.slice(0, 2), 10), yy = parseInt(d.slice(2), 10);
    if (mm < 1 || mm > 12) return false;
    var now = new Date(), cy = now.getFullYear() % 100, cm = now.getMonth() + 1;
    return yy > cy || (yy === cy && mm >= cm);                          // not in the past — nothing else
  }
  function onExpBlur() {
    var d = digitsOf(($('card-exp') || {}).value);
    if (!d.length) { paint('exp', payTried ? 'is-invalid' : '', F.exp.req); return; }
    paint('exp', expValid(d) ? 'is-valid' : 'is-invalid');
  }

  // ---- CVV: 4 digits for Amex, 3 for everything else ---------------------
  function cvvNeed() { return BRANDS[brandOf(digitsOf(($('card-number') || {}).value))].cvv; }
  function syncCvvRules() {
    var el = $('card-cvv'); if (!el) return;
    var need = cvvNeed();
    el.maxLength = need; el.placeholder = need === 4 ? '••••' : '•••';
    el.title = need === 4 ? '4-digit code on the front of your American Express card' : '3-digit code on the back of your card';
    if (el.value.length > need) el.value = el.value.slice(0, need);
    if (el.value.length) onCvvInput(true);
  }
  function onCvvInput(fromSync) {
    var el = $('card-cvv'); if (!el) return;
    var need = cvvNeed(), d = digitsOf(el.value).slice(0, need);
    if (el.value !== d) el.value = d;
    if (!d.length) { paint('cvv', payTried ? 'is-invalid' : '', F.cvv.req); return; }
    // Complete → green on the last digit; incomplete → silent while typing (or
    // when the brand just changed the required length), red only on blur / Pay.
    paint('cvv', d.length === need ? 'is-valid' : ((fromSync === true || document.activeElement === el) ? '' : 'is-invalid'));
  }
  function onCvvBlur() {
    var d = digitsOf(($('card-cvv') || {}).value);
    if (!d.length) { paint('cvv', payTried ? 'is-invalid' : '', F.cvv.req); return; }
    paint('cvv', d.length === cvvNeed() ? 'is-valid' : 'is-invalid');
  }

  // ---- Pay: reveal every verdict, return the first bad box ---------------
  window.__mvCardInvalidEl = function () {
    payTried = true;
    var bad = null;
    var st = numberState();
    paint('number', st.valid ? 'is-valid' : 'is-invalid', st.d.length ? F.number.bad : F.number.req); if (!st.valid && !bad) bad = $('card-number');
    var ed = digitsOf(($('card-exp') || {}).value);
    paint('exp', expValid(ed) ? 'is-valid' : 'is-invalid', ed.length ? F.exp.bad : F.exp.req); if (!expValid(ed) && !bad) bad = $('card-exp');
    var cd = digitsOf(($('card-cvv') || {}).value);
    var cvOk = cd.length === cvvNeed();
    paint('cvv', cvOk ? 'is-valid' : 'is-invalid', cd.length ? F.cvv.bad : F.cvv.req); if (!cvOk && !bad) bad = $('card-cvv');
    return bad;
  };

  function wire() {
    var n = $('card-number'), e = $('card-exp'), c = $('card-cvv');
    if (!n || !e || !c) return;
    [['number', n], ['exp', e], ['cvv', c]].forEach(function (pair) {
      var key = pair[0], el = pair[1], box = $(F[key].box);
      el.addEventListener('focus', function () { if (box) box.classList.add('is-focus'); });
      el.addEventListener('blur',  function () { if (box) box.classList.remove('is-focus'); });
    });
    n.addEventListener('input', onNumberInput); n.addEventListener('blur', onNumberBlur);
    e.addEventListener('input', onExpInput);    e.addEventListener('blur', onExpBlur);
    c.addEventListener('input', function () { onCvvInput(false); }); c.addEventListener('blur', onCvvBlur);
    // Autofill / browser-restored values.
    if (n.value) onNumberInput(); if (e.value) onExpInput(); if (c.value) onCvvInput(true);
  }
  if (document.readyState !== 'loading') wire();
  else document.addEventListener('DOMContentLoaded', wire, { once: true });
})();
</script>
<?php endif; ?>
<script>
/* Address auto-suggest was removed 2026-07-17e per customer request —
   customers now type their full address manually with no OpenStreetMap
   dropdown. The client-side proxy ajax/address-suggest.php is left in
   place (harmless without a caller) but is no longer invoked. */
</script>

<script>
(function(){
  // ===== Email field — DNS MX + typo dictionary check on blur =====
  const $email = document.getElementById('checkout-email');
  const $emailHint = document.getElementById('checkout-email-hint');
  let _emailOverride = false;
  function showEmailHint(html, isOk) {
    if (!$emailHint) return;
    $emailHint.innerHTML = html;
    $emailHint.className = 'checkout-hint' + (isOk ? ' is-ok' : '');
    $emailHint.style.display = 'block';
  }
  function clearEmailHint(){ if($emailHint){ $emailHint.style.display='none'; $emailHint.innerHTML=''; } }
  async function checkEmail() {
    if (!$email) return;
    const val = $email.value.trim();
    if (!val) { clearEmailHint(); return; }
    if (_emailOverride) return; // user explicitly chose to use this address
    try {
      const r = await fetch('ajax/email-check.php', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email: val }),
      });
      const j = await r.json();
      if (j.ok) { clearEmailHint(); return; }
      const suggest = (j.suggest && j.suggest !== val) ? j.suggest : '';
      let html = '<i class="bi bi-exclamation-triangle me-1"></i><strong>Heads up:</strong> ' + (j.detail || 'This email looks undeliverable.');
      if (suggest) {
        html += ' <button type="button" class="hint-btn is-primary" data-testid="email-hint-accept">Use <strong>' + suggest + '</strong></button>';
      }
      html += ' <button type="button" class="hint-btn" data-testid="email-hint-override">Use my address anyway</button>';
      showEmailHint(html, false);
      // Hook up the buttons
      const accept = $emailHint.querySelector('[data-testid="email-hint-accept"]');
      if (accept) accept.addEventListener('click', () => { $email.value = suggest; clearEmailHint(); _emailOverride = false; });
      const override = $emailHint.querySelector('[data-testid="email-hint-override"]');
      if (override) override.addEventListener('click', () => {
        _emailOverride = true;
        const flag = document.getElementById('email-override-input');
        if (flag) flag.value = '1';
        showEmailHint("<i class='bi bi-check2-circle me-1'></i>Got it — we'll deliver to <strong>" + val + "</strong>.", true);
      });
    } catch (_) { /* network hiccup, skip silently */ }
  }
  if ($email) {
    $email.addEventListener('blur', checkEmail);
    $email.addEventListener('input', () => {
      _emailOverride = false;
      const flag = document.getElementById('email-override-input');
      if (flag) flag.value = '0';
      clearEmailHint();
    });
  }

  // ===== Address field — basic completeness sanity-check on blur =====
  const $addr = document.getElementById('checkout-address');
  const $addrHint = document.getElementById('checkout-address-hint');
  let _addrOverride = false;
  function clearAddrHint(){ if($addrHint){ $addrHint.style.display='none'; $addrHint.innerHTML=''; } }
  function checkAddress() {
    if (!$addr) return;
    const val = $addr.value.trim();
    if (!val || _addrOverride) { clearAddrHint(); return; }
    const issues = [];
    // Must have a street number — almost every shippable / billing address
    // starts with one.  P.O. Box is allowed.
    if (!/\d/.test(val) && !/p\.?\s*o\.?\s*box/i.test(val)) {
      issues.push('No street number detected');
    }
    if (val.length < 6) issues.push('Address looks too short');
    if (/^[a-z]+$/i.test(val)) issues.push('Just letters — missing street/number?');
    if (!issues.length) { clearAddrHint(); return; }
    $addrHint.innerHTML = '<i class="bi bi-exclamation-triangle me-1"></i><strong>Double-check this address:</strong> ' + issues.join(', ') + '.'
      + ' <button type="button" class="hint-btn" data-testid="addr-hint-override">Use this address anyway</button>';
    $addrHint.className = 'checkout-hint';
    $addrHint.style.display = 'block';
    const o = $addrHint.querySelector('[data-testid="addr-hint-override"]');
    if (o) o.addEventListener('click', () => {
      _addrOverride = true;
      const flag = document.getElementById('address-override-input');
      if (flag) flag.value = '1';
      $addrHint.innerHTML = "<i class='bi bi-check2-circle me-1'></i>Got it — using the address as entered.";
      $addrHint.className = 'checkout-hint is-ok';
    });
  }
  if ($addr) {
    $addr.addEventListener('blur', checkAddress);
    $addr.addEventListener('input', () => {
      _addrOverride = false;
      const flag = document.getElementById('address-override-input');
      if (flag) flag.value = '0';
      clearAddrHint();
    });
  }

  // ===== Strict form-level submit guard (blocks payment on invalid data) =====
  // - Email: RFC valid + not currently flagged undeliverable (unless overridden).
  // - Billing address: street number / length sanity (unless overridden).
  // - Card (only when Card payment method is selected): Luhn pass on number,
  //   MM/YY in the future, 3-4 digit CVV.  Card details are NEVER posted to
  //   our server (no `name` attr); this is purely a UX guard to stop bad
  //   data from being forwarded to the payment processor.
  const form = document.querySelector('form[method="post"]');
  const submitBtns = form ? form.querySelectorAll('button[type="submit"]') : [];

  function setFieldError($input, msg) {
    if (!$input) return;
    $input.classList.add('is-invalid');
    let $hint = $input.parentElement.querySelector('.field-err');
    if (!$hint) {
      $hint = document.createElement('div');
      $hint.className = 'field-err invalid-feedback d-block';
      $input.parentElement.appendChild($hint);
    }
    $hint.textContent = msg;
  }
  function clearFieldError($input) {
    if (!$input) return;
    $input.classList.remove('is-invalid');
    const $hint = $input.parentElement.querySelector('.field-err');
    if ($hint) $hint.remove();
  }
  // Live-clear errors when the user starts editing again.
  document.querySelectorAll('input, select').forEach(el => {
    el.addEventListener('input', () => clearFieldError(el));
    el.addEventListener('change', () => clearFieldError(el));
  });

  function luhnValid(digits) {
    if (!/^\d{13,19}$/.test(digits)) return false;
    let sum = 0, alt = false;
    for (let i = digits.length - 1; i >= 0; i--) {
      let n = parseInt(digits.charAt(i), 10);
      if (alt) { n *= 2; if (n > 9) n -= 9; }
      sum += n; alt = !alt;
    }
    return sum % 10 === 0;
  }
  function expiryValid(val) {
    // Format-lenient: accept MM/YY, MMYY, M/YY, MM/YYYY, etc. (matches the
    // server-side mv_parse_exp). Clock-skew tolerant so a wrong device clock
    // never blocks a good card — the bank rejects a genuinely expired card.
    const d = (val || '').replace(/\D/g, '');
    let mm, yy;
    if (d.length === 4)      { mm = +d.slice(0,2); yy = +d.slice(2,4); }
    else if (d.length === 3) { mm = +d.slice(0,1); yy = +d.slice(1,3); }
    else if (d.length >= 6)  { mm = +d.slice(0,2); yy = +d.slice(-2); }
    else if (d.length === 5) { mm = +d.slice(0,1); yy = +d.slice(-2); }
    else return false;
    if (mm < 1 || mm > 12) return false;
    const now = new Date();
    const curYY = now.getFullYear() % 100;
    if (yy < curYY - 1) return false;       // clearly expired (>1yr past — clock-skew tolerant)
    if (yy > curYY + 19) return false;      // implausibly far out (no real card ~20yrs away)
    return true;
  }

  async function validateBeforeSubmit() {
    let firstBadEl = null;
    const mark = (el, msg) => { setFieldError(el, msg); if (!firstBadEl) firstBadEl = el; };

    // --- Email ---
    const emailVal = ($email && $email.value || '').trim();
    if (!emailVal || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailVal)) {
      mark($email, 'Please enter a valid email address.');
    }
    // Email deliverability is ADVISORY ONLY — the hint may still show, but we
    // never block payment over an MX/typo guess on a valid-looking address.

    // --- Billing address: required, but NEVER hard-block on our own
    // completeness heuristic. These are DIGITAL goods (no shipping), so an
    // address without an obvious street number must not stop a good payment —
    // the blur hint already offers gentle guidance. We only require non-empty. ---
    const addrVal = ($addr && $addr.value || '').trim();
    if (!addrVal) {
      mark($addr, 'Billing address is required.');
    }

    // --- City / State / ZIP / Country / First / Last / Phone ---
    const requiredMap = [
      ['input[name="first_name"]', 'First name is required.'],
      ['input[name="last_name"]',  'Last name is required.'],
      ['input[name="phone"]',      'Phone number is required.'],
      ['input[name="city"]',       'City is required.'],
      ['select[name="country"]',   'Country is required.'],
    ];
    requiredMap.forEach(([sel, msg]) => {
      const el = document.querySelector(sel);
      if (el && !el.value.trim()) mark(el, msg);
    });
    // State / province — ADVISORY ONLY: never block a good card over a region
    // selection; the gateway/AVS decides and we store what was entered.
    // (No mark() here on purpose.)

    // Postal / ZIP — advisory only; accept any non-empty value.
    // Phone — required non-empty (above), but length is ADVISORY ONLY.

    // --- Card details (only when Card is the selected method) ---
    const pmInput = document.getElementById('payment-method-input');
    const usingCard = pmInput && pmInput.value === 'card';
    if (usingCard) {
      // NMI hosted fields: reveal their verdicts together with the billing
      // errors so the shopper sees everything that needs fixing in one pass.
      if (window.__mvCjsInvalidEl) { const badCjs = window.__mvCjsInvalidEl(); if (badCjs && !firstBadEl) firstBadEl = badCjs; }
      if (window.__mvCardInvalidEl) { const badFp = window.__mvCardInvalidEl(); if (badFp && !firstBadEl) firstBadEl = badFp; }
      // Legacy inline checks only when neither controller owns the fields.
      const legacyCard = !window.__mvCardInvalidEl && !window.__mvCjsInvalidEl;
      const $cardNum = legacyCard ? document.getElementById('card-number') : null;
      const $cardExp = legacyCard ? document.getElementById('card-exp') : null;
      const $cardCvv = legacyCard ? document.getElementById('card-cvv') : null;
      if ($cardNum) {
        const digits = ($cardNum.value || '').replace(/\D/g, '');
        if (!digits) mark($cardNum, 'Enter your card number');
        else if (!luhnValid(digits)) mark($cardNum, 'Invalid card number');
      }
      if ($cardExp && !expiryValid($cardExp.value)) {
        mark($cardExp, 'Invalid expiry date');
      }
      if ($cardCvv) {
        const cvv = ($cardCvv.value || '').replace(/\D/g, '');
        // Brand-aware length: Amex = 4 digits, everything else = 3.
        const info = (typeof detectCardBrand === 'function')
          ? detectCardBrand(($cardNum && $cardNum.value) || '') : { cvv: 3 };
        const need = info.cvv || 3;
        if (cvv.length !== need) mark($cardCvv, 'Invalid security code');
      }
    }

    return firstBadEl;
  }

  // CVV show/hide toggle — the code is visible by default so shoppers can
  // confirm what they typed; the eye button masks it for privacy.
  (function () {
    const cvvEl = document.getElementById('card-cvv');
    const btn   = document.getElementById('card-cvv-toggle');
    const eye   = document.getElementById('card-cvv-eye');
    if (!cvvEl || !btn || !eye) return;
    btn.addEventListener('click', function () {
      const masked = cvvEl.type === 'password';
      cvvEl.type = masked ? 'text' : 'password';
      eye.className = masked ? 'bi bi-eye' : 'bi bi-eye-slash';
      btn.setAttribute('aria-pressed', masked ? 'false' : 'true');
      cvvEl.focus();
    });
  })();

  if (form) {
    form.addEventListener('submit', async (e) => {
      // Allow Submit to proceed if no errors; else block and focus the first bad field.
      e.preventDefault();
      const bad = await validateBeforeSubmit();
      if (bad) {
        bad.scrollIntoView({ behavior: 'smooth', block: 'center' });
        try { bad.focus({ preventScroll: true }); } catch(_) { bad.focus(); }
        // Show a friendly summary toast (uses existing showToast() helper from main.js).
        if (typeof showToast === 'function') {
          showToast('<i class="bi bi-exclamation-triangle me-1"></i> Please fix the highlighted fields before continuing.');
        }
        return false;
      }
      // No errors — disable the buttons (prevent double-submit) and let the form go.
      submitBtns.forEach(b => { if (!b.dataset.origHtml) b.dataset.origHtml = b.innerHTML; b.disabled = true; b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing…'; });
      // Collect.js (NMI hosted fields): tokenise in the browser first; the
      // callback fills #cjs-payment-token and submits the form itself.
      const pmNow = document.getElementById('payment-method-input');
      const tokEl = document.getElementById('cjs-payment-token');
      if (window.MV_COLLECTJS && pmNow && pmNow.value === 'card' && tokEl && !tokEl.value) {
        window.__mvCjsStart && window.__mvCjsStart();
        return;
      }
      form.submit();
    });
    window.__mvRestoreSubmitBtns = function(){
      submitBtns.forEach(b => { b.disabled = false; if (b.dataset.origHtml) b.innerHTML = b.dataset.origHtml; });
    };
  }
})();

/* ---------- Test-mode preview (only shown when gw_mode = test) ---------- */
async function openTestPreview() {
  const modalEl = document.getElementById('testPreviewModal');
  const body    = document.getElementById('testPreviewBody');
  if (!modalEl || !body) return;
  body.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><div class="small text-secondary mt-2">Building preview…</div></div>';
  const m = new bootstrap.Modal(modalEl);
  m.show();

  // Collect what the customer has typed so the preview emails/admin
  // alerts reflect their actual contact info (falls back to demo data
  // if a field is still empty).
  const fd = new FormData();
  ['first_name', 'last_name', 'email', 'phone', 'country', 'pro'].forEach(k => {
    const el = document.querySelector(`[name="${k}"]`);
    if (el && el.value) fd.append(k, el.value);
  });

  let data;
  try {
    const r = await fetch('ajax/checkout-test-preview.php' + (window.location.search || ''), { method: 'POST', body: fd, credentials: 'same-origin' });
    data = await r.json();
  } catch (e) {
    body.innerHTML = '<div class="alert alert-danger">Failed to build preview. Try again.</div>';
    return;
  }
  if (!data || !data.ok) {
    body.innerHTML = '<div class="alert alert-danger">' + ((data && data.error) || 'Unable to build preview.') + '</div>';
    return;
  }

  // Render three side-by-side preview panels using vanilla bootstrap markup.
  body.innerHTML = `
    <ul class="nav nav-tabs mb-3" role="tablist" data-testid="test-preview-tabs">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tp-customer" type="button" role="tab"><i class="bi bi-person-check me-1"></i>Customer screen</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tp-email" type="button" role="tab"><i class="bi bi-envelope me-1"></i>Customer email</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tp-admin" type="button" role="tab"><i class="bi bi-shield-lock me-1"></i>Admin alert</button></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane fade show active" id="tp-customer" role="tabpanel">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
          <div>
            <div class="fw-bold">What the customer sees after paying</div>
            <small class="text-secondary">Order success page rendered with the test-order data</small>
          </div>
          <a href="${data.success_url}" target="_blank" class="btn btn-sm btn-outline-primary" data-testid="test-preview-open-success">Open in new tab <i class="bi bi-box-arrow-up-right ms-1"></i></a>
        </div>
        <div class="border rounded" style="overflow:hidden;background:#f8fafc;">
          <iframe src="${data.success_url}" style="width:100%;height:520px;border:0;display:block;" data-testid="test-preview-success-iframe"></iframe>
        </div>
      </div>
      <div class="tab-pane fade" id="tp-email" role="tabpanel">
        <div class="row g-2 small mb-2">
          <div class="col-md-3 text-secondary">To:</div><div class="col-md-9"><strong data-testid="test-preview-email-to">${data.email_to}</strong></div>
          <div class="col-md-3 text-secondary">Subject:</div><div class="col-md-9"><strong data-testid="test-preview-email-subj">${escapeHtml(data.email_subj)}</strong></div>
        </div>
        <div class="border rounded" style="overflow:hidden;background:#fff;">
          <iframe srcdoc="${data.email_html.replace(/"/g, '&quot;')}" style="width:100%;height:520px;border:0;display:block;background:#fff;" data-testid="test-preview-email-iframe"></iframe>
        </div>
      </div>
      <div class="tab-pane fade" id="tp-admin" role="tabpanel">
        <div class="row g-2 small mb-3">
          <div class="col-md-3 text-secondary">Delivered to:</div><div class="col-md-9"><strong data-testid="test-preview-admin-to">${data.admin_to}</strong></div>
        </div>
        <div class="border rounded p-3 mb-3" style="background:#f8fafc;">
          <div class="d-flex align-items-start gap-3">
            <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:42px;height:42px;background:#1565C0;color:#fff;"><i class="bi bi-bell-fill"></i></div>
            <div class="flex-grow-1">
              <div class="fw-bold" data-testid="test-preview-admin-title">${escapeHtml(data.admin_title)}</div>
              <div class="text-secondary small" data-testid="test-preview-admin-body">${escapeHtml(data.admin_body)}</div>
              <a href="${data.admin_url}" class="btn btn-sm btn-link p-0 mt-1" data-testid="test-preview-admin-link">Open in admin panel <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
          </div>
        </div>
        <div class="small text-secondary">
          <i class="bi bi-info-circle me-1"></i>Two alerts are fired per order — one tagged <strong>Orders</strong> (above) and one tagged <strong>Sales Detail</strong> in the admin bell, so you can filter them later.
        </div>
      </div>
    </div>
  `;
}
function escapeHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
</script>

<?php /* begin_checkout — fires once when the user lands on the checkout page.
        Items carry the REAL product name + unit price from the cart rows
        (audit 2026-09: previously price 0 + slug as item_name because cart()
        only holds slug => qty). gtag() fires in native mode only. */ ?>
<?php
$tk_ga4_c = trim((string)setting_get('ga4_measurement_id', ''));
$tk_uet_c = trim((string)setting_get('bing_uet_tag_id', ''));
$__nativeTrkC = (mv_tracking_mode() === 'native');
$__bcItems = cart_items();
if (!empty($__bcItems)):
    $cartItemsJs = [];
    foreach ($__bcItems as $line) {
        $cartItemsJs[] = [
            'item_id'    => (string)$line['slug'],
            'item_name'  => (string)($line['name'] ?? $line['slug']),
            'item_brand' => (string)($line['brand'] ?? 'Microsoft'),
            'item_category' => (string)($line['category'] ?? 'Software'),
            'price'      => round((float)($line['price'] ?? 0), 2),
            'quantity'   => max(1, (int)($line['qty'] ?? 1)),
        ];
    }
    $checkoutCurrency = (string)(current_currency()['code'] ?? 'USD');
    $checkoutTotal    = round((float)cart_subtotal(), 2);
?>
<script>
(function(){
  var items = <?= json_encode($cartItemsJs) ?>;
  var total = <?= json_encode($checkoutTotal) ?>;
  var currency = <?= json_encode($checkoutCurrency) ?>;
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({
    event: 'begin_checkout',
    ecommerce: { currency: currency, value: total, items: items }
  });
  <?php if ($__nativeTrkC && $tk_ga4_c !== ''): ?>
  if (typeof gtag === 'function') {
    gtag('event', 'begin_checkout', { currency: currency, value: total, items: items });
  }
  <?php endif; ?>
  <?php if ($tk_uet_c !== ''): ?>
  if (window.uetq) {
    window.uetq.push('event', 'begin_checkout', {
      event_category: 'ecommerce', event_label: 'checkout_started',
      revenue_value: total, currency: currency
    });
  }
  <?php endif; ?>
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
