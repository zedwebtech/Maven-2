<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Download, Install & Activate Office 2024 | ' . brand_name();
$pageDescription = 'Step-by-step guide to download, install and activate your Microsoft Office 2024 license purchased from ' . brand_name() . '. Includes a full video walkthrough and screenshots.';

$brand = brand_name();
$supportEmail = setting_get('company_email', 'services@maventechsoftware.com');
$supportPhone = function_exists('company_phone_for_country') ? company_phone_for_country() : setting_get('company_phone', '(888) 823-3590');
$phoneTel = preg_replace('/[^0-9+]/', '', $supportPhone);
$IG = 'assets/install-guide';

$bareLayout = true; // standalone page — hide site header/nav + footer

// Graceful fallbacks: the heavy walkthrough video + installer ship in the
// one-time media bundle (kept out of the code ZIPs to stay small). If they
// aren't uploaded yet, the page must NEVER show a broken player or a dead
// download button — so we detect the files and degrade cleanly.
$igPath        = __DIR__ . '/assets/install-guide';
$hasVideo      = is_file($igPath . '/office-2024-install-guide.mp4');
$hasInstaller  = is_file($igPath . '/Office_2024_EN_standard_64Bits.exe');
$downloadHref  = $hasInstaller ? ($IG . '/Office_2024_EN_standard_64Bits.exe') : 'https://www.office.com/setup';
include __DIR__ . '/includes/header.php';
?>
<style>
  .ms-guide { --ms-blue:#0067B8; --ms-blue-d:#005DA6; --ms-ink:#242424; --ms-sub:#484644; --ms-mut:#605E5C; --ms-line:#E1DFDD; color:var(--ms-ink); background:#fff; }
  .ms-guide .ms-hero { background:#F2F2F2; border-bottom:1px solid var(--ms-line); }
  .ms-guide .ms-eyebrow { color:var(--ms-blue); font-weight:700; font-size:.82rem; letter-spacing:.04em; text-transform:uppercase; }
  .ms-guide h1.ms-title { font-size:clamp(2rem,4vw,2.9rem); line-height:1.1; font-weight:700; color:var(--ms-ink); max-width:46rem; }
  .ms-guide .ms-lead { font-size:1.12rem; color:var(--ms-sub); max-width:40rem; line-height:1.6; }
  .ms-guide .ms-wrap { max-width:1200px; }
  .ms-guide .ms-note { background:#FFF4CE; border:1px solid #F2D999; border-radius:8px; }
  .ms-guide .ms-note .bi { color:#C19C00; }
  .ms-guide .ms-step { background:#EFF6FC; border:1px solid #C7E0F4; border-radius:12px; position:relative; box-shadow:0 1.6px 3.6px rgba(0,0,0,.08); }
  .ms-guide .ms-step::before { content:""; position:absolute; top:0; left:0; height:100%; width:6px; background:var(--ms-blue); border-radius:12px 0 0 12px; }
  .ms-guide .ms-num { width:34px; height:34px; border-radius:50%; background:var(--ms-blue); color:#fff; font-weight:700; display:flex; align-items:center; justify-content:center; flex:0 0 auto; }
  .ms-guide .ms-pill { font-size:.7rem; font-weight:700; letter-spacing:.04em; color:var(--ms-blue); background:#fff; border:1px solid #C7E0F4; border-radius:999px; padding:.25rem .75rem; }
  .ms-guide .ms-card { background:#fff; border:1px solid var(--ms-line); border-radius:10px; box-shadow:0 1.6px 3.6px rgba(0,0,0,.08); }
  .ms-guide .ms-oicon { display:grid; grid-template-columns:repeat(2,10px); gap:2px; }
  .ms-guide .ms-oicon span { width:10px; height:10px; display:block; }
  .ms-guide .ms-dl { background:var(--ms-blue); color:#fff; font-weight:700; border-radius:8px; padding:.7rem 1.6rem; display:inline-flex; align-items:center; gap:.5rem; text-decoration:none; transition:background-color .15s; }
  .ms-guide .ms-dl:hover { background:var(--ms-blue-d); color:#fff; }
  .ms-guide .ms-shot { border:1px solid var(--ms-line); border-radius:10px; overflow:hidden; }
  .ms-guide .ms-shot img { width:100%; height:auto; display:block; }
  .ms-guide .ms-tip { background:#EFF6FC; border-left:4px solid var(--ms-blue); border-radius:0 8px 8px 0; }
  .ms-guide .ms-grey { background:#F2F2F2; border-radius:8px; }
  .ms-guide .ms-done { background:#F2FBF2; border:1px solid #C5E0C5; border-radius:12px; }
  .ms-guide .ms-done .bi { color:#107C10; }
  .ms-guide .ms-side .ms-card h3 { font-size:1.1rem; }
  .ms-guide .ms-link { color:var(--ms-blue); font-weight:600; text-decoration:none; }
  .ms-guide .ms-link:hover { text-decoration:underline; }
  .ms-guide video { width:100%; height:auto; display:block; background:#000; }
  @media (min-width:992px){ .ms-guide .ms-side .ms-sticky { position:sticky; top:90px; } }
</style>

<div class="ms-guide" data-testid="office-setup-page">
  <section class="ms-hero">
    <div class="ms-wrap mx-auto px-3 px-md-4 py-5">
      <p class="ms-eyebrow mb-2">Microsoft Office 2024</p>
      <h1 class="ms-title mb-3">Download, install, and activate Office</h1>
      <p class="ms-lead mb-0">Follow this step-by-step guide to get Microsoft Office 2024 set up on your PC in just a few minutes.</p>
    </div>
  </section>

  <main class="ms-wrap mx-auto px-3 px-md-4 py-5">
    <div class="row g-4 g-lg-5">
      <div class="col-lg-8">

        <!-- Before you begin -->
        <div class="ms-note p-4 mb-4 d-flex gap-3 align-items-start" data-testid="before-you-begin">
          <i class="bi bi-exclamation-triangle-fill fs-5 mt-1"></i>
          <div>
            <p class="fw-semibold mb-1">Before you begin</p>
            <p class="mb-0 small text-secondary" style="color:var(--ms-sub)!important;">Make sure any previous versions of Microsoft Office are removed. See
              <a class="ms-link" href="https://support.microsoft.com/en-us/windows/uninstall-or-remove-apps-and-programs-in-windows-4b55f974-2cc6-2d2b-d092-5905080eaf98" target="_blank" rel="noopener noreferrer">this Microsoft help article</a>
              if you need help with this step.</p>
          </div>
        </div>

        <!-- Step 1 -->
        <section class="ms-step p-4 p-md-5 mb-4" data-testid="step-download">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="ms-num">1</span>
            <h2 class="h4 fw-semibold mb-0">Download the installer</h2>
            <span class="ms-pill ms-auto d-none d-sm-inline">START HERE</span>
          </div>
          <p class="mb-4" style="color:var(--ms-sub);">Click the button below to download the official Office 2024 installer.</p>

          <div class="ms-card p-4 mb-3">
            <div class="d-flex flex-column flex-md-row gap-3 align-items-start align-items-md-center justify-content-between">
              <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center justify-content-center rounded" style="width:48px;height:48px;background:rgba(216,59,1,.1);flex:0 0 auto;">
                  <span class="ms-oicon" aria-hidden="true">
                    <span style="background:#F25022;"></span><span style="background:#7FBA00;"></span>
                    <span style="background:#00A4EF;"></span><span style="background:#FFB900;"></span>
                  </span>
                </div>
                <div>
                  <div class="fw-semibold" style="font-size:1rem;">Microsoft Office 2024 Setup</div>
                  <div class="small" style="color:var(--ms-mut);">3.41 MB • English (United States)</div>
                </div>
              </div>
              <a class="ms-dl w-100 w-md-auto justify-content-center" href="<?= $downloadHref ?>" <?= $hasInstaller ? 'download' : 'target="_blank" rel="noopener noreferrer"' ?> data-testid="download-installer-btn">
                <i class="bi bi-download"></i> Download
              </a>
            </div>
          </div>
          <p class="small mb-4" style="color:var(--ms-mut);">Depending on your internet speed, this download may take a few minutes.</p>

          <!-- Video walkthrough (shown only when the media bundle is deployed) -->
          <?php if ($hasVideo): ?>
          <div class="ms-card overflow-hidden" data-testid="video-walkthrough">
            <div class="px-4 pt-4 pb-3 border-bottom" style="border-color:var(--ms-line)!important;">
              <div class="d-flex align-items-center gap-2 ms-eyebrow mb-1"><i class="bi bi-play-circle"></i> Video walkthrough</div>
              <h3 class="h5 fw-semibold mb-1">Watch the full installation guide</h3>
              <p class="small mb-0" style="color:var(--ms-mut);">Prefer to follow along? Watch this short video covering download, installation, and activation.</p>
            </div>
            <video controls playsinline preload="metadata" poster="<?= $IG ?>/office-2024-install-guide-poster.jpg" data-testid="install-video">
              <source src="<?= $IG ?>/office-2024-install-guide.mp4" type="video/mp4">
              Your browser does not support the video tag.
            </video>
          </div>
          <?php endif; ?>
        </section>

        <!-- Step 2 -->
        <section class="mb-4" data-testid="step-open">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="ms-num">2</span>
            <h2 class="h4 fw-semibold mb-0">Open the installation file</h2>
          </div>
          <p class="mb-4" style="color:var(--ms-sub);">Once the download is complete, locate the file (usually in your Downloads folder).</p>
          <div class="ms-shot mb-4">
            <img src="<?= $IG ?>/Screenshot_downloads-CxvwjxLR.png" alt="Downloads folder showing the Office installer file with Run as administrator option" loading="lazy">
          </div>
          <div class="ms-grey p-3 d-flex align-items-start gap-3 mb-4">
            <i class="bi bi-display fs-5" style="color:var(--ms-blue);"></i>
            <span>Right-click the <strong>.exe</strong> file and select <strong>Run as administrator</strong> to start the installation.</span>
          </div>
          <div class="ms-tip p-3 mb-4 small">
            <strong>Note:</strong> If prompted by User Account Control, click <strong>Yes</strong> to allow the installer to make changes to your device.
          </div>
          <p class="mb-3" style="color:var(--ms-sub);">The installation will begin. Please wait for it to complete.</p>
          <div class="ms-shot">
            <img src="<?= $IG ?>/Off_install_2_1763635818118-xfAgw1CK.jpg" alt="Office installation splash screen" loading="lazy">
          </div>
        </section>

        <!-- Step 3 -->
        <section class="mb-4" data-testid="step-activate">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="ms-num">3</span>
            <h2 class="h4 fw-semibold mb-0">Activate your product</h2>
          </div>
          <p class="mb-4" style="color:var(--ms-sub);">After installation, open any Office app (like Word or Excel) from the Windows Start menu. Go to <strong>Account</strong> in the bottom-left corner, then click <strong>Change Product Key</strong> on the right below the Office icons.</p>
          <div class="ms-shot mb-4">
            <img src="<?= $IG ?>/50-1024x858_1763635818117-CDBGoFfi.png" alt="Excel Account settings page" loading="lazy">
          </div>
          <div class="ms-card p-4">
            <div class="d-flex flex-column flex-md-row align-items-start gap-3">
              <div class="d-flex align-items-center justify-content-center rounded" style="width:48px;height:48px;background:#EFF6FC;flex:0 0 auto;">
                <i class="bi bi-key-fill fs-4" style="color:var(--ms-blue);"></i>
              </div>
              <div class="w-100">
                <h3 class="h5 fw-semibold mb-2">Enter your product key</h3>
                <p class="mb-3" style="color:var(--ms-sub);">Enter the 25-character code from your <?= esc($brand) ?> purchase email to activate your lifetime license.</p>
                <div class="ms-shot" style="max-width:36rem;">
                  <img src="<?= $IG ?>/Off_install_4a_1763635818116-X9PrWfvh.jpg" alt="Enter product key dialog" loading="lazy">
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- All set -->
        <section class="ms-done p-4 d-flex align-items-start gap-3" data-testid="all-set">
          <i class="bi bi-check-circle-fill" style="font-size:1.6rem;"></i>
          <div>
            <h2 class="h5 fw-semibold mb-1">You're all set!</h2>
            <p class="mb-0" style="color:var(--ms-sub);">Microsoft Office 2024 is now installed and activated. Enjoy your apps.</p>
          </div>
        </section>
      </div>

      <!-- Sidebar -->
      <aside class="col-lg-4 ms-side">
        <div class="ms-sticky d-flex flex-column gap-4">
          <div class="ms-card p-4" data-testid="need-help-card">
            <h3 class="fw-semibold mb-2">Need help?</h3>
            <p class="small mb-4" style="color:var(--ms-sub);">If you run into issues during installation, our support team is here to help.</p>
            <a class="ms-dl w-100 justify-content-center mb-4" href="mailto:<?= esc($supportEmail) ?>" data-testid="contact-support-btn">
              <i class="bi bi-envelope-fill"></i> Contact support
            </a>
            <div class="d-flex flex-column gap-2 mb-4">
              <a class="ms-link d-flex align-items-center gap-2 small" href="mailto:<?= esc($supportEmail) ?>" data-testid="support-email-link"><i class="bi bi-envelope"></i> <?= esc($supportEmail) ?></a>
              <a class="ms-link d-flex align-items-center gap-2 small" href="tel:<?= esc($phoneTel) ?>" data-testid="support-phone-link"><i class="bi bi-telephone"></i> Toll Free: <?= esc($supportPhone) ?></a>
            </div>
            <div class="ms-grey p-3 small">
              <p class="fw-semibold mb-2">Common issues we solve</p>
              <ul class="list-unstyled mb-0 d-flex flex-column gap-1" style="color:var(--ms-sub);">
                <li class="d-flex align-items-start gap-2"><i class="bi bi-chevron-right" style="color:var(--ms-mut);"></i> Installation stuck at 90%</li>
                <li class="d-flex align-items-start gap-2"><i class="bi bi-chevron-right" style="color:var(--ms-mut);"></i> "Invalid Product Key" error</li>
                <li class="d-flex align-items-start gap-2"><i class="bi bi-chevron-right" style="color:var(--ms-mut);"></i> Incompatible version detected</li>
              </ul>
            </div>
          </div>

          <div class="ms-card p-4" style="background:#EFF6FC;border-color:#C7E0F4;" data-testid="verified-card">
            <div class="d-flex align-items-center gap-2 mb-2">
              <i class="bi bi-patch-check-fill" style="color:var(--ms-blue);"></i>
              <h3 class="fw-semibold mb-0" style="font-size:1rem;">Verified software</h3>
            </div>
            <p class="small mb-0" style="color:var(--ms-sub);">This installer is digitally signed and verified to be free of malware and viruses.</p>
          </div>
        </div>
      </aside>
    </div>
  </main>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
