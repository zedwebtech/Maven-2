<?php
/**
 * /openapi.json (+ /api/openapi.json, /api/openapi.yaml) — OpenAPI 3.1 spec
 * describing Maventech Software's PUBLIC, read-only catalog API. Lets agents
 * discover the API surface automatically. Served via router.php and .htaccess.
 *
 * Set $GLOBALS['MV_OPENAPI_FORMAT']='yaml' before requiring to emit YAML.
 */
require_once __DIR__ . '/includes/functions.php';

$base  = function_exists('public_base_url') ? rtrim(public_base_url(), '/') : rtrim(site_url(), '/');
$ci    = function_exists('company_info') ? company_info() : ['name' => 'Maventech Software', 'email' => ''];
$brand = $ci['name'] ?: 'Maventech Software';

$errorSchema = [
    'type' => 'object',
    'required' => ['error', 'status'],
    'properties' => [
        'error' => [
            'type' => 'object',
            'required' => ['code', 'message'],
            'properties' => [
                'code'    => ['type' => 'string', 'example' => 'not_found', 'description' => 'Stable machine-readable error code.'],
                'message' => ['type' => 'string', 'example' => 'Product not found.', 'description' => 'Human-readable explanation.'],
                'hint'    => ['type' => 'string', 'example' => 'Check the slug against GET /api/products.', 'description' => 'Actionable resolution hint for the agent.'],
            ],
        ],
        'status'        => ['type' => 'integer', 'example' => 404],
        'documentation' => ['type' => 'string', 'format' => 'uri', 'example' => $base . '/developers'],
    ],
];

$productSchema = [
    'type' => 'object',
    'properties' => [
        'slug'              => ['type' => 'string', 'example' => 'microsoft-office-home-2024-pc'],
        'name'              => ['type' => 'string', 'example' => 'Microsoft Office Home 2024 (PC)'],
        'price'             => ['type' => 'number', 'format' => 'float', 'example' => 126.99],
        'compare_at_price'  => ['type' => 'number', 'format' => 'float', 'nullable' => true, 'example' => 195.37],
        'currency'          => ['type' => 'string', 'example' => 'USD'],
        'category'          => ['type' => 'string', 'example' => 'office-2024-pc'],
        'brand'             => ['type' => 'string', 'nullable' => true, 'example' => 'Microsoft'],
        'platform'          => ['type' => 'string', 'nullable' => true, 'example' => 'Windows'],
        'version'           => ['type' => 'string', 'nullable' => true, 'example' => '2024'],
        'year'              => ['type' => 'string', 'nullable' => true, 'example' => '2024'],
        'license_type'      => ['type' => 'string', 'nullable' => true, 'example' => 'lifetime'],
        'sku'               => ['type' => 'string', 'nullable' => true],
        'gtin'              => ['type' => 'string', 'nullable' => true],
        'in_stock'          => ['type' => 'boolean', 'example' => true],
        'badge'             => ['type' => 'string', 'nullable' => true, 'example' => 'Best Seller'],
        'description'       => ['type' => 'string', 'nullable' => true],
        'activation_url'    => ['type' => 'string', 'format' => 'uri', 'nullable' => true, 'example' => 'https://setup.office.com'],
        'url'               => ['type' => 'string', 'format' => 'uri', 'example' => $base . '/product.php?slug=microsoft-office-home-2024-pc'],
        'image'             => ['type' => 'string', 'format' => 'uri', 'nullable' => true],
    ],
];

$spec = [
    'openapi' => '3.1.0',
    'info' => [
        'title'       => $brand . ' Catalog API',
        'version'     => '1.0.0',
        'summary'     => 'Public, read-only API for browsing the ' . $brand . ' software-license catalog.',
        'description' => "The **{$brand} Catalog API** is a public, read-only JSON API that lets agents and developers "
                       . "browse the software-license catalog and fetch live prices, editions and availability. "
                       . "No authentication is required. All errors are returned as structured JSON with a stable "
                       . "`error.code`, a human `error.message` and an actionable `error.hint`.\n\n"
                       . "Discovery: `/.well-known/api-catalog`, `/llms.txt`, `/agents.json`, `/.well-known/mcp.json`. "
                       . "Human docs: `{$base}/developers`.",
        'contact'     => ['name' => $brand . ' Support', 'email' => $ci['email'] ?: 'services@maventechsoftware.com', 'url' => $base . '/contact.php'],
        'license'     => ['name' => 'Proprietary — public read access', 'url' => $base . '/page.php?slug=terms-of-service'],
    ],
    'servers' => [
        ['url' => $base . '/api', 'description' => 'Production'],
    ],
    'externalDocs' => ['description' => $brand . ' developer & agent resources', 'url' => $base . '/developers'],
    'tags' => [
        ['name' => 'catalog', 'description' => 'Browse products & categories'],
        ['name' => 'system',  'description' => 'Health & discovery'],
    ],
    'paths' => [
        '/health' => [
            'get' => [
                'tags' => ['system'], 'operationId' => 'getHealth',
                'summary' => 'Service health check',
                'responses' => [
                    '200' => [
                        'description' => 'Service is healthy.',
                        'content' => ['application/json' => ['schema' => [
                            'type' => 'object',
                            'properties' => [
                                'status'          => ['type' => 'string', 'example' => 'ok'],
                                'time'            => ['type' => 'string', 'format' => 'date-time'],
                                'products_active' => ['type' => 'integer', 'example' => 37],
                            ],
                        ]]],
                    ],
                ],
            ],
        ],
        '/products' => [
            'get' => [
                'tags' => ['catalog'], 'operationId' => 'listProducts',
                'summary' => 'List active products',
                'description' => 'Returns active products with live price + stock. Filter with `q` and `category`; page with `limit`/`offset`.',
                'parameters' => [
                    ['name' => 'q',        'in' => 'query', 'required' => false, 'schema' => ['type' => 'string'], 'description' => 'Full-text search over name/brand/category.'],
                    ['name' => 'category', 'in' => 'query', 'required' => false, 'schema' => ['type' => 'string'], 'description' => 'Filter by category slug.'],
                    ['name' => 'limit',    'in' => 'query', 'required' => false, 'schema' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 20]],
                    ['name' => 'offset',   'in' => 'query', 'required' => false, 'schema' => ['type' => 'integer', 'minimum' => 0, 'default' => 0]],
                ],
                'responses' => [
                    '200' => [
                        'description' => 'A page of products.',
                        'content' => ['application/json' => ['schema' => [
                            'type' => 'object',
                            'properties' => [
                                'data' => ['type' => 'array', 'items' => ['$ref' => '#/components/schemas/Product']],
                                'meta' => ['type' => 'object', 'properties' => [
                                    'total'  => ['type' => 'integer'],
                                    'limit'  => ['type' => 'integer'],
                                    'offset' => ['type' => 'integer'],
                                ]],
                            ],
                        ]]],
                    ],
                    '400' => ['$ref' => '#/components/responses/Error'],
                ],
            ],
        ],
        '/products/{slug}' => [
            'get' => [
                'tags' => ['catalog'], 'operationId' => 'getProduct',
                'summary' => 'Fetch a single product by slug',
                'parameters' => [
                    ['name' => 'slug', 'in' => 'path', 'required' => true, 'schema' => ['type' => 'string'], 'description' => 'Product slug (see listProducts).'],
                ],
                'responses' => [
                    '200' => [
                        'description' => 'The product.',
                        'content' => ['application/json' => ['schema' => [
                            'type' => 'object',
                            'properties' => ['data' => ['$ref' => '#/components/schemas/Product']],
                        ]]],
                    ],
                    '404' => ['$ref' => '#/components/responses/Error'],
                ],
            ],
        ],
        '/categories' => [
            'get' => [
                'tags' => ['catalog'], 'operationId' => 'listCategories',
                'summary' => 'List categories with product counts + price ranges',
                'responses' => [
                    '200' => [
                        'description' => 'All active categories.',
                        'content' => ['application/json' => ['schema' => [
                            'type' => 'object',
                            'properties' => ['data' => ['type' => 'array', 'items' => [
                                'type' => 'object',
                                'properties' => [
                                    'category'  => ['type' => 'string'],
                                    'count'     => ['type' => 'integer'],
                                    'min_price' => ['type' => 'number'],
                                    'max_price' => ['type' => 'number'],
                                ],
                            ]]],
                        ]]],
                    ],
                ],
            ],
        ],
    ],
    'components' => [
        'schemas' => [
            'Product' => $productSchema,
            'Error'   => $errorSchema,
        ],
        'responses' => [
            'Error' => [
                'description' => 'Structured JSON error.',
                'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/Error']]],
            ],
        ],
    ],
];

$fmt = $GLOBALS['MV_OPENAPI_FORMAT'] ?? (strtolower((string)($_GET['fmt'] ?? '')) === 'yaml' ? 'yaml' : 'json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=3600');

if ($fmt === 'yaml') {
    header('Content-Type: application/yaml; charset=UTF-8');
    if (function_exists('yaml_emit')) {
        echo yaml_emit($spec);
    } else {
        // Minimal, dependency-free JSON→YAML emitter (spec is plain scalars/arrays/maps).
        $emit = function ($data, int $indent = 0) use (&$emit) {
            $pad = str_repeat('  ', $indent);
            $out = '';
            $isList = is_array($data) && array_is_list($data);
            foreach ($data as $k => $v) {
                if (is_array($v)) {
                    if ($isList) {
                        if (array_is_list($v) || (is_array($v) && count($v) === 0)) {
                            $out .= $pad . "-\n" . $emit($v, $indent + 1);
                        } else {
                            $inner = $emit($v, $indent + 1);
                            $inner = preg_replace('/^' . preg_quote($pad . '  ', '/') . '/', $pad . '- ', $inner, 1);
                            $out .= $inner;
                        }
                    } else {
                        $out .= $pad . $k . ":\n" . $emit($v, $indent + 1);
                    }
                } else {
                    $sv = is_bool($v) ? ($v ? 'true' : 'false') : (is_null($v) ? 'null' : (is_string($v) ? json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : $v));
                    $out .= $isList ? ($pad . '- ' . $sv . "\n") : ($pad . $k . ': ' . $sv . "\n");
                }
            }
            return $out;
        };
        echo "# " . $brand . " Catalog API — OpenAPI 3.1 (YAML)\n" . $emit($spec, 0);
    }
    return;
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($spec, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
