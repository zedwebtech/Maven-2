<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/seo-content.php';

$id = $_GET['id'] ?? '';
$post = null;
if ($id) {
    $stmt = db()->prepare('SELECT * FROM blog_posts WHERE id = ?');
    $stmt->execute([$id]);
    $post = $stmt->fetch();
}
// A missing/old blog id (e.g. a deleted or regenerated post that Google still
// has indexed as blog-post.php?id=N) should NOT hard-404 — 301 the visitor to
// the blog index so the link equity consolidates and GSC clears the 404.
if (!$post && !headers_sent()) {
    header('Location: /blog.php', true, 301);
    exit;
}
$pageTitle = ($post ? $post['title'] : 'Post Not Found') . ' | ' . brand_name();
if ($post) {
    // Prefer AI-generated SEO meta when present; fall back to sensible defaults.
    if (!empty($post['meta_title']))   $pageTitle = trim((string)$post['meta_title']) . ' | ' . brand_name();
    $pageDescription = !empty($post['meta_description'])
        ? trim((string)$post['meta_description'])
        : trim(mb_substr(strip_tags($post['content']), 0, 155)) . '…';
    if (!empty($post['meta_keywords'])) $pageKeywords = trim((string)$post['meta_keywords']);
    $ogType = 'article';
    $canonicalUrl = site_url() . '/blog-post.php?id=' . rawurlencode((string)$post['id']);
    // Share/schema image must be a URL that really resolves — the stored
    // path may be missing on disk, so route through blog_image_src()
    // (DB copy → on-disk file → shipped on-brand cover).
    $__blogImg = blog_image_src((string)($post['image'] ?? ''), (string)($post['title'] ?? ''), $post['product_id'] ?? null, $post['id'] ?? null);
    $ogImage    = $__blogImg;
    $ogImageAlt = $post['title'];

    // Article JSON-LD — lets Gemini, ChatGPT, Copilot, Perplexity and other
    // AI engines extract a clean Article schema and cite the post directly.
    $articleDate = '';
    if (!empty($post['created_at'])) {
        $articleDate = date('c', strtotime((string)$post['created_at']));
    } elseif (!empty($post['date'])) {
        $ts = strtotime((string)$post['date']);
        if ($ts) $articleDate = date('c', $ts);
    }
    // Track actual modification time so AI search engines see fresh dates
    // when the auto-blogger refreshes the post via cron.  Falls back to
    // the publish date when no modification has happened yet.
    $modifiedDate = !empty($post['updated_at']) ? date('c', strtotime((string)$post['updated_at'])) : ($articleDate ?: date('c'));
    $authorName = brand_name();

    // --- E-E-A-T author / reviewer signals (settings-backed → editable from
    // admin without code changes; all zero-DDL). Branded editorial byline
    // (no personal name) + a specialist credential + fact-check note. ---
    $__sg = function_exists('setting_get');
    $blogAuthorName  = trim((string)($__sg ? setting_get('blog_author_name',  $authorName . ' Editorial Team') : $authorName . ' Editorial Team')) ?: ($authorName . ' Editorial Team');
    $blogAuthorTitle = trim((string)($__sg ? setting_get('blog_author_title', 'Microsoft licensing specialist · 2 yrs') : 'Microsoft licensing specialist · 2 yrs')) ?: 'Microsoft licensing specialist · 2 yrs';
    $blogAuthorBio   = trim((string)($__sg ? setting_get('blog_author_bio', '') : ''));
    if ($blogAuthorBio === '') {
        $blogAuthorBio = 'The ' . $authorName . ' editorial team are software-licensing specialists who have delivered thousands of genuine Microsoft product keys. We write and fact-check every guide against current Microsoft activation behaviour so you can buy, install and activate with confidence.';
    }

    // Word count for the wordCount + timeRequired signals — improves
    // E-E-A-T scoring in Google's quality framework.
    $plainBody    = trim(strip_tags((string)$post['content']));
    $articleWords = max(1, str_word_count($plainBody));
    $readMinutes  = max(1, (int)round($articleWords / 220));

    // Article section: drive topical-cluster signals via the linked
    // product's category so the post sits in the right neighbourhood.
    $articleSection = 'Software & Licensing';
    try {
        if (!empty($post['product_id'])) {
            $catRow = db()->prepare("SELECT p.category FROM products p WHERE p.id = ? LIMIT 1");
            $catRow->execute([(int)$post['product_id']]);
            $cs = (string)$catRow->fetchColumn();
            if ($cs !== '' && function_exists('category_title')) $articleSection = category_title($cs);
        }
    } catch (Throwable $e) {}

    // Resolve an absolute image URL (Google requires https:// and rejects
    // schema when the image field is empty or unreachable). Fall back to
    // the site OG default so `image` is never an empty array.
    $__blogImg = trim((string)$__blogImg);
    if ($__blogImg !== '' && !preg_match('#^https?://#i', $__blogImg)) {
        $__blogImg = rtrim(site_url(), '/') . '/' . ltrim($__blogImg, '/');
    }
    if ($__blogImg === '') {
        $__blogImg = rtrim(site_url(), '/') . '/og-default.png';
    }
    $jsonLdArticle = [
        '@context'      => 'https://schema.org',
        '@type'         => !empty($post['is_featured_trends']) ? 'Article' : 'BlogPosting',
        'headline'      => $post['title'],
        'image'         => [$__blogImg],
        'datePublished' => $articleDate ?: date('c'),
        'dateModified'  => $modifiedDate,
        // Author = the brand (Organization). Keeps the article attribution
        // consistent across the site whether the post is hand-written or
        // AI-assisted, and avoids exposing "AI Editorial Team" copy on the
        // public page (still emitted as schema for E-E-A-T parity).
        'author'        => [
            '@type'        => 'Organization',
            'name'         => $blogAuthorName,
            'url'          => site_url() . '/about-us.php',
            'worksFor'     => [
                '@type' => 'Organization',
                'name'  => brand_name(),
                '@id'   => site_url() . '/#organization',
            ],
            'knowsAbout'   => ['Microsoft licensing', 'Office software', 'Windows activation', 'Cybersecurity', 'Genuine software resale'],
        ],
        'publisher'     => [
            '@type' => 'Organization',
            '@id'   => site_url() . '/#organization',
            'name'  => brand_name(),
            'url'   => site_url() . '/',
            'logo'  => [
                '@type' => 'ImageObject',
                // 2026-07 FIX: Google's Article rich-result parser rejects
                // SVG for publisher.logo (must be a raster with an explicit
                // aspect ratio). Use the generated 512x512 PNG brand mark —
                // the Company Info logo or company-name monogram.
                'url'    => rtrim(site_url(), '/') . app_icon_url(512),
                'width'  => 512,
                'height' => 512,
            ],
        ],
        'mainEntityOfPage' => [
            '@type' => 'WebPage',
            '@id'   => $canonicalUrl,
        ],
        'description'   => $pageDescription,
        'inLanguage'    => 'en',
        'isAccessibleForFree' => true,
        'wordCount'     => $articleWords,
        'timeRequired'  => 'PT' . $readMinutes . 'M',
        'articleSection'=> $articleSection,
        'speakable'     => [
            '@type'       => 'SpeakableSpecification',
            'cssSelector' => ['h1', '.aeo-quick-answer', '.lead'],
        ],
    ];

    // AEO: Build FAQPage schema from stored FAQ data
    $jsonLdFaqPage = null;
    if (!empty($post['faq_json'])) {
        $faqItems = json_decode($post['faq_json'], true);
        if (is_array($faqItems) && count($faqItems) > 0) {
            $faqEntities = [];
            foreach ($faqItems as $fi) {
                if (!empty($fi['q']) && !empty($fi['a'])) {
                    $faqEntities[] = [
                        '@type' => 'Question',
                        'name'  => $fi['q'],
                        'acceptedAnswer' => [
                            '@type' => 'Answer',
                            'text'  => $fi['a'],
                        ],
                    ];
                }
            }
            if ($faqEntities) {
                $jsonLdFaqPage = [
                    '@context'   => 'https://schema.org',
                    '@type'      => 'FAQPage',
                    'mainEntity' => $faqEntities,
                ];
            }
        }
    }

    // Long-tail meta keywords — auto-derived from the post title, the
    // linked product (when present, via the category-aware intent
    // dispatcher) and the H2/H3 hierarchy of the post body.  Header.php
    // emits `<meta name="keywords">` when $pageKeywords is set, so this
    // lifts the SEO audit's keyword score for blog posts from 0 to 20+.
    // Prefer AI-generated SEO keywords when the post has them; otherwise
    // auto-derive long-tail keywords from the title/product/headings.
    $pageKeywords = !empty($post['meta_keywords'])
        ? trim((string)$post['meta_keywords'])
        : blog_post_long_tail_keywords($post);

    // BreadcrumbList JSON-LD — mirrors the visible breadcrumb so search
    // engines and AI engines parse the same hierarchy that users see.
    $jsonLdBreadcrumb = blog_post_breadcrumb_jsonld($post);

    /* Surface article-specific OG values so header.php emits
     * <meta property="article:published_time"> etc. — drives the rich
     * preview LinkedIn / WhatsApp / Discord show for shared posts. */
    $articlePublishedTime = $articleDate ?: date('c');
    $articleModifiedTime  = $modifiedDate;
    $articleAuthor        = $authorName;
    $articleTags          = !empty($post['tags']) ? array_filter(array_map('trim', explode(',', (string)$post['tags']))) : [];
} else {
    http_response_code(404);
    $noIndex = true;
}

include __DIR__ . '/includes/header.php';
?>
<?php if (!empty($jsonLdArticle)): ?>
<script type="application/ld+json"><?= json_encode($jsonLdArticle, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<?php endif; ?>
<?php if (!empty($jsonLdFaqPage)): ?>
<script type="application/ld+json"><?= json_encode($jsonLdFaqPage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<?php endif; ?>
<div class="container py-5" style="max-width: 800px;">
  <?php if ($post): ?>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb small">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item"><a href="blog.php">Blog</a></li>
        <li class="breadcrumb-item active"><?= esc($post['title']) ?></li>
      </ol>
    </nav>
    <h1 class="fw-bold" data-testid="blog-post-h1"><?= esc($post['title']) ?></h1>
    <p class="text-secondary small d-flex flex-wrap align-items-center gap-2 mb-2" data-testid="blog-post-byline">
      <span class="d-inline-flex align-items-center gap-2">
        <span class="blog-byline-ava" aria-hidden="true"><i class="bi bi-shield-check"></i></span>
        <span class="text-body">By <a href="/about" class="fw-semibold text-decoration-none" data-testid="blog-post-author"><?= esc($blogAuthorName) ?></a> <span class="text-secondary">· <?= esc($blogAuthorTitle) ?></span></span>
      </span>
      <span class="text-muted d-none d-sm-inline">·</span>
      <span><i class="bi bi-calendar-event me-1"></i><?= esc($post['date']) ?></span>
      <span class="text-muted">·</span>
      <span><i class="bi bi-clock me-1"></i><?= esc($post['read_time']) ?></span>
      <?php if (!empty($post['updated_at']) && $post['updated_at'] !== ($post['created_at'] ?? '')): ?>
        <span class="text-muted">·</span>
        <span class="badge text-bg-light text-secondary" data-testid="blog-post-last-updated" title="Last updated"><i class="bi bi-arrow-clockwise me-1"></i>Updated <?= esc(date('M j, Y', strtotime((string)$post['updated_at']))) ?></span>
      <?php endif; ?>
      <?php
        // Targeted-country badge — quick visual cue for international readers
        // PLUS a small E-E-A-T signal (regionally localised content).
        $rTag = strtoupper((string)($post['target_region'] ?? ''));
        $rFlagMap = ['US'=>'🇺🇸','UK'=>'🇬🇧','AU'=>'🇦🇺','CA'=>'🇨🇦'];
        if (isset($rFlagMap[$rTag])):
      ?>
        <span class="text-muted">·</span>
        <span class="badge text-bg-light" data-testid="blog-post-region-badge" style="border:1px solid #e2e8f0;"><?= $rFlagMap[$rTag] ?> <?= esc($rTag) ?></span>
      <?php endif; ?>
    </p>
    <div class="blog-trust-line" data-testid="blog-post-trust">
      <i class="bi bi-patch-check-fill"></i>
      <span>Written &amp; reviewed by our software-licensing specialists<?php if (!empty($post['updated_at'])): ?> · Last reviewed <?= esc(date('M j, Y', strtotime((string)$post['updated_at']))) ?><?php endif; ?></span>
    </div>
    <style>
      .blog-byline-ava{width:26px;height:26px;border-radius:50%;flex:0 0 auto;display:grid;place-items:center;
        font-size:.82rem;color:#fff;background:linear-gradient(135deg,#2563eb,#0ea5e9);}
      .blog-trust-line{display:inline-flex;align-items:center;gap:.5rem;font-size:.8rem;font-weight:600;color:#0f766e;
        background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.28);border-radius:999px;
        padding:.35rem .8rem;margin:0 0 1.25rem;}
      .blog-trust-line i{color:#10b981;}
      [data-bs-theme="dark"] .blog-trust-line{color:#5eead4;background:rgba(16,185,129,.12);}
    </style>
    <?php if (!empty($post['lead'])): ?>
      <?= render_aeo_answer(
            (string)$post['title'],
            esc((string)$post['lead']),
            'blog-post-quick-answer'
        ) ?>
    <?php endif; ?>
    <img src="<?= esc(blog_image_src($post['image'], $post['title'] ?? '', $post['product_id'] ?? null, $post['id'] ?? null)) ?>" class="img-fluid rounded mb-4 w-100 object-fit-cover" style="max-height:380px;" alt="<?= esc($post['title']) ?>" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/images/blog-covers/cover-tech.jpg';">
    <div class="post-content" data-testid="blog-post-content"><?= $post['content'] /* trusted HTML seeded from database.sql */ ?></div>

    <!-- E-E-A-T: transparency / methodology note — signals first-hand experience
         and editorial process to Google's quality raters and AI crawlers. -->
    <div class="blog-method" data-testid="blog-post-methodology">
      <div class="blog-method-head"><i class="bi bi-clipboard-check"></i>How we verify this guide</div>
      <p class="blog-method-body mb-0">We resell only genuine Microsoft product keys sourced under the First Sale Doctrine, and we activate and test editions ourselves before we write about them. Every guide is fact-checked against Microsoft's current activation behaviour and updated whenever it changes. Spot something out of date? <a href="/contact">Tell us</a> and we'll fix it.</p>
    </div>

    <!-- E-E-A-T: author / expertise box -->
    <div class="blog-author-box" data-testid="blog-post-author-box">
      <div class="blog-author-ava" aria-hidden="true"><i class="bi bi-shield-check"></i></div>
      <div class="blog-author-meta">
        <div class="blog-author-name"><?= esc($blogAuthorName) ?></div>
        <div class="blog-author-title"><?= esc($blogAuthorTitle) ?></div>
        <p class="blog-author-bio"><?= esc($blogAuthorBio) ?></p>
        <div class="blog-author-links">
          <a href="/about" class="blog-author-link" data-testid="blog-author-about"><i class="bi bi-building me-1"></i>About us</a>
          <a href="/contact" class="blog-author-link" data-testid="blog-author-contact"><i class="bi bi-envelope me-1"></i>Contact</a>
          <a href="reviews.php" class="blog-author-link" data-testid="blog-author-reviews"><i class="bi bi-star me-1"></i>Verified reviews</a>
        </div>
      </div>
    </div>
    <style>
      .blog-method{margin:2rem 0 0;padding:1rem 1.25rem;border-left:4px solid #0ea5e9;border-radius:10px;
        background:#f0f9ff;}
      .blog-method-head{font-weight:800;color:#0369a1;font-size:.9rem;display:flex;align-items:center;gap:.5rem;margin-bottom:.35rem;}
      .blog-method-body{color:#334155;font-size:.86rem;line-height:1.55;}
      .blog-method-body a{color:#0369a1;}
      .blog-author-box{display:flex;gap:1.1rem;align-items:flex-start;margin:1.25rem 0 0;padding:1.25rem 1.35rem;
        border:1px solid #e2e8f0;border-radius:16px;background:#fff;}
      .blog-author-ava{width:56px;height:56px;border-radius:14px;flex:0 0 auto;display:grid;place-items:center;
        font-size:1.6rem;color:#fff;background:linear-gradient(135deg,#2563eb,#0ea5e9);box-shadow:0 6px 16px rgba(37,99,235,.3);}
      .blog-author-name{font-weight:800;color:#0f172a;font-size:1.02rem;line-height:1.2;}
      .blog-author-title{color:#2563eb;font-weight:700;font-size:.8rem;margin-top:2px;}
      .blog-author-bio{color:#475569;font-size:.86rem;line-height:1.55;margin:.5rem 0 .6rem;}
      .blog-author-links{display:flex;flex-wrap:wrap;gap:.4rem;}
      .blog-author-link{display:inline-flex;align-items:center;font-size:.78rem;font-weight:700;text-decoration:none;
        color:#334155;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:999px;padding:.35rem .8rem;
        transition:background-color .15s ease,color .15s ease;}
      .blog-author-link:hover{background:#e0f2fe;color:#0369a1;}
      [data-bs-theme="dark"] .blog-method{background:rgba(14,165,233,.08);}
      [data-bs-theme="dark"] .blog-method-body{color:#cbd5e1;}
      [data-bs-theme="dark"] .blog-author-box{background:#0b1220;border-color:#1f2937;}
      [data-bs-theme="dark"] .blog-author-name{color:#e2e8f0;}
      [data-bs-theme="dark"] .blog-author-bio{color:#94a3b8;}
      [data-bs-theme="dark"] .blog-author-link{background:#111827;border-color:#1f2937;color:#cbd5e1;}
      @media (max-width:575.98px){.blog-author-box{flex-direction:column;}}
    </style>

    <?php
      /* End-of-article Google "Preferred Sources" call-out — placed where the
         reader is most engaged. Reuses the publisher.js loaded sitewide by
         includes/footer.php (it scans for every [google-add-preferred-source-btn]
         on the page). Same zero-DDL settings flag as the footer badge. */
      $__psBlogOn = function_exists('setting_get') ? (setting_get('preferred_sources_badge', '1') === '1') : true;
      if ($__psBlogOn):
        $__psBlogHost = '';
        try { $__psBlogHost = (string)parse_url(function_exists('public_base_url') ? public_base_url() : SITE_URL, PHP_URL_HOST); } catch (Throwable $e) {}
        $__psBlogHost = preg_replace('/^www\./i', '', $__psBlogHost) ?: 'maventechsoftware.com';
        $__psBlogLink = 'https://www.google.com/preferences/source?q=' . urlencode($__psBlogHost);
    ?>
    <div class="blog-prefsrc" data-testid="blog-preferred-source">
      <div class="blog-prefsrc-icon"><i class="bi bi-google"></i></div>
      <div class="blog-prefsrc-copy">
        <div class="blog-prefsrc-title">Found this helpful? Follow us on Google</div>
        <div class="blog-prefsrc-sub">Add <?= esc(brand_name()) ?> as a Preferred Source and Google will show more of our guides &amp; reviews in AI Overviews, Top Stories &amp; Discover.</div>
      </div>
      <div class="blog-prefsrc-btn">
        <div google-add-preferred-source-btn data-theme="light" data-testid="blog-preferred-source-btn"></div>
        <a href="<?= esc($__psBlogLink) ?>" target="_blank" rel="noopener" class="blog-prefsrc-fallback" data-testid="blog-preferred-source-fallback" style="display:none;">
          <i class="bi bi-plus-circle me-1"></i>Add as Preferred Source
        </a>
      </div>
    </div>
    <script>
    (function(){
      function mvBlogPrefSrc(){
        var host = document.querySelector('.blog-prefsrc [google-add-preferred-source-btn]');
        var fb   = document.querySelector('.blog-prefsrc-fallback');
        if (!host || !fb) return;
        var rendered = host.children.length > 0 || host.getBoundingClientRect().height > 4;
        if (!rendered) fb.style.display = 'inline-flex';
      }
      setTimeout(mvBlogPrefSrc, 3200);
    })();
    </script>
    <style>
    .blog-prefsrc{display:flex;align-items:center;gap:1rem;flex-wrap:wrap;margin:2rem 0 0;padding:1.15rem 1.35rem;
      border:1px solid #e2e8f0;border-radius:16px;
      background:linear-gradient(135deg,rgba(66,133,244,.06),rgba(52,168,83,.05));}
    .blog-prefsrc-icon{width:46px;height:46px;border-radius:12px;flex:0 0 auto;display:grid;place-items:center;
      font-size:1.4rem;color:#fff;background:linear-gradient(135deg,#4285F4,#34A853 60%,#FBBC05);
      box-shadow:0 6px 16px rgba(66,133,244,.3);}
    .blog-prefsrc-copy{flex:1 1 260px;min-width:0;}
    .blog-prefsrc-title{color:#0f172a;font-weight:800;font-size:1rem;line-height:1.3;}
    .blog-prefsrc-sub{color:#475569;font-size:.84rem;line-height:1.5;margin-top:3px;}
    .blog-prefsrc-btn{flex:0 0 auto;display:flex;align-items:center;min-height:40px;}
    .blog-prefsrc-fallback{display:inline-flex;align-items:center;text-decoration:none;font-weight:700;font-size:.86rem;
      padding:.6rem 1.15rem;border-radius:999px;background:#2563eb;color:#fff;white-space:nowrap;
      transition:transform .15s ease,box-shadow .15s ease;}
    .blog-prefsrc-fallback:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(37,99,235,.35);color:#fff;}
    [data-bs-theme="dark"] .blog-prefsrc{border-color:#1f2937;background:linear-gradient(135deg,rgba(66,133,244,.12),rgba(52,168,83,.08));}
    [data-bs-theme="dark"] .blog-prefsrc-title{color:#e2e8f0;}
    [data-bs-theme="dark"] .blog-prefsrc-sub{color:#94a3b8;}
    @media (max-width:575.98px){.blog-prefsrc{flex-direction:column;text-align:center;}.blog-prefsrc-copy{flex-basis:auto;}}
    </style>
    <?php endif; ?>

    <?php
      // -------- Internal "Related products" + "More articles" widgets --------
      // Internal linking is one of the single biggest SEO levers — Google uses
      // these intra-site anchors to understand topical authority and to crawl
      // deeper.  We pull (a) the featured product (if any), (b) 3 sibling
      // products in the same category, and (c) 3 newest blog posts excluding
      // the current one.
      $relatedProducts = [];
      $featuredProduct = null;
      if (!empty($post['product_id'])) {
          $fp = db()->prepare('SELECT id, slug, name, brand, category, price, image FROM products WHERE id = ? AND is_active = 1');
          $fp->execute([(int)$post['product_id']]);
          $featuredProduct = $fp->fetch();
      }
      if ($featuredProduct) {
          $rp = db()->prepare('SELECT slug, name, brand, price, image FROM products
                                WHERE category = ? AND id != ? AND is_active = 1
                                ORDER BY rating DESC, reviews DESC LIMIT 3');
          $rp->execute([$featuredProduct['category'], (int)$featuredProduct['id']]);
          $relatedProducts = $rp->fetchAll();
      }
      // Fallback if there's no featured product — pick top-rated overall.
      if (!$relatedProducts) {
          $relatedProducts = db()->query('SELECT slug, name, brand, price, image FROM products WHERE is_active = 1 ORDER BY rating DESC, reviews DESC LIMIT 3')->fetchAll();
      }
      $morePosts = db()->prepare("SELECT id, title, date, read_time, image, product_id FROM blog_posts WHERE id != ? ORDER BY COALESCE(created_at, '1970-01-01') DESC, id DESC LIMIT 3");
      $morePosts->execute([$post['id']]);
      $morePosts = $morePosts->fetchAll();
    ?>

    <?php if ($featuredProduct): ?>
      <hr class="my-4">
      <div class="card p-3 d-flex flex-row align-items-center gap-3" style="border-left:4px solid #4338ca;background:#fafaff;" data-testid="featured-product-card">
        <img src="<?= esc($featuredProduct['image'] ?: '/assets/images/product-placeholder.svg') ?>" onerror="this.onerror=null;this.src='/assets/images/product-placeholder.svg';" alt="<?= esc($featuredProduct['name']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:8px;flex-shrink:0;">
        <div style="flex:1;min-width:0;">
          <div class="small text-uppercase text-secondary" style="letter-spacing:1px;font-weight:700;font-size:10px;color:#4338ca !important;">Article featured product</div>
          <div class="fw-bold" style="font-size:16px;color:#0f172a;line-height:1.3;"><?= esc($featuredProduct['name']) ?></div>
          <div class="small text-secondary mt-1"><?= esc($featuredProduct['brand'] ?: 'Genuine') ?> · From $<?= number_format((float)$featuredProduct['price'], 2) ?></div>
        </div>
        <a href="product.php?slug=<?= urlencode($featuredProduct['slug']) ?>" class="btn btn-primary rounded-pill px-4 flex-shrink-0" data-testid="featured-product-link">View product →</a>
      </div>
    <?php endif; ?>

    <?php if ($relatedProducts): ?>
      <h3 class="fw-bold mt-5 h5">You might also like</h3>
      <div class="row g-3 mt-1" data-testid="related-products">
        <?php foreach ($relatedProducts as $rp): ?>
          <div class="col-md-4">
            <a href="product.php?slug=<?= urlencode($rp['slug']) ?>" class="card h-100 text-decoration-none p-2" style="border:1px solid #e5e7eb;">
              <img src="<?= esc($rp['image'] ?: '/assets/images/product-placeholder.svg') ?>" onerror="this.onerror=null;this.src='/assets/images/product-placeholder.svg';" alt="<?= esc($rp['name']) ?>" class="rounded mb-2" style="width:100%;height:120px;object-fit:cover;">
              <div class="small fw-bold text-body" style="line-height:1.3;"><?= esc(mb_strimwidth($rp['name'], 0, 60, '…')) ?></div>
              <div class="small text-secondary mt-1"><?= esc($rp['brand']) ?> · $<?= number_format((float)$rp['price'], 2) ?></div>
            </a>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($morePosts): ?>
      <h3 class="fw-bold mt-5 h5">More from the blog</h3>
      <div class="row g-3 mt-1" data-testid="more-posts">
        <?php foreach ($morePosts as $mp): ?>
          <div class="col-md-4">
            <a href="blog-post.php?id=<?= urlencode($mp['id']) ?>" class="card h-100 text-decoration-none p-2" style="border:1px solid #e5e7eb;">
              <img src="<?= esc(blog_image_src($mp['image'], $mp['title'] ?? '', $mp['product_id'] ?? null, $mp['id'] ?? null)) ?>" alt="<?= esc($mp['title']) ?>" class="rounded mb-2" style="width:100%;height:120px;object-fit:cover;" onerror="this.onerror=null;this.src='/assets/images/blog-covers/cover-tech.jpg';">
              <div class="small fw-bold text-body" style="line-height:1.3;"><?= esc(mb_strimwidth($mp['title'], 0, 70, '…')) ?></div>
              <div class="small text-secondary mt-1"><i class="bi bi-calendar3 me-1"></i><?= esc($mp['date']) ?> · <?= esc($mp['read_time']) ?></div>
            </a>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <hr class="my-4">
    <div class="card p-4 text-center">
      <h5 class="fw-bold">Ready to upgrade your software?</h5>
      <p class="small text-secondary">Original Microsoft product keys with digital delivery.</p>
      <a href="shop.php" class="btn btn-primary rounded-pill px-4 mx-auto">Shop Now</a>
    </div>
  <?php else: ?>
    <div class="text-center py-5">
      <h1 class="fw-bold">Post not found</h1>
      <a href="blog.php" class="btn btn-primary rounded-pill px-4 mt-3">Back to Blog</a>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
