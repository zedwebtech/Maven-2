<?php
/**
 * Per-order document download (admin): ?id=ORDER&doc=invoice|communication|email-logs
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/pdf.php';
require_once __DIR__ . '/includes/email-tracking.php';
require_admin();
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$q = $pdo->prepare('SELECT * FROM orders WHERE id=?');
$q->execute([$id]);
$o = $q->fetch(PDO::FETCH_ASSOC);
if (!$o) { http_response_code(404); exit('Order not found'); }
$safe = preg_replace('/[^A-Za-z0-9\-_]/', '', (string)$o['order_number']);
$doc = (string)($_GET['doc'] ?? '');
try {
    if ($doc === 'invoice') {
        $its = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?'); $its->execute([$id]);
        $bin = generate_invoice_pdf($o, $its->fetchAll(PDO::FETCH_ASSOC)); $fn = 'Invoice-' . $safe . '.pdf';
    } elseif ($doc === 'communication') {
        $bin = mv_render_customer_communication_pdf($o); $fn = 'Customer-Communication-' . $safe . '.pdf';
    } elseif ($doc === 'email-logs') {
        $bin = mv_render_email_logs_pdf($o); $fn = 'Email-Logs-' . $safe . '.pdf';
    } else { http_response_code(400); exit('Unknown document.'); }
} catch (Throwable $e) {
    error_log('[order-doc] ' . $e->getMessage());
    http_response_code(500); exit('PDF generation failed.');
}
header('Content-Type: application/pdf');
header('Content-Disposition: ' . (isset($_GET['view']) ? 'inline' : 'attachment') . '; filename="' . $fn . '"');
header('Content-Length: ' . strlen($bin));
header('Cache-Control: private, no-store');
echo $bin;
