<?php
/** Landing page — Microsoft Office 2024 for Windows, Lifetime License. */
$OFFICE_VERSION  = '2024';
$OFFICE_PLATFORM = 'win';
require __DIR__ . '/includes/office-landing.php';
