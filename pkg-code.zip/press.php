<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle = brand_name() . ' Press & Media Kit | Brand Assets, Boilerplate & Contact';
$pageDescription = 'Press and media kit for ' . brand_name() . ' — official brand name, boilerplate, logo assets, company facts and media contact. ' . brand_name() . ' is an independent reseller of genuine Microsoft Office, Windows and antivirus software product keys.';

$co        = company_info();
$rev       = function_exists('site_review_stats') ? site_review_stats() : ['count' => 0, 'avg' => 0];
$revCount  = number_format((int)($rev['count'] ?? 0));
$revAvg    = number_format((float)($rev['avg'] ?? 0), 1);
$brandEmail = $co['email'] ?: brand_email();
$brandPhone = $co['phone'] ?? '';
$addr = trim(implode(', ', array_filter([
    $co['address'] ?? '', $co['city'] ?? '', trim(($co['state'] ?? '') . ' ' . ($co['zip'] ?? '')), $co['country'] ?? '',
])));

$boilerShort = brand_name() . ' is an independent third-party reseller of original Microsoft Office, Windows and antivirus software product keys, delivered instantly by email with a 30-day money-back guarantee.';
$boilerLong  = brand_name() . ' (' . brand_legal() . ') is an independent U.S.-based reseller specialising in genuine digital software product keys — Microsoft Office, Windows, and leading antivirus suites. Operating since 2024 under the First Sale Doctrine, every key is verified before dispatch, delivered instantly by email with a step-by-step activation guide, and backed by a 30-day money-back guarantee. ' . brand_name() . ' is not affiliated with, endorsed by, or sponsored by Microsoft or any other trademark holder.';

/* Press-page structured data: an Organization the press can cite + the page itself. */
$jsonLdPress = [
    '@context' => 'https://schema.org',
    '@type'    => 'CollectionPage',
    '@id'      => site_url() . '/press.php#press',
    'url'      => site_url() . '/press.php',
    'name'     => brand_name() . ' Press & Media Kit',
    'description' => $pageDescription,
    'inLanguage'  => 'en',
    'isPartOf'    => ['@id' => site_url() . '/#website'],
    'about'       => ['@id' => site_url() . '/#organization'],
    'mainEntity'  => [
        '@type' => 'Organization',
        '@id'   => site_url() . '/#organization',
        'name'  => brand_name(),
        'legalName' => brand_legal(),
        'url'   => site_url() . '/',
        'logo'  => brand_logo_absolute_url(),
        'foundingDate' => '2024',
        'slogan'  => 'Original software product keys, digital delivery, dedicated support.',
        'description' => $boilerShort,
    ],
];

$facts = [
    ['bi-building',        'Legal name',   brand_legal()],
    ['bi-calendar-check',  'Founded',      '2024'],
    ['bi-geo-alt-fill',    'Headquarters', $addr ?: 'Vallejo, California, USA'],
    ['bi-briefcase-fill',  'Industry',     'Digital software resale (Office, Windows, antivirus)'],
    ['bi-star-fill',       'Customer rating', $revAvg . ' / 5 from ' . $revCount . ' verified reviews'],
    ['bi-shield-check',    'Guarantee',    '30-day money-back on every order'],
];
include __DIR__ . '/includes/header.php';
?>
<script type="application/ld+json"><?= json_encode($jsonLdPress, JSON_UNESCAPED_SLASHES) ?></script>

<!-- Hero -->
<div class="page-head" data-testid="press-hero">
  <div class="container py-5">
    <nav aria-label="breadcrumb"><ol class="breadcrumb small"><li class="breadcrumb-item"><a href="/">Home</a></li><li class="breadcrumb-item active">Press &amp; Media</li></ol></nav>
    <div class="text-center mx-auto" style="max-width: 760px;">
      <div class="d-flex justify-content-center mb-3"><?= render_logo(56) ?></div>
      <span class="eyebrow">PRESS &amp; MEDIA KIT</span>
      <h1 class="display-5 fw-bold mt-1">Press &amp; Media Kit</h1>
      <p class="text-secondary mt-2 fs-5">Official brand assets, boilerplate and company facts for journalists, partners and reviewers writing about <span class="brand-grad"><?= esc(brand_name()) ?></span>.</p>
    </div>
  </div>
</div>

<!-- Boilerplate -->
<section class="py-5" data-testid="press-boilerplate">
  <div class="container" style="max-width: 900px;">
    <h2 class="fw-bold mb-3">About <?= esc(brand_name()) ?> (boilerplate)</h2>
    <div class="p-4 rounded-4 border bg-soft mb-3" data-testid="press-boiler-short">
      <div class="d-flex justify-content-between align-items-center mb-2"><strong class="text-uppercase small text-secondary">Short (one-liner)</strong></div>
      <p class="mb-0"><?= esc($boilerShort) ?></p>
    </div>
    <div class="p-4 rounded-4 border" data-testid="press-boiler-long">
      <div class="d-flex justify-content-between align-items-center mb-2"><strong class="text-uppercase small text-secondary">Long</strong></div>
      <p class="mb-0"><?= esc($boilerLong) ?></p>
    </div>
    <p class="small text-secondary mt-3 mb-0">When citing us, please link to <a href="<?= esc(site_url()) ?>/"><?= esc(preg_replace('#^https?://#', '', site_url())) ?></a>.</p>
  </div>
</section>

<!-- Company facts -->
<section class="py-5 bg-soft" data-testid="press-facts">
  <div class="container" style="max-width: 900px;">
    <h2 class="fw-bold mb-4">Company facts</h2>
    <div class="row g-3">
      <?php foreach ($facts as $f): ?>
      <div class="col-md-6">
        <div class="d-flex align-items-start gap-3 p-3 rounded-4 border bg-white h-100">
          <i class="bi <?= esc($f[0]) ?> fs-4 text-primary"></i>
          <div><div class="small text-secondary"><?= esc($f[1]) ?></div><div class="fw-semibold"><?= esc($f[2]) ?></div></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Brand assets -->
<section class="py-5" data-testid="press-assets">
  <div class="container" style="max-width: 900px;">
    <h2 class="fw-bold mb-4">Brand assets</h2>
    <div class="row g-4 align-items-stretch">
      <div class="col-md-6">
        <div class="p-4 rounded-4 border text-center h-100 d-flex flex-column justify-content-between">
          <div class="d-flex justify-content-center align-items-center py-4" style="min-height:120px;"><?= render_logo(64) ?></div>
          <div>
            <div class="fw-semibold mb-1">Primary logo</div>
            <a class="btn btn-sm btn-outline-primary rounded-pill px-3" href="<?= esc(brand_logo_absolute_url()) ?>" download data-testid="press-download-logo"><i class="bi bi-download me-1"></i>Download logo</a>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-4 rounded-4 border h-100">
          <div class="fw-semibold mb-2">Usage guidelines</div>
          <ul class="small text-secondary mb-0 ps-3 d-grid gap-2">
            <li>Use the official name <strong><?= esc(brand_name()) ?></strong> (or legal name <strong><?= esc(brand_legal()) ?></strong>).</li>
            <li>Please don't alter, recolour or stretch the logo.</li>
            <li>Describe us as an <strong>independent reseller</strong> — not as Microsoft or any vendor.</li>
            <li>Always link the brand name to <?= esc(preg_replace('#^https?://#', '', site_url())) ?>.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Media contact -->
<section class="py-5 bg-soft" data-testid="press-contact">
  <div class="container text-center" style="max-width: 700px;">
    <h2 class="fw-bold mb-2">Media &amp; press enquiries</h2>
    <p class="text-secondary mb-4">For interviews, quotes, fact-checks or partnership enquiries, reach our team directly.</p>
    <div class="d-inline-flex flex-wrap gap-2 justify-content-center">
      <?= obf_email_link($brandEmail, 'class="btn btn-primary rounded-pill px-4" data-testid="press-email"', false, 'Email the press team') ?>
      <?php if ($brandPhone): ?><a class="btn btn-outline-primary rounded-pill px-4" href="tel:<?= esc(preg_replace('/[^0-9+]/', '', $brandPhone)) ?>" data-testid="press-phone"><i class="bi bi-telephone me-1"></i><?= esc($brandPhone) ?></a><?php endif; ?>
      <a class="btn btn-outline-secondary rounded-pill px-4" href="contact.php" data-testid="press-contact-link">Contact page</a>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
