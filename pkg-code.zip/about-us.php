<?php
require_once __DIR__ . '/includes/functions.php';
// Canonicalize both /about and legacy /about-us to the clean /about URL
// (avoids an /about vs /about-us duplicate-content pair). The /about entry
// file pre-sets $canonicalUrl, so honour that if present.
if (!isset($canonicalUrl)) { $canonicalUrl = site_url() . '/about'; }
$pageTitle = 'About ' . brand_name() . ' | Independent Software Reseller';
$pageDescription = brand_name() . ' is an independent third-party reseller of original Microsoft Office, Windows and antivirus software product keys. Not affiliated with Microsoft or any other trademark holder. 30-day money-back guarantee.';

/* AboutPage schema — gives AI search engines and Google a clear,
   citation-friendly snapshot of who we are, what we sell, and why
   we are credible (E-E-A-T signals). */
$jsonLdAboutPage = [
    '@context'   => 'https://schema.org',
    '@type'      => 'AboutPage',
    '@id'        => site_url() . '/about-us.php#aboutpage',
    'url'        => site_url() . '/about-us.php',
    'name'       => 'About ' . brand_name(),
    'description'=> $pageDescription,
    'inLanguage' => 'en',
    'isPartOf'   => ['@id' => site_url() . '/#website'],
    'mainEntity' => [
        '@type'    => 'Organization',
        '@id'      => site_url() . '/#organization',
        'name'     => brand_name(),
        'url'      => site_url() . '/',
        'logo'     => site_url() . '/assets/images/badges/microsoft-verified.svg',
        'foundingDate'    => '2024',
        'numberOfEmployees' => ['@type' => 'QuantitativeValue', 'value' => 12],
        'slogan'     => 'Original software product keys, digital delivery, dedicated support.',
        'description'=> brand_name() . ' has delivered original Microsoft, Adobe and antivirus software product keys since 2024, operating as an independent third-party reseller under the First Sale Doctrine. Every key is verified pre-dispatch and backed by a 30-day money-back guarantee.',
        'knowsAbout' => ['Microsoft Office', 'Microsoft 365', 'Windows 11', 'Windows 10', 'Bitdefender', 'McAfee', 'Adobe', 'software licensing', 'digital downloads', 'SaaS subscriptions'],
        'award'   => ['Independent software key provider', '30-day money-back guarantee since 2024'],
    ],
    // E-E-A-T signals: explicit datePublished + dateModified on the
    // AboutPage so Google's quality raters can verify the page is
    // actively maintained.  Datemod auto-tracks file mtime.
    'datePublished' => '2024-09-03',
    'dateModified'  => date('Y-m-d', @filemtime(__FILE__) ?: time()),
];

/* FAQPage block — surfaces 5 high-intent questions directly under the
   About description in Google SERP ("People Also Ask").  Highest-impact
   schema for new-domain trust signals; we keep answers short + factual. */
$aboutFaqLd = [
    '@context' => 'https://schema.org',
    '@type'    => 'FAQPage',
    '@id'      => site_url() . '/about-us.php#faq',
    'mainEntity' => [
        ['@type' => 'Question', 'name' => 'Is ' . brand_name() . ' affiliated with Microsoft?',
         'acceptedAnswer' => ['@type' => 'Answer', 'text' => brand_name() . ' is an independent provider of genuine software licence keys. We are not affiliated with, endorsed by, or sponsored by Microsoft Corporation. All licences are sourced from authorized software clearing houses and verified before delivery.']],
        ['@type' => 'Question', 'name' => 'How are licence keys delivered?',
         'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Every licence key is sent by email once the order is processed (see Shipping & Delivery for full timing). The email includes the activation key, an official download link to the vendor (Microsoft, Bitdefender, Norton, etc.) and a step-by-step installation guide.']],
        ['@type' => 'Question', 'name' => 'What is your refund policy?',
         'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Every order is covered by a 30-day money-back guarantee. If the key fails to activate or the product is not what you expected, contact support within 30 days for a full refund — no hoops to jump through.']],
        ['@type' => 'Question', 'name' => 'How long has ' . brand_name() . ' been in business?',
         'acceptedAnswer' => ['@type' => 'Answer', 'text' => brand_name() . ' has been shipping genuine software licences since 2024, serving customers across the United States, United Kingdom, Canada, Australia and the European Union.']],
        ['@type' => 'Question', 'name' => 'Is the software genuine?',
         'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Yes — every licence we sell is a genuine perpetual or subscription key sourced through legitimate volume-licensing channels.  The software is downloaded directly from the vendor (microsoft.com, bitdefender.com, mcafee.com, etc.); we never ship pirated, cracked or shared keys.']],
    ],
];
include __DIR__ . '/includes/header.php';

$stats = [
    ['icon' => 'bi-patch-check-fill', 'color' => 'success', 'value' => '100%', 'label' => 'Genuine Products'],
    ['icon' => 'bi-shield-check',     'color' => 'primary', 'value' => '30-Day', 'label' => 'Money-Back Guarantee'],
    ['icon' => 'bi-star-fill', 'color' => 'info', 'value' => '4.9/5', 'label' => 'Customer Rating'],
];
$checklist = [
    ['bi-award-fill', 'Independent reseller of genuine software product keys'],
    ['bi-envelope-check', 'Digital delivery by email (see Shipping &amp; Delivery)'],
    ['bi-journal-text', 'Step-by-step activation guide included with every order'],
    ['bi-headset', 'Customer service Mon–Sat, 9 AM–6 PM EST'],
    ['bi-arrow-counterclockwise', '30-day money-back guarantee'],
];
$features = [
    ['bi-award-fill',       'warning', 'Independent Reseller Since 2024', 'Registered as ' . esc(trim((string)(company_info()['legal_name'] ?? '')) ?: brand_name()) . ' (Company Registration Number: ' . esc((string)(company_info()['reg_number'] ?? '')) . ', filed ' . esc(date('n/j/Y', strtotime((string)(company_info()['reg_date_filed'] ?? '2024-09-03')) ?: 0)) . ') — a fully-compliant U.S. business focused solely on surplus &amp; pre-licensed software from vetted clearing houses.'],
    ['bi-globe-americas',   'primary', 'Global Reach, Regional Pricing',  'Storefronts optimised for the US, Canada, UK, EU and Australia — with local currency, address formats and tax-friendly invoicing baked into checkout.'],
    ['bi-diagram-3-fill',   'info',    'Direct Supply-Chain Auditing',    'Every key is traced back to the originating volume-licence pool before it ever hits your inbox. If a key ever fails validation, we replace it that same day.'],
    ['bi-star-fill',        'warning', 'Real Reviews Only',               'Every star rating you see is left by a shopper who actually paid on this site. No incentivised reviews, no farmed testimonials, no purchased 5-stars.'],
    ['bi-people-fill',      'success', 'Boutique Support Team',           'A tight-knit, US-based support crew — not a call-centre. You will usually speak with the same person from first ticket to activation success.'],
    ['bi-flower1',          'primary', 'Zero-Waste, Zero-Landfill',       'Because every product is a digital key, your ' . esc(brand_name()) . ' order will never generate shipping cardboard, plastic packaging, or e-waste.'],
];
?>
<!-- Hero -->
<div class="page-head" data-testid="about-hero">
  <div class="container py-5">
    <nav aria-label="breadcrumb"><ol class="breadcrumb small"><li class="breadcrumb-item"><a href="/">Home</a></li><li class="breadcrumb-item active">About Us</li></ol></nav>
    <div class="text-center mx-auto" style="max-width: 760px;">
      <div class="d-flex justify-content-center mb-3"><?= render_logo(56) ?></div>
      <span class="eyebrow">OUR STORY</span>
      <h1 class="display-5 fw-bold mt-1">About <span class="brand-grad"><?= esc(brand_name()) ?></span></h1>
      <p class="text-secondary mt-2 fs-5">Your trusted independent third-party reseller for software product keys</p>
    </div>
  </div>
</div>

<!-- Trusted partner -->
<section class="py-5" data-testid="about-mission">
  <div class="container">
    <div class="row g-4 g-lg-5 align-items-center">
      <div class="col-lg-6">
        <span class="eyebrow">WHO WE ARE</span>
        <h2 class="fw-bold mt-1">Your Trusted Independent Software Reseller</h2>
        <p class="text-secondary mt-3">At <?= brand_legal() ?>, we are committed to delivering original Microsoft software product keys at honest, competitive prices as an <strong>independent third-party reseller</strong> — we are not affiliated with, endorsed by, or sponsored by Microsoft or any other trademark holder. Our team of specialists makes sure every customer gets the guidance they need for a seamless experience — from checkout to activation.</p>
        <p class="text-secondary">We see ourselves as more than a storefront. Our focus is fast, reliable order fulfillment — making sure your product key is delivered promptly, along with a clear, step-by-step digital activation guide for every purchase.</p>
        <a href="page.php?slug=why-choose-us" class="btn btn-outline-primary rounded-pill px-4 mt-2" data-testid="about-learn-more">Learn More About Us <i class="bi bi-arrow-right ms-1"></i></a>
      </div>
      <div class="col-lg-6">
        <div class="card p-4" data-testid="about-checklist">
          <?php foreach ($checklist as [$icon, $text]): ?>
            <div class="d-flex align-items-center gap-3 py-2 border-bottom border-opacity-25">
              <span class="d-inline-flex align-items-center justify-content-center rounded-circle flex-shrink-0" style="width:34px;height:34px;background:rgba(37,99,235,.1);"><i class="bi <?= $icon ?> text-primary"></i></span>
              <span class="small fw-semibold"><?= $text ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Stats — centered so the 3-tile row sits balanced in the middle of
         the container instead of hugging the left edge with dead-space on
         the right (col-6 col-lg-3 × 3 = 75% width). -->
    <div class="row g-3 mt-4 justify-content-center" data-testid="about-stats">
      <?php foreach ($stats as $s): ?>
        <div class="col-6 col-lg-3">
          <div class="card text-center p-4 h-100">
            <i class="bi <?= $s['icon'] ?> text-<?= $s['color'] ?> fs-3"></i>
            <div class="fs-3 fw-bold mt-2"><?= $s['value'] ?></div>
            <div class="small text-secondary"><?= $s['label'] ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Why Choose Perpetual Licenses -->
<section class="py-5 bg-soft" data-testid="about-why-choose">
  <div class="container">
    <div class="text-center mb-5 mx-auto" style="max-width: 640px;">
      <span class="eyebrow">WHY CHOOSE US</span>
      <h2 class="fw-bold mt-1">Why Choose Perpetual Licenses?</h2>
      <p class="text-secondary">Get the complete Microsoft Office experience with a single purchase. No recurring subscription fees — just authentic software that's yours forever.</p>
    </div>
    <div class="row g-4">
      <?php foreach ($features as [$icon, $color, $title, $text]): ?>
        <div class="col-lg-4 col-md-6">
          <div class="card p-4 h-100">
            <span class="d-inline-flex align-items-center justify-content-center rounded-3 mb-3" style="width:46px;height:46px;background:rgba(37,99,235,.08);"><i class="bi <?= $icon ?> text-<?= $color ?> fs-5"></i></span>
            <h3 class="h6 fw-bold mb-1"><?= $title ?></h3>
            <p class="small text-secondary mb-0"><?= $text ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Company / legal transparency (Google Ads trust signal) -->
<section class="py-5" data-testid="about-company-info">
  <div class="container">
    <div class="text-center mb-4">
      <span class="eyebrow">COMPANY INFORMATION</span>
      <h2 class="fw-bold mt-1">Legal &amp; Business Details</h2>
      <p class="text-secondary">We believe in full transparency. Here is our registered business information.</p>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card p-4">
          <div class="row g-3 small company-info-grid">
            <div class="col-sm-6 d-flex align-items-start gap-2"><i class="bi bi-building text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Legal entity</div><div class="fw-semibold"><?= esc($brandLegalName) ?></div></div></div>
            <?php if ($brandRegNumber): ?><div class="col-sm-6 d-flex align-items-start gap-2" data-testid="about-reg-file-no"><i class="bi bi-patch-check text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Company Registration Number</div><div class="fw-semibold"><?= esc($brandRegNumber) ?></div></div></div><?php endif; ?>
            <?php if ($brandRegDateFiled): ?><div class="col-sm-6 d-flex align-items-start gap-2" data-testid="about-reg-date-filed"><i class="bi bi-calendar-check text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Date filed</div><div class="fw-semibold"><?= esc(date('n/j/Y', strtotime((string)$brandRegDateFiled))) ?></div></div></div><?php endif; ?>
            <?php if ($brandRegJurisdiction): ?><div class="col-sm-6 d-flex align-items-start gap-2" data-testid="about-reg-jurisdiction"><i class="bi bi-flag text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Jurisdiction</div><div class="fw-semibold"><?= esc($brandRegJurisdiction) ?></div></div></div><?php endif; ?>
            <div class="col-sm-6 d-flex align-items-start gap-2"><i class="bi bi-geo-alt text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Registered address</div><div class="fw-semibold"><?= esc($brandAddress) ?></div></div></div>
            <div class="col-sm-6 d-flex align-items-start gap-2"><i class="bi bi-envelope text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Email</div><div class="fw-semibold"><a href="mailto:<?= esc($brandEmail) ?>"><?= esc($brandEmail) ?></a></div></div></div>
            <div class="col-sm-6 d-flex align-items-start gap-2"><i class="bi bi-telephone text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Phone</div><div class="fw-semibold"><a href="tel:<?= esc(tel_e164($brandPhone)) ?>"><?= esc($brandPhone) ?></a></div></div></div>
            <div class="col-sm-6 d-flex align-items-start gap-2"><i class="bi bi-clock text-primary mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Hours</div><div class="fw-semibold"><?= SITE_HOURS ?></div></div></div>
            <?php if ($brandRegCertUrl): ?><div class="col-12 d-flex align-items-start gap-2 pt-1" data-testid="about-reg-certificate"><i class="bi bi-file-earmark-pdf text-danger mt-1"></i><div><div class="text-secondary text-uppercase" style="font-size:.65rem;letter-spacing:.06em;">Articles of Organization</div><a class="fw-semibold" href="<?= esc($brandRegCertUrl) ?>" target="_blank" rel="noopener" data-testid="about-reg-certificate-link">View certificate (PDF) <i class="bi bi-box-arrow-up-right ms-1"></i></a></div></div><?php endif; ?>
          </div>
          <hr class="my-3">
          <p class="small text-secondary mb-0"><?= esc($brandLegalName) ?> is an <strong>independent third-party reseller</strong> of original digital software product keys. We are <strong>not affiliated with, endorsed by, or sponsored by</strong> Microsoft Corporation, Bitdefender, McAfee, Norton, or any other trademark holder referenced on this site — no official-partner, distributor, franchise, or reseller-of-record relationship exists. All product names, logos, and brands are the property of their respective trademark owners and are used strictly for identification (nominative fair use) purposes.</p>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- CTA -->
<?php /* Emit the FAQPage schema so Google can render "People Also Ask"
        snippets and the AI engines can quote individual Q-A pairs. */ ?>
<script type="application/ld+json"><?= json_encode($aboutFaqLd, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?></script>

<!-- Trust & Compliance — visible facts that match the JSON-LD and pass
     ad-platform manual reviews.  Each chip is a concrete, verifiable
     statement (not marketing claim), tied back to a corresponding
     policy page in the footer so a Google Ads reviewer can click
     through to the source. -->
<section class="py-5 bg-soft" data-testid="about-trust-compliance">
  <div class="container">
    <div class="text-center mb-4 mx-auto" style="max-width: 720px;">
      <span class="eyebrow">TRUST &amp; COMPLIANCE</span>
      <h2 class="fw-bold mt-1">Verifiable Facts About Our Business</h2>
      <p class="text-secondary small">Concrete commitments, not marketing claims — each one is backed by a policy you can read in full.</p>
    </div>
    <div class="row g-3" data-testid="trust-grid">
      <?php
      $trustRows = [
        ['bi-shield-check',   'Independent reseller — not Microsoft', 'Microsoft® is a trademark of Microsoft Corporation. We are independent of, and not affiliated with, Microsoft Corporation.', 'page.php?slug=disclaimer'],
        ['bi-arrow-counterclockwise', '30-day money-back guarantee', 'Refund any licence within 30 days of purchase — full amount, no questions asked.',         'return-policy.php'],
        ['bi-clock-history',  'Founded 2024 · California LLC', 'MavenTech LLC was formed in California on September 3, 2024 (LLC No. 202463711253) and has delivered original software product keys as an independent third-party reseller ever since.',         'page.php?slug=terms-of-service'],
        ['bi-lock-fill',      'PCI-DSS-secured checkout',                'Payments processed by our PCI-DSS compliant card gateway & PayPal; we never see or store full card numbers.',             'page.php?slug=payment-policy'],
        ['bi-eye-slash-fill', 'GDPR + CCPA-aware data handling',         'Customer data is collected for fulfilment only and never sold to third parties.',              'page.php?slug=privacy-policy'],
        ['bi-headset',        'Real human support — Mon–Sat, 9am–6pm ET','Live phone + chat. Average first-response time under 15 minutes during business hours.',     'contact.php'],
      ];
      foreach ($trustRows as [$icon, $title, $body, $href]):
      ?>
        <div class="col-md-6 col-lg-4">
          <a href="<?= esc($href) ?>" class="card p-3 h-100 text-decoration-none trust-row" data-testid="trust-row" style="color:inherit;">
            <div class="d-flex align-items-center gap-2 mb-2">
              <i class="bi <?= $icon ?> text-primary fs-5"></i>
              <h3 class="h6 fw-bold mb-0"><?= esc($title) ?></h3>
            </div>
            <p class="small text-secondary mb-0"><?= esc($body) ?></p>
            <small class="text-primary mt-2"><i class="bi bi-arrow-up-right me-1"></i>Read the policy</small>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ — same content as the JSON-LD above so humans + crawlers see one source -->
<section class="py-5" data-testid="about-faq">
  <div class="container" style="max-width: 880px;">
    <div class="text-center mb-4">
      <span class="eyebrow">FREQUENTLY ASKED</span>
      <h2 class="fw-bold mt-1">Common Questions About Us</h2>
    </div>
    <div class="accordion" id="aboutFaqAcc" data-testid="about-faq-accordion">
      <?php foreach ($aboutFaqLd['mainEntity'] as $i => $q): $aid = 'aboutFaqQ' . $i; ?>
        <div class="accordion-item">
          <h3 class="accordion-header">
            <button class="accordion-button <?= $i === 0 ? '' : 'collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $aid ?>" aria-expanded="<?= $i === 0 ? 'true' : 'false' ?>" data-testid="faq-q-<?= $i ?>">
              <?= esc($q['name']) ?>
            </button>
          </h3>
          <div id="<?= $aid ?>" class="accordion-collapse collapse <?= $i === 0 ? 'show' : '' ?>" data-bs-parent="#aboutFaqAcc">
            <div class="accordion-body small text-secondary" data-testid="faq-a-<?= $i ?>">
              <?= esc($q['acceptedAnswer']['text']) ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SMS disclosure (same wording as Terms + Contact) -->
<section class="pb-5" data-testid="about-sms-disclosure">
  <div class="container" style="max-width: 980px;">
    <?= sms_disclosure_html() ?>
  </div>
</section>

<!-- CTA -->
<section class="py-5" data-testid="about-help-cta">
  <div class="container">
    <div class="rounded-4 text-center text-white p-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, #2563eb, #4338ca);">
      <div class="biz-glow"></div>
      <h2 class="fw-bold">Get Your Microsoft Office License Today</h2>
      <p class="opacity-75 mx-auto" style="max-width: 560px;">Authentic perpetual licenses with professional support.</p>
      <div class="d-flex justify-content-center gap-3 flex-wrap small mb-4">
        <span class="biz-chip"><i class="bi bi-patch-check-fill me-1"></i>Genuine Licenses</span>
        <span class="biz-chip"><i class="bi bi-download me-1"></i>Instant Download</span>
        <span class="biz-chip"><i class="bi bi-headset me-1"></i>Professional Support</span>
        <span class="biz-chip"><i class="bi bi-lock-fill me-1"></i>Secure Checkout</span>
      </div>
      <div class="d-flex justify-content-center gap-2 flex-wrap">
        <a href="shop.php" class="btn btn-light rounded-pill px-4 fw-semibold" data-testid="about-browse-btn">Browse Products</a>
        <a href="category.php?slug=office" class="btn btn-outline-light rounded-pill px-4" data-testid="about-compare-btn">Compare Editions</a>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
