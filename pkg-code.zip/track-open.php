<?php
// Email open-tracking endpoint. Returns a 1x1 transparent GIF and marks
// the email row as opened in `email_outbox`. Public — no auth.
// On the FIRST open we also push an admin bell notification so the
// merchant is clearly told the customer opened that specific email.

define('MV_NO_AUTOCRON', true); // the pixel must answer instantly
require_once __DIR__ . '/includes/db.php';

$t = $_GET['t'] ?? '';
if ($t !== '' && preg_match('/^[a-f0-9]{32,64}$/', $t)) {
    try {
        $pdo = db();
        // secs = how long after delivery this hit arrived (DB clock on both
        // sides). Used to spot mail-server prefetches that fire instantly.
        $cols = 'id, recipient, subject, template_code, order_id, opened_at,
                 TIMESTAMPDIFF(SECOND, COALESCE(delivered_at, created_at), NOW()) AS secs';
        $row = $pdo->prepare("SELECT $cols FROM email_outbox WHERE tracking_token = ? ORDER BY id ASC LIMIT 1");
        $row->execute([$t]);
        $em = $row->fetch();
        // LEGACY FALLBACK: emails sent by older builds stored a tracking_token
        // that differs from the pixel token embedded in the HTML, so the direct
        // match above fails and the open never registered ("Customer Opened
        // Email" stuck on pending). Find the row whose saved HTML carries THIS
        // exact pixel token so historical opens register correctly after deploy.
        if (!$em) {
            $row2 = $pdo->prepare("SELECT $cols FROM email_outbox WHERE html LIKE ? ORDER BY id DESC LIMIT 1");
            $row2->execute(['%track-open.php?t=' . $t . '%']);
            $em = $row2->fetch();
        }
        if ($em) {
            // Dispute evidence: store IP / location / ISP / device / client per
            // hit — and score it. Gmail's prefetch bot, Apple Mail Privacy
            // Protection and security scanners fetch the pixel seconds after
            // delivery without the customer opening anything: those are logged
            // but must NOT flip the email to "opened".
            require_once __DIR__ . '/includes/functions.php';
            require_once __DIR__ . '/includes/email-tracking.php';
            $verdict = mv_record_open_event((int)$em['id'], (string)$t, isset($em['secs']) ? (int)$em['secs'] : null);

            if (empty($verdict['auto'])) {
                $firstOpen = empty($em['opened_at']);
                $stmt = $pdo->prepare('UPDATE email_outbox
                    SET opened_at = COALESCE(opened_at, NOW()),
                        opened_count = opened_count + 1,
                        status = CASE WHEN status IN ("queued","failed") THEN status ELSE "opened" END
                    WHERE id = ?');
                $stmt->execute([(int)$em['id']]);

                if ($firstOpen && ($em['template_code'] ?? '') !== 'sale_company_copy' && ($em['template_code'] ?? '') !== 'order_email_bounced') {
                    require_once __DIR__ . '/includes/admin-notify.php';
                    $orderNum = '';
                    if (!empty($em['order_id'])) {
                        $oq = $pdo->prepare('SELECT order_number FROM orders WHERE id = ? LIMIT 1');
                        $oq->execute([(int)$em['order_id']]);
                        $orderNum = (string)($oq->fetchColumn() ?: '');
                    }
                    admin_notify(
                        'email_opened',
                        '📬 Customer opened email — ' . $em['recipient'],
                        mb_strimwidth((string)$em['subject'], 0, 120, '…') . ($orderNum !== '' ? ' (Order #' . $orderNum . ')' : ''),
                        !empty($em['order_id']) ? '/order-view.php?id=' . (int)$em['order_id'] : '/admin.php?tab=emails'
                    );
                }
            }
        }
    } catch (Throwable $e) { /* swallow — never break the pixel */ }
}

// 1x1 transparent GIF
header('Content-Type: image/gif');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
