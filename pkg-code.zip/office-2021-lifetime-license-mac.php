<?php
/** Landing page — Microsoft Office 2021 for Mac, Lifetime License. */
$OFFICE_VERSION  = '2021';
$OFFICE_PLATFORM = 'mac';
require __DIR__ . '/includes/office-landing.php';
