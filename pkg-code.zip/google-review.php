<?php
/*
 * Google review hand-off page — landed from the nudge email.
 * Shows the customer's own review; one tap copies it to the clipboard and
 * opens the Google review dialog. Marks google_shared_at on click.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/google-nudge.php';
$pdo = db();
mv_gn_ensure_cols($pdo);

$token = trim((string)($_GET['t'] ?? ''));
$review = null;
if ($token !== '') {
    $q = $pdo->prepare("SELECT cr.*, (SELECT oi.name FROM order_items oi WHERE oi.order_id = cr.order_id LIMIT 1) AS product_name
                          FROM customer_reviews cr WHERE cr.request_token = ? LIMIT 1");
    $q->execute([$token]);
    $review = $q->fetch();
}
$gurl = trim((string)setting_get('google_review_url', defined('GOOGLE_REVIEW_URL') ? GOOGLE_REVIEW_URL : ''));
$valid = $review && (int)$review['rating'] >= 4 && trim((string)$review['comment']) !== '' && $gurl !== '';
$brand = brand_name();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Share your review on Google · <?= esc($brand) ?></title>
<style>
  body{font-family:'Segoe UI',system-ui,Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 14px;color:#0f172a;}
  .card{max-width:520px;margin:24px auto;background:#fff;border-radius:18px;padding:34px 30px;border:1px solid #e2e8f0;box-shadow:0 10px 30px rgba(2,6,23,.08);text-align:center;}
  .stars{color:#f59e0b;font-size:24px;letter-spacing:3px;margin-bottom:8px;}
  .rev{background:#f8fafc;border:1px dashed #cbd5e1;border-radius:12px;padding:14px 16px;margin:14px 0 20px;font-size:15px;line-height:1.55;font-style:italic;text-align:left;word-break:break-word;}
  .gbtn{display:inline-flex;align-items:center;gap:10px;justify-content:center;width:100%;max-width:360px;padding:14px 22px;background:#fff;border:2px solid #e2e8f0;border-radius:999px;font-weight:700;font-size:15px;color:#0f172a;cursor:pointer;transition:border-color .15s, box-shadow .15s;}
  .gbtn:hover{border-color:#2563eb;box-shadow:0 4px 14px rgba(37,99,235,.18);}
  .hint{display:none;color:#10b981;font-weight:600;font-size:13px;margin-top:12px;}
  .steps{color:#64748b;font-size:12.5px;margin-top:14px;line-height:1.6;}
  .muted{color:#94a3b8;font-size:12px;margin-top:22px;}
  a{color:#2563eb;}
</style>
</head>
<body>
<div class="card" data-testid="google-review-landing">
<?php if ($valid): ?>
  <div style="font-size:34px;">🙏</div>
  <h1 style="font-size:21px;margin:8px 0 4px;">One tap and you're done<?= trim((string)$review['customer_name']) ? ', ' . esc(explode(' ', trim((string)$review['customer_name']))[0]) : '' ?>!</h1>
  <p style="color:#475569;font-size:14px;margin:0 0 10px;">Here's the review you left us<?= $review['product_name'] ? ' for <strong>' . esc($review['product_name']) . '</strong>' : '' ?> — the button below <strong>copies it</strong> and opens Google. Just paste &amp; post (edit it if you like).</p>
  <div class="stars" data-testid="gr-stars"><?= str_repeat('★', (int)$review['rating']) . str_repeat('☆', 5 - (int)$review['rating']) ?></div>
  <div class="rev" id="grText" data-testid="gr-review-text">&ldquo;<?= esc($review['comment']) ?>&rdquo;</div>
  <button type="button" class="gbtn" id="grBtn" data-testid="gr-google-btn">
    <svg viewBox="0 0 48 48" style="width:20px;height:20px;flex-shrink:0;"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34A21.99 21.99 0 0 0 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/></svg>
    <span id="grBtnLabel">Copy my review &amp; open Google</span>
  </button>
  <div class="hint" id="grHint" data-testid="gr-copied-hint">✓ Copied! On the Google page tap the review box, then <strong>Ctrl+V</strong> (or long-press → <strong>Paste</strong>).</div>
  <div class="steps">1. Tap the button &nbsp;·&nbsp; 2. Google opens with your review copied &nbsp;·&nbsp; 3. Paste &amp; hit Post ⭐</div>
  <div class="muted">Thanks for helping other shoppers buy with confidence — <?= esc($brand) ?></div>
  <script>
    (function(){
      var GURL = <?= json_encode($gurl) ?>;
      var TOKEN = <?= json_encode($token) ?>;
      var TEXT = <?= json_encode((string)$review['comment']) ?>;
      document.getElementById('grBtn').addEventListener('click', function(){
        var w = window.open(GURL, '_blank', 'noopener'); // synchronous — same gesture
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(TEXT); }
          else {
            var ta = document.createElement('textarea');
            ta.value = TEXT; ta.style.position='fixed'; ta.style.top='-1000px';
            document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch(_){}
            ta.remove();
          }
        } catch(_){}
        document.getElementById('grHint').style.display = 'block';
        document.getElementById('grBtnLabel').textContent = 'Review copied — paste it on Google';
        try {
          fetch('ajax/google-share-track.php', { method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ token: TOKEN }) });
        } catch(_){}
      });
    })();
  </script>
<?php else: ?>
  <div style="font-size:34px;">🤔</div>
  <h1 style="font-size:20px;margin:8px 0 4px;">This link isn't available</h1>
  <p style="color:#475569;font-size:14px;">The review link may have expired or already been used.<br>You can still leave us a review on Google — we'd love that!</p>
  <?php if ($gurl !== ''): ?><p><a href="<?= esc($gurl) ?>" rel="noopener" data-testid="gr-fallback-link">Write a review on Google →</a></p><?php endif; ?>
  <p class="muted"><a href="/">← Back to <?= esc($brand) ?></a></p>
<?php endif; ?>
</div>
</body>
</html>
