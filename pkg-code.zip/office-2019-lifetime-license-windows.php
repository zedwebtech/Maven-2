<?php
/** Landing page — Microsoft Office 2019 for Windows, Lifetime License. */
$OFFICE_VERSION  = '2019';
$OFFICE_PLATFORM = 'win';
require __DIR__ . '/includes/office-landing.php';
