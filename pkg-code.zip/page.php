<?php
require_once __DIR__ . '/includes/functions.php';

$slug = $_GET['slug'] ?? '';
if ($slug === 'contact-us') { // rich contact page replaced the DB page
    header('Location: contact.php');
    exit;
}
/* 2026-07 FIX — Semrush "2 pages have duplicate content issues" + "2 issues
   with duplicate title tags".  Legal pages that also live at clean URLs
   (/refund-policy.php, /return-policy.php — the latter is the URL submitted
   to Google Merchant Center's Return Policy) 301-redirect here so we keep
   ONE canonical index target per policy instead of two identical pages. */
if ($slug === 'refund-policy') {
    header('Location: /refund-policy.php', true, 301);
    exit;
}
if ($slug === 'return-policy') {
    header('Location: /return-policy.php', true, 301);
    exit;
}
/* 2026-07 FIX — Semrush "2 issues with duplicate title tags" flagged
   /shipping-delivery.php and /page.php?slug=shipping-delivery as sharing
   the same "Shipping & Delivery | Maventech" title.  The dedicated
   /shipping-delivery.php file is the canonical fulfilment-policy page
   (Google Ads compliance), so 301-redirect the legacy DB-backed slug
   here — same treatment as refund-policy / return-policy above. */
if ($slug === 'shipping-delivery') {
    header('Location: /shipping-delivery.php', true, 301);
    exit;
}
// Ensure policy pages use the dynamic company phone (one-time cleanup).
mv_placeholderize_legacy_page_phones();
$page = null;
if ($slug) {
    $stmt = db()->prepare('SELECT * FROM pages WHERE slug = ?');
    $stmt->execute([$slug]);
    $page = $stmt->fetch();
}
$pageTitle = ($page ? $page['title'] : 'Page Not Found') . ' | ' . brand_name();
// Canonicalize the privacy policy to its clean /privacy trust URL whether it is
// reached via /privacy (entry file sets this), the legacy /privacy-policy (301
// -> page.php?slug=privacy-policy), or page.php?slug= directly.
if (!isset($canonicalUrl) && $slug === 'privacy-policy') { $canonicalUrl = site_url() . '/privacy'; }
if ($page) {
    // Resolve company-info placeholders once so they render consistently in
    // the body AND in the meta description / any derived text below.
    $page['content'] = company_placeholders_apply((string)$page['content']);
    $pageDescription = $page['title'] . ' — ' . trim(mb_substr(strip_tags($page['content']), 0, 140)) . '…';
} else {
    http_response_code(404);
    $noIndex = true;
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5" style="max-width: 860px;">
  <?php if ($page): ?>
    <h1 class="fw-bold" data-testid="page-title"><?= esc($page['title']) ?></h1>
    <?php if ($page['updated']): ?><p class="text-secondary small">Last updated: <?= esc($page['updated']) ?></p><?php endif; ?>
    <hr>
    <div class="page-content"><?= $page['content'] /* trusted HTML; company placeholders already resolved above */ ?></div>

    <?php if ($slug === 'disclaimer'): ?>
      <div class="card p-4 mt-4" data-testid="disclaimer-promo"><?= render_menu_promo() ?></div>
    <?php endif; ?>
  <?php else: ?>
    <div class="text-center py-5">
      <h1 class="fw-bold">Page not found</h1>
      <a href="/" class="btn btn-primary rounded-pill px-4 mt-3">Back to Home</a>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
