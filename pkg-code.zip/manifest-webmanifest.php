<?php
/* ===========================================================================
 *  STOREFRONT PWA MANIFEST  —  /manifest.webmanifest
 *  ---------------------------------------------------------------------------
 *  Lets users "Install Maventech" to their iOS / Android home screen.
 *  Installed instances get a real app icon (no browser chrome on iOS 16.4+
 *  and all modern Android browsers), a dedicated splash screen, and — most
 *  importantly for us — appear in the OS's app-switcher / dock, giving us
 *  far higher repeat-visit rates than a plain bookmark.
 *
 *  Generated dynamically so the brand name, theme colour and start URL
 *  always reflect the live Company Info admin settings.  Served at
 *  /manifest.webmanifest via router.php; referenced from <head> by
 *  includes/header.php's <link rel="manifest"> tag.
 *  =========================================================================== */

require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/manifest+json; charset=UTF-8');
header('Cache-Control: public, max-age=3600');

$brand = function_exists('company_info') ? (company_info()['name'] ?? brand_name()) : brand_name();
$short = preg_replace('/\s+software\s*$/i', '', $brand);
if (mb_strlen($short) > 12) $short = mb_substr($short, 0, 12);

// Icons generated live from the Admin → Company Info logo (see /app-icon.php).
$iconVer = function_exists('app_icon_version') ? app_icon_version() : (string)time();
$icon    = fn(int $s) => '/app-icon.php?size=' . $s . '&v=' . $iconVer;

$manifest = [
    'name'             => $brand,
    'short_name'       => $short,
    'description'      => 'Original Microsoft Office, Windows 11 and antivirus software product keys sold by an independent third-party reseller — digital delivery by email, one-time purchase. Not affiliated with Microsoft, Norton or McAfee.',
    'start_url'        => '/?source=pwa',
    'scope'            => '/',
    'display'          => 'standalone',
    'orientation'      => 'any',
    'background_color' => '#0b1220',
    'theme_color'      => '#0B5CFF',
    'id'               => '/?source=pwa',
    'categories'       => ['shopping', 'business', 'productivity'],
    'lang'             => 'en-US',
    'icons'            => [
        ['src' => $icon(192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
        ['src' => $icon(512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
        ['src' => $icon(180), 'sizes' => '180x180', 'type' => 'image/png', 'purpose' => 'any'],
    ],
    'shortcuts'        => [
        ['name' => 'Track an order',  'short_name' => 'Track', 'url' => '/order-history.php?source=pwa-shortcut',
         'icons' => [['src' => $icon(96), 'sizes' => '96x96', 'type' => 'image/png']]],
        ['name' => 'Shop catalog',    'short_name' => 'Shop',  'url' => '/shop.php?source=pwa-shortcut',
         'icons' => [['src' => $icon(96), 'sizes' => '96x96', 'type' => 'image/png']]],
        ['name' => 'Get support',     'short_name' => 'Help',  'url' => '/support.php?source=pwa-shortcut',
         'icons' => [['src' => $icon(96), 'sizes' => '96x96', 'type' => 'image/png']]],
    ],
];

echo json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
