<?php
/**
 * /paypal-webhook.php
 *
 * PayPal → server webhook endpoint. Backstop that finalises a paid order when
 * the buyer closes the tab before the return redirect completes.
 *
 * Configure on the PayPal dashboard (Apps & Credentials → Webhooks):
 *   URL        : https://<your-domain>/paypal-webhook.php
 *   Webhook ID : paste into Admin → API / Payment Gateway → PayPal (stored as
 *                gw_paypal_webhook_id_{live|test})
 *   Events     : PAYMENT.CAPTURE.COMPLETED (minimum)
 *
 * Every event is signature-verified against PayPal before we trust it.
 */

declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/email.php';      // fulfill_order()
require_once __DIR__ . '/includes/recovery.php';   // mv_mark_payment_failed()
require_once __DIR__ . '/includes/gateways/paypal-api.php';

// Only POST; a browser GET should not 500.
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo 'Method Not Allowed';
    exit;
}

$raw = file_get_contents('php://input') ?: '';
$mode = setting_get('gw_mode', 'live') === 'live' ? 'live' : 'test';

// Collect the PayPal transmission headers (case-insensitive).
$hdr = [];
foreach ($_SERVER as $k => $v) {
    if (strpos($k, 'HTTP_') === 0) {
        $name = strtolower(str_replace('_', '-', substr($k, 5)));
        $hdr[$name] = $v;
    }
}

$webhookId = trim((string)setting_get('gw_paypal_webhook_id_' . $mode,
                setting_get('gw_paypal_webhook_id', '')));

/**
 * Verify the webhook signature via PayPal's verify-webhook-signature API.
 * Returns true only on an explicit SUCCESS verdict.
 */
function pp_webhook_verified(string $raw, array $hdr, string $webhookId, string $mode): bool {
    if ($webhookId === '') { @error_log('[paypal-webhook] no webhook id configured'); return false; }
    try {
        $token = paypal_access_token($mode);
        if ($token === '') return false;
        $event = json_decode($raw, true);
        if (!is_array($event)) return false;
        $body = [
            'transmission_id'   => $hdr['paypal-transmission-id']   ?? '',
            'transmission_time' => $hdr['paypal-transmission-time'] ?? '',
            'cert_url'          => $hdr['paypal-cert-url']          ?? '',
            'auth_algo'         => $hdr['paypal-auth-algo']         ?? '',
            'transmission_sig'  => $hdr['paypal-transmission-sig']  ?? '',
            'webhook_id'        => $webhookId,
            'webhook_event'     => $event,
        ];
        $ch = curl_init(paypal_api_base($mode) . '/v1/notifications/verify-webhook-signature');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
            CURLOPT_POSTFIELDS     => json_encode($body),
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        $j = json_decode((string)$resp, true);
        return is_array($j) && ($j['verification_status'] ?? '') === 'SUCCESS';
    } catch (Throwable $e) {
        @error_log('[paypal-webhook] verify error: ' . $e->getMessage());
        return false;
    }
}

if (!pp_webhook_verified($raw, $hdr, $webhookId, $mode)) {
    // Never trust an unverified event.
    http_response_code(400);
    echo 'unverified';
    exit;
}

// Verified — acknowledge fast, then act.
http_response_code(200);
echo 'ok';
if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }

try {
    $event   = json_decode($raw, true) ?: [];
    $type    = (string)($event['event_type'] ?? '');
    $res     = $event['resource'] ?? [];

    // We finalise on a completed capture (money actually received).
    if ($type !== 'PAYMENT.CAPTURE.COMPLETED') { exit; }

    // Resolve the local order:
    //   • custom_id / invoice_id were set to our order_number at create time.
    //   • related order id maps to orders.transaction_id = 'PP:'<id>.
    $orderNumber = (string)($res['custom_id'] ?? $res['invoice_id'] ?? '');
    $ppOrderId   = (string)($res['supplementary_data']['related_ids']['order_id'] ?? '');
    $capId       = (string)($res['id'] ?? '');

    $pdo = db();
    $order = null;
    if ($orderNumber !== '') {
        $q = $pdo->prepare('SELECT * FROM orders WHERE order_number = ? LIMIT 1');
        $q->execute([$orderNumber]);
        $order = $q->fetch();
    }
    if (!$order && $ppOrderId !== '') {
        $q = $pdo->prepare('SELECT * FROM orders WHERE transaction_id = ? LIMIT 1');
        $q->execute(['PP:' . $ppOrderId]);
        $order = $q->fetch();
    }
    if (!$order) { @error_log('[paypal-webhook] no matching order for ' . $orderNumber . ' / ' . $ppOrderId); exit; }

    // Idempotent — skip if already paid.
    if (in_array((string)($order['payment_status'] ?? ''), ['succeeded', 'paid'], true)
        || (string)($order['status'] ?? '') === 'paid') {
        exit;
    }

    // Money-safe: trust the capture resource itself — its status must be
    // COMPLETED and the captured amount/currency must equal our order total
    // (paypal_settle_order re-checks; a mismatch is held for review, not paid).
    if ((string)($res['status'] ?? '') !== 'COMPLETED') {
        @error_log('[paypal-webhook] capture ' . $capId . ' status ' . ($res['status'] ?? '?') . ' — not settling order #' . $order['order_number']);
        exit;
    }
    $settle = paypal_settle_order($order, [
        'ok'         => true,
        'capture_id' => $capId ?: ('PP:' . $ppOrderId),
        'amount'     => isset($res['amount']['value']) ? (float)$res['amount']['value'] : null,
        'currency'   => (string)($res['amount']['currency_code'] ?? ''),
        'processor'  => [
            'response_code' => (string)($res['processor_response']['response_code'] ?? ''),
            'avs_code'      => (string)($res['processor_response']['avs_code'] ?? ''),
            'cvv_code'      => (string)($res['processor_response']['cvv_code'] ?? ''),
        ],
    ], 'webhook');
    if (!empty($settle['ok'])) {
        @error_log('[paypal-webhook] order #' . $order['order_number'] . ' marked paid via webhook');
    } else {
        @error_log('[paypal-webhook] order #' . $order['order_number'] . ' NOT settled: ' . ($settle['error'] ?? ''));
    }
} catch (Throwable $e) {
    @error_log('[paypal-webhook] processing error: ' . $e->getMessage());
}
