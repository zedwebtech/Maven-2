<?php
/*
 * One-click document bundle — downloads EVERY PDF for a single customer order
 * in a single ZIP: Invoice, Receipt, and the Email Thread & Delivery Proof.
 * Admin-only. Linked from order-view.php ("Download all documents").
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/pdf.php';
ensure_admin();
require_admin();
$pdo = db();

$id = (int)($_GET['id'] ?? 0);
$q = $pdo->prepare('SELECT * FROM orders WHERE id=?');
$q->execute([$id]);
$o = $q->fetch(PDO::FETCH_ASSOC);
if (!$o) { http_response_code(404); die('Order not found'); }

$its = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?');
$its->execute([$id]);
$items = $its->fetchAll(PDO::FETCH_ASSOC);

$safe = preg_replace('/[^A-Za-z0-9\-_]/', '', (string)$o['order_number']);
$files = [];
try { $files['1-Proof-of-Fulfillment-' . $safe . '.pdf'] = mv_render_proof_of_fulfillment_pdf($o); } catch (Throwable $e) { @error_log('[order-docs proof] ' . $e->getMessage()); }
try { $files['2-Email-Thread-Proof-' . $safe . '.pdf'] = mv_render_email_thread_proof_pdf($o); } catch (Throwable $e) { @error_log('[order-docs thread] ' . $e->getMessage()); }
try { $files['3-Invoice-' . $safe . '.pdf'] = generate_invoice_pdf($o, $items); } catch (Throwable $e) { @error_log('[order-docs invoice] ' . $e->getMessage()); }
try { $files['4-Receipt-' . $safe . '.pdf'] = generate_receipt_pdf($o, $items); } catch (Throwable $e) { @error_log('[order-docs receipt] ' . $e->getMessage()); }
require_once __DIR__ . '/includes/email-tracking.php';
try { $files['5-Customer-Communication-' . $safe . '.pdf'] = mv_render_customer_communication_pdf($o); } catch (Throwable $e) { @error_log('[order-docs comm] ' . $e->getMessage()); }
try { $files['6-Email-Logs-' . $safe . '.pdf'] = mv_render_email_logs_pdf($o); } catch (Throwable $e) { @error_log('[order-docs logs] ' . $e->getMessage()); }

if (!$files) { http_response_code(500); die('Could not generate documents.'); }

$tmp = tempnam(sys_get_temp_dir(), 'mvdocs_');
$zip = new ZipArchive();
if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) { http_response_code(500); die('Could not create archive.'); }
foreach ($files as $name => $bytes) { if ($bytes !== '') $zip->addFromString($name, $bytes); }
$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="Order-' . $safe . '-documents.zip"');
header('Content-Length: ' . filesize($tmp));
header('Cache-Control: no-store');
readfile($tmp);
@unlink($tmp);
