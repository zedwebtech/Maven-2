<?php
/*
 * AI Newsletter — admin composes a newsletter (AI suggests topics + writes the
 * content), reviews/edits it, then sends it to every existing customer
 * (paying customers + newsletter sign-ups, minus anyone who unsubscribed).
 * Each newsletter can also be published to the website blog.
 *
 * Reuses the app's existing Emergent AI helper (mv_ai_llm_chat, ai-studio.php),
 * the SMTP queue (smtp_queue_email) and the HMAC unsubscribe flow.
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/followup-emails.php';   // unsubscribe_token_for()

/** Idempotent, non-destructive table creation (mirrors ensure_db_schema()). */
function mv_newsletter_ensure_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS newsletters (
            id INT AUTO_INCREMENT PRIMARY KEY,
            topic VARCHAR(255) NOT NULL DEFAULT '',
            subject VARCHAR(255) NOT NULL DEFAULT '',
            preheader VARCHAR(255) NOT NULL DEFAULT '',
            body_html MEDIUMTEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            total_recipients INT NOT NULL DEFAULT 0,
            sent_count INT NOT NULL DEFAULT 0,
            blog_post_id VARCHAR(100) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at TIMESTAMP NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) { error_log('[newsletter] schema: ' . $e->getMessage()); }
}

/**
 * The recipient list: distinct lower-cased emails of PAYING customers (paid /
 * delivered orders) with everyone on the unsubscribe list removed. Footer
 * newsletter sign-ups are included only when setting nl_include_signups = 1.
 * @return string[]
 */
function mv_newsletter_audience(): array
{
    $pdo = db();
    $sql = "SELECT CONVERT(LOWER(TRIM(email)) USING utf8mb4) AS email FROM orders
                WHERE status IN ('paid','delivered') AND email IS NOT NULL AND TRIM(email) <> ''";
    if (setting_get('nl_include_signups', '0') === '1') {
        $sql .= " UNION SELECT CONVERT(LOWER(TRIM(email)) USING utf8mb4) AS email FROM newsletter_subscribers
                    WHERE email IS NOT NULL AND TRIM(email) <> ''";
    }
    $sql = "SELECT a.email FROM ($sql) a
            WHERE a.email NOT IN (SELECT CONVERT(LOWER(TRIM(email)) USING utf8mb4) FROM email_unsubscribes)";
    $out = [];
    try {
        foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN) as $e) {
            if (filter_var($e, FILTER_VALIDATE_EMAIL)) $out[] = $e;
        }
    } catch (Throwable $e) { error_log('[newsletter] audience: ' . $e->getMessage()); }
    return array_values(array_unique($out));
}

function mv_newsletter_audience_count(): int
{
    return count(mv_newsletter_audience());
}

/** AI: suggest a handful of newsletter topic ideas for this store. */
function mv_newsletter_suggest_topics(): array
{
    require_once __DIR__ . '/ai-studio.php';
    $co  = company_info();
    $sys = "You are an email-marketing assistant for \"" . ($co['name'] ?? 'our store')
         . "\", an online shop selling genuine Microsoft Office/Windows product keys and antivirus software. "
         . "Suggest newsletter topics that existing customers would open and enjoy — practical value, not salesy. "
         . "Mix ideas: security tips, how-to guides, product news/updates, seasonal offers, productivity tips. "
         . "Return ONLY a JSON array of 6 short topic titles (max 8 words each), no numbering, no extra text.";
    $usr = "Give me 6 fresh newsletter topic ideas for this month.";
    $ans = '';
    try { $ans = mv_ai_llm_chat($sys, $usr, 700, 0.9); } catch (Throwable $e) { $ans = ''; }

    $topics = [];
    if ($ans !== '') {
        $jsonStart = strpos($ans, '[');
        $jsonEnd   = strrpos($ans, ']');
        if ($jsonStart !== false && $jsonEnd !== false && $jsonEnd > $jsonStart) {
            $arr = json_decode(substr($ans, $jsonStart, $jsonEnd - $jsonStart + 1), true);
            if (is_array($arr)) {
                foreach ($arr as $t) {
                    $t = trim((string)$t);
                    if ($t !== '') $topics[] = mb_substr($t, 0, 120);
                }
            }
        }
        if (!$topics) { // fallback: split lines
            foreach (preg_split('/\r?\n/', $ans) as $line) {
                $line = trim(preg_replace('/^[\s\-\*\d\.\)]+/', '', $line));
                if ($line !== '' && mb_strlen($line) < 120) $topics[] = $line;
            }
        }
    }
    if (!$topics) {
        $topics = [
            'Keep your PC safe: 5 quick security wins',
            'Getting the most out of Microsoft Office',
            'Windows tips that save you time every day',
            'Why genuine keys matter (and how to check yours)',
            'This month\'s exclusive customer offers',
            'New arrivals and product updates',
        ];
    }
    return array_slice($topics, 0, 6);
}

/** AI: write a full newsletter for a topic. Returns [subject, preheader, body_html]. */
function mv_newsletter_generate(string $topic): array
{
    require_once __DIR__ . '/ai-studio.php';
    $co    = company_info();
    $brand = $co['name'] ?? 'our store';
    $topic = trim($topic);
    if ($topic === '') $topic = 'A friendly update from ' . $brand;

    $sys = "You are a senior email copywriter for \"$brand\", an online store selling genuine "
         . "Microsoft Office/Windows keys and antivirus software. Write a warm, helpful customer "
         . "newsletter. Keep it skimmable and genuine — helpful first, lightly promotional. "
         . "Return your answer in EXACTLY this plain-text format and nothing else (no JSON, no code "
         . "fences, no backticks):\n"
         . "SUBJECT: <one catchy line, max 68 chars, no emojis>\n"
         . "PREHEADER: <one preview line, max 110 chars>\n"
         . "---BODY---\n"
         . "<the newsletter body as simple HTML using ONLY these tags: <h2>, <h3>, <p>, <ul>, <li>, "
         . "<strong>, <em>, <a href>. No <html>, <head>, <body>, <style>, no inline styles, no classes. "
         . "350-550 words: friendly greeting, 2-4 short sections, and a closing call-to-action paragraph.>\n"
         . "Do not invent specific prices or fake discount codes.";
    $usr = "Write the newsletter about this topic: \"$topic\".";

    $ans = '';
    try { $ans = mv_ai_llm_chat($sys, $usr, 3000, 0.7); } catch (Throwable $e) { $ans = ''; }

    // Strip any stray code fences the model may add (```json, ```html, ```).
    $ans = trim($ans);
    $ans = preg_replace('/^```[a-zA-Z]*\s*/', '', $ans);
    $ans = preg_replace('/```\s*$/', '', $ans);

    $subject = ''; $preheader = ''; $body = '';

    // Primary: parse the SUBJECT / PREHEADER / ---BODY--- format.
    if (preg_match('/SUBJECT:\s*(.+)/i', $ans, $m1)) $subject = trim($m1[1]);
    if (preg_match('/PREHEADER:\s*(.+)/i', $ans, $m2)) $preheader = trim($m2[1]);
    if (preg_match('/---\s*BODY\s*---\s*(.+)$/is', $ans, $m3)) $body = trim($m3[1]);

    // Fallback: the model returned JSON anyway — dig the fields out of it.
    if ($body === '' && ($js = strpos($ans, '{')) !== false) {
        $je = strrpos($ans, '}');
        if ($je !== false && $je > $js) {
            $j = json_decode(substr($ans, $js, $je - $js + 1), true);
            if (is_array($j)) {
                $subject   = $subject   ?: trim((string)($j['subject']   ?? ''));
                $preheader = $preheader ?: trim((string)($j['preheader'] ?? ''));
                $body      = trim((string)($j['body_html'] ?? $j['body'] ?? ''));
            }
        }
    }

    // Last resort: treat the whole thing as the body (never show JSON to the admin).
    if ($body === '') {
        $clean = $ans;
        // If it still looks like JSON, drop it and use a safe default instead.
        if ($clean === '' || $clean[0] === '{' || stripos($clean, '"body_html"') !== false) {
            $clean = '';
        }
        if ($clean !== '') {
            $body = (strip_tags($clean) === $clean) ? '<p>' . nl2br(esc($clean)) . '</p>' : $clean;
        }
    }

    $subject   = trim(strip_tags($subject));
    $preheader = trim(strip_tags($preheader));
    if ($subject === '')   $subject   = mb_substr($topic, 0, 68);
    if ($preheader === '') $preheader = 'A quick update from ' . $brand;
    if ($body === '') {
        $body = '<h2>Hello from ' . esc($brand) . '</h2><p>We wanted to share a quick update with you. '
              . 'Thank you for being our customer!</p>';
    }
    // Keep only safe tags.
    $body = strip_tags($body, '<h2><h3><p><ul><ol><li><strong><b><em><i><a><br>');
    return ['subject' => mb_substr($subject, 0, 255), 'preheader' => mb_substr($preheader, 0, 255), 'body_html' => $body];
}

/** Wrap the body in a branded, email-safe HTML shell with an unsubscribe footer. */
function mv_newsletter_wrap_html(string $subject, string $preheader, string $bodyHtml, string $unsubUrl): string
{
    $co    = company_info();
    $brand = esc($co['name']  ?? 'Maventech');
    $addr  = esc($co['address'] ?? '');
    $email = esc($co['email'] ?? '');
    $year  = date('Y');
    $pre   = esc($preheader);
    $unsub = esc($unsubUrl);

    return '<!doctype html><html><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . esc($subject) . '</title></head>'
        . '<body style="margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        . '<span style="display:none!important;opacity:0;color:transparent;height:0;width:0;overflow:hidden;">' . $pre . '</span>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:24px 0;"><tr><td align="center">'
        . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 8px 30px rgba(15,23,42,.08);">'
        . '<tr><td style="background:#0f172a;padding:22px 28px;"><span style="color:#fff;font-size:20px;font-weight:800;letter-spacing:.3px;">' . $brand . '</span></td></tr>'
        . '<tr><td style="padding:28px 28px 8px 28px;line-height:1.65;font-size:15px;">' . $bodyHtml . '</td></tr>'
        . '<tr><td style="padding:18px 28px 28px 28px;">'
        . '<hr style="border:none;border-top:1px solid #e2e8f0;margin:0 0 16px;">'
        . '<p style="font-size:12px;color:#64748b;margin:0 0 6px;">You are receiving this because you are a customer of ' . $brand . '.'
        . ($addr ? '<br>' . $addr : '') . ($email ? '<br>' . $email : '') . '</p>'
        . '<p style="font-size:12px;color:#64748b;margin:0;">&copy; ' . $year . ' ' . $brand . '. '
        . '<a href="' . $unsub . '" style="color:#64748b;text-decoration:underline;">Unsubscribe</a></p>'
        . '</td></tr></table></td></tr></table></body></html>';
}

/** Publish a newsletter to the website blog. Returns the new blog_posts id, or ''. */
function mv_newsletter_publish_blog(string $subject, string $bodyHtml): string
{
    try {
        $pdo   = db();
        $slug  = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $subject));
        $slug  = trim($slug, '-') ?: 'newsletter';
        $postId = 'nl-' . date('Ymd') . '-' . mb_substr($slug, 0, 60) . '-' . substr(bin2hex(random_bytes(3)), 0, 5);
        $words  = str_word_count(strip_tags($bodyHtml));
        $read   = max(2, (int)ceil($words / 200)) . ' min read';
        $lead   = mb_substr(trim(strip_tags($bodyHtml)), 0, 180);
        $image  = '';
        if (function_exists('mv_blog_stock_fallback')) {
            try { $image = (string)mv_blog_stock_fallback($postId); } catch (Throwable $e) { $image = ''; }
        }
        $content = '<p style="color:#64748b;font-size:14px;"><em>From our newsletter</em></p>' . $bodyHtml;
        $pdo->prepare(
            "INSERT INTO blog_posts (id, title, date, read_time, image, content, ai_generated, lead, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW(), NOW())"
        )->execute([$postId, mb_substr($subject, 0, 255), date('M j, Y'), $read, $image, $content, $lead]);
        return $postId;
    } catch (Throwable $e) {
        error_log('[newsletter] blog: ' . $e->getMessage());
        return '';
    }
}

/**
 * Send a draft newsletter to the full audience (queued for the SMTP worker),
 * mark it sent, and optionally publish it to the blog.
 * @return array{ok:bool, queued:int, blog_post_id:string, message?:string}
 */
function mv_newsletter_send(int $id, bool $alsoBlog = true): array
{
    mv_newsletter_ensure_schema();
    $pdo = db();
    $row = null;
    try {
        $st = $pdo->prepare("SELECT * FROM newsletters WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
    if (!$row) return ['ok' => false, 'queued' => 0, 'blog_post_id' => '', 'message' => 'Newsletter not found.'];
    if (($row['status'] ?? '') === 'sent') {
        return ['ok' => false, 'queued' => 0, 'blog_post_id' => '', 'message' => 'This newsletter was already sent.'];
    }

    $audience = mv_newsletter_audience();
    if (!$audience) {
        return ['ok' => false, 'queued' => 0, 'blog_post_id' => '', 'message' => 'No customers to send to yet.'];
    }

    $subject   = (string)$row['subject'];
    $preheader = (string)$row['preheader'];
    $body      = (string)$row['body_html'];
    $base      = rtrim(site_url(), '/');

    $queued = 0;
    foreach ($audience as $to) {
        try {
            $unsub = $base . '/unsubscribe.php?e=' . rawurlencode($to) . '&t=' . rawurlencode(unsubscribe_token_for($to));
            $html  = mv_newsletter_wrap_html($subject, $preheader, $body, $unsub);
            smtp_queue_email($to, $subject, $html, [
                'template_code' => 'newsletter',
                'priority'      => 7,       // below transactional mail
                'no_cc'         => true,    // don't copy the store on every customer's newsletter
                'headers'       => ['List-Unsubscribe' => '<' . $unsub . '>'],
            ]);
            $queued++;
        } catch (Throwable $e) { /* skip bad address, keep going */ }
    }

    $blogId = '';
    if ($alsoBlog) $blogId = mv_newsletter_publish_blog($subject, $body);

    try {
        $pdo->prepare("UPDATE newsletters SET status='sent', total_recipients=?, sent_count=?, blog_post_id=?, sent_at=NOW() WHERE id=?")
            ->execute([count($audience), $queued, ($blogId ?: null), $id]);
    } catch (Throwable $e) {}

    // Start delivering right away; the auto-scheduler / cron drains the rest.
    try { smtp_process_queue(10); } catch (Throwable $e) {}

    return ['ok' => true, 'queued' => $queued, 'blog_post_id' => $blogId];
}
