<?php
/**
 * includes/office-landing.php
 *
 * Shared, data-driven landing page for the "Microsoft Office <YEAR> Lifetime
 * License" pages. Modelled on the reference layout: hero with version imagery,
 * an edition selector (Home / Home & Business / Professional Plus), a
 * "What You Get" feature grid, an Office-vs-365 comparison, a 3-step
 * "How it works", trust cards, FAQ and a final CTA.
 *
 * Each route file (office-2024-lifetime-license.php, …2021…, …2019…) sets
 * $OFFICE_VERSION then requires this file.  Prices, names and box images are
 * pulled live from the products table so the page always matches the store.
 *
 * Buy buttons reuse the storefront's `.buy-now-btn` / `.add-to-cart-btn`
 * handlers (assets/js/main.js) via data-slug, so checkout works end-to-end.
 */
require_once __DIR__ . '/functions.php';

$VER = in_array(($OFFICE_VERSION ?? '2024'), ['2024', '2021', '2019'], true) ? $OFFICE_VERSION : '2024';
$IS_MAC   = (($OFFICE_PLATFORM ?? 'win') === 'mac');
$PLAT_KEY = $IS_MAC ? 'mac' : 'win';
$PLAT_LBL = $IS_MAC ? 'Mac' : 'Windows';

/* -------------------------------------------------------------------- */
/* Per-version configuration: editions map to REAL product slugs.       */
/* msrp = "retail" compare-at price used to compute the SAVE % badge.    */
/* -------------------------------------------------------------------- */
$CONFIG = [
    '2024' => [
        'intro' => 'Office 2024 is the latest one-time-purchase release — classic Word, Excel, PowerPoint and more, with no subscription and free lifetime updates.',
        'editions' => [
            ['slug'=>'microsoft-office-home-2024-pc',                'mac_slug'=>'microsoft-office-home-2024-mac',          'label'=>'Home',              'tagline'=>'Essential productivity apps',   'apps'=>'Word + Excel + PowerPoint',                       'msrp'=>199.99, 'badge'=>'Best Seller',   'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-home-business-2024-pc',       'mac_slug'=>'microsoft-office-home-business-2024-mac', 'label'=>'Home & Business',   'tagline'=>'Includes Outlook email',         'apps'=>'Word + Excel + PowerPoint + Outlook',             'msrp'=>249.99, 'badge'=>'Best Value',    'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-2024-professional-plus-windows','label'=>'Professional Plus','tagline'=>'All 5 apps + Access database',  'apps'=>'Word + Excel + PowerPoint + Outlook + Access',    'msrp'=>499.99, 'badge'=>'Most Powerful', 'platform'=>'Windows PC Only',    'pc_only'=>true],
        ],
    ],
    '2021' => [
        'intro' => 'Office 2021 delivers the apps you rely on as a single one-time purchase — perfect for a modern Windows PC with no recurring fees.',
        'editions' => [
            ['slug'=>'microsoft-office-2021-home-student-windows',   'mac_slug'=>'microsoft-office-2021-home-student-mac',  'label'=>'Home & Student',    'tagline'=>'Essential productivity apps',   'apps'=>'Word + Excel + PowerPoint',                       'msrp'=>149.99, 'badge'=>'Best Seller',   'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-2021-home-business-windows',  'mac_slug'=>'microsoft-office-2021-home-business-mac', 'label'=>'Home & Business',   'tagline'=>'Includes Outlook email',         'apps'=>'Word + Excel + PowerPoint + Outlook',             'msrp'=>279.99, 'badge'=>'Best Value',    'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-2021-professional-plus-windows','label'=>'Professional Plus','tagline'=>'All 5 apps + Access database',  'apps'=>'Word + Excel + PowerPoint + Outlook + Access',    'msrp'=>439.99, 'badge'=>'Most Powerful', 'platform'=>'Windows PC Only',    'pc_only'=>true],
        ],
    ],
    '2019' => [
        'intro' => 'Office 2019 is the proven one-time-purchase suite for Windows — own it forever with a genuine perpetual license and no subscription.',
        'editions' => [
            ['slug'=>'microsoft-office-2019-home-student-windows',   'mac_slug'=>'microsoft-office-home-and-student-2019-mac',  'label'=>'Home & Student',    'tagline'=>'Essential productivity apps',   'apps'=>'Word + Excel + PowerPoint',                       'msrp'=>129.99, 'badge'=>'Best Seller',   'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-2019-home-business-pc',       'mac_slug'=>'microsoft-office-home-and-business-2019-mac', 'label'=>'Home & Business',   'tagline'=>'Includes Outlook email',         'apps'=>'Word + Excel + PowerPoint + Outlook',             'msrp'=>229.99, 'badge'=>'Best Value',    'platform'=>'Windows PC & macOS', 'pc_only'=>false],
            ['slug'=>'microsoft-office-2019-professional-plus-windows','label'=>'Professional Plus','tagline'=>'All 5 apps + Access database',  'apps'=>'Word + Excel + PowerPoint + Outlook + Access',    'msrp'=>379.99, 'badge'=>'Most Powerful', 'platform'=>'Windows PC Only',    'pc_only'=>true],
        ],
    ],
];

$cfg = $CONFIG[$VER];
if ($IS_MAC) {
    $cfg['intro'] = str_ireplace(
        ['a modern Windows PC', 'for a modern Windows PC', 'for Windows', 'Windows PC', 'Windows'],
        ['a modern Mac', 'for a modern Mac', 'for Mac', 'Mac', 'macOS'],
        $cfg['intro']
    );
}

/* Hydrate each edition with the live product row (price, name, image). */
$editions = [];
foreach ($cfg['editions'] as $e) {
    if ($IS_MAC && (!empty($e['pc_only']) || empty($e['mac_slug']))) continue;  // Mac page: skip PC-only editions
    $slug = $IS_MAC ? $e['mac_slug'] : $e['slug'];   // Mac page uses the dedicated Mac SKU
    $p = get_product($slug);
    if (!$p || (int)($p['is_active'] ?? 1) !== 1) continue;
    $e['slug'] = $slug;   // downstream data-slug / buy-now / images use the platform SKU
    if ($IS_MAC) { $e['platform'] = 'macOS'; }
    $e['product']  = $p;
    $e['price']    = (float)$p['price'];
    $e['image']    = $p['image'] ?: '/uploads/products/' . $e['slug'] . '.webp';
    $e['save_pct'] = ($e['msrp'] > 0 && $e['price'] < $e['msrp'])
        ? (int)round((($e['msrp'] - $e['price']) / $e['msrp']) * 100) : 0;
    $editions[] = $e;
}

if (!$editions) { http_response_code(404); require __DIR__ . '/../404.php'; return; }

$minPrice   = min(array_map(fn($e) => $e['price'], $editions));
$maxMsrp    = max(array_map(fn($e) => $e['msrp'],  $editions));
$topSavePct = ($maxMsrp > 0) ? (int)round((($maxMsrp - $minPrice) / $maxMsrp) * 100) : 0;
$heroImg    = end($editions)['image'];   // Professional Plus box = hero
reset($editions);

/* Standard per-edition selling points. */
$stdBullets = [
    'Original Microsoft Product Key',
    'One-Time Purchase — Own It Forever',
    'Free Lifetime Updates',
    'Instant Email Delivery',
    'Free Installation Support Included',
];

/* Shared feature-section imagery (sourced via vision expert). */
$featureImgs = [
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=900&q=70',
    'https://images.pexels.com/photos/6694560/pexels-photo-6694560.jpeg?auto=compress&cs=tinysrgb&w=900',
    'https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b?auto=format&fit=crop&w=900&q=70',
];

/* Cross-links to the other version landing pages. */
$otherVersions = array_values(array_filter(['2024','2021','2019'], fn($v) => $v !== $VER));

/* Real, live review aggregate from customer_reviews (grows as reviews come
   in — no hardcoded numbers). Falls back to the stat labels only. */
$siteRev  = site_review_stats();
$revCount = number_format((int)$siteRev['count']);
$revAvg   = number_format((float)$siteRev['avg'], 1);

$pageTitle       = 'Buy Microsoft Office ' . $VER . ($IS_MAC ? ' for Mac' : '') . ' — Genuine Lifetime License | ' . brand_name();
$pageDescription = 'Buy Microsoft Office ' . $VER . ($IS_MAC ? ' for Mac (macOS)' : '') . ' online — genuine lifetime license, one-time purchase, instant digital delivery. Word, Excel, PowerPoint and more. From ' . format_price($minPrice) . '.';
$canonicalUrl    = rtrim(site_url(), '/') . '/office-' . $VER . '-lifetime-license' . ($IS_MAC ? '-mac' : '-windows') . '.php';
$curSym          = current_currency()['symbol'] ?? '$';
$preloadImage    = $heroImg; // LCP: <link rel="preload" as="image"> emitted by header.php

include __DIR__ . '/header.php';
?>
<div class="office-lp" data-testid="office-landing-<?= $VER ?><?= $IS_MAC ? '-mac' : '' ?>">

  <!-- ============================ HERO ============================ -->
  <section class="olp-hero">
    <div class="container">
      <div class="row align-items-center g-4">
        <div class="col-lg-6 order-lg-1 order-2">
          <div class="d-flex align-items-center gap-2 mb-2">
            <span class="olp-brand-badge"><i class="bi bi-microsoft me-1"></i>Microsoft</span>
            <span class="olp-pill"><i class="bi bi-patch-check-fill me-1"></i>100% Genuine</span>
          </div>
          <h1 class="olp-title">Microsoft Office <?= esc($VER) ?><?= $IS_MAC ? ' for Mac' : '' ?></h1>
          <p class="olp-subtitle">Lifetime License — One-Time Purchase<?= $IS_MAC ? ' · macOS' : '' ?></p>
          <?php
            // Cross-platform switch: link between the Windows and Mac editions of this year.
            $winUrl = '/office-' . $VER . '-lifetime-license-windows.php';
            $macUrl = '/office-' . $VER . '-lifetime-license-mac.php';
          ?>
          <div class="olp-platswitch" data-testid="olp-platform-switch">
            <a class="olp-platswitch-btn<?= $IS_MAC ? '' : ' is-active' ?>" href="<?= esc($winUrl) ?>" data-testid="olp-platlink-windows"><i class="bi bi-windows me-1"></i>Windows</a>
            <a class="olp-platswitch-btn<?= $IS_MAC ? ' is-active' : '' ?>" href="<?= esc($macUrl) ?>" data-testid="olp-platlink-mac"><i class="bi bi-apple me-1"></i>Mac</a>
          </div>
          <?php
            // Offer an easy upgrade path to NEWER editions (2019 -> 2021 & 2024, 2021 -> 2024).
            $olpNewer = [];
            foreach (['2021', '2024'] as $yr) {
                if ((int)$yr > (int)$VER) $olpNewer[] = $yr;
            }
          ?>
          <?php if ($olpNewer): ?>
          <div class="olp-verswitch" data-testid="olp-version-switch">
            <span class="olp-verswitch-label">Looking for a newer version?</span>
            <span class="olp-verswitch-btns">
              <span class="olp-ver-current">Office <?= esc($VER) ?></span>
              <?php foreach ($olpNewer as $yr): ?>
                <a class="olp-ver-link" href="/office-<?= esc($yr) ?>-lifetime-license<?= $IS_MAC ? '-mac' : '' ?>.php" data-testid="olp-goto-<?= esc($yr) ?>">Office <?= esc($yr) ?> <i class="bi bi-arrow-right-short"></i></a>
              <?php endforeach; ?>
            </span>
          </div>
          <?php endif; ?>
          <div class="d-flex align-items-end gap-3 flex-wrap mb-3">
            <div>
              <div class="olp-retail">Retail price: <?= format_price($maxMsrp) ?></div>
              <div class="olp-price">From <?= format_price($minPrice) ?></div>
            </div>
            <?php if ($topSavePct > 0): ?><span class="olp-save">SAVE <?= $topSavePct ?>%</span><?php endif; ?>
          </div>
          <div class="d-flex flex-wrap gap-2 mb-3">
            <a href="#editions" class="btn btn-orange-solid btn-lg rounded-pill px-4 fw-bold" data-testid="hero-buy-now"><i class="bi bi-cart-plus me-2"></i>Buy Now — From <?= format_price($minPrice) ?></a>
            <a href="#editions" class="btn btn-orange-outline btn-lg rounded-pill px-4">Compare Editions</a>
          </div>
          <ul class="olp-trust-row list-unstyled">
            <li><i class="bi bi-check-circle-fill"></i> 100% Genuine License</li>
            <li><i class="bi bi-envelope-check"></i> Instant Email Delivery</li>
            <li><i class="bi bi-shield-check"></i> 30-Day Money-Back</li>
            <li><i class="bi bi-infinity"></i> No Subscription Ever</li>
          </ul>
          <div class="olp-rating"><span class="olp-stars">★★★★★</span> <?= $revAvg ?>/5 <span class="text-muted">(<?= $revCount ?> verified reviews)</span></div>
        </div>

        <div class="col-lg-6 order-lg-2 order-1">
          <div class="olp-hero-media">
            <img id="olpHeroImg" src="<?= esc($heroImg) ?>" alt="Microsoft Office <?= esc($VER) ?> lifetime license" class="olp-hero-img" loading="eager" fetchpriority="high" decoding="async" width="640" height="480">
            <div class="olp-thumbs" role="tablist" aria-label="Office <?= esc($VER) ?> editions">
              <?php foreach ($editions as $i => $e): ?>
                <button type="button" class="olp-thumb<?= $i === 0 ? ' active' : '' ?>" data-slug="<?= esc($e['slug']) ?>" data-img="<?= esc($e['image']) ?>" data-label="<?= esc('Office ' . $VER . ' ' . $e['label']) ?>" aria-label="Show <?= esc($e['label']) ?> image">
                  <img src="<?= esc($e['image']) ?>" alt="<?= esc('Office ' . $VER . ' ' . $e['label']) ?>" loading="lazy" width="90" height="70">
                </button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="olp-countdown" data-testid="olp-countdown">
            <span class="me-2 fw-semibold"><i class="bi bi-lightning-charge-fill text-warning me-1"></i>Sale ends in:</span>
            <span id="olpCd" class="olp-cd">--:--:--</span>
          </div>
        </div>
      </div>

      <!-- trust stat strip -->
      <div class="row g-3 mt-2 olp-stats">
        <div class="col-6 col-md-3"><div class="olp-stat"><div class="olp-stat-n"><?= $revCount ?></div><div class="olp-stat-l">Happy Customers</div></div></div>
        <div class="col-6 col-md-3"><div class="olp-stat"><div class="olp-stat-n"><?= $revAvg ?>/5</div><div class="olp-stat-l">Average Rating</div></div></div>
        <div class="col-6 col-md-3"><div class="olp-stat"><div class="olp-stat-n">98%+</div><div class="olp-stat-l">Activation Success</div></div></div>
        <div class="col-6 col-md-3"><div class="olp-stat"><div class="olp-stat-n">&lt;30min</div><div class="olp-stat-l">Avg. Delivery Time</div></div></div>
      </div>
    </div>
  </section>

  <!-- ======================= EDITION SELECTOR ======================= -->
  <section class="olp-section" id="editions">
    <div class="container">
      <div class="text-center mb-4">
        <span class="olp-eyebrow">Limited Time Pricing</span>
        <h2 class="olp-h2">Choose Your Office <?= esc($VER) ?> Edition</h2>
        <p class="olp-lead"><?= esc($cfg['intro']) ?> Select the edition that fits you — all include lifetime access, free updates and instant digital delivery.</p>
      </div>
      <div class="row g-3 justify-content-center" id="olpEditionGrid">
        <?php foreach ($editions as $i => $e): ?>
          <div class="col-lg-4 col-md-6">
            <div class="olp-edition<?= $i === 0 ? ' selected' : '' ?>" data-slug="<?= esc($e['slug']) ?>" data-price="<?= esc((string)$e['price']) ?>" data-img="<?= esc($e['image']) ?>" data-testid="olp-edition-<?= $i ?>" role="button" tabindex="0" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>">
              <?php if (!empty($e['badge'])): ?><span class="olp-edition-badge"><?= esc($e['badge']) ?></span><?php endif; ?>
              <div class="olp-edition-imgwrap"><img src="<?= esc($e['image']) ?>" alt="<?= esc($e['product']['name']) ?>" loading="lazy" width="220" height="170"></div>
              <h3 class="olp-edition-name"><?= esc($e['label']) ?></h3>
              <div class="olp-edition-tag"><?= esc($e['tagline']) ?></div>
              <div class="olp-edition-apps"><?= esc($e['apps']) ?></div>
              <div class="olp-edition-pricing">
                <?php if ($e['msrp'] > $e['price']): ?><span class="olp-edition-msrp"><?= format_price($e['msrp']) ?></span><?php endif; ?>
                <span class="olp-edition-price"><?= format_price($e['price']) ?></span>
              </div>
              <?php if ($e['save_pct'] > 0): ?><div class="olp-edition-save">Save <?= $e['save_pct'] ?>% — You save <?= format_price($e['msrp'] - $e['price']) ?></div><?php endif; ?>
              <ul class="olp-edition-list list-unstyled">
                <?php foreach ($stdBullets as $b): ?><li><i class="bi bi-check2"></i> <?= esc($b) ?></li><?php endforeach; ?>
                <li><i class="bi bi-check2"></i> Available for <?= esc($e['platform']) ?></li>
              </ul>
              <button class="btn btn-orange-solid w-100 rounded-pill fw-bold buy-now-btn" data-slug="<?= esc($e['slug']) ?>" data-testid="olp-buy-<?= $i ?>"><i class="bi bi-lightning-charge-fill me-1"></i>Buy Now — <?= format_price($e['price']) ?></button>
              <div class="olp-edition-secure"><i class="bi bi-lock-fill me-1"></i>Secure checkout with 256-bit encryption</div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ========================= PC OR MAC ========================= -->
  <section class="olp-section olp-alt">
    <div class="container">
      <div class="row align-items-center g-4">
        <div class="col-lg-6">
          <span class="olp-eyebrow">Genuine · Perpetual</span>
          <h2 class="olp-h2">One License. Own It Forever.</h2>
          <p class="olp-lead">Office <?= esc($VER) ?> is a one-time purchase — pay once and use it for life. Choose your edition above and receive your genuine product key instantly via email.</p>
          <div class="row g-3">
            <?php
              $pcmac = [
                ['bi-key-fill','Genuine product key delivered instantly','Receive your activation key via email within minutes.'],
                ['bi-window-stack','Word, Excel & PowerPoint included','All the essential apps you use every day.'],
                ['bi-infinity','One-time purchase — no subscription','Pay once and own it forever, no recurring fees.'],
                ['bi-headset','Free download & installation support','Our team guides you through the entire setup.'],
              ];
              foreach ($pcmac as $f): ?>
              <div class="col-sm-6"><div class="olp-mini"><i class="bi <?= $f[0] ?>"></i><div><strong><?= esc($f[1]) ?></strong><span><?= esc($f[2]) ?></span></div></div></div>
            <?php endforeach; ?>
          </div>
          <a href="#editions" class="btn btn-orange-outline rounded-pill px-4 mt-3">View All Editions</a>
        </div>
        <div class="col-lg-6 text-center">
          <?php
            $olpBoxWin = '/uploads/office-landing/office-' . $VER . '-win.jpg';
            $olpBoxMac = '/uploads/office-landing/office-' . $VER . '-mac.jpg';
            $hasWin = is_file(__DIR__ . '/..' . $olpBoxWin);
            $hasMac = is_file(__DIR__ . '/..' . $olpBoxMac);
            $defImg = $IS_MAC
                ? ($hasMac ? $olpBoxMac : ($hasWin ? $olpBoxWin : $editions[0]['image']))
                : ($hasWin ? $olpBoxWin : ($hasMac ? $olpBoxMac : $editions[0]['image']));
          ?>
          <div class="olp-boxwrap" data-testid="olp-box-showcase">
            <img id="olpBoxImg" src="<?= esc($defImg) ?>" alt="Microsoft Office <?= esc($VER) ?> box" class="olp-box-img" loading="lazy" width="520" height="520">
            <?php if ($hasWin && $hasMac): ?>
            <div class="olp-plat-toggle" role="tablist" aria-label="Choose platform">
              <a href="<?= esc($winUrl) ?>" class="olp-plat-btn<?= $IS_MAC ? '' : ' is-active' ?>" data-testid="olp-plat-windows"><i class="bi bi-windows me-1"></i>Windows</a>
              <a href="<?= esc($macUrl) ?>" class="olp-plat-btn<?= $IS_MAC ? ' is-active' : '' ?>" data-testid="olp-plat-mac"><i class="bi bi-apple me-1"></i>Mac</a>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ======================= WHAT YOU GET ======================= -->
  <section class="olp-section">
    <div class="container">
      <div class="text-center mb-4">
        <h2 class="olp-h2">What You Get with Office <?= esc($VER) ?></h2>
        <p class="olp-lead">Powerful productivity tools designed for modern work.</p>
      </div>
      <?php
        $feats = [
          ['Familiar Apps, One-Time Purchase','Install classic Office apps on your ' . ($IS_MAC ? 'Mac' : 'PC') . ' for a single payment — no recurring fees ever.'],
          ['Faster Multi-Tasking','Work with multiple documents and spreadsheets open simultaneously with improved performance.'],
          ['Enhanced Productivity','New tools and templates help you create better, more polished documents in less time.'],
          ['Focused Inbox & Email','Outlook sorts your most important emails automatically so you never miss what matters.'],
        ];
      ?>
      <div class="row g-3">
        <?php foreach ($feats as $i => $f): ?>
          <div class="col-md-6 col-lg-3">
            <div class="olp-feature">
              <div class="olp-feature-img"><img src="<?= esc($featureImgs[$i] ?? '') ?>" alt="<?= esc($f[0]) ?>" loading="lazy" width="400" height="260"></div>
              <h3 class="olp-feature-title"><?= esc($f[0]) ?></h3>
              <p class="olp-feature-text"><?= esc($f[1]) ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ==================== OFFICE vs MICROSOFT 365 ==================== -->
  <section class="olp-section olp-alt">
    <div class="container">
      <div class="text-center mb-4">
        <h2 class="olp-h2">Office <?= esc($VER) ?> vs Microsoft 365</h2>
        <p class="olp-lead">See why a one-time purchase saves you money.</p>
      </div>
      <div class="table-responsive olp-cmp-wrap">
        <table class="table olp-cmp align-middle mb-0">
          <thead><tr><th></th><th class="olp-cmp-hi">Office <?= esc($VER) ?></th><th>Microsoft 365</th></tr></thead>
          <tbody>
            <tr><td>Payment</td><td class="olp-cmp-hi">One-time</td><td>$99.99/year</td></tr>
            <tr><td>Total cost (3 years)</td><td class="olp-cmp-hi">From <?= format_price($minPrice) ?></td><td><?= format_price(299.97) ?></td></tr>
            <tr><td>Ownership</td><td class="olp-cmp-hi">Own forever</td><td>Subscription</td></tr>
            <tr><td>Updates</td><td class="olp-cmp-hi">Free lifetime</td><td>Included</td></tr>
            <tr><td>Internet required</td><td class="olp-cmp-hi">No</td><td>Yes (periodic)</td></tr>
            <tr><td>Auto-renewal fees</td><td class="olp-cmp-hi">Never</td><td>Annually</td></tr>
          </tbody>
        </table>
      </div>
      <div class="text-center mt-3"><a href="#editions" class="btn btn-orange-solid rounded-pill px-4 fw-bold">Get Office <?= esc($VER) ?> Now</a></div>
    </div>
  </section>

  <!-- ========================= HOW IT WORKS ========================= -->
  <section class="olp-section">
    <div class="container">
      <div class="text-center mb-4">
        <h2 class="olp-h2">How It Works</h2>
        <p class="olp-lead">Get started in 3 simple steps — it takes less than 30 minutes.</p>
      </div>
      <div class="row g-3">
        <?php
          $steps = [
            ['Choose &amp; Buy','Select your edition, complete secure checkout with card or PayPal.'],
            ['Receive Your Key','Your genuine product key arrives in your email inbox within minutes.'],
            ['Download &amp; Activate','Visit setup.office.com, enter your key, download and start working.'],
          ];
          foreach ($steps as $i => $s): ?>
          <div class="col-md-4"><div class="olp-step"><span class="olp-step-n"><?= $i+1 ?></span><h3 class="olp-step-title"><?= $s[0] ?></h3><p class="olp-feature-text"><?= $s[1] ?></p></div></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- =========================== WHY BUY =========================== -->
  <section class="olp-section olp-alt">
    <div class="container">
      <div class="text-center mb-4"><h2 class="olp-h2">Why Buy from <?= esc(brand_name()) ?>?</h2></div>
      <div class="row g-3">
        <?php
          $why = [
            ['bi-patch-check-fill','Original Product Keys','All product keys are original Microsoft product keys backed by a full activation guarantee.'],
            ['bi-shield-fill-check','30-Day Guarantee','If your key does not work, we replace it or give you a full refund. No questions asked.'],
            ['bi-lightning-charge-fill','Instant Delivery','Receive your product key via email in minutes, not days. Available 24/7.'],
            ['bi-headset','Free Support','Our expert team provides free installation and activation support with every purchase.'],
          ];
          foreach ($why as $w): ?>
          <div class="col-md-6 col-lg-3"><div class="olp-why"><i class="bi <?= $w[0] ?>"></i><h3 class="olp-feature-title"><?= esc($w[1]) ?></h3><p class="olp-feature-text"><?= esc($w[2]) ?></p></div></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ============================= FAQ ============================= -->
  <section class="olp-section">
    <div class="container" style="max-width:820px;">
      <div class="text-center mb-4"><h2 class="olp-h2">Frequently Asked Questions</h2></div>
      <div class="accordion olp-faq" id="olpFaq">
        <?php
          $faqs = [
            ['Is this an original Microsoft product key?','Yes. Every product key is an original Microsoft product key sourced through legitimate secondary-market channels and backed by a full activation guarantee. Sold by an independent third-party reseller (not affiliated with Microsoft).'],
            ['How quickly will I receive my product key?','Your key is emailed automatically, usually within 15–30 minutes of a successful order — 24/7.'],
            ['What is the difference between Office ' . $VER . ' and Microsoft 365?','Office ' . $VER . ' is a one-time purchase you own forever with free lifetime updates and no subscription. Microsoft 365 is a recurring annual subscription.'],
            ['Which edition should I choose?', $IS_MAC ? 'On Mac choose Home for Word/Excel/PowerPoint, or Home & Business if you also need Outlook.' : 'Home for Word/Excel/PowerPoint, Home & Business if you also need Outlook, or Professional Plus for all five apps plus Access.'],
            ['What if the license does not activate?','Contact our support team — we will replace the key or issue a full refund within the guarantee period.'],
            ['Do you provide installation support?','Yes, free installation and activation support is included with every purchase.'],
            ['Is there a subscription or recurring fee?','No. This is a one-time purchase — pay once and own it forever, with no recurring fees.'],
            ['What payment methods do you accept?','We accept all major credit/debit cards and PayPal through a secure, encrypted checkout.'],
          ];
          foreach ($faqs as $i => $q):
        ?>
          <div class="accordion-item">
            <h3 class="accordion-header" id="olpFaqH<?= $i ?>">
              <button class="accordion-button collapsed" type="button" data-testid="olp-faq-<?= $i ?>" data-bs-toggle="collapse" data-bs-target="#olpFaqC<?= $i ?>" aria-expanded="false" aria-controls="olpFaqC<?= $i ?>"><?= esc($q[0]) ?></button>
            </h3>
            <div id="olpFaqC<?= $i ?>" class="accordion-collapse collapse" aria-labelledby="olpFaqH<?= $i ?>" data-bs-parent="#olpFaq">
              <div class="accordion-body"><?= esc($q[1]) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ===================== OTHER VERSIONS + CTA ===================== -->
  <section class="olp-section olp-cta">
    <div class="container text-center">
      <h2 class="olp-h2 text-white">Ready to Get Microsoft Office <?= esc($VER) ?>?</h2>
      <p class="olp-lead text-white-50">Join <?= $revCount ?> satisfied customers. Original product key, instant delivery, lifetime access — no subscription ever. Sold by an independent third-party reseller.</p>
      <a href="#editions" class="btn btn-orange-solid btn-lg rounded-pill px-4 fw-bold mb-4"><i class="bi bi-cart-plus me-2"></i>Shop Now — From <?= format_price($minPrice) ?></a>
      <div class="olp-otherver">
        <span class="text-white-50 me-2">Looking for another year?</span>
        <?php foreach ($otherVersions as $ov): ?>
          <a href="/office-<?= $ov ?>-lifetime-license-<?= $IS_MAC ? 'mac' : 'windows' ?>.php" class="olp-verlink" data-testid="olp-link-<?= $ov ?>">Office <?= $ov ?> Lifetime License</a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
</div>

<style>
.office-lp{--olp-orange:#f97316;--olp-ink:#0f172a;}
.office-lp .olp-hero{padding:2.4rem 0 1.2rem;background:linear-gradient(180deg,rgba(249,115,22,.06),transparent);}
.office-lp .olp-brand-badge{display:inline-flex;align-items:center;background:#0f172a;color:#fff;font-weight:700;font-size:.8rem;padding:.3rem .7rem;border-radius:999px;}
.office-lp .olp-pill{display:inline-flex;align-items:center;background:rgba(16,185,129,.12);color:#059669;font-weight:700;font-size:.78rem;padding:.3rem .7rem;border-radius:999px;}
.office-lp .olp-title{font-size:2.6rem;font-weight:800;line-height:1.05;margin:.2rem 0 .1rem;}
.office-lp .olp-subtitle{font-size:1.05rem;color:#64748b;font-weight:600;margin-bottom:1rem;}
.office-lp .olp-retail{color:#94a3b8;text-decoration:line-through;font-size:.95rem;}
.office-lp .olp-price{font-size:2rem;font-weight:800;color:var(--olp-orange);line-height:1;}
.office-lp .olp-save{background:#fee2e2;color:#dc2626;font-weight:800;font-size:.85rem;padding:.35rem .7rem;border-radius:8px;}
.office-lp .olp-trust-row{display:flex;flex-wrap:wrap;gap:.4rem 1.2rem;margin:.6rem 0;}
.office-lp .olp-trust-row li{font-size:.86rem;font-weight:600;color:#334155;}
.office-lp .olp-trust-row i{color:#059669;margin-right:.25rem;}
.office-lp .olp-rating{font-weight:700;color:#334155;font-size:.9rem;}
.office-lp .olp-stars{color:#f59e0b;letter-spacing:1px;}
.office-lp .olp-hero-media{background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:1.2rem;box-shadow:0 18px 40px -24px rgba(2,6,23,.35);text-align:center;}
.office-lp .olp-hero-img{max-width:100%;height:auto;max-height:340px;object-fit:contain;}
.office-lp .olp-thumbs{display:flex;gap:.5rem;justify-content:center;margin-top:.9rem;flex-wrap:wrap;}
.office-lp .olp-thumb{border:2px solid #e2e8f0;background:#fff;border-radius:10px;padding:.25rem;cursor:pointer;transition:.15s;}
.office-lp .olp-thumb.active,.office-lp .olp-thumb:hover{border-color:var(--olp-orange);}
.office-lp .olp-thumb img{width:64px;height:52px;object-fit:contain;}
.office-lp .olp-countdown{margin-top:.9rem;text-align:center;font-size:.92rem;color:#334155;}
.office-lp .olp-cd{font-variant-numeric:tabular-nums;font-weight:800;background:#0f172a;color:#fff;padding:.25rem .6rem;border-radius:8px;letter-spacing:1px;}
.office-lp .olp-stats{margin-top:1.4rem;}
.office-lp .olp-stat{text-align:center;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:.9rem .5rem;}
.office-lp .olp-stat-n{font-size:1.35rem;font-weight:800;color:var(--olp-orange);}
.office-lp .olp-stat-l{font-size:.78rem;color:#64748b;font-weight:600;}
.office-lp .olp-section{padding:2.6rem 0;}
.office-lp .olp-alt{background:#f8fafc;}
.office-lp .olp-eyebrow{display:inline-block;background:rgba(249,115,22,.12);color:var(--olp-orange);font-weight:800;font-size:.72rem;letter-spacing:1.4px;text-transform:uppercase;padding:.3rem .7rem;border-radius:999px;margin-bottom:.5rem;}
.office-lp .olp-h2{font-size:1.9rem;font-weight:800;}
.office-lp .olp-lead{color:#64748b;max-width:720px;margin:.4rem auto 0;}
.office-lp .olp-edition{position:relative;background:#fff;border:2px solid #e2e8f0;border-radius:16px;padding:1.4rem 1.2rem 1.2rem;height:100%;transition:.18s;text-align:center;}
.office-lp .olp-edition:hover{box-shadow:0 16px 34px -22px rgba(2,6,23,.4);transform:translateY(-3px);}
.office-lp .olp-edition.selected{border-color:var(--olp-orange);box-shadow:0 0 0 3px rgba(249,115,22,.15);}
.office-lp .olp-edition-badge{position:absolute;top:-11px;left:50%;transform:translateX(-50%);background:var(--olp-orange);color:#fff;font-weight:800;font-size:.7rem;letter-spacing:.5px;padding:.25rem .7rem;border-radius:999px;white-space:nowrap;}
.office-lp .olp-edition-imgwrap{height:130px;display:flex;align-items:center;justify-content:center;margin-bottom:.6rem;}
.office-lp .olp-edition-imgwrap img{max-height:130px;max-width:100%;object-fit:contain;}
.office-lp .olp-edition-name{font-size:1.25rem;font-weight:800;margin-bottom:.15rem;}
.office-lp .olp-edition-tag{color:#64748b;font-size:.85rem;}
.office-lp .olp-edition-apps{font-size:.8rem;color:#334155;font-weight:600;margin:.3rem 0 .6rem;}
.office-lp .olp-edition-msrp{color:#94a3b8;text-decoration:line-through;margin-right:.4rem;}
.office-lp .olp-edition-price{font-size:1.7rem;font-weight:800;color:var(--olp-ink);}
.office-lp .olp-edition-save{color:#059669;font-weight:700;font-size:.8rem;margin:.2rem 0 .6rem;}
.office-lp .olp-edition-list{text-align:left;margin:.7rem 0;font-size:.83rem;}
.office-lp .olp-edition-list li{margin-bottom:.28rem;color:#334155;}
.office-lp .olp-edition-list i{color:#059669;margin-right:.3rem;}
.office-lp .olp-edition-secure{font-size:.72rem;color:#94a3b8;margin-top:.5rem;}
.office-lp .olp-mini{display:flex;gap:.6rem;align-items:flex-start;}
.office-lp .olp-mini i{color:var(--olp-orange);font-size:1.2rem;margin-top:.1rem;}
.office-lp .olp-mini strong{display:block;font-size:.9rem;}
.office-lp .olp-mini span{font-size:.8rem;color:#64748b;}
.office-lp .olp-round-img{max-width:100%;height:auto;border-radius:18px;box-shadow:0 18px 40px -24px rgba(2,6,23,.4);}
.office-lp .olp-feature,.office-lp .olp-why,.office-lp .olp-step{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.1rem;height:100%;}
.office-lp .olp-feature-img{border-radius:10px;overflow:hidden;margin-bottom:.7rem;aspect-ratio:16/10;}
.office-lp .olp-feature-img img{width:100%;height:100%;object-fit:cover;}
.office-lp .olp-feature-title{font-size:1.02rem;font-weight:800;margin-bottom:.3rem;}
.office-lp .olp-feature-text{color:#64748b;font-size:.85rem;margin:0;}
.office-lp .olp-why{text-align:center;}
.office-lp .olp-why i{font-size:1.7rem;color:var(--olp-orange);}
.office-lp .olp-step{text-align:center;}
.office-lp .olp-step-n{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;background:var(--olp-orange);color:#fff;font-weight:800;font-size:1.1rem;margin-bottom:.5rem;}
.office-lp .olp-cmp-wrap{background:#fff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;}
.office-lp .olp-cmp th,.office-lp .olp-cmp td{padding:.8rem 1rem;font-size:.9rem;}
.office-lp .olp-cmp thead th{background:#0f172a;color:#fff;font-weight:700;}
.office-lp .olp-cmp .olp-cmp-hi{background:rgba(249,115,22,.06);font-weight:700;color:var(--olp-ink);}
.office-lp .olp-faq .accordion-button{font-weight:700;font-size:.95rem;}
.office-lp .olp-faq .accordion-button:not(.collapsed){color:var(--olp-orange);background:rgba(249,115,22,.06);box-shadow:none;}
.office-lp .olp-cta{background:linear-gradient(135deg,#1e293b,#0f172a);}
.office-lp .olp-otherver{margin-top:.6rem;display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap;align-items:center;}
.office-lp .olp-verlink{color:#fff;font-weight:700;text-decoration:underline;text-underline-offset:3px;}
.office-lp .olp-verlink:hover{color:var(--olp-orange);}
[data-bs-theme="dark"] .office-lp .olp-hero-media,[data-bs-theme="dark"] .office-lp .olp-edition,[data-bs-theme="dark"] .office-lp .olp-feature,[data-bs-theme="dark"] .office-lp .olp-why,[data-bs-theme="dark"] .office-lp .olp-step,[data-bs-theme="dark"] .office-lp .olp-stat,[data-bs-theme="dark"] .office-lp .olp-cmp-wrap{background:#111827;border-color:#1f2937;}
[data-bs-theme="dark"] .office-lp .olp-alt{background:#0b1220;}
[data-bs-theme="dark"] .office-lp .olp-title,[data-bs-theme="dark"] .office-lp .olp-h2,[data-bs-theme="dark"] .office-lp .olp-edition-name,[data-bs-theme="dark"] .office-lp .olp-edition-price,[data-bs-theme="dark"] .office-lp .olp-feature-title{color:#e2e8f0;}
@media(max-width:576px){.office-lp .olp-title{font-size:2rem;}}
/* One-License showcase box + platform toggle */
.office-lp .olp-boxwrap{display:flex;flex-direction:column;align-items:center;gap:1rem;}
.office-lp .olp-box-img{max-width:100%;width:auto;max-height:420px;object-fit:contain;filter:drop-shadow(0 26px 44px rgba(2,6,23,.20));transition:opacity .18s ease, transform .35s ease;animation:olpBoxIn .6s ease both;}
.office-lp .olp-box-img:hover{transform:translateY(-6px) scale(1.015);}
@keyframes olpBoxIn{from{opacity:0;transform:translateY(14px) scale(.97);}to{opacity:1;transform:none;}}
.office-lp .olp-plat-toggle{display:inline-flex;background:#eef2f7;border:1px solid #e2e8f0;border-radius:999px;padding:.28rem;gap:.28rem;box-shadow:inset 0 1px 2px rgba(2,6,23,.06);}
.office-lp .olp-plat-btn{border:0;background:transparent;color:#475569;font-weight:700;font-size:.92rem;padding:.5rem 1.25rem;border-radius:999px;cursor:pointer;display:inline-flex;align-items:center;transition:background .2s ease,color .2s ease,box-shadow .2s ease,transform .12s ease;}
.office-lp .olp-plat-btn:hover{color:#0f172a;}
.office-lp .olp-plat-btn:active{transform:scale(.97);}
.office-lp .olp-plat-btn.is-active{background:#fff;color:var(--olp-orange);box-shadow:0 4px 12px -4px rgba(2,6,23,.25);}
[data-bs-theme="dark"] .office-lp .olp-plat-toggle{background:#0b1220;border-color:#1f2937;}
[data-bs-theme="dark"] .office-lp .olp-plat-btn{color:#94a3b8;}
[data-bs-theme="dark"] .office-lp .olp-plat-btn.is-active{background:#111827;color:#fb923c;}
/* Cross-year version switch bar */
.office-lp .olp-verswitch{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .75rem;margin:0 0 1rem;}
.office-lp .olp-verswitch-label{font-size:.9rem;color:#64748b;font-weight:600;}
.office-lp .olp-verswitch-btns{display:inline-flex;flex-wrap:wrap;gap:.4rem;align-items:center;}
.office-lp .olp-ver-current{display:inline-flex;align-items:center;font-weight:800;font-size:.9rem;color:#0f172a;background:#eef2f7;border:1px solid #e2e8f0;border-radius:999px;padding:.35rem .9rem;}
.office-lp .olp-ver-link{display:inline-flex;align-items:center;font-weight:700;font-size:.9rem;color:var(--olp-orange);background:#fff;border:1.5px solid var(--olp-orange);border-radius:999px;padding:.35rem .9rem;text-decoration:none;transition:background .18s ease,color .18s ease,transform .12s ease;}
.office-lp .olp-ver-link:hover{background:var(--olp-orange);color:#fff;transform:translateY(-1px);}
[data-bs-theme="dark"] .office-lp .olp-ver-current{background:#0b1220;border-color:#1f2937;color:#e2e8f0;}
[data-bs-theme="dark"] .office-lp .olp-ver-link{background:transparent;}
/* Dark-mode fixes: keep the SELECTED edition highlight + readable SAVE badge */
[data-bs-theme="dark"] .office-lp .olp-edition.selected{border-color:var(--olp-orange) !important;box-shadow:0 0 0 3px rgba(249,115,22,.45) !important;}
[data-bs-theme="dark"] .office-lp .olp-save{background:#7c2d12;color:#ffedd5;}
/* Hero Windows/Mac platform switch (links to the other platform's page) */
.office-lp .olp-platswitch{display:inline-flex;background:#eef2f7;border:1px solid #e2e8f0;border-radius:999px;padding:.28rem;gap:.28rem;margin:0 0 1rem;}
.office-lp .olp-platswitch-btn{border:0;background:transparent;color:#475569;font-weight:700;font-size:.9rem;padding:.45rem 1.15rem;border-radius:999px;text-decoration:none;display:inline-flex;align-items:center;transition:background .2s ease,color .2s ease,box-shadow .2s ease;}
.office-lp .olp-platswitch-btn:hover{color:#0f172a;}
.office-lp .olp-platswitch-btn.is-active{background:#fff;color:var(--olp-orange);box-shadow:0 4px 12px -4px rgba(2,6,23,.25);}
[data-bs-theme="dark"] .office-lp .olp-platswitch{background:#0b1220;border-color:#1f2937;}
[data-bs-theme="dark"] .office-lp .olp-platswitch-btn{color:#94a3b8;}
[data-bs-theme="dark"] .office-lp .olp-platswitch-btn.is-active{background:#111827;color:#fb923c;}
/* Anchor-based pills: beat the global <a> link colour in both themes. */
.office-lp .olp-platswitch-btn{color:#475569 !important;}
.office-lp .olp-platswitch-btn.is-active{color:var(--olp-orange) !important;}
.office-lp .olp-ver-link{color:var(--olp-orange) !important;}
.office-lp .olp-ver-link:hover{color:#fff !important;}
[data-bs-theme="dark"] .office-lp .olp-platswitch-btn{color:#94a3b8 !important;}
[data-bs-theme="dark"] .office-lp .olp-platswitch-btn.is-active{color:#fb923c !important;}
[data-bs-theme="dark"] .office-lp .olp-ver-link{color:#fb923c !important;}
</style>

<script>
(function(){
  // Hero thumbnails and edition cards are kept in sync by product slug, so
  // clicking a thumbnail highlights the MATCHING edition card below (and vice
  // versa) and swaps the hero image.
  var hero = document.getElementById('olpHeroImg');

  function syncTo(slug, img, label){
    document.querySelectorAll('.office-lp .olp-thumb').forEach(function(t){
      t.classList.toggle('active', t.getAttribute('data-slug') === slug);
    });
    document.querySelectorAll('.office-lp .olp-edition').forEach(function(c){
      var on = c.getAttribute('data-slug') === slug;
      c.classList.toggle('selected', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    if(hero && img){ hero.src = img; if(label) hero.alt = label; }
  }

  document.querySelectorAll('.office-lp .olp-thumb').forEach(function(t){
    t.addEventListener('click', function(){
      syncTo(t.getAttribute('data-slug'), t.getAttribute('data-img'), t.getAttribute('data-label'));
    });
  });

  function selectEdition(card){
    syncTo(card.getAttribute('data-slug'), card.getAttribute('data-img'), null);
  }
  document.querySelectorAll('.office-lp .olp-edition').forEach(function(card){
    card.addEventListener('click', function(e){
      if(e.target.closest('.buy-now-btn')) return; // let Buy Now do its thing
      selectEdition(card);
    });
    card.addEventListener('keydown', function(e){
      if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); selectEdition(card); }
    });
  });

  // Countdown timer — always resets to end of the current day.
  var cd = document.getElementById('olpCd');
  if(cd){
    function tick(){
      var now = new Date();
      var end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
      var s = Math.max(0, Math.floor((end - now)/1000));
      var h = String(Math.floor(s/3600)).padStart(2,'0');
      var m = String(Math.floor((s%3600)/60)).padStart(2,'0');
      var ss = String(s%60).padStart(2,'0');
      cd.textContent = h+':'+m+':'+ss;
    }
    tick(); setInterval(tick, 1000);
  }
})();
</script>

<?php include __DIR__ . '/footer.php'; ?>
