<?php
// Traffic-driven scheduler ("no cron job needed"). The first page view after
// the interval claims a slot and runs the due background jobs AFTER the
// response has been handed to the visitor, so follow-up emails, newsletters
// and the SMTP queue keep flowing on shared hosting (Namecheap / cPanel /
// LiteSpeed) even when no cPanel cron was ever configured. cron.php still
// works (and is faster) when set up — both paths use the same workers.
require_once __DIR__ . '/functions.php';

const MV_AUTOCRON_INTERVAL = 300; // seconds between ticks

function mv_autocron_arm(): void
{
    static $armed = false;
    if ($armed || PHP_SAPI === 'cli' || defined('MV_NO_AUTOCRON')) return;
    $armed = true;
    // Polls (heartbeat, chat, notifications) must stay instant: on hosts that
    // cannot hand the response back first (no FPM/LiteSpeed), only real page
    // views may run the inline tick.
    $isPoll = isset($_GET['ajax']) || strpos((string)($_SERVER['SCRIPT_NAME'] ?? ''), '/ajax/') !== false;
    $canDetach = function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');
    if ($isPoll && !$canDetach) return;
    try {
        $pdo = db();
        $now = time();
        $cur = $pdo->query("SELECT v FROM settings WHERE k='autocron_next' LIMIT 1")->fetchColumn();
        if ($cur === false) { $pdo->exec("INSERT IGNORE INTO settings (k, v) VALUES ('autocron_next', '0')"); $cur = '0'; }
        if ((int)$cur > $now) return;
        // Atomic claim — only one concurrent request wins this slot.
        $st = $pdo->prepare("UPDATE settings SET v=? WHERE k='autocron_next' AND v=?");
        $st->execute([(string)($now + MV_AUTOCRON_INTERVAL), (string)$cur]);
        if ($st->rowCount() !== 1) return;
    } catch (Throwable $e) { return; }
    register_shutdown_function('mv_autocron_run');
}

/** Runs the due jobs. Called at shutdown by mv_autocron_arm() or directly by cron.php. */
function mv_autocron_run(bool $fromCron = false): array
{
    @ignore_user_abort(true);
    @set_time_limit(120);
    $detached = $fromCron;
    if (!$fromCron) {
        while (ob_get_level() > 0) { @ob_end_flush(); }
        @flush();
        if (function_exists('fastcgi_finish_request'))       { @fastcgi_finish_request();   $detached = true; }
        elseif (function_exists('litespeed_finish_request')) { @litespeed_finish_request(); $detached = true; }
    }
    // Without a way to detach we are still holding the visitor's connection:
    // keep it short. Detached (LiteSpeed / FPM / cron) we can work for a while.
    $budget = $detached ? 60 : 8;
    $t0  = microtime(true);
    $log = ['at' => date('Y-m-d H:i:s'), 'mode' => $detached ? ($fromCron ? 'cron' : 'background') : 'inline'];

    try {
        require_once __DIR__ . '/followup-emails.php';
        $log['followups_queued'] = send_pending_followups($detached ? 25 : 5);
    } catch (Throwable $e) { $log['followups_queued'] = 'ERR ' . $e->getMessage(); }

    try {
        require_once __DIR__ . '/mailer.php';
        $sent = 0;
        do {
            $n = smtp_process_queue($detached ? 10 : 3);
            $sent += $n;
        } while ($detached && $n > 0 && (microtime(true) - $t0) < $budget);
        $log['emails_sent'] = $sent;
    } catch (Throwable $e) { $log['emails_sent'] = 'ERR ' . $e->getMessage(); }

    if ($detached && (microtime(true) - $t0) < $budget) {
        try { require_once __DIR__ . '/chat-relay.php'; $log['chat_relay'] = chat_relay_sweep(10); } catch (Throwable $e) {}
    }
    $log['ms'] = (int)((microtime(true) - $t0) * 1000);
    try {
        setting_set('autocron_last_run', $log['at']);
        setting_set('autocron_last_log', json_encode($log));
    } catch (Throwable $e) {}
    return $log;
}

/** Status facts for the admin "Automatic sending" card. */
function mv_autocron_status(): array
{
    $s = ['last_run' => setting_get('autocron_last_run', ''), 'log' => json_decode(setting_get('autocron_last_log', '{}'), true) ?: [],
          'queued' => 0, 'followups_pending' => 0, 'followups_sent' => 0, 'next_followup' => null, 'cron_seen' => setting_get('cron_last_hit', '')];
    try {
        $pdo = db();
        $s['queued'] = (int)$pdo->query("SELECT COUNT(*) FROM email_outbox WHERE status='queued'")->fetchColumn();
        $s['followups_pending'] = (int)$pdo->query("SELECT COUNT(*) FROM email_followup_schedule WHERE status='pending'")->fetchColumn();
        $s['followups_sent'] = (int)$pdo->query("SELECT COUNT(*) FROM email_followup_schedule WHERE status='sent'")->fetchColumn();
        $s['next_followup'] = $pdo->query("SELECT MIN(scheduled_at) FROM email_followup_schedule WHERE status='pending'")->fetchColumn() ?: null;
    } catch (Throwable $e) {}
    return $s;
}
