<?php
/**
 * Maventech SMTP mailer — wraps vendored PHPMailer with:
 *  • settings-driven SMTP config (host/port/user/pass/encryption/from)
 *  • retry-aware queue persistence in `email_outbox`
 *  • plain-text fallback auto-generated from HTML
 *  • proper deliverability headers (Message-ID, Date, Reply-To, Return-Path, List-Unsubscribe)
 *  • per-minute rate limiting
 *  • obfuscated SMTP password at rest (base64; not a real secret — host already protects)
 *
 * Public API:
 *   smtp_config()                       -> array  full SMTP config from settings
 *   smtp_set_config($arr)               -> void   save SMTP config back
 *   smtp_test_connection($to = null)    -> array  ['ok'=>bool, 'message'=>str, 'log'=>str]
 *   smtp_send($to,$subject,$html, ...)  -> array  ['ok'=>bool, 'id'=>int, 'error'=>?str]
 *   smtp_queue_email($to,$subject,$html,$opts=[]) -> int    queue row id
 *   smtp_process_queue($maxBatch = 5)   -> int    rows processed
 *   smtp_mark_bounce($trackingToken)    -> void   helper for inbound bounce webhooks
 *   html_to_plain($html)                -> string
 */
require_once __DIR__ . '/../lib/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/SMTP.php';
require_once __DIR__ . '/../lib/PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as MailerException;

/* ------------------------------------------------------------------------- */
/* Bootstrap: self-heal the email_outbox columns we rely on. Same pattern as
   regions_bootstrap() — protects against shared-hosting users running on an
   older database.sql import.                                                */
/* ------------------------------------------------------------------------- */
function mailer_bootstrap(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    // Persisted guard: run the email_outbox column/index DDL once per deploy
    // instead of on every mailer call (part of the admin-freeze fix).
    try { if (function_exists('setting_get') && setting_get('mailer_schema_v', '') === '1') return; } catch (Throwable $e) {}
    try {
        $pdo = db();
        // Ensure the columns required for retry / status tracking exist.
        $needed = [
            'retry_count'         => 'INT NOT NULL DEFAULT 0',
            'max_retries'         => 'INT NOT NULL DEFAULT 3',
            'next_retry_at'       => 'TIMESTAMP NULL DEFAULT NULL',
            'error_details'       => 'TEXT NULL DEFAULT NULL',
            'last_error'          => 'VARCHAR(255) NULL DEFAULT NULL',
            'message_id'          => 'VARCHAR(190) NULL DEFAULT NULL',
            'bounced_at'          => 'TIMESTAMP NULL DEFAULT NULL',
            'priority'            => "TINYINT NOT NULL DEFAULT 5", // 1=highest, 9=lowest
            // Bug fix 2026-07-17d: track when we've notified admin about a failed/bounced
            // customer email so we never send a duplicate admin bounce notice.
            'bounce_notified_at'  => 'TIMESTAMP NULL DEFAULT NULL',
            // Capture the gateway mode (test/live) at queue time so Email Activity
            // can be filtered by test vs live purchases even after settings change.
            'gw_mode'             => "VARCHAR(10) NULL DEFAULT NULL",
            // Per-email sender override: surface the CUSTOMER's name as the
            // email sender + route replies to them, so admin notifications
            // (sales, subscriptions, chat, leads, contact) show who wrote in.
            'sender_name'         => "VARCHAR(190) NULL DEFAULT NULL",
            'reply_to_addr'       => "VARCHAR(190) NULL DEFAULT NULL",
        ];
        $tableExists = (int)$pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='email_outbox'")->fetchColumn();
        if (!$tableExists) return;
        foreach ($needed as $col => $def) {
            $st = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='email_outbox' AND COLUMN_NAME = ?");
            $st->execute([$col]);
            if (!(int)$st->fetchColumn()) {
                try { $pdo->exec("ALTER TABLE email_outbox ADD COLUMN `$col` $def"); } catch (Throwable $e) { /* ignore */ }
            }
        }
        try { $pdo->exec("CREATE INDEX idx_outbox_status_retry ON email_outbox (status, next_retry_at)"); } catch (Throwable $e) {}
        if (function_exists('setting_set')) { try { setting_set('mailer_schema_v', '1'); } catch (Throwable $e) {} }
    } catch (Throwable $e) { /* silent */ }
}

/* ------------------------------------------------------------------------- */
/* Config                                                                    */
/* ------------------------------------------------------------------------- */
function smtp_config(): array {
    mailer_bootstrap();
    $rawPwd = setting_get('smtp_password_b64', '');
    return [
        'enabled'       => (int)setting_get('smtp_enabled', '0') === 1,
        'host'          => setting_get('smtp_host', ''),
        'port'          => (int)setting_get('smtp_port', '587') ?: 587,
        'username'      => setting_get('smtp_username', ''),
        'password'      => $rawPwd !== '' ? (base64_decode($rawPwd, true) ?: '') : '',
        'encryption'    => setting_get('smtp_encryption', 'tls'),   // tls | ssl | none
        'from_email'    => setting_get('smtp_from_email', setting_get('company_email', '')),
        'from_name'     => setting_get('smtp_from_name',  setting_get('company_name',  '')),
        'reply_to'      => setting_get('smtp_reply_to', setting_get('company_email', '')),
        // Global CC — a copy of every outgoing email is also sent here. Blank
        // means "use the From address" (resolved at send time in _smtp_prepare).
        'cc'            => setting_get('smtp_cc', ''),
        'max_retries'   => (int)setting_get('smtp_max_retries', '3') ?: 3,
        'rate_per_min'  => (int)setting_get('smtp_rate_per_min', '60') ?: 60,
        // Provider daily cap (free Gmail = 500, Workspace = 2000). We stop
        // non-essential mail at 80 % so order/license emails keep room.
        'daily_cap'     => (int)setting_get('smtp_daily_cap', '450') ?: 450,
        'verify_peer'   => (int)setting_get('smtp_verify_peer', '1') === 1,
        'debug_level'   => (int)setting_get('smtp_debug', '0'),
    ];
}

function smtp_set_config(array $in): void {
    mailer_bootstrap();
    $map = [
        'enabled'      => fn($v) => setting_set('smtp_enabled',     $v ? '1' : '0'),
        'host'         => fn($v) => setting_set('smtp_host',        trim((string)$v)),
        'port'         => fn($v) => setting_set('smtp_port',        (string)(int)$v),
        'username'     => fn($v) => setting_set('smtp_username',    trim((string)$v)),
        'password'     => function ($v) {
            // Normalise the password.  Two common paste-pitfalls we clean here:
            //
            //   1. Gmail App Passwords are displayed as 4x4 groups
            //      ("abcd efgh ijkl mnop"). Users copy the whole block —
            //      Google's docs say the spaces are ignored, so we strip
            //      them here rather than confusing the admin with an
            //      auth-fail on a superficially-correct password.
            //
            //   2. Trailing / leading whitespace or an accidental newline
            //      from a copy-paste. Same fix as (1).
            //
            //   Passwords that legitimately contain internal spaces are
            //   rare, and no mainstream provider (Gmail, O365, SendGrid,
            //   SES, cPanel Mailboxes) uses one. We keep the ORIGINAL
            //   password when normalisation would leave it identical, so
            //   we never silently mutate a valid credential.
            $orig = (string)$v;
            $norm = trim($orig);
            // Only strip inner spaces on Gmail-App-Password-shaped inputs
            // (16 hex-ish chars in 4x4 groups).  Anything else keeps its
            // internal spaces intact so we don't break real passwords.
            if (preg_match('/^[A-Za-z0-9]{4}[ \t]+[A-Za-z0-9]{4}[ \t]+[A-Za-z0-9]{4}[ \t]+[A-Za-z0-9]{4}$/', $norm)) {
                $norm = preg_replace('/\s+/', '', $norm);
            }
            setting_set('smtp_password_b64', $norm === '' ? '' : base64_encode($norm));
        },
        'encryption'   => fn($v) => setting_set('smtp_encryption',  in_array($v,['tls','ssl','none'],true) ? $v : 'tls'),
        'from_email'   => fn($v) => setting_set('smtp_from_email',  trim((string)$v)),
        'from_name'    => fn($v) => setting_set('smtp_from_name',   trim((string)$v)),
        'reply_to'     => fn($v) => setting_set('smtp_reply_to',    trim((string)$v)),
        // Global CC address(es). Comma/semicolon separated allowed; blank =
        // fall back to the From address at send time. Control chars stripped
        // to defend against header injection.
        'cc'           => fn($v) => setting_set('smtp_cc',          preg_replace('/[\r\n\t]+/', '', trim((string)$v))),
        'max_retries'  => fn($v) => setting_set('smtp_max_retries', (string)max(0, min(10, (int)$v))),
        'rate_per_min' => fn($v) => setting_set('smtp_rate_per_min',(string)max(1, min(2000, (int)$v))),
        'daily_cap'    => fn($v) => setting_set('smtp_daily_cap',   (string)max(20, min(100000, (int)$v))),
        'verify_peer'  => fn($v) => setting_set('smtp_verify_peer', $v ? '1' : '0'),
        'debug_level'  => fn($v) => setting_set('smtp_debug',       (string)max(0, min(4, (int)$v))),
    ];
    foreach ($in as $k => $v) if (isset($map[$k])) $map[$k]($v);
}

/* ------------------------------------------------------------------------- */
/* Build a configured PHPMailer instance                                     */
/* ------------------------------------------------------------------------- */
function _smtp_make(): PHPMailer {
    $c = smtp_config();
    $m = new PHPMailer(true);          // throw exceptions
    $m->isSMTP();
    $m->Host          = $c['host'];
    $m->Port          = $c['port'];
    $m->SMTPAuth      = $c['username'] !== '';
    $m->Username      = $c['username'];
    $m->Password      = $c['password'];
    $m->Timeout       = 25;
    $m->CharSet       = PHPMailer::CHARSET_UTF8;
    $m->Encoding      = PHPMailer::ENCODING_BASE64;
    $m->XMailer       = (function_exists('company_info') ? (string)(company_info()['name'] ?? 'Store') : 'Store') . ' Admin';

    if ($c['encryption'] === 'ssl') {
        $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            // implicit TLS, usually port 465
    } elseif ($c['encryption'] === 'tls') {
        $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // STARTTLS, usually port 587
    } else {
        $m->SMTPSecure = false;
        $m->SMTPAutoTLS = false;
    }

    if (!$c['verify_peer']) {
        $m->SMTPOptions = ['ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ]];
    }

    if ($c['debug_level'] > 0) {
        $m->SMTPDebug = $c['debug_level'];
        $m->Debugoutput = function($str, $level){ /* captured via output buffer */ echo "[smtp:$level] $str\n"; };
    }

    if ($c['from_email'] !== '') {
        $m->setFrom($c['from_email'], $c['from_name'] !== '' ? $c['from_name'] : $c['from_email']);
    }
    if ($c['reply_to'] !== '') {
        $m->addReplyTo($c['reply_to']);
    }
    return $m;
}

/* ------------------------------------------------------------------------- */
/* Convert HTML body → plain-text fallback                                   */
/* ------------------------------------------------------------------------- */
function html_to_plain(string $html): string {
    // Strip head/style/script blocks
    $h = preg_replace('#<(head|style|script)[^>]*>.*?</\\1>#is', '', $html);
    // Convert anchors to "text (url)"
    $h = preg_replace_callback('#<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>#is', function($m){
        $url = trim($m[1]); $txt = trim(strip_tags($m[2]));
        return $txt && $txt !== $url ? "$txt ($url)" : $url;
    }, $h);
    // Block elements → newline
    $h = preg_replace('#</(p|div|tr|li|h1|h2|h3|h4|h5|h6|br)\\s*>#i', "\n", $h);
    $h = preg_replace('#<br\\s*/?>#i', "\n", $h);
    $h = strip_tags($h);
    $h = html_entity_decode($h, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    // Collapse whitespace
    $h = preg_replace("/[\r]+/", '', $h);
    $h = preg_replace("/[ \\t]+/", ' ', $h);
    $h = preg_replace("/\\n{3,}/", "\n\n", $h);
    return trim($h);
}

/* ------------------------------------------------------------------------- */
/* Inline every first-party image as a CID attachment                        */
/* ------------------------------------------------------------------------- */
/**
 * Rewrites <img src="…"> that point at OUR OWN static assets/uploads into
 * embedded (cid:) attachments, so the images render in every mail client
 * regardless of whether the public domain is live/reachable. This is the
 * root-cause fix for "broken logo/product images" in transactional emails:
 * previously images were absolute URLs to the production host, which shows
 * a broken icon whenever that host isn't serving the file yet (fresh deploy,
 * preview environment, CDN hiccup, or an image blocked by the client).
 *
 * External images (e.g. setup.office.com), the 1x1 open-tracking pixel, and
 * data:/cid: URIs are left untouched.
 */
function mv_embed_inline_images(PHPMailer $m, string $html): string {
    $webroot = dirname(__DIR__); // /app
    $extMime = [
        'gif' => 'image/gif', 'png' => 'image/png', 'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'svg' => 'image/svg+xml',
    ];
    $cids = [];
    return (string)preg_replace_callback(
        '/(<img\b[^>]*?\bsrc\s*=\s*(["\']))(.*?)\2/is',
        function ($mm) use ($m, $webroot, $extMime, &$cids) {
            $quote = $mm[2];
            $src = trim($mm[3]);
            if ($src === '' || preg_match('#^(data|cid):#i', $src)) return $mm[0];
            // Never inline the open-tracking pixel — it must hit the server.
            if (stripos($src, 'track-open.php') !== false) return $mm[0];
            // Extract the path component (works for absolute + root-relative).
            $path = preg_match('#^(https?:)?//#i', $src)
                ? (string)parse_url($src, PHP_URL_PATH)
                : $src;
            $path = urldecode((string)$path);
            // Only ever embed OUR OWN static files (skips external hosts).
            if (!preg_match('#^/(assets|uploads)/#', $path)) return $mm[0];
            $fs = $webroot . $path;
            if (!is_file($fs)) return $mm[0];
            $ext = strtolower(pathinfo($fs, PATHINFO_EXTENSION));
            if (!isset($extMime[$ext])) return $mm[0];
            $key = md5($fs);
            if (!isset($cids[$key])) {
                $cid = 'img' . substr($key, 0, 12) . '@maventech';
                // Email-client compatibility: Outlook desktop and older Apple
                // Mail cannot decode WebP. Convert WebP -> JPEG (white matte
                // for any alpha) into a temp file so the inline image renders
                // everywhere. Other formats (gif/png/jpg) are embedded as-is.
                $embedPath = $fs;
                $embedMime = $extMime[$ext];
                $embedName = basename($fs);
                if ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
                    try {
                        $im = @imagecreatefromwebp($fs);
                        if ($im !== false) {
                            $w = imagesx($im); $h = imagesy($im);
                            $canvas = imagecreatetruecolor($w, $h);
                            $white = imagecolorallocate($canvas, 255, 255, 255);
                            imagefilledrectangle($canvas, 0, 0, $w, $h, $white);
                            imagecopy($canvas, $im, 0, 0, 0, 0, $w, $h);
                            $tmp = tempnam(sys_get_temp_dir(), 'mvimg') . '.jpg';
                            if (imagejpeg($canvas, $tmp, 85)) {
                                $embedPath = $tmp;
                                $embedMime = 'image/jpeg';
                                $embedName = preg_replace('/\.webp$/i', '.jpg', basename($fs));
                            }
                            imagedestroy($canvas);
                            imagedestroy($im);
                        }
                    } catch (Throwable $e) { /* fall back to raw webp */ }
                }
                try {
                    $m->addEmbeddedImage($embedPath, $cid, $embedName, PHPMailer::ENCODING_BASE64, $embedMime);
                    $cids[$key] = $cid;
                } catch (Throwable $e) {
                    @error_log('[mailer embed] ' . $e->getMessage());
                    return $mm[0];
                }
            }
            return $mm[1] . 'cid:' . $cids[$key] . $quote;
        },
        $html
    );
}


/* ------------------------------------------------------------------------- */
/* Apply deliverability headers + body to a PHPMailer instance               */
/* ------------------------------------------------------------------------- */
/**
 * Is this address one of the store's OWN inboxes — the SMTP account (From /
 * username) or the company notification address? Mail to these is what the
 * "CC Email" setting mirrors.
 */
/** Canonical mailbox for comparisons: lower-case, and the "+tag" sub-address
 *  removed — ops+sales@x.com, ops+failedpayment@x.com and ops@x.com are the SAME
 *  inbox (admin alerts are tagged this way so Gmail can filter them). */
function smtp_norm_addr(string $address): string {
    $a = strtolower(trim($address));
    if ($a === '' || strpos($a, '@') === false) return $a;
    [$local, $domain] = explode('@', $a, 2);
    $plus = strpos($local, '+');
    if ($plus !== false) $local = substr($local, 0, $plus);
    return $local . '@' . $domain;
}

function smtp_is_own_inbox(string $address): bool {
    $a = smtp_norm_addr($address);
    if ($a === '') return false;
    $own = [
        (string)setting_get('smtp_from_email', ''),
        (string)setting_get('smtp_username', ''),
        (string)setting_get('company_email', ''),
        (string)setting_get('company_support_email', ''),
    ];
    if (function_exists('company_info')) { try { $own[] = (string)(company_info()['email'] ?? ''); } catch (Throwable $e) {} }
    foreach ($own as $o) { if ($o !== '' && smtp_norm_addr($o) === $a) return true; }
    return false;
}

function _smtp_prepare(PHPMailer $m, string $to, string $subject, string $html, array $opts = []): string {
    // Validate recipient first — prevents header injection / undeliverable sends.
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Invalid recipient address: ' . $to);
    }
    // Strip any control chars from subject — defends against header injection.
    $cleanSubject = preg_replace('/[\\r\\n\\t\\0]+/', ' ', $subject);

    $m->addAddress($to, $opts['to_name'] ?? '');

    // CC RULE (Admin → SMTP → "CC Email"): whatever lands in the store's OWN
    // inbox (the SMTP account / company address) is also copied to the CC
    // address — nothing else. Customer-addressed mail is never CC'd. Decided
    // from the recipient; callers may still force it via $opts['no_cc'].
    $noCc = array_key_exists('no_cc', $opts) ? (bool)$opts['no_cc'] : !smtp_is_own_inbox($to);
    if (!$noCc) {
        $cfgCc  = smtp_config();
        $ccList = trim((string)($cfgCc['cc'] ?? ''));
        // Fallback for ADMIN-only templates (reached only when no_cc is false):
        // if the merchant has not set an explicit CC, copy the alert to the
        // sending mailbox (SMTP From / username) so new-lead / new-sale alerts
        // always land in the inbox the store actually watches — even when the
        // company_email notification address does not forward there. Customer
        // mail is sent with no_cc=true and never reaches this fallback.
        if ($ccList === '') {
            $ccList = trim((string)(setting_get('smtp_from_email', setting_get('smtp_username', ''))));
        }
        if ($ccList !== '') {
            // Compare on the canonical mailbox so ops+sales@x.com (the To) never
            // also gets a pointless CC to ops@x.com, while a real CC address does.
            $seenCc = [smtp_norm_addr($to) => true];
            foreach (preg_split('/[,;]+/', $ccList) as $ccAddr) {
                $ccAddr = trim($ccAddr);
                if ($ccAddr === '' || !filter_var($ccAddr, FILTER_VALIDATE_EMAIL)) continue;
                $lc = smtp_norm_addr($ccAddr);
                if (isset($seenCc[$lc])) continue;
                $seenCc[$lc] = true;
                try { $m->addCC($ccAddr); } catch (Throwable $e) { /* ignore invalid */ }
            }
        }
    }
    $m->Subject = $cleanSubject;
    $m->isHTML(true);
    // Inline first-party images (logo, product art) as cid: attachments so
    // they never render as broken icons in the customer's inbox.
    $html = mv_embed_inline_images($m, $html);
    $m->Body    = $html;
    $m->AltBody = $opts['alt_body'] ?? html_to_plain($html);

    // Per-email sender/reply overrides (used by the sales-notification copy so
    // the admin's inbox shows the CUSTOMER's name as the sender + replying goes
    // straight to the buyer). Gmail rewrites the From *address* to the
    // authenticated account but preserves the display NAME.
    $fromNameOverride = isset($opts['from_name']) ? preg_replace('/[\r\n\t]+/', ' ', trim((string)$opts['from_name'])) : '';
    if ($fromNameOverride !== '') {
        $c = smtp_config();
        $fromEmail = $c['from_email'] !== '' ? $c['from_email'] : $m->From;
        if ($fromEmail !== '') { try { $m->setFrom($fromEmail, $fromNameOverride, false); } catch (Throwable $e) { /* keep default */ } }
    }
    if (!empty($opts['reply_to']) && filter_var($opts['reply_to'], FILTER_VALIDATE_EMAIL)) {
        $m->clearReplyTos();
        $replyName = isset($opts['reply_to_name']) ? preg_replace('/[\r\n\t]+/', ' ', trim((string)$opts['reply_to_name'])) : '';
        try { $m->addReplyTo($opts['reply_to'], $replyName); } catch (Throwable $e) { /* ignore */ }
    }

    // RFC 5322 deliverability headers
    $host = parse_url(site_url(), PHP_URL_HOST) ?: 'localhost';
    $mid  = '<' . bin2hex(random_bytes(12)) . '@' . $host . '>';
    $m->MessageID = $mid;

    if (!empty($opts['unsubscribe_url'])) {
        $m->addCustomHeader('List-Unsubscribe', '<' . $opts['unsubscribe_url'] . '>');
        $m->addCustomHeader('List-Unsubscribe-Post', 'List-Unsubscribe=One-Click');
    }
    if (!empty($opts['headers']) && is_array($opts['headers'])) {
        foreach ($opts['headers'] as $hk => $hv) {
            $hk = preg_replace('/[^A-Za-z0-9\\-]/', '', $hk);
            $hv = preg_replace('/[\\r\\n]+/', ' ', (string)$hv);
            if ($hk !== '') $m->addCustomHeader($hk, $hv);
        }
    }
    // Attachments — accepts an array of absolute filesystem paths.  Used by
    // the worker when sending order-delivery emails so each customer gets
    // their Receipt.pdf + Invoice.pdf bundled.
    if (!empty($opts['attachments']) && is_array($opts['attachments'])) {
        foreach ($opts['attachments'] as $p) {
            if (is_string($p) && $p !== '' && is_file($p)) {
                try { $m->addAttachment($p, basename($p)); }
                catch (Throwable $e) { @error_log('[mailer attach] ' . $e->getMessage()); }
            }
        }
    }
    return $mid;
}

/* ------------------------------------------------------------------------- */
/* PERMANENT content block — Volume Licensing / Business Pricing emails.     */
/* Single source of truth used by send_email(), smtp_queue_email(),          */
/* smtp_send(), the queue worker, email-api and every resend path.           */
/* ------------------------------------------------------------------------- */
function mv_email_blocked(?string $subject, ?string $templateCode = null): bool {
    $hay = strtolower((string)$subject . ' ' . (string)$templateCode);
    return strpos($hay, 'volume') !== false
        || strpos($hay, 'business pricing') !== false
        || strpos($hay, 'bulk licens') !== false;
}

/* Templates that must always get sending room (transactional / admin alerts). */
function _smtp_is_essential_template(?string $tc): bool {
    $tc = strtolower((string)$tc);
    if ($tc === '') return true; // unknown/manual sends: treat as important
    static $nonEssential = [
        'customer_service_ack', 'followup_1', 'followup_2', 'activation_checkin',
        'abandoned_cart', 'newsletter', 'review_thanks', 'stock_back',
        'stock_waitlist_confirm', 'subscription_confirm', 'chat_reply_relay',
    ];
    return !in_array($tc, $nonEssential, true);
}

/* Gmail "550 5.4.5 Daily user sending limit exceeded" & friends. */
function _smtp_is_quota_error(string $err): bool {
    return (bool)preg_match('/daily\s+(user\s+)?sending\s+(limit|quota)|sending\s+quota|quota\s+exceeded|5\.4\.5|4\.7\.0\s+.*(limit|quota)|limit\s+exceeded|too many messages/i', $err);
}

/* Sent in the rolling last 24 h (what Gmail counts against the daily cap). */
function _smtp_sent_last_24h(): int {
    try {
        return (int)db()->query("SELECT COUNT(*) FROM email_outbox WHERE status='sent' AND delivered_at >= (NOW() - INTERVAL 24 HOUR)")->fetchColumn();
    } catch (Throwable $e) { return 0; }
}

/* ------------------------------------------------------------------------- */
/* Per-minute rate limit guard                                               */
/* ------------------------------------------------------------------------- */
function _smtp_under_rate_limit(): bool {
    $c = smtp_config();
    try {
        $st = db()->prepare("SELECT COUNT(*) FROM email_outbox WHERE delivered_at >= (NOW() - INTERVAL 1 MINUTE)");
        $st->execute();
        return (int)$st->fetchColumn() < $c['rate_per_min'];
    } catch (Throwable $e) { return true; }
}

/* ------------------------------------------------------------------------- */
/* Synchronous send — used by smtp_test_connection() and queue worker        */
/* ------------------------------------------------------------------------- */
function smtp_send(string $to, string $subject, string $html, array $opts = []): array {
    mailer_bootstrap();
    $c = smtp_config();
    if (!$c['enabled'] || $c['host'] === '') {
        return ['ok' => false, 'error' => 'SMTP is not configured. Open admin → SMTP / Mail Server.'];
    }
    if (mv_email_blocked($subject, $opts['template_code'] ?? null)) {
        return ['ok' => false, 'error' => 'Blocked — volume licensing emails are permanently disabled.', 'retryable' => false, 'blocked' => true];
    }
    if (!_smtp_under_rate_limit()) {
        return ['ok' => false, 'error' => 'Rate limit reached. Try again in a minute.', 'retryable' => true];
    }
    try {
        $m = _smtp_make();
        $messageId = _smtp_prepare($m, $to, $subject, $html, $opts);
        $m->send();
        return ['ok' => true, 'message_id' => $messageId];
    } catch (Throwable $e) {
        // PHPMailer's ErrorInfo is more descriptive than the exception message
        $detail = isset($m) ? trim($m->ErrorInfo) : '';
        return ['ok' => false, 'error' => $e->getMessage() . ($detail ? ' · ' . $detail : ''), 'retryable' => true];
    }
}

/* ------------------------------------------------------------------------- */
/* Queue an email — single insert. Idempotent on (recipient,subject,template) */
/* within the same minute to prevent accidental duplicates.                  */
/* ------------------------------------------------------------------------- */
function smtp_queue_email(string $to, string $subject, string $html, array $opts = []): int {
    mailer_bootstrap();
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Invalid recipient address: ' . $to);
    }
    // Never even enter the queue for a volume / business-pricing email.
    if (mv_email_blocked($subject, $opts['template_code'] ?? null)) return 0;
    // Defence-in-depth: substitute any leftover {{var}} placeholders in the
    // subject using company-info + standard vars. Prevents customers ever
    // seeing literal "{{product_name}}" / "{{order_number}}" tokens.
    if (strpos($subject, '{{') !== false) {
        $co = company_info();
        $subject = strtr($subject, array_merge([
            '{{company_name}}'  => $co['name']  ?? '',
            '{{support_email}}' => $co['email'] ?? '',
            '{{support_phone}}' => $co['phone'] ?? '',
            '{{year}}'          => date('Y'),
        ], $opts['subject_vars'] ?? []));
        // Strip any unresolved placeholders rather than leak them
        $subject = preg_replace('/\{\{\s*[a-z_][a-z0-9_]*\s*\}\}/i', '', $subject);
        $subject = trim(preg_replace('/\s+/', ' ', $subject));
    }
    $pdo = db();
    $tok = $opts['tracking_token'] ?? bin2hex(random_bytes(16));
    $tpl = $opts['template_code'] ?? null;
    $oid = $opts['order_id']      ?? null;
    $priority   = (int)($opts['priority']    ?? 5);
    $maxRetries = (int)($opts['max_retries'] ?? smtp_config()['max_retries']);

    // Duplicate suppression — same recipient + subject + template within last
    // 60s. Admin-forced deliveries (manual key/link sends) bypass this window,
    // otherwise entering a key right after the sale would silently swallow
    // the customer's key email.
    if (empty($opts['force'])) {
        $dup = $pdo->prepare("SELECT id FROM email_outbox
            WHERE recipient = ? AND subject = ? AND COALESCE(template_code,'') = ? AND created_at >= (NOW() - INTERVAL 60 SECOND)
            ORDER BY id DESC LIMIT 1");
        $dup->execute([$to, $subject, (string)$tpl]);
        if ($existing = (int)$dup->fetchColumn()) return $existing;
    }

    // Optional delay (in minutes) before the cron worker is allowed to send
    // this row. Defaults to NOW() (immediate).
    $delayMin = (int)($opts['delay_minutes'] ?? 0);
    // Capture gateway mode at queue time so Email Activity can be filtered
    // test-vs-live even after the admin later toggles the mode.
    $gwMode = $opts['gw_mode'] ?? null;
    if ($gwMode === null) {
        try {
            if (!empty($oid)) {
                $q = $pdo->prepare("SELECT gw_mode FROM orders WHERE id = ? LIMIT 1");
                $q->execute([(int)$oid]);
                $gwMode = $q->fetchColumn() ?: null;
            }
        } catch (Throwable $e) { /* ignore */ }
        if (!$gwMode) $gwMode = setting_get('gw_mode', 'test');
    }
    // Per-email sender override (customer name shown as sender + replies routed
    // to them). Sanitised to single-line to prevent header injection.
    $senderName = isset($opts['sender_name']) ? trim(preg_replace('/[\r\n\t]+/', ' ', (string)$opts['sender_name'])) : '';
    $replyAddr  = (isset($opts['reply_to']) && filter_var($opts['reply_to'], FILTER_VALIDATE_EMAIL)) ? trim((string)$opts['reply_to']) : '';
    $senderName = $senderName !== '' ? mb_substr($senderName, 0, 185, 'UTF-8') : null;
    $replyAddr  = $replyAddr !== ''  ? $replyAddr : null;
    if ($delayMin > 0) {
        $pdo->prepare("INSERT INTO email_outbox
            (recipient, subject, html, status, note, order_id, tracking_token, template_code, retry_count, max_retries, next_retry_at, priority, attachments_json, gw_mode, sender_name, reply_to_addr)
            VALUES (?,?,?,'queued',NULL,?,?,?,0,?,DATE_ADD(NOW(), INTERVAL ? MINUTE),?,?,?,?,?)")
            ->execute([$to, $subject, $html, $oid, $tok, $tpl, $maxRetries, $delayMin, $priority, $opts['attachments'] ?? null, $gwMode, $senderName, $replyAddr]);
    } else {
        $pdo->prepare("INSERT INTO email_outbox
            (recipient, subject, html, status, note, order_id, tracking_token, template_code, retry_count, max_retries, next_retry_at, priority, attachments_json, gw_mode, sender_name, reply_to_addr)
            VALUES (?,?,?,'queued',NULL,?,?,?,0,?,NOW(),?,?,?,?,?)")
            ->execute([$to, $subject, $html, $oid, $tok, $tpl, $maxRetries, $priority, $opts['attachments'] ?? null, $gwMode, $senderName, $replyAddr]);
    }
    return (int)$pdo->lastInsertId();
}

/* ------------------------------------------------------------------------- */
/* Worker — process N due rows from email_outbox                             */
/* ------------------------------------------------------------------------- */

/**
 * Reduce an SMTP error message to a comparable "shape" so two errors with
 * variable parts (timestamps, request IDs, port numbers, ms, IPs) are
 * recognised as the same root cause. Used by smtp_process_queue() to detect
 * a stuck-retry pattern and auto-bounce after the same error repeats.
 */
function _smtp_error_shape(string $msg): string {
    $s = strtolower(trim($msg));
    if ($s === '') return '';
    // Strip variable / noisy parts
    $s = preg_replace('/\b\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}\b/', '', $s); // timestamps
    $s = preg_replace('/\b\d{1,3}(\.\d{1,3}){3}\b/', '', $s);                    // IPv4
    $s = preg_replace('/\b[a-f0-9]{16,}\b/', '', $s);                            // hex IDs
    $s = preg_replace('/\d+\s*(ms|s|kb|mb|gb|bytes?)\b/', '', $s);               // numeric durations / sizes
    $s = preg_replace('/\b\d{3,}\b/', '', $s);                                   // big numbers (ports, IDs)
    $s = preg_replace('/[\s,;:]+/', ' ', $s);                                    // collapse punctuation/whitespace
    return trim(substr($s, 0, 120));
}

/**
 * Per-row sender override. For admin-facing customer notifications, surface the
 * CUSTOMER's name as the email sender (display name) + set Reply-To to them, so
 * the admin's inbox shows who wrote in. Explicit persisted columns win; the
 * order lookup is a fallback for legacy sale rows queued before those columns.
 */
function _smtp_sender_override_for_row(array $row): array {
    $out  = [];
    $name = trim((string)($row['sender_name'] ?? ''));
    $rep  = trim((string)($row['reply_to_addr'] ?? ''));
    if ($name !== '') $out['from_name'] = $name;
    if ($rep !== '' && filter_var($rep, FILTER_VALIDATE_EMAIL)) {
        $out['reply_to'] = $rep;
        if ($name !== '') $out['reply_to_name'] = $name;
    }
    if ($out) return $out;

    // Fallback: sale copy rows carry the order id — derive the buyer from it.
    if (($row['template_code'] ?? '') !== 'sale_company_copy') return [];
    $oid = (int)($row['order_id'] ?? 0);
    if ($oid <= 0) return [];
    try {
        $q = db()->prepare("SELECT first_name, last_name, email FROM orders WHERE id = ? LIMIT 1");
        $q->execute([$oid]);
        $o = $q->fetch();
    } catch (Throwable $e) { return []; }
    if (!$o) return [];
    $name = trim((string)($o['first_name'] ?? '') . ' ' . (string)($o['last_name'] ?? ''));
    if ($name !== '') $out['from_name'] = $name;
    $email = trim((string)($o['email'] ?? ''));
    if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $out['reply_to'] = $email;
        if ($name !== '') $out['reply_to_name'] = $name;
    }
    return $out;
}

function smtp_process_queue(int $maxBatch = 5): int {
    mailer_bootstrap();
    $c = smtp_config();
    if (!$c['enabled'] || $c['host'] === '') return 0;

    $pdo = db();
    // Provider said "daily limit exceeded" recently → everything waits; the
    // rows stay queued (NOT bounced) and resume automatically.
    try {
        if ((int)setting_get('smtp_quota_pause_until', '0') > time()) return 0;
    } catch (Throwable $e) {}
    $maxBatch = max(1, min(50, $maxBatch));
    $rows = $pdo->query("SELECT * FROM email_outbox
        WHERE status IN ('queued','retrying')
          AND (next_retry_at IS NULL OR next_retry_at <= NOW())
        ORDER BY priority ASC, id ASC
        LIMIT $maxBatch")->fetchAll();

    $dailyCap  = (int)$c['daily_cap'];
    $softCap   = (int)floor($dailyCap * 0.8);
    $sent24    = _smtp_sent_last_24h();
    $processed = 0;
    foreach ($rows as $row) {
        // PERMANENT block: Volume Licensing was removed from the site. Any
        // volume-related email still in the queue must NEVER be delivered.
        // Mark it terminal so it leaves the queue for good.
        if (mv_email_blocked((string)($row['subject'] ?? ''), (string)($row['template_code'] ?? ''))) {
            try {
                $pdo->prepare("UPDATE email_outbox
                    SET status='cancelled', next_retry_at=NULL,
                        last_error='Volume licensing removed — email suppressed'
                    WHERE id=?")->execute([$row['id']]);
            } catch (Throwable $e) {}
            continue;
        }
        // Daily-cap budgeting: non-essential mail (acks, follow-ups, newsletters)
        // pauses at 80 % of the cap; essential mail (orders, keys, admin
        // alerts) may use the full cap. Held rows re-check in 60 minutes.
        $essential = _smtp_is_essential_template($row['template_code'] ?? null);
        if ($sent24 >= ($essential ? $dailyCap : $softCap)) {
            try {
                $pdo->prepare("UPDATE email_outbox
                    SET next_retry_at=DATE_ADD(NOW(), INTERVAL 60 MINUTE),
                        last_error=?
                    WHERE id=?")->execute([
                        $essential
                            ? 'Held — daily sending limit reached (' . $sent24 . '/' . $dailyCap . '); resumes automatically'
                            : 'Held — non-essential email paused at 80% of daily limit (' . $sent24 . '/' . $dailyCap . ') so order emails get priority',
                        $row['id']]);
            } catch (Throwable $e) {}
            continue;
        }
        if (!_smtp_under_rate_limit()) break;

        // ATOMIC CLAIM — several workers can run at once (the checkout request's
        // immediate send, the page-view auto-scheduler, cron.php). Without this
        // two of them read the same queued row and the customer (and the company
        // copy) received the SAME email twice. Only the worker that wins this
        // conditional UPDATE sends; it also leases the row for 10 minutes so a
        // crashed send is retried later instead of being lost.
        $claim = $pdo->prepare("UPDATE email_outbox
            SET next_retry_at = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
            WHERE id = ? AND status IN ('queued','retrying')
              AND (next_retry_at IS NULL OR next_retry_at <= NOW())");
        $claim->execute([$row['id']]);
        if ($claim->rowCount() === 0) continue; // another worker already took it

        $tok = $row['tracking_token'];
        $base = rtrim(site_url(), '/');
        $html = $row['html'];
        if ($tok && strpos($html, 'track-open.php') === false) {
            $html .= '<img src="' . $base . '/track-open.php?t=' . urlencode($tok) . '" width="1" height="1" alt="">';
        }
        // Carry queued attachments (Receipt + Invoice PDF paths) into the
        // real send so the customer actually receives them.  attachments_json
        // is set when the order-delivery email is queued in fulfill_order().
        $attachments = [];
        if (!empty($row['attachments_json'])) {
            $decoded = json_decode((string)$row['attachments_json'], true);
            if (is_array($decoded)) {
                foreach ($decoded as $p) {
                    if (is_string($p) && $p !== '' && is_file($p)) $attachments[] = $p;
                }
            }
        }
        // CC policy — copy to the Admin → SMTP "CC Email" ONLY what the store's
        // own inbox receives (sale copies, lead / contact / chat alerts,
        // payment-failed + bounce notices, ProAssist requests, test emails…).
        // Customer-addressed mail (keys, receipts, follow-ups, newsletters) is
        // never copied. Decided purely by the recipient address.
        $__noCc = !smtp_is_own_inbox((string)$row['recipient']);
        $result = smtp_send($row['recipient'], $row['subject'], $html, [
            'attachments' => $attachments,
            'no_cc'       => $__noCc,
        ] + _smtp_sender_override_for_row($row));
        if ($result['ok']) {
            $pdo->prepare("UPDATE email_outbox
                SET status='sent', delivered_at=NOW(), last_error=NULL, message_id=?, next_retry_at=NULL
                WHERE id=?")
                ->execute([$result['message_id'] ?? null, $row['id']]);
            $sent24++;
        } elseif (!empty($result['blocked'])) {
            $pdo->prepare("UPDATE email_outbox SET status='cancelled', next_retry_at=NULL, last_error=? WHERE id=?")
                ->execute([mb_substr((string)$result['error'], 0, 250, 'UTF-8'), $row['id']]);
        } elseif (_smtp_is_quota_error((string)$result['error'])) {
            // Provider daily limit hit: this is NOT a bounce. Keep the email
            // queued, pause the whole worker for an hour, resume automatically.
            try { setting_set('smtp_quota_pause_until', (string)(time() + 3600)); } catch (Throwable $e) {}
            $pdo->prepare("UPDATE email_outbox
                SET status='queued', next_retry_at=DATE_ADD(NOW(), INTERVAL 60 MINUTE), last_error=?
                WHERE id=?")
                ->execute(['Held — SMTP daily sending limit reached; will retry automatically (not a bounce). ' . mb_substr((string)$result['error'], 0, 150, 'UTF-8'), $row['id']]);
            $processed++;
            break;
        } else {
            $newCount   = (int)$row['retry_count'] + 1;
            $maxRetries = (int)($row['max_retries'] ?: 3);
            // Exponential backoff: 2, 10, 60 minutes (then bounce)
            $delays = [2, 10, 60, 240];
            $delay  = $delays[min($newCount - 1, count($delays) - 1)];
            // last_error is VARCHAR(255) — truncate long SMTP error messages so
            // a verbose failure can never break the retry pipeline.
            $errMsg = mb_substr((string)$result['error'], 0, 250, 'UTF-8');

            // Hard-bounce early when the SAME error has repeated 3+ times — no
            // point grinding through 10× retries against a recipient the server
            // keeps refusing. We compare error "shapes" (strip variable parts
            // like timestamps, IDs, port numbers) so the same root cause is
            // recognised even when the wording differs slightly.
            $errShape  = _smtp_error_shape($errMsg);
            $prevShape = _smtp_error_shape((string)($row['last_error'] ?? ''));
            $sameErrorStreak = ($prevShape !== '' && $errShape === $prevShape && $newCount >= 3);

            if ($newCount > $maxRetries || $sameErrorStreak) {
                $reason = $sameErrorStreak
                    ? "Auto-bounced — same error repeated {$newCount} times. " . $errMsg
                    : $errMsg;
                $pdo->prepare("UPDATE email_outbox
                    SET status='bounced', bounced_at=NOW(), retry_count=?, last_error=?, next_retry_at=NULL
                    WHERE id=?")
                    ->execute([$newCount, mb_substr($reason, 0, 250, 'UTF-8'), $row['id']]);
                // Notify admin about this bounce (deduped inside helper).
                try { email_notify_admin_of_bounce((int)$row['id'], $reason); }
                catch (Throwable $e) { @error_log('[queue bounce admin notify] '.$e->getMessage()); }
            } else {
                $pdo->prepare("UPDATE email_outbox
                    SET status='retrying', retry_count=?, last_error=?, next_retry_at=DATE_ADD(NOW(), INTERVAL $delay MINUTE)
                    WHERE id=?")
                    ->execute([$newCount, $errMsg, $row['id']]);
            }
        }
        $processed++;
    }
    return $processed;
}

/* ------------------------------------------------------------------------- */
/* Test the SMTP connection by sending an admin self-test email              */
/* ------------------------------------------------------------------------- */
function smtp_test_connection(?string $to = null): array {
    mailer_bootstrap();
    $c = smtp_config();
    if ($c['host'] === '') return ['ok' => false, 'message' => 'No SMTP host configured.'];
    $to = $to ?: ($c['reply_to'] ?: $c['from_email']);
    if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'message' => 'Provide a valid test recipient address.'];
    }
    $body = '<!doctype html><html><body style="font-family:Segoe UI,Arial,sans-serif;background:#f8fafc;padding:30px;">
      <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:14px;padding:28px;box-shadow:0 4px 18px rgba(0,0,0,.05);">
        <h2 style="margin:0 0 8px;color:#0f172a;">SMTP test successful ✅</h2>
        <p style="color:#475569;line-height:1.6;">Your <strong>'.esc($c['host']).':'.esc($c['port']).'</strong> mail server delivered this test message to <strong>'.esc($to).'</strong>.</p>
        <ul style="color:#475569;font-size:14px;line-height:1.7;">
          <li>Encryption: <strong>'.esc(strtoupper($c['encryption'])).'</strong></li>
          <li>From: <strong>'.esc($c['from_email']).'</strong></li>
          <li>Sent at: <strong>'.date('Y-m-d H:i:s').' '.date_default_timezone_get().'</strong></li>
        </ul>
        <p style="font-size:12px;color:#94a3b8;margin-top:18px;">You can now switch SMTP <em>Enabled</em> ON and all transactional emails will flow through this server.</p>
      </div></body></html>';
    // Force SMTP debug output for the duration of the test so the admin
    // gets the raw server response when something fails (Gmail's
    // "5.7.8 Username and Password not accepted", O365's "5.7.3 Not
    // Authorized to send from this address", etc.).  We do this by
    // toggling the debug setting temporarily, then restoring it.  This
    // is the single biggest UX win for diagnosing SMTP auth failures.
    $prevDebug = setting_get('smtp_debug', '0');
    setting_set('smtp_debug', '2');
    ob_start();
    try {
        $res = smtp_send($to, (function_exists('company_info') ? (string)(company_info()['name'] ?? 'Store') : 'Store') . ' SMTP test', $body, ['headers' => ['X-Test-Email' => '1']]);
    } finally {
        $log = ob_get_clean();
        setting_set('smtp_debug', (string)$prevDebug);
    }
    // Friendly-fy well-known SMTP error signatures so the admin sees
    // actionable guidance instead of a raw SMTP error string.
    $friendlyMessage = $res['ok']
        ? ('Test email sent to ' . $to)
        : ($res['error'] ?? 'Send failed');
    if (!$res['ok']) {
        $lc = strtolower($res['error'] ?? '' . ' ' . $log);
        if (strpos($lc, 'username and password not accepted') !== false
            || strpos($lc, '535 5.7.8') !== false) {
            $friendlyMessage = 'Authentication failed — Gmail rejected the username/password. Use an App Password (not your Google account password). Generate one at https://myaccount.google.com/apppasswords after enabling 2-Step Verification.';
        } elseif (strpos($lc, '5.7.3') !== false || strpos($lc, 'not authorized to send') !== false) {
            $friendlyMessage = 'Authentication OK but the "From Email" is not allowed on this mailbox. Set From Email to match the SMTP Username exactly (Gmail / O365 both rewrite From: to the authenticated mailbox).';
        } elseif (strpos($lc, 'smtp authenticate') !== false || strpos($lc, 'smtp_auth') !== false || strpos($lc, '535 ') !== false) {
            $friendlyMessage = 'SMTP authentication failed — check the Username and Password. For SendGrid the Username must be literally "apikey". For Amazon SES use SMTP credentials (not AWS access keys).';
        } elseif (strpos($lc, 'connection refused') !== false || strpos($lc, 'network is unreachable') !== false || strpos($lc, 'no route to host') !== false) {
            $friendlyMessage = 'Could not reach the SMTP host. Check the Host + Port. Some shared hosts block outbound port 25 — use 587 (STARTTLS) or 465 (SSL) instead.';
        } elseif (strpos($lc, 'ssl') !== false && strpos($lc, 'certificate') !== false) {
            $friendlyMessage = 'TLS certificate verification failed. If this is a legitimate self-signed cert on an internal relay, uncheck "Strict TLS peer verification" and try again.';
        } elseif (strpos($lc, 'sender rejected') !== false || strpos($lc, '550 5.7.1') !== false) {
            $friendlyMessage = 'Your SMTP host rejected the From Email address. Make sure it belongs to a real mailbox on the configured server (or a verified sender identity for SendGrid/SES).';
        }
    }
    return ['ok' => $res['ok'], 'message' => $friendlyMessage, 'log' => $log];
}

/* ------------------------------------------------------------------------- */
/* Recipient deliverability pre-flight                                       */
/*                                                                           */
/* Catches the #1 cause of bounce reports: customers mistyping their email   */
/* domain (gmial.com / hotmial.com / nodomain.xyz).  We do a fast DNS MX/A   */
/* lookup BEFORE handing the row to the queue worker.  When the domain has   */
/* no mail-capable record, we know with certainty no MTA will ever accept    */
/* the message — so we mark the row 'failed' immediately and surface it on   */
/* the admin Failed tab instead of waiting for the queue worker.             */
/*                                                                           */
/* Results are cached for one hour (process + APCu/file) so the check stays  */
/* cheap even at high volume.                                                */
/* ------------------------------------------------------------------------- */
function email_address_deliverable(string $address): array {
    $result = ['ok' => false, 'reason' => '', 'detail' => ''];
    if (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
        $result['reason'] = 'invalid_syntax';
        $result['detail'] = 'Not a valid RFC-5322 email address.';
        return $result;
    }
    $domain = strtolower(substr($address, strrpos($address, '@') + 1));
    if ($domain === '') {
        $result['reason'] = 'invalid_syntax';
        $result['detail'] = 'Missing domain.';
        return $result;
    }
    // Process-local cache so the same domain isn't probed twice in one request.
    static $cache = [];
    if (isset($cache[$domain])) return $cache[$domain];

    // Skip DNS for obvious local/test domains so dev workflows still flow.
    if (in_array($domain, ['localhost', 'example.com', 'example.org', 'example.net', 'test.local'], true)) {
        $result['ok'] = true;
        $result['reason'] = 'local_or_test';
        return $cache[$domain] = $result;
    }

    // Common typo dictionary — catches the bulk of real-world support tickets.
    // These are intentionally flagged as undeliverable EVEN when DNS resolves,
    // because squatter / parking pages still bounce real customer email.  We
    // surface a friendly hint so the admin can ask the customer to confirm.
    $typos = [
        'gmial.com'   => 'gmail.com',
        'gmal.com'    => 'gmail.com',
        'gmail.con'   => 'gmail.com',
        'gnail.com'   => 'gmail.com',
        'gmai.com'    => 'gmail.com',
        'gmaill.com'  => 'gmail.com',
        'hotmial.com' => 'hotmail.com',
        'hotnail.com' => 'hotmail.com',
        'hotmal.com'  => 'hotmail.com',
        'hotmail.con' => 'hotmail.com',
        'yaho.com'    => 'yahoo.com',
        'yahooo.com'  => 'yahoo.com',
        'yahoo.con'   => 'yahoo.com',
        'outlok.com'  => 'outlook.com',
        'outlook.con' => 'outlook.com',
        'iclud.com'   => 'icloud.com',
        'icould.com'  => 'icloud.com',
    ];
    if (isset($typos[$domain])) {
        $result['reason'] = 'no_mx';
        $result['detail'] = "Likely typo: {$domain}. Did the customer mean {$typos[$domain]}?";
        return $cache[$domain] = $result;
    }

    $hasMx = false; $hasA = false;
    try {
        $hasMx = @checkdnsrr($domain, 'MX');
        if (!$hasMx) {
            // RFC 5321 §5 — if no MX, mail can fall back to the A record.
            $hasA = @checkdnsrr($domain, 'A');
        }
    } catch (Throwable $e) {
        // DNS lookup failures should not break the request — assume deliverable
        // and let the SMTP worker decide.
        $result['ok'] = true;
        $result['reason'] = 'dns_unavailable';
        return $cache[$domain] = $result;
    }

    if ($hasMx || $hasA) {
        $result['ok'] = true;
        return $cache[$domain] = $result;
    }

    $hint = isset($typos[$domain]) ? " Did the customer mean {$typos[$domain]}?" : '';
    $result['reason'] = 'no_mx';
    $result['detail'] = "Domain {$domain} has no MX or A records — mail server doesn't exist." . $hint;
    return $cache[$domain] = $result;
}


/**
 * Bounce reconciliation — reads the mailbox (IMAP) for delivery-failure
 * notifications (from MAILER-DAEMON / "Undelivered Mail Returned to Sender")
 * and flips the matching Email Activity row from "sent" to "BOUNCED" with the
 * failure reason. This is what makes the admin show the REAL delivery status
 * instead of leaving genuinely-bounced mail marked as sent/delivered.
 *
 * Uses dedicated imap_* settings, falling back to the SMTP host/credentials.
 * Returns ['ok'=>bool,'checked'=>int,'bounced'=>int,'error'=>string].
 */
function email_sync_bounces(int $maxScan = 80): array
{
    $out = ['ok' => false, 'checked' => 0, 'bounced' => 0, 'error' => ''];
    if (!function_exists('imap_open')) {
        $out['error'] = 'PHP IMAP extension is not enabled on this server — ask your host to enable php-imap so bounce status can be read from the mailbox.';
        return $out;
    }
    $cfg  = smtp_config();
    $host = trim((string)setting_get('imap_host', $cfg['host']));
    $port = (int)setting_get('imap_port', '993') ?: 993;
    $user = trim((string)setting_get('imap_username', $cfg['username']));
    $rawP = (string)setting_get('imap_password_b64', '');
    $pass = $rawP !== '' ? (base64_decode($rawP, true) ?: '') : (string)$cfg['password'];
    $enc  = setting_get('imap_encryption', 'ssl'); // ssl | tls | none
    if ($host === '' || $user === '' || $pass === '') {
        $out['error'] = 'IMAP mailbox not configured (needs host, username & password). Set it under Admin → SMTP / Mail Server (bounce inbox).';
        return $out;
    }
    $flags = '/imap';
    $flags .= $enc === 'ssl' ? '/ssl' : ($enc === 'tls' ? '/tls' : '/notls');
    if (empty($cfg['verify_peer'])) $flags .= '/novalidate-cert';
    $mailbox = '{' . $host . ':' . $port . $flags . '}INBOX';

    $imap = @imap_open($mailbox, $user, $pass, 0, 1);
    if (!$imap) {
        $out['error'] = 'Could not connect to the IMAP mailbox: ' . (imap_last_error() ?: 'unknown error');
        return $out;
    }
    try {
        $ids = @imap_search($imap, 'UNSEEN FROM "MAILER-DAEMON"') ?: [];
        $ids = array_merge($ids, @imap_search($imap, 'UNSEEN SUBJECT "Undelivered"') ?: []);
        $ids = array_merge($ids, @imap_search($imap, 'UNSEEN SUBJECT "Delivery Status"') ?: []);
        $ids = array_slice(array_values(array_unique($ids)), 0, $maxScan);
        $pdo = db();
        foreach ($ids as $num) {
            $out['checked']++;
            $body = (string)@imap_body($imap, $num);
            $rcpt = '';
            if (preg_match('/Final-Recipient:\s*[^;]*;\s*([^\s<>]+@[^\s<>]+)/i', $body, $m)) {
                $rcpt = strtolower(trim($m[1], " \t<>."));
            } elseif (preg_match('/(?:Original-Recipient|X-Failed-Recipients):\s*(?:[^;]*;\s*)?([^\s<>,]+@[^\s<>,]+)/i', $body, $m)) {
                $rcpt = strtolower(trim($m[1], " \t<>."));
            } elseif (preg_match('/(?:to|for)\s+<?([^\s<>]+@[^\s<>]+)>?/i', $body, $m)) {
                $rcpt = strtolower(trim($m[1], " \t<>."));
            }
            $reason = '';
            if (preg_match('/Diagnostic-Code:\s*[^;\r\n]*;?\s*([^\r\n]+)/i', $body, $m)) $reason = trim($m[1]);
            elseif (preg_match('/\b(5\.\d\.\d+[^\r\n]*)/', $body, $m)) $reason = trim($m[1]);
            else $reason = 'Message bounced — delivery failed.';
            $reason = mb_substr($reason, 0, 300);

            if ($rcpt !== '' && filter_var($rcpt, FILTER_VALIDATE_EMAIL)) {
                // Find the most-recent customer-facing row so we can flip it AND
                // fire an admin bounce notice for THAT specific row.
                $findRow = $pdo->prepare(
                    "SELECT id, order_id, template_code FROM email_outbox " .
                    "WHERE recipient=? AND status IN ('sent','queued','delivered') " .
                    "ORDER BY id DESC LIMIT 1"
                );
                $findRow->execute([$rcpt]);
                $rowHit = $findRow->fetch();
                if ($rowHit) {
                    $upd = $pdo->prepare(
                        "UPDATE email_outbox SET status='bounced', bounced_at=NOW(), last_error=? " .
                        "WHERE id=?"
                    );
                    $upd->execute([$reason, (int)$rowHit['id']]);
                    if ($upd->rowCount() > 0) {
                        $out['bounced']++;
                        // Notify admin about this specific bounce (deduped by
                        // bounce_notified_at inside the helper).
                        try { email_notify_admin_of_bounce((int)$rowHit['id'], $reason); }
                        catch (Throwable $e) { @error_log('[bounce admin notify] '.$e->getMessage()); }
                    }
                }
            }
            @imap_setflag_full($imap, (string)$num, "\\Seen");
        }
        $out['ok'] = true;
    } catch (Throwable $e) {
        $out['error'] = 'Bounce sync error: ' . $e->getMessage();
    } finally {
        @imap_close($imap);
    }
    return $out;
}

/* ------------------------------------------------------------------------- */
/* Admin bounce notification — fires once per failed/bounced customer email.
 *
 * When a customer-facing email is marked 'failed' or 'bounced' (whether via
 * preflight, SMTP-level rejection, retry-exhaustion or the IMAP bounce sync)
 * we send ONE admin notification email to the site's company_email so the
 * merchant knows immediately without having to keep the admin panel open.
 * The notification is ALSO written into email_outbox with a dedicated
 * template_code ('order_email_bounced') so it shows up on the admin's
 * Product Purchases → Failed tab.
 *
 * Dedup: we set email_outbox.bounce_notified_at on the original row so the
 * same failure never triggers two admin notices.
 */
function email_notify_admin_of_bounce(int $outboxId, string $reason = ''): bool {
    mailer_bootstrap();
    $pdo = db();

    // Load the original row; bail if already notified or not customer-facing.
    $r = $pdo->prepare("SELECT * FROM email_outbox WHERE id = ? LIMIT 1");
    $r->execute([$outboxId]);
    $row = $r->fetch();
    if (!$row) return false;
    if (!empty($row['bounce_notified_at'])) return false;
    if (!in_array((string)$row['status'], ['failed','bounced'], true)) return false;
    // Never recurse on our own admin notices.
    if (($row['template_code'] ?? '') === 'order_email_bounced') return false;

    $adminEmail = trim((string)setting_get('company_email', ''));
    if ($adminEmail === '') $adminEmail = trim((string)setting_get('smtp_reply_to', ''));
    if ($adminEmail === '' || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        // No admin address configured — mark as notified anyway so we don't
        // keep retrying, and log for the operator.
        $pdo->prepare("UPDATE email_outbox SET bounce_notified_at=NOW() WHERE id=?")->execute([$outboxId]);
        @error_log('[bounce admin notify] no company_email set — skipping outbox '.$outboxId);
        return false;
    }

    // Enrich with order context if we have it.
    $order = null;
    if (!empty($row['order_id'])) {
        $oq = $pdo->prepare("SELECT id, order_number, first_name, last_name, phone, total, currency, gw_mode, created_at
                             FROM orders WHERE id = ? LIMIT 1");
        $oq->execute([(int)$row['order_id']]);
        $order = $oq->fetch() ?: null;
    }
    $reason = $reason !== '' ? $reason : ((string)($row['last_error'] ?? 'Delivery failed'));
    $reason = mb_substr($reason, 0, 500, 'UTF-8');

    $customerEmail = (string)$row['recipient'];
    $tplLabels = [
        'order_delivery'      => 'Order delivery (license keys)',
        'order_confirmation'  => 'Order confirmation',
        'order_pending'       => 'Payment reminder',
        'refund_confirm'      => 'Refund confirmation',
        'review_request'      => 'Review request',
    ];
    $tplLabel = $tplLabels[$row['template_code'] ?? ''] ?? ($row['template_code'] ?? 'transactional');
    $baseUrl  = rtrim((function_exists('site_url') ? site_url() : (setting_get('site_url', '') ?: '')), '/');

    $custName = '';
    $orderLink = '';
    $orderNum  = '';
    $modePill  = '';
    if ($order) {
        $custName = trim(($order['first_name'] ?? '').' '.($order['last_name'] ?? ''));
        $orderNum = (string)$order['order_number'];
        $orderLink = $baseUrl . '/admin.php?tab=orders&q=' . urlencode($orderNum);
        $modePill = (($order['gw_mode'] ?? 'live') === 'test')
            ? '<span style="display:inline-block;padding:2px 8px;border-radius:999px;background:#fef3c7;color:#92400e;font-size:11px;font-weight:700;letter-spacing:1px;">TEST</span>'
            : '<span style="display:inline-block;padding:2px 8px;border-radius:999px;background:#dcfce7;color:#166534;font-size:11px;font-weight:700;letter-spacing:1px;">LIVE</span>';
    }

    $subj = '⚠ Delivery failed — ' . htmlspecialchars($customerEmail, ENT_QUOTES, 'UTF-8')
          . ($orderNum ? ' (Order #'.htmlspecialchars($orderNum, ENT_QUOTES, 'UTF-8').')' : '');
    $subjPlain = '⚠ Delivery failed — ' . $customerEmail . ($orderNum ? ' (Order #'.$orderNum.')' : '');

    $rowHtml = '';
    $rowHtml .= '<tr><td style="padding:6px 10px;color:#64748b;font-size:13px;">Customer email</td>'
             .  '<td style="padding:6px 10px;font-weight:600;color:#0f172a;">'.htmlspecialchars($customerEmail, ENT_QUOTES, 'UTF-8').'</td></tr>';
    if ($custName !== '') {
        $rowHtml .= '<tr><td style="padding:6px 10px;color:#64748b;font-size:13px;">Customer name</td>'
                 .  '<td style="padding:6px 10px;color:#0f172a;">'.htmlspecialchars($custName, ENT_QUOTES, 'UTF-8').'</td></tr>';
    }
    if ($orderNum !== '') {
        $rowHtml .= '<tr><td style="padding:6px 10px;color:#64748b;font-size:13px;">Order</td>'
                 .  '<td style="padding:6px 10px;color:#0f172a;">#'.htmlspecialchars($orderNum, ENT_QUOTES, 'UTF-8').' '.$modePill.'</td></tr>';
    }
    $rowHtml .= '<tr><td style="padding:6px 10px;color:#64748b;font-size:13px;">Email type</td>'
             .  '<td style="padding:6px 10px;color:#0f172a;">'.htmlspecialchars($tplLabel, ENT_QUOTES, 'UTF-8').'</td></tr>';
    $rowHtml .= '<tr><td style="padding:6px 10px;color:#64748b;font-size:13px;">Failure reason</td>'
             .  '<td style="padding:6px 10px;color:#b91c1c;">'.htmlspecialchars($reason, ENT_QUOTES, 'UTF-8').'</td></tr>';

    $activityLink = $baseUrl . '/admin.php?tab=emails&filter=failed';
    $html = '<!doctype html><html><body style="font-family:Segoe UI,Arial,sans-serif;background:#f8fafc;padding:24px;">'
          . '<div style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;padding:28px;box-shadow:0 4px 18px rgba(0,0,0,.05);border:1px solid #fee2e2;">'
          . '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">'
          . '<div style="width:36px;height:36px;border-radius:10px;background:#fef2f2;color:#b91c1c;display:flex;align-items:center;justify-content:center;font-size:22px;">⚠</div>'
          . '<h2 style="margin:0;color:#0f172a;font-size:19px;">Customer email undeliverable</h2></div>'
          . '<p style="color:#475569;line-height:1.55;margin:0 0 14px;">A customer-facing email could not be delivered. '
          . 'You may want to reach the customer through another channel (phone / SMS) to confirm the correct address.</p>'
          . '<table style="width:100%;border-collapse:collapse;background:#f8fafc;border-radius:10px;overflow:hidden;font-size:14px;margin:0 0 18px;">'
          . $rowHtml . '</table>'
          . '<div style="margin-top:6px;">';
    if ($orderLink !== '') {
        $html .= '<a href="'.htmlspecialchars($orderLink, ENT_QUOTES, 'UTF-8').'" '
              .  'style="display:inline-block;padding:10px 16px;background:#2563eb;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;margin-right:8px;">View order</a>';
    }
    $html .= '<a href="'.htmlspecialchars($activityLink, ENT_QUOTES, 'UTF-8').'" '
          .  'style="display:inline-block;padding:10px 16px;background:#fff;color:#0f172a;text-decoration:none;border-radius:8px;font-weight:600;border:1px solid #e2e8f0;">Open Email Activity → Failed</a>'
          . '</div>'
          . '<p style="color:#94a3b8;font-size:12px;margin-top:18px;line-height:1.55;">This alert was sent because Email Activity row #'.(int)$outboxId
          . ' flipped to <strong>'.htmlspecialchars((string)$row['status'], ENT_QUOTES, 'UTF-8').'</strong>. '
          . 'You can resend the email to a corrected address from the row\'s action menu.</p>'
          . '</div></body></html>';

    // Directly insert into outbox so we never recurse through send_email().
    $tok = bin2hex(random_bytes(16));
    $gwModeVal = $order['gw_mode'] ?? setting_get('gw_mode', 'test');
    try {
        $pdo->prepare("INSERT INTO email_outbox
            (recipient, subject, html, status, note, order_id, tracking_token, template_code, retry_count, max_retries, next_retry_at, priority, gw_mode)
            VALUES (?,?,?,'queued',?,?,?,?,0,3,NOW(),3,?)")
            ->execute([
                $adminEmail, $subjPlain, $html,
                'Admin bounce notice for outbox #'.$outboxId,
                $order['id'] ?? null, $tok, 'order_email_bounced', $gwModeVal,
            ]);
    } catch (Throwable $e) { @error_log('[bounce admin notify insert] '.$e->getMessage()); return false; }

    // Try to send immediately if SMTP is enabled — best-effort.
    try {
        $c = smtp_config();
        if ($c['enabled'] && $c['host'] !== '') { smtp_process_queue(1); }
    } catch (Throwable $e) { /* fall through — cron will pick it up */ }

    $pdo->prepare("UPDATE email_outbox SET bounce_notified_at=NOW() WHERE id=?")->execute([$outboxId]);

    // Bell notification so the failure is impossible to miss in the admin.
    try {
        require_once __DIR__ . '/admin-notify.php';
        admin_notify(
            'email_failed',
            '⚠ Email NOT delivered — ' . $customerEmail,
            $tplLabel . ($orderNum !== '' ? ' (Order #' . $orderNum . ')' : '') . ' — ' . mb_strimwidth($reason, 0, 160, '…'),
            '/admin.php?tab=emails&filter=failed'
        );
    } catch (Throwable $e) { /* decorative */ }
    return true;
}
