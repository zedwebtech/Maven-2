<?php
/*
 * Background job runner for the AI Auto-Blogger.
 * Blog generation takes 60-90s per post (LLM + image). Running it inline in
 * an admin request holds the PHP session lock + a server worker for minutes —
 * on shared hosting / the preview's built-in server that freezes the whole
 * admin ("server crash"). Every generation now runs in a DETACHED worker:
 *   1. php-cli child process (preferred), else
 *   2. fire-and-forget loopback HTTP hit to /cron/seo-job.php, else
 *   3. inline as a last resort (old behaviour — still produces the post).
 * Job state lives in the `seo_job_status` setting (JSON) so the admin tab can
 * show a live "writing in background…" banner and announce the finished post.
 */
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/db.php';

function seo_job_status(): array {
    // Always read FRESH from the DB — setting_get() caches per request, and
    // seo_job_spawn() polls this while a worker (another process) updates it.
    $raw = null;
    try {
        $st = db()->prepare('SELECT v FROM settings WHERE k = ? LIMIT 1');
        $st->execute(['seo_job_status']);
        $raw = $st->fetchColumn();
    } catch (Throwable $e) { $raw = null; }
    if ($raw === false || $raw === null) $raw = setting_get('seo_job_status', '');
    $j = json_decode((string)$raw, true);
    return is_array($j) ? $j : [];
}

function seo_job_set_status(array $s): void {
    setting_set('seo_job_status', json_encode($s));
}

function seo_job_is_busy(): bool {
    $s = seo_job_status();
    $state = $s['state'] ?? '';
    if (!in_array($state, ['queued', 'running'], true)) return false;
    $t = strtotime($s['updated_at'] ?? ($s['queued_at'] ?? '')) ?: 0;
    $age = time() - $t;
    // A job stuck in "queued" for >2 min means the worker never started
    // (e.g. exec pointed at a non-CLI php) — treat it as dead, not busy.
    if ($state === 'queued') return $age < 120;
    return $age < 600; // running: stale after 10 min
}

/**
 * Find a REAL php-cli binary (cached). On cPanel/LiteSpeed PHP_BINARY is often
 * lsphp (a CGI binary) — spawning the worker through it silently dies, which
 * left jobs stuck in "queued" forever. Probe candidates and only accept one
 * whose PHP_SAPI is exactly "cli".
 */
function seo_job_cli_probe(string $c): bool {
    if ($c === '') return false;
    // Absolute paths must exist on THIS server — a cached path copied from
    // another machine (staging DB import) must never be trusted blindly.
    if (strpos($c, '/') !== false && !@is_file($c)) return false;
    try {
        $out = []; $rc = 1;
        @exec(escapeshellarg($c) . ' -r ' . escapeshellarg('echo PHP_SAPI;') . ' 2>/dev/null', $out, $rc);
        return $rc === 0 && trim(implode('', $out)) === 'cli';
    } catch (Throwable $e) { return false; }
}

function seo_job_find_cli_php(bool $forceProbe = false): string {
    static $verified = null;
    if ($verified !== null && !$forceProbe) return $verified;
    $cached = setting_get('seo_job_cli_php', "\x00unset");
    // Re-validate the cached binary every time (one ~20 ms exec). If it was
    // recorded on another host / an empty probe result, redo the full scan.
    if (!$forceProbe && $cached !== "\x00unset" && (string)$cached !== '' && seo_job_cli_probe((string)$cached)) {
        return $verified = (string)$cached;
    }
    $found = '';
    $candidates = array_values(array_unique(array_filter([
        PHP_BINARY,
        'php',
        '/usr/local/bin/php',
        '/usr/bin/php',
        '/opt/cpanel/ea-php83/root/usr/bin/php',
        '/opt/cpanel/ea-php82/root/usr/bin/php',
        '/opt/cpanel/ea-php81/root/usr/bin/php',
        '/opt/alt/php82/usr/bin/php',
        '/opt/alt/php81/usr/bin/php',
    ])));
    foreach ($candidates as $c) {
        if (seo_job_cli_probe($c)) { $found = $c; break; }
    }
    try { setting_set('seo_job_cli_php', $found); } catch (Throwable $e) {}
    return $verified = $found;
}

/** Wait (max $maxMs) until the worker flipped the job to 'running'/'done'/'failed'. */
function seo_job_wait_started(string $queuedAt, int $maxMs = 5000): bool {
    $deadline = microtime(true) + $maxMs / 1000;
    do {
        usleep(250000);
        $s = seo_job_status();
        if (($s['state'] ?? '') !== 'queued') return true;
        if (($s['queued_at'] ?? '') !== $queuedAt) return true; // replaced by another job
    } while (microtime(true) < $deadline);
    return false;
}

/** Returns the spawn mode used ('cli' | 'http' | 'inline') or false. */
function seo_job_spawn(string $job, string $region = '', array $args = [])
{
    if (seo_job_is_busy()) return false;
    $now = date('Y-m-d H:i:s');
    seo_job_set_status(['job' => $job, 'region' => $region, 'args' => $args,
                        'state' => 'queued', 'queued_at' => $now, 'updated_at' => $now]);

    // ---- (1) detached php-cli child (only via a VERIFIED cli binary) ----
    // Each spawn method is CONFIRMED (the worker must flip the job to
    // 'running' within a few seconds) before we trust it — a silently dying
    // child (missing binary, LVE process limit, killed on request end) used
    // to leave the job "queued" forever and the admin waiting for nothing.
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    if (function_exists('exec') && !in_array('exec', $disabled, true)) {
        $php = seo_job_find_cli_php();
        if ($php !== '') {
            $cmd = escapeshellarg($php) . ' ' . escapeshellarg(__DIR__ . '/../cron/seo-job-run.php') . ' '
                 . escapeshellarg($job) . ' ' . escapeshellarg($region) . ' ' . escapeshellarg(json_encode($args))
                 . ' > /dev/null 2>&1 &';
            try {
                exec($cmd);
                if (seo_job_wait_started($now)) return 'cli';
                // Worker never started: forget this binary so the next spawn re-probes.
                try { setting_set('seo_job_cli_php', ''); } catch (Throwable $e) {}
            } catch (Throwable $e) { /* fall through */ }
        }
    }

    // ---- (2) fire-and-forget loopback HTTP ----
    try {
        require_once __DIR__ . '/seo-bot.php';
        $token = seo_bot_cron_token();
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == 443);
        $port  = (int)($_SERVER['SERVER_PORT'] ?? ($https ? 443 : 80));
        $host  = preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
        $path  = '/cron/seo-job.php?token=' . rawurlencode($token) . '&job=' . rawurlencode($job)
               . '&region=' . rawurlencode($region) . '&args=' . rawurlencode(json_encode($args));
        $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]]);
        $scheme = $https ? 'ssl://' : 'tcp://';
        $fp = @stream_socket_client($scheme . '127.0.0.1:' . $port, $en, $es, 2, STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) $fp = @stream_socket_client($scheme . $host . ':' . $port, $en, $es, 2, STREAM_CLIENT_CONNECT, $ctx);
        if ($fp) {
            fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
            usleep(200000); // let the server accept the request, then walk away
            fclose($fp);
            if (seo_job_wait_started($now, 6000)) return 'http';
        }
    } catch (Throwable $e) { /* fall through */ }

    // ---- (3) inline last resort ----
    // Release the session lock first so other admin tabs stay responsive
    // even in this worst-case synchronous path.
    $st = seo_job_status();
    if (($st['state'] ?? '') !== 'queued' || ($st['queued_at'] ?? '') !== $now) return 'inline'; // a late worker picked it up after all
    try { if (session_status() === PHP_SESSION_ACTIVE) session_write_close(); } catch (Throwable $e) {}
    try { seo_job_execute($job, $region, $args); return 'inline'; }
    catch (Throwable $e) {
        seo_job_set_status(['job' => $job, 'state' => 'failed', 'error' => $e->getMessage(),
                            'updated_at' => date('Y-m-d H:i:s'), 'announced' => 0]);
    }
    return false;
}

/** The actual work — called by the CLI runner / HTTP endpoint / inline fallback. */
function seo_job_execute(string $job, string $region = '', array $args = []): array
{
    ignore_user_abort(true);
    @set_time_limit(900);
    require_once __DIR__ . '/functions.php';
    require_once __DIR__ . '/seo-bot.php';
    require_once __DIR__ . '/admin-notify.php';

    $now = static fn() => date('Y-m-d H:i:s');
    $status = array_merge(seo_job_status(), [
        'job' => $job, 'region' => $region, 'state' => 'running',
        'started_at' => $now(), 'updated_at' => $now(),
    ]);
    seo_job_set_status($status);

    $done = static function (string $message, ?array $post = null, array $extra = []) use (&$status, $now) {
        $status = array_merge($status, $extra, ['state' => 'done', 'message' => $message, 'post' => $post,
                              'finished_at' => $now(), 'updated_at' => $now(), 'announced' => 0]);
        seo_job_set_status($status);
        // No bell notification by design — the operator only wants chats,
        // leads/sales/orders and email activity in the notification stream.
        // Blog results announce via the AI-blogger tab flash card instead.
        return ['ok' => true, 'message' => $message, 'post' => $post];
    };
    $fail = static function (string $error) use (&$status, $now, $job) {
        $status = array_merge($status, ['state' => 'failed', 'error' => $error,
                              'finished_at' => $now(), 'updated_at' => $now(), 'announced' => 0]);
        seo_job_set_status($status);
        // Failures surface in the AI-blogger tab flash — not the bell.
        return ['ok' => false, 'error' => $error];
    };

    try {
        switch ($job) {
            case 'random': {
                [$apiKey, $baseUrl] = _seo_resolve_llm_credentials();
                if (!$apiKey || !$baseUrl) return $fail('LLM key not configured — add your AI key in the API Keys section');
                $regions = array_values(array_filter(array_map('trim', explode(',', SEOBOT_BLOG_REGIONS))));
                $r = ($region !== '' && in_array($region, $regions, true)) ? $region : $regions[array_rand($regions)];
                $rep = ['errors' => []];
                $one = _seo_generate_one_blog_post(db(), $apiKey, $baseUrl, $r, [], $rep);
                if (empty($one['blog_post_id'])) return $fail($rep['errors'][0] ?? 'unknown error');
                setting_set('seo_bot_random_post_last_at', date('Y-m-d H:i:s'));
                return $done('Random post published — featured ' . ($one['product_name'] ?: 'a product') . ' for ' . $r . ' market.', [
                    'blog_post_id' => $one['blog_post_id'], 'blog_post_title' => $one['blog_post_title'],
                    'blog_post_image' => $one['blog_post_image'] ?? '', 'product_name' => $one['product_name'] ?? '',
                    'target_region' => $r,
                ]);
            }
            case 'underserved': {
                $res = seo_publish_one_post_now($region !== '' ? $region : null);
                if (empty($res['ok'])) return $fail(($res['error'] ?? 'unknown error') . ' (' . ($res['region'] ?? '—') . ')');
                setting_set('seo_bot_force_one_last_at', date('Y-m-d H:i:s'));
                return $done('Force-published one post for the next under-served market (' . ($res['region'] ?? '—') . ') — ' . ($res['product_name'] ?: 'a product') . '.', [
                    'blog_post_id' => $res['blog_post_id'], 'blog_post_title' => $res['blog_post_title'],
                    'blog_post_image' => $res['blog_post_image'] ?? '', 'product_name' => $res['product_name'] ?? '',
                    'target_region' => $res['region'] ?? '',
                ]);
            }
            case 'trends': {
                $report = ['errors' => []];
                $res = seo_publish_featured_trends_article($report, !empty($args['force']), $region !== '' ? $region : 'ALL');
                if (!empty($res['skipped'])) return $done('Featured trends article skipped — ' . ($res['reason'] ?? '') . ' (use "Generate Trends Now" to force one).');
                if (empty($res['blog_post_id'])) return $fail($report['errors'][0] ?? ($res['error'] ?? 'unknown error'));
                $regionLabel = ($res['target_region'] ?? 'ALL') === 'ALL' ? 'Global audience' : ('Targeted at ' . $res['target_region']);
                return $done('✓ Featured trends article published — "' . $res['blog_post_title'] . '" (' . $regionLabel . ').', [
                    'blog_post_id' => $res['blog_post_id'], 'blog_post_title' => $res['blog_post_title'],
                    'blog_post_image' => $res['blog_post_image'] ?? '', 'product_name' => $res['product_name'] ?? '',
                    'target_region' => $res['target_region'] ?? 'ALL',
                ]);
            }
            case 'daily': {
                $parts = [];
                $posts = [];
                if (!empty($args['publish'])) {
                    $r = seo_bot_run_if_due(!empty($args['force']));
                    if (!empty($r['skipped'])) {
                        $parts[] = 'blogger already up to date (' . ($r['reason'] ?? '') . ')';
                    } else {
                        $posts = is_array($r['blog_posts'] ?? null) ? $r['blog_posts'] : [];
                        $publishedCount = count($posts) ?: (!empty($r['blog_post_id']) ? 1 : 0);
                        $parts[] = $publishedCount . ' new blog post' . ($publishedCount === 1 ? '' : 's')
                                 . ' · IndexNow ' . ($r['indexnow_status'] ?? '—') . ' (' . ($r['indexnow_count'] ?? 0) . ' URLs)'
                                 . ' · ' . count($r['errors'] ?? []) . ' error(s)';
                        // Surface WHY nothing was published (cooldown / cap /
                        // missing key) instead of a silent "0 new posts".
                        if ($publishedCount === 0) {
                            $why = array_merge((array)($r['skipped'] ?? []), (array)($r['errors'] ?? []));
                            if ($why) $parts[] = reset($why);
                        }
                    }
                }
                try { seo_bot_weekly_sitemap_tick(); } catch (Throwable $e) { @error_log('[seo-job weekly] ' . $e->getMessage()); }
                try { seo_bot_freshness_tick(); } catch (Throwable $e) { @error_log('[seo-job freshness] ' . $e->getMessage()); }
                $msg = 'AI Auto-Blogger background run complete' . ($parts ? ' — ' . implode('; ', $parts) : '') . '.';
                return $done($msg, $posts[0] ?? null, count($posts) > 1 ? ['posts' => $posts] : []);
            }
            case 'ai_studio': {
                require_once __DIR__ . '/ai-studio.php';
                $mode = (($args['mode'] ?? 'blog') === 'trends') ? 'trends' : 'blog';
                $res  = mv_ai_generate_post($mode, (int)($args['product_id'] ?? 0), $region,
                                            (string)($args['topic'] ?? ''), (string)($args['keyword'] ?? ''));
                if (empty($res['id'])) return $fail('AI Studio: generation returned no post.');
                $label = !empty($res['is_article']) ? 'Trending article' : 'Blog post';
                return $done('✓ ' . $label . ' published — "' . $res['title'] . '".', [
                    'blog_post_id' => $res['id'], 'blog_post_title' => $res['title'],
                    'blog_post_image' => '', 'target_region' => $res['region'] ?? 'ALL',
                ]);
            }
            default:
                return $fail('Unknown job "' . $job . '"');
        }
    } catch (Throwable $e) {
        return $fail($e->getMessage());
    }
}
