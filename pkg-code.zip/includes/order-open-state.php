<?php
// Per-order "did the customer open it?" state, scored from the open log so
// automated fetches (Gmail prefetch, Apple privacy proxy, scanners) never
// count. Shared by order-view.php (first paint) and ajax/order-open-status.php
// (live refresh) so both always agree.
require_once __DIR__ . '/email-tracking.php';

function mv_order_open_state(array $o, array $emRows): array
{
    $custLc = strtolower(trim((string)($o['email'] ?? '')));
    $cust = [];
    foreach ($emRows as $r) {
        if ($custLc === '' || strtolower(trim((string)($r['recipient'] ?? ''))) !== $custLc) continue;
        if (in_array(strtolower((string)($r['status'] ?? '')), ['sent', 'delivered', 'opened'], true)) $cust[] = $r;
    }
    usort($cust, fn($a, $b) => strcmp((string)$b['created_at'], (string)$a['created_at']) ?: ((int)$b['id'] <=> (int)$a['id']));
    $sum = mv_open_summary($emRows);
    $log = [];
    foreach ($cust as $r) {
        $s = $sum[(int)$r['id']] ?? ['opened' => false, 'opened_at' => null, 'opens' => 0, 'auto' => 0, 'auto_reason' => ''];
        $log[] = [
            'id'          => (int)$r['id'],
            'subject'     => (string)($r['subject'] ?? ''),
            'sent_at'     => (string)($r['delivered_at'] ?: $r['created_at']),
            'opened'      => !empty($s['opened']),
            'opened_at'   => $s['opened_at'],
            'count'       => (int)$s['opens'],
            'auto'        => (int)$s['auto'],
            'auto_reason' => (string)$s['auto_reason'],
        ];
    }
    $latest = $log[0] ?? null;
    $sig = [];
    foreach ($log as $l) $sig[] = $l['id'] . ':' . ($l['opened'] ? 1 : 0) . ':' . $l['count'] . ':' . $l['auto'];
    return [
        'cust_sent'        => $latest !== null,
        'cust_sent_at'     => $latest['sent_at'] ?? null,
        'latest_opened'    => $latest ? $latest['opened'] : false,
        'latest_opened_at' => $latest ? $latest['opened_at'] : null,
        'latest_opens'     => $latest ? $latest['count'] : 0,
        'log'              => $log,
        'summary'          => $sum,
        'sig'              => md5(implode('|', $sig)),
    ];
}

/** <li> items for the timeline open log — gray until the customer really opens. */
function mv_render_open_log(array $st): string
{
    $h = '';
    foreach ($st['log'] as $l) {
        $subj = esc($l['subject'] !== '' ? $l['subject'] : '(no subject)');
        if ($l['opened']) {
            $meta = 'opened ' . (int)$l['count'] . '× · ' . esc(date('M j, H:i', strtotime((string)$l['opened_at'])));
            $h .= '<li class="is-open" data-testid="open-log-' . (int)$l['id'] . '" data-opened="1"><i class="bi bi-envelope-open-fill"></i>'
                . '<span class="tl-openlog-subj" title="' . $subj . '">' . $subj . '</span><span class="tl-openlog-meta">' . $meta . '</span></li>';
        } else {
            $meta = 'sent ' . esc(date('M j, H:i', strtotime($l['sent_at']))) . ' · <strong>not opened yet</strong>';
            $tip  = $l['auto'] > 0 ? ' title="' . esc($l['auto_reason']) . '"' : '';
            $h .= '<li class="is-unopened" data-testid="open-log-' . (int)$l['id'] . '" data-opened="0"' . $tip . '><i class="bi bi-envelope"></i>'
                . '<span class="tl-openlog-subj" title="' . $subj . '">' . $subj . '</span><span class="tl-openlog-meta">' . $meta
                . ($l['auto'] > 0 ? ' <span class="tl-openlog-auto"><i class="bi bi-robot"></i> auto-loaded by mail server — not a real open</span>' : '')
                . '</span></li>';
        }
    }
    return $h;
}

/** Fulfillment card "Customer Opened" cell — reflects the LATEST email only. */
function mv_render_open_badge(array $st): string
{
    if ($st['latest_opened']) {
        return '<span class="s-badge opened" data-testid="customer-opened-badge">Opened ' . (int)$st['latest_opens'] . '×</span>'
             . '<div class="text-muted" style="font-size:10px;">' . esc(date('M j, Y H:i', strtotime((string)$st['latest_opened_at']))) . '</div>';
    }
    if ($st['cust_sent']) {
        return '<span class="s-badge queued" data-testid="customer-opened-badge" title="We delivered the email. It turns green the moment the customer opens it (their mail app must load images — some never do).">Not opened yet</span>';
    }
    return '<span class="text-muted" data-testid="customer-opened-badge">—</span>';
}

/** "opened N×" / auto-fetch note shown on a thread row. */
function mv_render_thread_open_note(array $st, int $outboxId): string
{
    $s = $st['summary'][$outboxId] ?? null;
    if (!$s) return '';
    if (!empty($s['opened'])) return ' · <span style="color:#059669;font-weight:600;">opened ' . (int)$s['opens'] . '×</span>';
    if ((int)($s['auto'] ?? 0) > 0) return ' · <span class="text-muted" title="' . esc((string)$s['auto_reason']) . '"><i class="bi bi-robot"></i> auto-loaded by mail server · not opened</span>';
    return '';
}
