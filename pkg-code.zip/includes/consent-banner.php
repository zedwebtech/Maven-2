<?php
/**
 * First-party cookie-consent banner (Consent Mode v2 "update" caller).
 *
 * Rendered ONLY for visitors in GB / EEA / CH (mv_consent_required()) who have
 * not chosen yet. Accept / Reject calls gtag('consent','update', …) — which
 * both GTM and native gtag.js consume — and stores the choice in the
 * first-party `mv_consent` cookie (180 days) so includes/header.php can replay
 * the update BEFORE the tags load on every later page view.
 *
 * Nothing here loads a third-party CMP; no DDL; no settings required.
 */
if (!function_exists('mv_consent_required') || !mv_consent_required()) return;
$__cbChoice = mv_consent_choice();
$__cbPrivacy = (function_exists('country_prefix') ? country_prefix() : '') . '/privacy';
?>
<div id="mv-consent" class="mv-consent<?= $__cbChoice !== '' ? ' mv-consent-hidden' : '' ?>"<?= $__cbChoice !== '' ? ' hidden' : '' ?> role="dialog" aria-modal="false" aria-live="polite" aria-label="Cookie preferences" data-testid="consent-banner">
  <div class="mv-consent-inner">
    <div class="mv-consent-text">
      <strong>Your privacy choices</strong>
      <span>We use cookies for analytics and to measure our advertising. Nothing is set for these purposes until you choose. See our <a href="<?= esc($__cbPrivacy) ?>" data-testid="consent-privacy-link">Privacy Policy</a>.</span>
    </div>
    <div class="mv-consent-actions">
      <button type="button" class="mv-consent-btn mv-consent-reject" id="mv-consent-reject" data-testid="consent-reject-btn">Reject</button>
      <button type="button" class="mv-consent-btn mv-consent-accept" id="mv-consent-accept" data-testid="consent-accept-btn">Accept all</button>
    </div>
  </div>
</div>
<style>
  .mv-consent{position:fixed;left:0;right:0;bottom:0;z-index:2147483000;padding:12px 14px calc(12px + env(safe-area-inset-bottom));background:#0f172a;color:#e2e8f0;box-shadow:0 -10px 30px rgba(2,6,23,.35);font-size:.9rem;transform:translateY(0);transition:transform .35s ease,opacity .35s ease}
  .mv-consent.mv-consent-hidden{transform:translateY(110%);opacity:0;pointer-events:none}
  .mv-consent-inner{max-width:1100px;margin:0 auto;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
  .mv-consent-text{flex:1 1 420px;line-height:1.45}
  .mv-consent-text strong{display:block;font-size:.95rem;margin-bottom:2px;color:#fff}
  .mv-consent-text a{color:#93c5fd;text-decoration:underline}
  .mv-consent-actions{display:flex;gap:10px;flex:0 0 auto}
  .mv-consent-btn{border-radius:999px;padding:.55rem 1.15rem;font-weight:700;font-size:.88rem;border:1.5px solid transparent;cursor:pointer;transition:background-color .2s,color .2s,transform .15s}
  .mv-consent-btn:hover{transform:translateY(-1px)}
  .mv-consent-reject{background:transparent;color:#e2e8f0;border-color:#475569}
  .mv-consent-reject:hover{background:#1e293b}
  .mv-consent-accept{background:#2563eb;color:#fff}
  .mv-consent-accept:hover{background:#1d4ed8}
  @media (max-width:575.98px){.mv-consent-actions{width:100%}.mv-consent-btn{flex:1 1 0}}
</style>
<script>
(function(){
  var el = document.getElementById('mv-consent');
  if (!el) return;
  function apply(choice){
    var v = choice === 'granted' ? 'granted' : 'denied';
    var upd = { 'ad_storage': v, 'ad_user_data': v, 'ad_personalization': v, 'analytics_storage': v };
    if (typeof gtag === 'function') { gtag('consent', 'update', upd); }
    else { window.dataLayer = window.dataLayer || []; window.dataLayer.push(['consent', 'update', upd]); }
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'mv_consent_update', consent_choice: v });
    var secure = location.protocol === 'https:' ? ';Secure' : '';
    document.cookie = 'mv_consent=' + v + ';max-age=' + (180*86400) + ';path=/;SameSite=Lax' + secure;
    window.MV_CONSENT = window.MV_CONSENT || {}; window.MV_CONSENT.choice = v;
    el.classList.add('mv-consent-hidden');
    setTimeout(function(){ el.hidden = true; }, 380);
  }
  var a = document.getElementById('mv-consent-accept'), r = document.getElementById('mv-consent-reject');
  if (a) a.addEventListener('click', function(){ apply('granted'); });
  if (r) r.addEventListener('click', function(){ apply('denied'); });
  // Footer "Cookie preferences" link re-opens the banner so a choice can be changed.
  window.mvOpenConsent = function(){ el.hidden = false; requestAnimationFrame(function(){ el.classList.remove('mv-consent-hidden'); }); };
})();
</script>
