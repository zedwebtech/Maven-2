<?php
/**
 * includes/demo-purge.php
 * ---------------------------------------------------------------------------
 * One-time, self-healing cleanup that removes the bundled DEMO/sample
 * transactional data (demo orders like #MVT-DEMO-xxx, sample leads such as
 * Alex Carter / Priya Sharma / Mike Anderson, placeholder license keys,
 * demo notifications & visitor logs) so a deployed store starts FRESH with
 * ZERO manual database work.
 *
 * Runs ONCE, guarded by the `demo_purged_v` setting, so it can NEVER wipe
 * real orders/leads/keys that arrive later.  Products, categories, settings,
 * customer reviews and the admin login are left untouched.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!defined('MV_DEMO_PURGE_VERSION')) define('MV_DEMO_PURGE_VERSION', '4');

function mv_purge_demo_data(): array {
    $pdo = db();
    $log = [];
    // ── HARD SAFETY GUARD ────────────────────────────────────────────────
    // NEVER wipe an established store. If the store contains ANY real order
    // (i.e. an order that is not one of the bundled demo samples), treat it as
    // LIVE: mark the guard satisfied and delete NOTHING. This makes a code-only
    // deploy 100% non-destructive — orders, customers, leads, subscriptions,
    // reviews, email history, inventory, etc. can never be truncated, even if
    // the purge version is bumped or the `demo_purged_v` setting is reset.
    try {
        $real = (int)$pdo->query(
            "SELECT COUNT(*) FROM orders WHERE order_number NOT LIKE 'MVT-DEMO%' AND UPPER(order_number) NOT LIKE '%DEMO%'"
        )->fetchColumn();
        // Any lead, contact message or subscription also marks the store as live.
        foreach (['chat_leads', 'support_messages', 'customer_subscriptions', 'license_keys'] as $t) {
            try { $real += (int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); } catch (Throwable $e) {}
        }
        if ($real > 0) {
            setting_set('demo_purged_v', MV_DEMO_PURGE_VERSION);
            return ['skipped: live store detected (' . $real . ' real orders/leads/messages) — no data touched'];
        }
    } catch (Throwable $e) {
        // If we cannot confirm the store is empty, err on the side of caution
        // and do NOTHING destructive.
        setting_set('demo_purged_v', MV_DEMO_PURGE_VERSION);
        return ['skipped: could not verify store is empty — no data touched'];
    }
    $tables = [
        'orders', 'order_items', 'license_keys', 'chat_leads', 'chat_messages',
        'lead_notes', 'admin_notifications', 'refund_requests',
        'customer_subscriptions', 'subscription_notes', 'stock_notifications',
        'email_outbox', 'email_followup_schedule', 'transaction_logs',
        'stripe_events', 'support_messages', 'support_tickets', 'visitor_log',
        'product_ai_chats', 'proassist_schedules', 'password_resets',
    ];
    try { $pdo->exec('SET FOREIGN_KEY_CHECKS=0'); } catch (Throwable $e) {}
    foreach ($tables as $t) {
        try { $pdo->exec("TRUNCATE TABLE `$t`"); $log[] = "cleared $t"; }
        catch (Throwable $e) { /* table may not exist on older schemas */ }
    }
    try { $pdo->exec('SET FOREIGN_KEY_CHECKS=1'); } catch (Throwable $e) {}
    setting_set('demo_purged_v', MV_DEMO_PURGE_VERSION);
    return $log;
}

/** Silent, guarded web auto-heal — purges demo data exactly once per version. */
function mv_autoheal_demo_purge(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting_get('demo_purged_v', '') !== MV_DEMO_PURGE_VERSION) {
            mv_purge_demo_data();
        }
    } catch (Throwable $e) { /* DB not ready — retry next request */ }
}
