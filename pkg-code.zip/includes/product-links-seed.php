<?php
/**
 * includes/product-links-seed.php
 * ---------------------------------------------------------------------------
 * Baked-in per-product Installer Download URL + Activation / Sign-in URL so a
 * fresh deploy on ANY host has the correct download/activation link on every
 * product with ZERO manual entry — same self-heal pattern as marketing/SMTP.
 *
 * Each mapped product also has its *_mode flipped to 'manual' so the explicit
 * URL below is always used (not the AI-derived fallback).  Version-guarded:
 * bump MV_PRODUCT_LINKS_SEED_VERSION whenever the URL list changes and the new
 * values are force-applied once on the next page load / deploy.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!defined('MV_PRODUCT_LINKS_SEED_VERSION')) define('MV_PRODUCT_LINKS_SEED_VERSION', '1');

function mv_product_links_map(): array {
    $OFF2024_PROPLUS = 'https://c2rsetup-officeapps.b-cdn.net/Office%202024%20Pro%20Plus.exe';
    $OFF2024_HOME    = 'https://std.mscdn2024.com/Office_2024_EN_standard_64Bits.exe';
    $OFF_SETUP_Q     = 'https://setup.office.com/?ms.officeurl=setup';
    $OFF_MAC2024     = 'https://mac.mscdn2024.com/';
    $OFF_SETUP       = 'https://setup.office.com';
    $WIN11           = 'https://go.microsoft.com/fwlink/?linkid=2171764';
    $WIN10           = 'https://www.microsoft.com/en-in/software-download/windows10';
    $BITDEF          = 'https://central.bitdefender.com/';
    $MCAFEE          = 'https://www.mcafee.com/activate';

    // slug => ['installer' => url, 'activation' => url]  (either key optional)
    return [
        // ---- Office 2024 (Windows) ----
        'microsoft-office-2024-professional-plus-windows'                    => ['installer' => $OFF2024_PROPLUS],
        'microsoft-office-2024-professional-plus-lifetime-license-windows-pc'=> ['installer' => $OFF2024_PROPLUS],
        'microsoft-office-home-2024-pc'                                      => ['installer' => $OFF2024_HOME],
        'microsoft-office-home-business-2024-pc'                             => ['installer' => $OFF2024_HOME],
        // ---- Office 2021 (Windows) ----
        'microsoft-office-2021-home-business-windows'                        => ['installer' => $OFF_SETUP_Q],
        'microsoft-office-2021-professional-plus-windows'                    => ['installer' => $OFF_SETUP_Q],
        'microsoft-office-2021-home-student-windows'                         => ['installer' => $OFF_SETUP_Q],
        'microsoft-word-2021-windows'                                        => ['installer' => $OFF_SETUP_Q],
        'microsoft-excel-2021-windows'                                       => ['installer' => $OFF_SETUP_Q],
        // ---- Office 2019 (Windows) ----
        'microsoft-office-2019-home-student-windows'                         => ['installer' => $OFF_SETUP_Q],
        'microsoft-office-2019-home-business-pc'                             => ['installer' => $OFF_SETUP_Q],
        'microsoft-office-2019-professional-plus-windows'                    => ['installer' => $OFF_SETUP_Q],
        // ---- Office 2024 / 2021 (Mac) ----
        'microsoft-office-home-business-2024-mac'                            => ['installer' => $OFF_MAC2024],
        'microsoft-office-home-2024-mac'                                     => ['installer' => $OFF_MAC2024],
        'microsoft-office-2021-home-student-mac'                             => ['installer' => $OFF_MAC2024],
        'microsoft-office-2021-home-business-mac'                            => ['installer' => $OFF_MAC2024],
        'microsoft-word-2021-mac-lifetime-license-no-subscription'          => ['installer' => $OFF_MAC2024],
        'microsoft-excel-2021-mac-lifetime-license-no-subscription'         => ['installer' => $OFF_MAC2024],
        // ---- Office 2019 (Mac) ----
        'microsoft-office-home-and-business-2019-mac'                        => ['installer' => $OFF_SETUP],
        'microsoft-office-home-and-student-2019-mac'                         => ['installer' => $OFF_SETUP],
        // ---- Windows OS ----
        'windows-11-home'                                                    => ['installer' => $WIN11],
        'windows-11-pro'                                                     => ['installer' => $WIN11],
        'windows-10-home'                                                    => ['installer' => $WIN10],
        'windows-10-pro'                                                     => ['installer' => $WIN10],
        // ---- Project ----
        'microsoft-project-2024-professional-pc'                             => ['installer' => $OFF_SETUP],
        'microsoft-project-professional-2021-pc'                             => ['installer' => $OFF_SETUP],
        'ms-project-professional-2019-pc'                                    => ['installer' => $OFF_SETUP],
        // ---- Visio ----
        'microsoft-visio-2024-professional-windows-pc'                       => ['installer' => $OFF_SETUP],
        'microsoft-visio-2021-professional-windows-pc'                       => ['installer' => $OFF_SETUP],
        'ms-visio-professional-2019-pc'                                      => ['installer' => $OFF_SETUP],
        // ---- Antivirus / Security (activation / sign-in only) ----
        'bitdefender-premium-vpn-unlimited-devices-1-year'                   => ['activation' => $BITDEF],
        'bitdefender-antivirus-for-mac-1-mac-1-year'                         => ['activation' => $BITDEF],
        'bitdefender-antivirus-for-mac-1-mac-2-years'                        => ['activation' => $BITDEF],
        'bitdefender-antivirus-for-mac-3-mac-1-year'                         => ['activation' => $BITDEF],
        'bitdefender-antivirus-for-mac-3-mac-2-years'                        => ['activation' => $BITDEF],
        'bitdefender-small-office-security-5-devices-1-year'                 => ['activation' => $BITDEF],
        'mcafee-premium-individual-1-year-unlimited-devices-usa'             => ['activation' => $MCAFEE],
    ];
}

/** Apply the baked-in installer/activation URLs to each product row. */
function mv_seed_product_links(bool $force = true): array {
    $pdo = db();
    $log = [];
    $up = $pdo->prepare('UPDATE products SET installer_url=?, install_url_mode=? WHERE slug=?');
    $ua = $pdo->prepare('UPDATE products SET activation_url=?, activation_url_mode=? WHERE slug=?');
    foreach (mv_product_links_map() as $slug => $urls) {
        if (!empty($urls['installer'])) { $up->execute([$urls['installer'], 'manual', $slug]); }
        if (!empty($urls['activation'])) { $ua->execute([$urls['activation'], 'manual', $slug]); }
        $log[] = $slug;
    }
    setting_set('product_links_seed_v', MV_PRODUCT_LINKS_SEED_VERSION);
    return $log;
}

/** Silent, guarded web auto-heal — force-applies once per version. */
function mv_autoheal_product_links(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting_get('product_links_seed_v', '') !== MV_PRODUCT_LINKS_SEED_VERSION) {
            mv_seed_product_links(true);
        }
    } catch (Throwable $e) { /* DB not ready — retry next request */ }
}
