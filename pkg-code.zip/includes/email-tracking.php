<?php
/**
 * Email open-event tracking (dispute evidence) + per-order document builders:
 *   • every open of a tracked email is stored with IP, location, ISP, device
 *     and mail client (email_open_events — self-created, additive only)
 *   • Email Logs PDF, Customer Communication PDF
 */

function mv_open_events_bootstrap(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try { if (function_exists('setting_get') && setting_get('open_events_schema_v', '') === '1') return; } catch (Throwable $e) {}
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS email_open_events (
            id INT AUTO_INCREMENT PRIMARY KEY,
            outbox_id INT NOT NULL,
            tracking_token VARCHAR(64) NULL,
            opened_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            ip VARCHAR(45) NULL,
            country VARCHAR(80) NULL,
            region VARCHAR(80) NULL,
            city VARCHAR(80) NULL,
            isp VARCHAR(160) NULL,
            device VARCHAR(120) NULL,
            client VARCHAR(120) NULL,
            user_agent VARCHAR(500) NULL,
            INDEX idx_open_outbox (outbox_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        if (function_exists('setting_set')) { try { setting_set('open_events_schema_v', '1'); } catch (Throwable $e) {} }
    } catch (Throwable $e) { /* silent */ }
}

/** Best-effort parse of a mail-client / proxy user agent. */
function mv_parse_user_agent(string $ua): array
{
    $u = strtolower($ua);
    $client = 'Unknown'; $device = 'Unknown';
    if (strpos($u, 'chrome/42.0.2311.135') !== false && strpos($u, 'edge/12.246') !== false) { $client = 'Gmail Prefetch Bot'; $device = 'Email Proxy — Google (prefetch)'; }
    elseif (strpos($u, 'googleimageproxy') !== false || strpos($u, 'ggpht.com') !== false) { $client = 'Gmail'; $device = 'Email Proxy — Google'; }
    elseif (strpos($u, 'yahoomailproxy') !== false || strpos($u, 'yahoo') !== false) { $client = 'Yahoo Mail'; $device = 'Email Proxy — Yahoo'; }
    elseif (strpos($u, 'outlook') !== false || strpos($u, 'microsoft office') !== false || strpos($u, 'msoffice') !== false) { $client = 'Microsoft Outlook'; }
    elseif (strpos($u, 'thunderbird') !== false) { $client = 'Mozilla Thunderbird'; }
    elseif (strpos($u, 'applemail') !== false || (strpos($u, 'mac os x') !== false && strpos($u, 'applewebkit') !== false && strpos($u, 'chrome') === false && strpos($u, 'safari') === false)) { $client = 'Apple Mail'; }
    elseif (strpos($u, 'edg/') !== false) { $client = 'Microsoft Edge (webmail)'; }
    elseif (strpos($u, 'chrome') !== false) { $client = 'Google Chrome (webmail)'; }
    elseif (strpos($u, 'firefox') !== false) { $client = 'Firefox (webmail)'; }
    elseif (strpos($u, 'safari') !== false) { $client = 'Safari (webmail)'; }
    elseif ($ua === '') { $client = 'Not reported'; }
    if ($device === 'Unknown') {
        if (strpos($u, 'iphone') !== false) $device = 'iPhone (iOS)';
        elseif (strpos($u, 'ipad') !== false) $device = 'iPad (iPadOS)';
        elseif (strpos($u, 'android') !== false) $device = 'Android ' . (strpos($u, 'mobile') !== false ? 'phone' : 'tablet');
        elseif (strpos($u, 'windows') !== false) $device = 'Windows PC';
        elseif (strpos($u, 'mac os x') !== false || strpos($u, 'macintosh') !== false) $device = 'Mac';
        elseif (strpos($u, 'linux') !== false) $device = 'Linux';
        elseif (preg_match('/proxy|bot|fetch/', $u)) $device = 'Email Proxy — Unknown';
    }
    return ['client' => $client, 'device' => $device];
}

/** Country/region/city/ISP for an IP via free services; cached; never throws. */
function mv_ip_lookup(string $ip): array
{
    $empty = ['country' => '', 'region' => '', 'city' => '', 'isp' => ''];
    if ($ip === '' || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $empty;
    $ck = 'ipgeo_' . md5($ip);
    try {
        $cached = setting_get($ck, '');
        if ($cached !== '') { $d = json_decode($cached, true); if (is_array($d)) return $d + $empty; }
    } catch (Throwable $e) {}
    $out = $empty;
    $fetch = function (string $url) {
        $ctx = stream_context_create(['http' => ['timeout' => 2.5, 'ignore_errors' => true, 'header' => "User-Agent: Maventech-Tracking/1.0\r\n"]]);
        $raw = @file_get_contents($url, false, $ctx);
        return $raw ? json_decode($raw, true) : null;
    };
    $d = $fetch('https://ipwho.is/' . rawurlencode($ip));
    if (is_array($d) && !empty($d['success'])) {
        $out = ['country' => (string)($d['country'] ?? ''), 'region' => (string)($d['region'] ?? ''), 'city' => (string)($d['city'] ?? ''),
                'isp' => (string)(($d['connection']['isp'] ?? '') ?: ($d['connection']['org'] ?? ''))];
    } else {
        $d = $fetch('http://ip-api.com/json/' . rawurlencode($ip) . '?fields=status,country,regionName,city,isp,org');
        if (is_array($d) && ($d['status'] ?? '') === 'success') {
            $out = ['country' => (string)($d['country'] ?? ''), 'region' => (string)($d['regionName'] ?? ''), 'city' => (string)($d['city'] ?? ''),
                    'isp' => (string)(($d['isp'] ?? '') ?: ($d['org'] ?? ''))];
        }
    }
    if (array_filter($out)) { try { setting_set($ck, json_encode($out)); } catch (Throwable $e) {} }
    return $out;
}

/**
 * Automated-fetch fingerprint. Gmail's prefetch bot, Apple Mail Privacy
 * Protection and corporate security scanners load every image the moment an
 * email is delivered — before the customer has seen it. Those hits must never
 * count as "Customer Opened Email".
 */
function mv_classify_open(string $ua, string $isp = '', string $referer = '', ?int $secsSinceSend = null): array
{
    $u = strtolower(trim($ua)); $i = strtolower($isp); $r = strtolower($referer);
    $gmailProxy = strpos($u, 'googleimageproxy') !== false || strpos($u, 'ggpht.com') !== false;
    if (strpos($u, 'chrome/42.0.2311.135') !== false && strpos($u, 'edge/12.246') !== false) {
        return ['auto' => true, 'reason' => 'Gmail prefetch bot — Gmail scans the images the moment the email lands while the inbox is open, before the customer sees it'];
    }
    if (!$gmailProxy && strpos($r, 'mail.google.com') !== false) {
        return ['auto' => true, 'reason' => 'Gmail prefetch — image fetched by Gmail on delivery, not by the customer'];
    }
    if ($u === 'mozilla/5.0' || $u === 'mozilla/5.0 (compatible)') {
        return ['auto' => true, 'reason' => 'Apple Mail Privacy Protection / proxy prefetch — images auto-loaded on delivery'];
    }
    if (preg_match('/\b(apple|icloud)\b/', $i)) {
        return ['auto' => true, 'reason' => 'Apple Mail Privacy Protection — Apple\'s servers pre-load images when the email arrives'];
    }
    if (preg_match('/barracuda|mimecast|proofpoint|symantec|trend ?micro|forcepoint|sophos|fireeye|fortinet|ironport|zscaler|checkpoint|python|curl\/|wget|go-http|java\/|okhttp|httpclient|libwww|axios|node-fetch|bot\b|crawler|spider|scanner|headless|phantomjs|bingpreview|facebookexternalhit|slackbot|skypeuripreview|whatsapp|telegrambot|linkcheck|validator/', $u)) {
        return ['auto' => true, 'reason' => 'Security scanner / link-preview bot fetched the image — not the customer'];
    }
    if (!$gmailProxy && $secsSinceSend !== null && $secsSinceSend >= 0 && $secsSinceSend <= 8) {
        return ['auto' => true, 'reason' => 'Fetched ' . $secsSinceSend . 's after delivery — automated mail-server scan, too fast for a human open'];
    }
    return ['auto' => false, 'reason' => ''];
}

/** Verdict for a stored open event (uses the saved flag, else re-scores it). */
function mv_open_event_kind(array $ev): array
{
    $secs = isset($ev['secs']) && $ev['secs'] !== null ? (int)$ev['secs'] : null;
    $k = mv_classify_open((string)($ev['user_agent'] ?? ''), (string)($ev['isp'] ?? ''), '', $secs);
    if (!$k['auto'] && strpos((string)($ev['client'] ?? ''), '[auto-fetch]') !== false) {
        $k = ['auto' => true, 'reason' => 'Automated fetch by the mail server (Gmail prefetch) — not a confirmed open'];
    }
    return $k;
}

/** Store one open event for an outbox row (called by track-open.php); returns its verdict. */
function mv_record_open_event(int $outboxId, string $token, ?int $secsSinceSend = null): array
{
    mv_open_events_bootstrap();
    $ip = function_exists('client_ip') ? client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $ua = mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500);
    $p  = mv_parse_user_agent($ua);
    $g  = mv_ip_lookup($ip);
    $k  = mv_classify_open($ua, (string)$g['isp'], (string)($_SERVER['HTTP_REFERER'] ?? ''), $secsSinceSend);
    $client = $k['auto'] ? mb_substr($p['client'] . ' [auto-fetch]', 0, 120) : $p['client'];
    try {
        db()->prepare('INSERT INTO email_open_events (outbox_id, tracking_token, ip, country, region, city, isp, device, client, user_agent)
                       VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([$outboxId, $token, $ip, $g['country'], $g['region'], $g['city'], mb_substr($g['isp'], 0, 160), $p['device'], $client, $ua]);
    } catch (Throwable $e) { /* never break the pixel */ }
    return $k;
}

function mv_open_events_for(int $outboxId): array
{
    mv_open_events_bootstrap();
    try {
        $st = db()->prepare('SELECT ev.*, TIMESTAMPDIFF(SECOND, COALESCE(o.delivered_at, o.created_at), ev.opened_at) AS secs
                               FROM email_open_events ev LEFT JOIN email_outbox o ON o.id = ev.outbox_id
                              WHERE ev.outbox_id=? ORDER BY ev.opened_at DESC, ev.id DESC');
        $st->execute([$outboxId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return []; }
}

/**
 * Per-email open summary that ignores automated fetches. Keyed by outbox id:
 * human / auto counts, first real open, and the honest opened/opens values.
 * Rows without any per-event log (legacy) fall back to the stored columns.
 */
function mv_open_summary(array $rows): array
{
    mv_open_events_bootstrap();
    $out = []; $ids = [];
    foreach ($rows as $r) {
        $id = (int)($r['id'] ?? 0);
        if ($id > 0) { $ids[] = $id; $out[$id] = ['human' => 0, 'auto' => 0, 'events' => 0, 'first_human_at' => null, 'last_human_at' => null, 'auto_reason' => '']; }
    }
    if (!$ids) return $out;
    try {
        $in = implode(',', array_unique($ids));
        $q = db()->query("SELECT ev.*, TIMESTAMPDIFF(SECOND, COALESCE(o.delivered_at, o.created_at), ev.opened_at) AS secs
                            FROM email_open_events ev JOIN email_outbox o ON o.id = ev.outbox_id
                           WHERE ev.outbox_id IN ($in) ORDER BY ev.opened_at ASC, ev.id ASC");
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $ev) {
            $id = (int)$ev['outbox_id']; if (!isset($out[$id])) continue;
            $k = mv_open_event_kind($ev);
            $out[$id]['events']++;
            if ($k['auto']) {
                $out[$id]['auto']++;
                if ($out[$id]['auto_reason'] === '') $out[$id]['auto_reason'] = $k['reason'];
            } else {
                $out[$id]['human']++;
                $out[$id]['first_human_at'] = $out[$id]['first_human_at'] ?? $ev['opened_at'];
                $out[$id]['last_human_at']  = $ev['opened_at'];
            }
        }
    } catch (Throwable $e) { /* fall back to stored columns */ }
    foreach ($rows as $r) {
        $id = (int)($r['id'] ?? 0); if (!isset($out[$id])) continue;
        $s = &$out[$id];
        if ($s['events'] === 0) {
            $s['opened']    = !empty($r['opened_at']);
            $s['opened_at'] = $r['opened_at'] ?? null;
            $s['opens']     = $s['opened'] ? max(1, (int)($r['opened_count'] ?? 1)) : 0;
        } else {
            $s['opened']    = $s['human'] > 0;
            $s['opened_at'] = $s['first_human_at'];
            $s['opens']     = $s['human'];
        }
        unset($s);
    }
    return $out;
}

/**
 * One-time data heal: re-score every tracked email from its open log so
 * automated fetches recorded before this fix stop showing as customer opens.
 */
function mv_heal_open_events_reclassify(): void
{
    mv_open_events_bootstrap();
    try {
        $pdo  = db();
        $rows = $pdo->query("SELECT o.id, o.opened_at, o.opened_count, o.status FROM email_outbox o
                              WHERE EXISTS (SELECT 1 FROM email_open_events ev WHERE ev.outbox_id = o.id)")->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return;
        $sum = mv_open_summary($rows);
        $upd = $pdo->prepare('UPDATE email_outbox SET opened_at = ?, opened_count = ?, status = ? WHERE id = ?');
        foreach ($rows as $r) {
            $s = $sum[(int)$r['id']] ?? null;
            if (!$s || $s['events'] === 0) continue;
            $st = (string)$r['status'];
            if ($s['human'] > 0) {
                $upd->execute([$s['first_human_at'], $s['human'], in_array($st, ['sent', 'delivered', 'opened'], true) ? 'opened' : $st, (int)$r['id']]);
            } else {
                $upd->execute([null, 0, $st === 'opened' ? 'sent' : $st, (int)$r['id']]);
            }
        }
    } catch (Throwable $e) { /* best-effort */ }
}

function mv_email_status_label(array $em): string
{
    $st = strtolower((string)($em['status'] ?? ''));
    if (!empty($em['opened_at']) || $st === 'opened') return 'Opened';
    if (in_array($st, ['sent', 'delivered'], true)) return 'Delivered';
    if (in_array($st, ['failed', 'bounced', 'error'], true)) return ucfirst($st);
    if ($st === 'cancelled') return 'Cancelled';
    return 'Queued';
}

/** Structured tracking details for one email (popup + PDFs). */
function mv_email_tracking_data(int $outboxId): ?array
{
    $st = db()->prepare('SELECT e.*, o.order_number FROM email_outbox e LEFT JOIN orders o ON o.id=e.order_id WHERE e.id=? LIMIT 1');
    $st->execute([$outboxId]);
    $em = $st->fetch(PDO::FETCH_ASSOC);
    if (!$em) return null;
    $events = mv_open_events_for($outboxId);
    $fmt = fn($ts) => $ts ? date('M j, Y, h:i:s A', strtotime((string)$ts)) : '—';
    $tc = (string)($em['template_code'] ?? '');
    $kinds = array_map('mv_open_event_kind', $events);
    $humanEvents = 0; $autoEvents = 0;
    foreach ($kinds as $k) { if ($k['auto']) $autoEvents++; else $humanEvents++; }
    $legacy = max(0, (int)($em['opened_count'] ?? 0) - $humanEvents);
    $totalOpens = $events ? $humanEvents : (int)($em['opened_count'] ?? 0);
    return [
        'id'           => (int)$em['id'],
        'recipient'    => (string)$em['recipient'],
        'status'       => mv_email_status_label($em),
        'subject'      => (string)$em['subject'],
        'type'         => function_exists('mv_email_type_label') ? mv_email_type_label($tc, (string)($em['html'] ?? '')) : ($tc ?: 'Email'),
        'template'     => $tc,
        'order_number' => (string)($em['order_number'] ?? ''),
        'sent_at'      => $fmt($em['delivered_at'] ?: $em['created_at']),
        'first_opened' => $fmt($em['opened_at'] ?? null),
        'total_opens'  => $totalOpens,
        'auto_fetches' => $autoEvents,
        'tracking_id'  => (string)($em['tracking_token'] ?? ''),
        'last_error'   => (string)($em['last_error'] ?? ''),
        'events'       => array_map(fn($ev, $k) => [
            'opened_at' => $fmt($ev['opened_at']), 'ip' => (string)$ev['ip'],
            'location'  => implode(', ', array_filter([(string)$ev['city'], (string)$ev['region'], (string)$ev['country']])) ?: 'Not available',
            'isp'       => (string)($ev['isp'] ?: 'Not available'), 'device' => (string)$ev['device'],
            'client'    => str_replace(' [auto-fetch]', '', (string)$ev['client']),
            'user_agent'=> (string)$ev['user_agent'],
            'auto'      => (bool)$k['auto'],
            'kind'      => $k['auto'] ? 'Automated fetch — not an open' : 'Confirmed open by recipient',
            'reason'    => (string)$k['reason'],
        ], $events, $kinds),
        'legacy_opens' => $events ? 0 : $legacy,
    ];
}

/** Every email ever sent to this customer's address (all orders + newsletters). */
function mv_customer_comm_rows(string $email, int $orderId = 0): array
{
    $email = strtolower(trim($email));
    try {
        if ($email !== '') {
            $st = db()->prepare('SELECT e.*, o.order_number FROM email_outbox e LEFT JOIN orders o ON o.id=e.order_id
                                 WHERE LOWER(e.recipient)=? OR (e.order_id=? AND ? > 0 AND LOWER(e.recipient)=?)
                                 ORDER BY e.created_at DESC, e.id DESC');
            $st->execute([$email, $orderId, $orderId, $email]);
        } else {
            $st = db()->prepare('SELECT e.*, o.order_number FROM email_outbox e LEFT JOIN orders o ON o.id=e.order_id WHERE e.order_id=? ORDER BY e.created_at DESC, e.id DESC');
            $st->execute([$orderId]);
        }
        return $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return []; }
}

/* ---------------------------------------------------------------- PDFs --- */

function _mv_doc_head_html(array $o, string $title, string $sub, string $accent = '#0f766e'): string
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $co = function_exists('company_info') ? company_info() : ['name' => 'Maventech'];
    $siteUrl = rtrim(function_exists('site_url') ? site_url() : '', '/');
    $logoPath = function_exists('_pdf_company_logo_path') ? _pdf_company_logo_path() : '';
    $logoTag  = ($logoPath && file_exists($logoPath)) ? '<img src="' . $logoPath . '" style="height:38px;width:auto;">' : '<div style="font-size:16px;font-weight:800;color:#0f172a;">' . $e($co['name'] ?? '') . '</div>';
    $genAt = gmdate('F j, Y H:i') . ' UTC';
    $custName = trim((string)($o['first_name'] ?? '') . ' ' . (string)($o['last_name'] ?? ''));
    return '<table class="doc-head"><tr><td><div class="doc-title">' . $e($title) . '</div><div class="doc-sub" style="color:' . $accent . ';">' . $e($sub) . ' — Order #' . $e($o['order_number'] ?? '') . '</div>'
        . '<div class="doc-meta">Generated ' . $genAt . '</div></td>'
        . '<td class="brand-cell">' . $logoTag . '<br><strong style="color:#0f172a;">' . $e($co['name'] ?? '') . '</strong><br>' . $e($siteUrl) . '</td></tr></table>'
        . '<h2 style="border-left-color:' . $accent . ';">Customer &amp; order</h2><table class="kv">'
        . '<tr><td class="k">Name</td><td class="v">' . $e($custName) . '</td></tr>'
        . '<tr><td class="k">Email address</td><td class="v">' . $e($o['email'] ?? '') . '</td></tr>'
        . '<tr><td class="k">Order number</td><td class="v">' . $e($o['order_number'] ?? '') . '</td></tr>'
        . '<tr><td class="k">Order placed (UTC)</td><td class="v">' . $e($o['created_at'] ?? '') . '</td></tr></table>';
}

function _mv_doc_css(): string
{
    return '<style>@page{margin:34px 40px;size:letter portrait;} body{font-family:"DejaVu Sans",Helvetica,Arial,sans-serif;font-size:9pt;color:#1f2937;}
    .doc-head{width:100%;border-collapse:collapse;margin-bottom:10px;} .doc-head td{vertical-align:top;} .doc-title{font-size:16pt;font-weight:800;color:#0f172a;letter-spacing:.5px;}
    .doc-sub{font-size:8pt;letter-spacing:2px;font-weight:700;text-transform:uppercase;margin-top:2px;} .doc-meta{font-size:7.5pt;color:#64748b;margin-top:4px;}
    .brand-cell{text-align:right;font-size:7.5pt;color:#64748b;line-height:1.4;} h2{font-size:10pt;font-weight:800;color:#0f172a;margin:14px 0 5px;padding:4px 8px;background:#f1f5f9;border-left:4px solid #0f766e;}
    table.kv{width:100%;border-collapse:collapse;margin-bottom:4px;} table.kv td{padding:3.5px 8px;font-size:8.5pt;border-bottom:1px solid #eef2f7;vertical-align:top;} table.kv td.k{color:#64748b;width:28%;} table.kv td.v{color:#0f172a;font-weight:700;}
    table.grid{width:100%;border-collapse:collapse;font-size:7.6pt;} table.grid th{background:#0f172a;color:#fff;text-align:left;padding:5px 6px;font-size:7pt;letter-spacing:.5px;text-transform:uppercase;} table.grid td{padding:5px 6px;border-bottom:1px solid #e5e7eb;vertical-align:top;}
    .pill{display:inline-block;font-size:6.8pt;font-weight:800;padding:2px 7px;border-radius:999px;letter-spacing:.3px;} .p-open{background:#dcfce7;color:#166534;} .p-del{background:#dbeafe;color:#1e40af;} .p-fail{background:#fee2e2;color:#991b1b;} .p-q{background:#f1f5f9;color:#475569;}
    .ev{border:1px solid #e2e8f0;border-radius:6px;padding:6px 8px;margin:4px 0;page-break-inside:avoid;background:#fafafa;} .ev table{width:100%;border-collapse:collapse;font-size:7.4pt;} .ev td{padding:1.5px 4px;vertical-align:top;} .ev .l{color:#64748b;width:16%;}
    .card{border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;margin:0 0 8px;page-break-inside:avoid;} .cert{margin-top:12px;padding-top:8px;border-top:2px solid #0f172a;font-size:7.5pt;color:#475569;line-height:1.55;}</style>';
}

function _mv_pill(string $label): string
{
    $cls = $label === 'Opened' ? 'p-open' : ($label === 'Delivered' ? 'p-del' : (in_array($label, ['Failed', 'Bounced', 'Error', 'Cancelled'], true) ? 'p-fail' : 'p-q'));
    return '<span class="pill ' . $cls . '">' . strtoupper($label) . '</span>';
}

/** "Customer Communication" — every email sent to the customer's address. */
function mv_render_customer_communication_pdf(array $o): string
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $rows = mv_customer_comm_rows((string)($o['email'] ?? ''), (int)($o['id'] ?? 0));
    $co = function_exists('company_info') ? company_info() : ['name' => 'Maventech', 'email' => ''];
    $tr = '';
    foreach ($rows as $em) {
        $label = mv_email_status_label($em);
        $type  = function_exists('mv_email_type_label') ? mv_email_type_label((string)($em['template_code'] ?? ''), (string)($em['html'] ?? '')) : (string)$em['template_code'];
        $tr .= '<tr><td>' . $e($em['recipient']) . '</td><td>' . $e($em['subject']) . '</td><td>' . $e($type) . '</td><td>' . _mv_pill($label) . '</td>'
             . '<td>' . $e($em['order_number'] ?: '—') . '</td><td style="text-align:center;">' . ((int)$em['opened_count'] ?: '—') . '</td>'
             . '<td style="white-space:nowrap;">' . ($em['created_at'] ? $e(date('M j, Y', strtotime($em['created_at']))) . '<br>' . $e(date('h:i A', strtotime($em['created_at']))) : '—') . '</td>'
             . '<td style="white-space:nowrap;">' . (!empty($em['opened_at']) ? $e(date('M j, Y', strtotime($em['opened_at']))) . '<br>' . $e(date('h:i A', strtotime($em['opened_at']))) : '—') . '</td></tr>';
    }
    if ($tr === '') $tr = '<tr><td colspan="8" style="color:#94a3b8;">No emails recorded for this customer.</td></tr>';
    $opened = count(array_filter($rows, fn($r) => !empty($r['opened_at'])));
    $html = '<!doctype html><html><head><meta charset="utf-8">' . _mv_doc_css() . '</head><body>'
        . _mv_doc_head_html($o, 'CUSTOMER COMMUNICATION', 'All emails sent to this customer', '#1d4ed8')
        . '<h2 style="border-left-color:#1d4ed8;">Communication log (' . count($rows) . ' emails · ' . $opened . ' opened)</h2>'
        . '<p style="font-size:7.5pt;color:#64748b;margin:2px 0 6px;">Every message our system sent to <strong>' . $e($o['email'] ?? '') . '</strong> — license delivery, order confirmation, activation check-ins, follow-ups, newsletters and support replies — newest first.</p>'
        . '<table class="grid"><thead><tr><th>Recipient</th><th>Subject</th><th>Type</th><th>Status</th><th>Order</th><th>Opens</th><th>Sent</th><th>Opened at</th></tr></thead><tbody>' . $tr . '</tbody></table>'
        . '<div class="cert"><strong>Certification:</strong> true and unaltered extract of the email-delivery log held by the ' . $e($co['name'] ?? '') . ' order-management system for ' . $e($o['email'] ?? '') . ', produced ' . gmdate('F j, Y H:i') . ' UTC. Timestamps are recorded automatically by the mail system (UTC). Contact: ' . $e($co['email'] ?? '') . '</div>'
        . '</body></html>';
    $d = _pdf_dompdf(); $d->loadHtml($html, 'UTF-8'); $d->setPaper('letter', 'portrait'); $d->render();
    return $d->output();
}

/** "Email Logs" — tracking details + every open event (IP, location, ISP, device, client). */
function mv_render_email_logs_pdf(array $o): string
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $rows = mv_customer_comm_rows((string)($o['email'] ?? ''), (int)($o['id'] ?? 0));
    $co = function_exists('company_info') ? company_info() : ['name' => 'Maventech', 'email' => ''];
    $cards = ''; $n = 0;
    foreach ($rows as $em) {
        $n++;
        $t = mv_email_tracking_data((int)$em['id']);
        if (!$t) continue;
        $ev = '';
        $k = count($t['events']);
        foreach ($t['events'] as $x) {
            $kindPill = $x['auto']
                ? '<span class="pill p-q">AUTOMATED FETCH — NOT AN OPEN</span>'
                : '<span class="pill p-open">CONFIRMED OPEN</span>';
            $ev .= '<div class="ev"><table><tr><td colspan="4" style="font-weight:800;color:#0f172a;">Event #' . $k . ' ' . $kindPill . ' <span style="float:right;font-weight:400;color:#64748b;">' . $e($x['opened_at']) . '</span></td></tr>'
                 . ($x['auto'] ? '<tr><td colspan="4" style="color:#64748b;font-size:7.2pt;">' . $e($x['reason']) . '</td></tr>' : '')
                 . '<tr><td class="l">IP address</td><td>' . $e($x['ip']) . '</td><td class="l">Location</td><td>' . $e($x['location']) . '</td></tr>'
                 . '<tr><td class="l">ISP / Network</td><td>' . $e($x['isp']) . '</td><td class="l">Device</td><td>' . $e($x['device']) . '</td></tr>'
                 . '<tr><td class="l">Mail client</td><td>' . $e($x['client']) . '</td><td class="l">User agent</td><td style="word-break:break-all;">' . $e($x['user_agent'] ?: '—') . '</td></tr></table></div>';
            $k--;
        }
        if ($t['legacy_opens'] > 0) $ev .= '<div style="font-size:7.2pt;color:#64748b;margin-top:3px;">+ ' . (int)$t['legacy_opens'] . ' earlier open(s) recorded before per-open device logging was enabled.</div>';
        if ($ev === '') $ev = '<div style="font-size:7.5pt;color:#94a3b8;">No open events recorded yet.</div>';
        $cards .= '<div class="card"><table style="width:100%;border-collapse:collapse;"><tr><td style="font-size:7pt;color:#64748b;font-weight:700;">EMAIL ' . $n . ' OF ' . count($rows) . ' · ' . $e($t['type']) . '</td><td style="text-align:right;">' . _mv_pill($t['status']) . '</td></tr></table>'
            . '<div style="font-size:9pt;font-weight:700;color:#0f172a;margin:4px 0;">' . $e($t['subject']) . '</div>'
            . '<table class="kv"><tr><td class="k">Recipient</td><td class="v">' . $e($t['recipient']) . '</td></tr>'
            . '<tr><td class="k">Order number</td><td class="v">' . $e($t['order_number'] ?: '—') . '</td></tr>'
            . '<tr><td class="k">Sent at</td><td class="v">' . $e($t['sent_at']) . '</td></tr>'
            . '<tr><td class="k">First opened</td><td class="v">' . $e($t['first_opened']) . '</td></tr>'
            . '<tr><td class="k">Confirmed opens</td><td class="v">' . (int)$t['total_opens'] . ($t['auto_fetches'] > 0 ? ' <span style="font-weight:400;color:#64748b;">(+ ' . (int)$t['auto_fetches'] . ' automated fetch(es) by the recipient\'s mail server, not counted)</span>' : '') . '</td></tr>'
            . '<tr><td class="k">Tracking ID</td><td class="v" style="font-family:\'DejaVu Sans Mono\',monospace;font-size:7.5pt;">' . $e($t['tracking_id']) . '</td></tr>'
            . ($t['last_error'] !== '' ? '<tr><td class="k">Delivery note</td><td class="v" style="color:#991b1b;">' . $e($t['last_error']) . '</td></tr>' : '')
            . '</table><div style="font-size:7.5pt;font-weight:800;color:#0f172a;margin:6px 0 2px;">Open events — dispute evidence</div>' . $ev . '</div>';
    }
    if ($cards === '') $cards = '<div style="font-size:8.5pt;color:#94a3b8;">No emails recorded for this customer.</div>';
    $html = '<!doctype html><html><head><meta charset="utf-8">' . _mv_doc_css() . '</head><body>'
        . _mv_doc_head_html($o, 'EMAIL LOGS & TRACKING', 'Delivery + open tracking evidence', '#7c3aed')
        . '<h2 style="border-left-color:#7c3aed;">Email tracking details (' . count($rows) . ' emails)</h2>'
        . '<p style="font-size:7.5pt;color:#64748b;margin:2px 0 8px;">Each time the recipient opened an email, the IP address, location, ISP, device and mail client were captured automatically. Automated image fetches made by the recipient\'s mail provider (Gmail prefetch, Apple Mail privacy proxy, security scanners) are listed for completeness but are <strong>not</strong> counted as opens. This can be used as evidence in bank/card disputes.</p>'
        . $cards
        . '<div class="cert"><strong>Certification:</strong> true and unaltered extract of the email-delivery and open-tracking log held by the ' . $e($co['name'] ?? '') . ' order-management system for ' . $e($o['email'] ?? '') . ', produced ' . gmdate('F j, Y H:i') . ' UTC. Contact: ' . $e($co['email'] ?? '') . '</div>'
        . '</body></html>';
    $d = _pdf_dompdf(); $d->loadHtml($html, 'UTF-8'); $d->setPaper('letter', 'portrait'); $d->render();
    return $d->output();
}
