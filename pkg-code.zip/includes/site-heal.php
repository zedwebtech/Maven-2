<?php
// One-time guarded site updates applied on any deploy (web bootstrap +
// scripts/seed-keywords.php). Cheap no-op once the guards are latched:
//   1. Toll-free number -> (888) 823-3590 across settings + all content tables
//   2. "Best Seller" badge on the five flagship (ad push) products
//   3. Buy-intent meta keywords per product (Google Ads plan v2)

function mv_autoheal_site_updates(): void
{
    try { db()->query('SELECT 1 FROM settings LIMIT 1'); } catch (Throwable $e) { return; }

    /* 1. Toll-free number ------------------------------------------------ */
    try {
        if ((string)setting_get('phone_normalized_current', '') !== '+18888233590') {
            $new = '(888) 823-3590';
            $map = [
                '+18888120952'      => '+18888233590',
                '+1 (888) 812-0952' => '+1 (888) 823-3590',
                '1-888-812-0952'    => $new,
                '(888) 812-0952'    => $new,
                '888-812-0952'      => $new,
                '888.812.0952'      => $new,
                '888 812 0952'      => '888 823 3590',
                '8888120952'        => '8888233590',
                '+18886329902'      => '+18888233590',
                '(888) 632-9902'    => $new,
                '888-632-9902'      => $new,
                '+18052941524'      => '+18888233590',
                '(805) 294-1524'    => $new,
                '805-294-1524'      => $new,
                '8052941524'        => '8888233590',
                '+18058239961'      => '+18888233590',
                '(805) 823-9961'    => $new,
                '805-823-9961'      => $new,
                '8058239961'        => '8888233590',
            ];
            foreach (['company_phone', 'contact_phone', 'support_phone', 'toll_free_phone'] as $k) {
                db()->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)')
                    ->execute([$k, $new]);
            }
            $sweep = [
                ['settings',           ['v']],
                ['pages',              ['content']],
                ['blog_posts',         ['content', 'excerpt', 'seo_meta_description']],
                ['email_templates',    ['html', 'body', 'subject']],
                ['email_outbox',       ['html', 'subject']],
                ['faqs',               ['question', 'answer']],
                ['category_faqs',      ['question', 'answer']],
                ['product_faqs',       ['question', 'answer']],
                ['reviews',            ['comment']],
                ['customer_reviews',   ['comment']],
                ['chat_messages',      ['body']],
                ['subscription_notes', ['note']],
                ['support_tickets',    ['message', 'admin_reply']],
                ['hubs',               ['content', 'intro']],
                ['orders',             ['note', 'admin_note']],
                ['products',           ['description', 'ai_summary']],
            ];
            foreach ($sweep as [$table, $cols]) {
                try { db()->query("SELECT 1 FROM `$table` LIMIT 1"); } catch (Throwable $e) { continue; }
                foreach ($cols as $col) {
                    try { db()->query("SELECT `$col` FROM `$table` LIMIT 1"); } catch (Throwable $e) { continue; }
                    foreach ($map as $old => $rep) {
                        try {
                            db()->prepare("UPDATE `$table` SET `$col` = REPLACE(`$col`, ?, ?) WHERE `$col` LIKE ?")
                                ->execute([$old, $rep, '%' . $old . '%']);
                        } catch (Throwable $e) { /* ignore */ }
                    }
                }
            }
            setting_set('phone_normalized_current', '+18888233590');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 2. Best Seller badges ---------------------------------------------- */
    try {
        if ((string)setting_get('bestseller_badges_v1', '') !== '1') {
            $flagships = [
                'windows-11-pro',
                'microsoft-office-2021-professional-plus-windows',
                'microsoft-office-2024-professional-plus-windows',
                'microsoft-office-home-business-2024-mac',
                'mcafee-premium-individual-1-year-unlimited-devices-usa',
            ];
            $in = implode(',', array_fill(0, count($flagships), '?'));
            db()->prepare("UPDATE products SET badge = 'Best Seller' WHERE slug IN ($in)")->execute($flagships);
            setting_set('bestseller_badges_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 3. Buy-intent meta keywords per product ----------------------------- */
    try {
        if ((string)setting_get('keywords_seeded_v2', '') !== '1') {
            try { db()->query('SELECT meta_keywords FROM products LIMIT 1'); }
            catch (Throwable $e) { db()->exec('ALTER TABLE products ADD COLUMN meta_keywords TEXT NULL'); }
            $KW = [
        'microsoft-office-2024-professional-plus-windows' => 'buy office 2024 professional plus, office 2024 professional plus product key, office 2024 professional plus price, office 2024 professional plus license, purchase office 2024 professional plus, buy office 2024 pro plus, office 2024 pro plus key',
        'microsoft-office-2024-professional-plus-lifetime-license-windows-pc' => 'buy office 2024 professional plus lifetime, office 2024 professional plus lifetime product key, office 2024 professional plus lifetime price, office 2024 professional plus lifetime license, purchase office 2024 professional plus lifetime, office 2024 lifetime license, office 2024 pro plus lifetime',
        'microsoft-office-home-2024-pc' => 'buy microsoft office home 2024, microsoft office home 2024 product key, microsoft office home 2024 price, microsoft office home 2024 license, purchase microsoft office home 2024',
        'microsoft-office-home-business-2024-pc' => 'buy office home and business 2024, office home and business 2024 product key, office home and business 2024 price, office home and business 2024 license, purchase office home and business 2024',
        'microsoft-office-2021-home-business-windows' => 'buy office 2021 home and business, office 2021 home and business product key, office 2021 home and business price, office 2021 home and business license, purchase office 2021 home and business',
        'microsoft-office-2021-professional-plus-windows' => 'buy office 2021 professional plus, office 2021 professional plus product key, office 2021 professional plus price, office 2021 professional plus license, purchase office 2021 professional plus, office 2021 pro plus buy',
        'microsoft-office-2021-home-student-windows' => 'buy office 2021 home and student, office 2021 home and student product key, office 2021 home and student price, office 2021 home and student license, purchase office 2021 home and student',
        'microsoft-word-2021-windows' => 'buy microsoft word 2021, microsoft word 2021 product key, microsoft word 2021 price, microsoft word 2021 license, purchase microsoft word 2021, buy microsoft word, microsoft word product key, microsoft word purchase',
        'microsoft-excel-2021-windows' => 'buy microsoft excel 2021, microsoft excel 2021 product key, microsoft excel 2021 price, microsoft excel 2021 license, purchase microsoft excel 2021, buy microsoft excel, microsoft excel product key',
        'microsoft-office-2019-home-student-windows' => 'buy office 2019 home and student, office 2019 home and student product key, office 2019 home and student price, office 2019 home and student license, purchase office 2019 home and student',
        'microsoft-office-2019-home-business-pc' => 'buy office 2019 home and business, office 2019 home and business product key, office 2019 home and business price, office 2019 home and business license, purchase office 2019 home and business',
        'microsoft-office-2019-professional-plus-windows' => 'buy office 2019 professional plus, office 2019 professional plus product key, office 2019 professional plus price, office 2019 professional plus license, purchase office 2019 professional plus',
        'microsoft-office-home-business-2024-mac' => 'buy office home and business 2024 for mac, office home and business 2024 for mac product key, office home and business 2024 for mac price, office home and business 2024 for mac license, purchase office home and business 2024 for mac, microsoft office home 2024 for mac, office home & business 2024 for mac',
        'microsoft-office-home-2024-mac' => 'buy microsoft office home 2024 mac, microsoft office home 2024 mac product key, microsoft office home 2024 mac price, microsoft office home 2024 mac license, purchase microsoft office home 2024 mac',
        'microsoft-office-2021-home-student-mac' => 'buy office 2021 home and student mac, office 2021 home and student mac product key, office 2021 home and student mac price, office 2021 home and student mac license, purchase office 2021 home and student mac',
        'microsoft-office-2021-home-business-mac' => 'buy office 2021 home and business mac, office 2021 home and business mac product key, office 2021 home and business mac price, office 2021 home and business mac license, purchase office 2021 home and business mac, buy microsoft office for mac',
        'microsoft-word-2021-mac-lifetime-license-no-subscription' => 'buy microsoft word for mac, microsoft word for mac product key, microsoft word for mac price, microsoft word for mac license, purchase microsoft word for mac, buy ms word for mac, word for mac one time purchase',
        'microsoft-excel-2021-mac-lifetime-license-no-subscription' => 'buy microsoft excel for mac, microsoft excel for mac product key, microsoft excel for mac price, microsoft excel for mac license, purchase microsoft excel for mac, buy excel for mac',
        'microsoft-office-home-and-business-2019-mac' => 'buy office 2019 home and business mac, office 2019 home and business mac product key, office 2019 home and business mac price, office 2019 home and business mac license, purchase office 2019 home and business mac',
        'microsoft-office-home-and-student-2019-mac' => 'buy office 2019 home and student mac, office 2019 home and student mac product key, office 2019 home and student mac price, office 2019 home and student mac license, purchase office 2019 home and student mac',
        'windows-11-home' => 'buy windows 11 home, windows 11 home product key, windows 11 home price, windows 11 home license, purchase windows 11 home, windows 11 home key',
        'windows-11-pro' => 'buy windows 11 pro, windows 11 pro product key, windows 11 pro price, windows 11 pro license, purchase windows 11 pro, buy windows 11 pro key, windows 11 pro lifetime license, where to buy windows 11 product key',
        'windows-10-home' => 'buy windows 10 home, windows 10 home product key, windows 10 home price, windows 10 home license, purchase windows 10 home, windows 10 home key',
        'windows-10-pro' => 'buy windows 10 pro, windows 10 pro product key, windows 10 pro price, windows 10 pro license, purchase windows 10 pro, windows 10 pro key, where do i buy a windows 10 product key',
        'microsoft-project-2024-professional-pc' => 'buy microsoft project 2024, microsoft project 2024 product key, microsoft project 2024 price, microsoft project 2024 license, purchase microsoft project 2024, buy microsoft project, ms project product key',
        'microsoft-project-professional-2021-pc' => 'buy microsoft project 2021, microsoft project 2021 product key, microsoft project 2021 price, microsoft project 2021 license, purchase microsoft project 2021, project professional 2021',
        'ms-project-professional-2019-pc' => 'buy microsoft project 2019, microsoft project 2019 product key, microsoft project 2019 price, microsoft project 2019 license, purchase microsoft project 2019',
        'microsoft-visio-2024-professional-windows-pc' => 'buy microsoft visio 2024, microsoft visio 2024 product key, microsoft visio 2024 price, microsoft visio 2024 license, purchase microsoft visio 2024, buy microsoft visio, ms visio product key',
        'microsoft-visio-2021-professional-windows-pc' => 'buy microsoft visio 2021, microsoft visio 2021 product key, microsoft visio 2021 price, microsoft visio 2021 license, purchase microsoft visio 2021, visio professional 2021',
        'ms-visio-professional-2019-pc' => 'buy microsoft visio 2019, microsoft visio 2019 product key, microsoft visio 2019 price, microsoft visio 2019 license, purchase microsoft visio 2019',
        'bitdefender-premium-vpn-unlimited-devices-1-year' => 'buy bitdefender premium vpn, bitdefender premium vpn price, bitdefender premium vpn deal, bitdefender premium vpn best price, bitdefender vpn price, bitdefender vpn unlimited devices',
        'bitdefender-antivirus-for-mac-1-mac-1-year' => 'buy bitdefender antivirus for mac, bitdefender antivirus for mac price, bitdefender antivirus for mac deal, bitdefender antivirus for mac best price, buy bitdefender antivirus, antivirus for mac buy, bitdefender for mac 1 year',
        'bitdefender-antivirus-for-mac-1-mac-2-years' => 'buy bitdefender for mac 2 years, bitdefender for mac 2 years price, bitdefender for mac 2 years deal, bitdefender for mac 2 years best price, bitdefender antivirus for mac 2 years',
        'bitdefender-antivirus-for-mac-3-mac-1-year' => 'buy bitdefender for 3 macs, bitdefender for 3 macs price, bitdefender for 3 macs deal, bitdefender for 3 macs best price, bitdefender antivirus 3 macs',
        'bitdefender-antivirus-for-mac-3-mac-2-years' => 'buy bitdefender 3 macs 2 years, bitdefender 3 macs 2 years price, bitdefender 3 macs 2 years deal, bitdefender 3 macs 2 years best price',
        'bitdefender-small-office-security-5-devices-1-year' => 'buy bitdefender small office security, bitdefender small office security price, bitdefender small office security deal, bitdefender small office security best price, antivirus for small business, business antivirus 5 devices',
        'mcafee-premium-individual-1-year-unlimited-devices-usa' => 'buy mcafee premium, mcafee premium price, mcafee premium deal, mcafee premium best price, buy mcafee antivirus, mcafee unlimited devices, mcafee 1 year subscription',
            ];
            $st = db()->prepare('UPDATE products SET meta_keywords = ? WHERE slug = ?');
            foreach ($KW as $slug => $kw) {
                try { $st->execute([$kw, $slug]); } catch (Throwable $e) { /* ignore */ }
            }
            setting_set('keywords_seeded_v2', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 4+5. (Removed) The old 50-120-per-product "review volume boost" and the
           date-spreader are SUPERSEDED by the reviews-seed v5 rebalance
           (includes/reviews-seed.php): 1,100-1,500 total, 3-7/day, unique
           names, every review with a comment. Kept the old guards untouched
           so already-healed hosts don't re-run anything. */

    /* 6. Live "sold" counter — snapshot today's derived baseline once, then
          every real PAID order adds its units on top (see product_sold_count). */
    try {
        if ((string)setting_get('sold_base_v1', '') !== '1') {
            try { db()->query('SELECT sold_base FROM products LIMIT 1'); }
            catch (Throwable $e) { db()->exec('ALTER TABLE products ADD COLUMN sold_base INT NOT NULL DEFAULT 0'); }
            db()->exec("UPDATE products p
                        SET p.sold_base = 3 * (SELECT COUNT(*) FROM customer_reviews r
                                               WHERE r.product_slug = p.slug
                                                 AND r.status = 'published'
                                                 AND r.rating IS NOT NULL)");
            setting_set('sold_base_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 7. Card gateway label ALWAYS matches the active provider type + creds.
          Runs every load (writes only on mismatch) so a stale "Stripe" label
          can never stick while NMI/Authorize.Net/Custom is the real gateway. */
    try {
        $type = (string)setting_get('gw_card_provider_type', 'stripe');
        $hasCreds = [
            'stripe'  => setting_get('gw_card_secret_key', '') !== '' || setting_get('gw_card_secret_key_test', '') !== '' || setting_get('gw_card_secret_key_live', '') !== '',
            'nmi'     => setting_get('gw_nmi_security_key_test', '') !== '' || setting_get('gw_nmi_security_key_live', '') !== '',
            'authnet' => (setting_get('gw_authnet_login_id_test', '') !== '' && setting_get('gw_authnet_transaction_key_test', '') !== '')
                      || (setting_get('gw_authnet_login_id_live', '') !== '' && setting_get('gw_authnet_transaction_key_live', '') !== ''),
            'custom'  => setting_get('gw_custom_api_key_test', '') !== '' || setting_get('gw_custom_api_key_live', '') !== '',
        ];
        if (empty($hasCreds[$type])) {
            foreach (['nmi', 'authnet', 'custom', 'stripe'] as $cand) {
                if ($cand !== $type && $hasCreds[$cand]) {
                    $type = $cand;
                    setting_set('gw_card_provider_type', $type);
                    break;
                }
            }
        }
        $names = ['nmi' => 'NMI', 'authnet' => 'Authorize.Net', 'custom' => ((string)setting_get('gw_custom_name', '') !== '' ? (string)setting_get('gw_custom_name', '') : 'Custom Gateway'), 'stripe' => 'Stripe'];
        $label = $names[$type] ?? 'Stripe';
        if ((string)setting_get('gw_card_provider', '') !== $label) {
            setting_set('gw_card_provider', $label);
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 8. Vendor URLs — every product must carry Download + Guide URLs so the
          delivery email always shows Download / Sign-in / Guide buttons. */
    try {
        if ((string)setting_get('vendor_urls_v1', '') !== '1') {
            $fills = [
                ['%bitdefender%vpn%', 'https://central.bitdefender.com', 'https://www.bitdefender.com/consumer/support/answer/13418/'],
                ['%bitdefender%',     'https://central.bitdefender.com', 'https://www.bitdefender.com/consumer/support/'],
                ['%mcafee%',          'https://home.mcafee.com',         'https://www.mcafee.com/support/'],
                ['%norton%',          'https://norton.com/setup',        'https://support.norton.com/'],
            ];
            $updDl = db()->prepare("UPDATE products SET installer_url = ? WHERE name LIKE ? AND (installer_url IS NULL OR installer_url = '')");
            $updG  = db()->prepare("UPDATE products SET install_guide_url = ? WHERE name LIKE ? AND (install_guide_url IS NULL OR install_guide_url = '')");
            foreach ($fills as [$like, $dl, $g]) {
                $updDl->execute([$dl, $like]);
                $updG->execute([$g, $like]);
            }
            setting_set('vendor_urls_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 9. Query-speed indexes for the admin panel (idempotent). */
    try {
        if ((string)setting_get('perf_idx_v1', '') !== '1') {
            $idx = [
                "ALTER TABLE email_outbox ADD INDEX idx_outbox_order (order_id)",
                "ALTER TABLE email_outbox ADD INDEX idx_outbox_tpl (template_code)",
                "ALTER TABLE email_outbox ADD INDEX idx_outbox_created (created_at)",
                "ALTER TABLE customer_reviews ADD INDEX idx_cr_slug_status (product_slug, status)",
                "ALTER TABLE orders ADD INDEX idx_orders_created (created_at)",
                "ALTER TABLE orders ADD INDEX idx_orders_status (status)",
                "ALTER TABLE license_keys ADD INDEX idx_lk_slug_status (product_slug, status)",
            ];
            foreach ($idx as $sql) { try { db()->exec($sql); } catch (Throwable $e) { /* exists */ } }
            setting_set('perf_idx_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 10. Original (MSRP) prices — every product ships with a realistic
           "was" price out of the box so the % OFF pill + strike-through
           render without manual setup. Fills ONLY where original_price is
           empty/0 and runs once (guard), so any value the admin edits or
           clears afterwards is never overwritten. Deterministic per slug:
           13-40% off, always ending in .99. */
    try {
        if ((string)setting_get('orig_price_seed_v1', '') !== '1') {
            $rows = db()->query("SELECT slug, price FROM products WHERE (original_price IS NULL OR original_price = 0) AND price > 0")->fetchAll();
            if ($rows) {
                $upd = db()->prepare('UPDATE products SET original_price = ? WHERE slug = ?');
                foreach ($rows as $r) {
                    $factor = 1.15 + ((crc32('op1|' . $r['slug']) % 26) / 100); // 1.15 .. 1.40
                    $orig   = floor((float)$r['price'] * $factor) + 0.99;
                    if ($orig <= (float)$r['price']) $orig = floor((float)$r['price'] * 1.2) + 0.99;
                    $upd->execute([number_format($orig, 2, '.', ''), $r['slug']]);
                }
            }
            setting_set('orig_price_seed_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* 11. Payment Policy wording (tracking audit 2026-09, Change 11): the page
           advertised Apple Pay / G Pay (not offered) and "charged in EUR/GBP/
           CAD/AUD" while checkout bills in USD unless a currency is gateway-
           live. Exact-match replacements only, run once — an admin-edited
           page is left untouched. Data-only (no DDL). */
    try {
        if ((string)setting_get('payment_policy_text_v1', '') !== '1') {
            $st = db()->prepare('SELECT content FROM pages WHERE slug = ? LIMIT 1');
            $st->execute(['payment-policy']);
            $html = (string)($st->fetchColumn() ?: '');
            if ($html !== '') {
                $new = str_replace([
                    "\n<tr><td><span class=\"pay-badge me-1\">Apple Pay</span><span class=\"pay-badge\">G Pay</span></td><td>One-tap checkout on supported devices</td></tr>",
                    "<td>All major credit and debit cards</td>",
                    "<td>Pay with balance or linked methods</td>",
                    "<p>Prices can be displayed and charged in <strong>USD, EUR, GBP, CAD, and AUD</strong>. Select your currency from the menu in the site header — totals update automatically.</p>",
                ], [
                    "",
                    "<td>All major credit and debit cards — entered on PCI-DSS compliant hosted card fields</td>",
                    "<td>Pay with your PayPal balance, a linked bank account, or a debit/credit card as a PayPal guest</td>",
                    "<p>Prices can be <strong>displayed</strong> in <strong>USD, EUR, GBP, CAD, and AUD</strong> — select your currency from the menu in the site header and totals update automatically. Payments are <strong>charged in USD</strong> unless your currency is shown as the checkout currency; the exact amount you will be charged is always displayed on the checkout page before you pay, and your bank converts it at its own rate.</p>",
                ], $html);
                if ($new !== $html) {
                    db()->prepare('UPDATE pages SET content = ? WHERE slug = ?')->execute([$new, 'payment-policy']);
                }
            }
            setting_set('payment_policy_text_v1', '1');
        }
    } catch (Throwable $e) { /* ignore */ }

    /* Volume Licensing reset — clear the existing (spam) volume-pricing leads
       ONE TIME on deploy so Admin → Lead Management → Volume Licensing starts
       completely empty on the live domain. Latched by a settings flag, so any
       genuine volume request submitted AFTER the reset is kept. Bump the flag
       suffix (v1 → v2…) if you ever want to force another clean-out. */
    try {
        if ((string)setting_get('volume_leads_reset_v1', '') !== '1') {
            try { db()->exec("DELETE FROM support_messages WHERE subject='Volume / Business Pricing'"); } catch (Throwable $e) {}
            setting_set('volume_leads_reset_v1', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* Purge the fake-lead notification backlog ONE TIME on deploy. The spam
       flood posted to contact.php with the (now-invalid) "Volume / Business
       Pricing" subject, creating "New contact message" bell notifications.
       Genuine leads use other subjects / titles and are preserved. */
    try {
        if ((string)setting_get('notif_spam_purge_v1', '') !== '1') {
            try {
                db()->exec("DELETE FROM admin_notifications
                             WHERE type='lead'
                               AND title LIKE 'New contact message%'
                               AND body = 'Volume / Business Pricing'");
            } catch (Throwable $e) {}
            setting_set('notif_spam_purge_v1', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Volume Licensing CLEAN RESET (v2) ──────────────────────────────────
       The old 'Volume / Business Pricing' pipeline got overrun with spam and
       its notifications were corrupted, so on deploy we wipe it completely and
       start the fresh 'Volume Licensing Request' pipeline from zero. Latched by
       a flag; genuine requests submitted AFTER this reset are kept. Bump the
       suffix (v2 → v3…) to force another clean-out in future. */
    try {
        if ((string)setting_get('volume_clean_reset_v2', '') !== '1') {
            // 1) delete every old-tag volume lead (active + archived)
            try { db()->exec("DELETE FROM support_messages WHERE subject='Volume / Business Pricing'"); } catch (Throwable $e) {}
            // 2) delete every old volume notification (bell) — identified by the
            //    volume deep-link or a volume title, so contact alerts survive.
            try {
                db()->exec("DELETE FROM admin_notifications
                             WHERE link LIKE '%view=volume%'
                                OR title LIKE '%olume %icensing%'
                                OR title LIKE '%olume / Business%'");
            } catch (Throwable $e) {}
            setting_set('volume_clean_reset_v2', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Volume notifications: PERMANENT bell purge (v4) ────────────────────
       The activity bell kept showing fake "Volume / Business Pricing" alerts
       (spam posted to the contact form with that subject). On deploy, wipe
       every volume-related bell notification for good. The bell queries also
       exclude them going forward, and admin_notify() now drops them at the
       single choke point (bell + Web Push), so they can never reappear. Safe
       because a legitimate non-volume notification never contains "Volume". */
    try {
        if ((string)setting_get('volume_notif_purge_v4', '') !== '1') {
            try {
                db()->exec("DELETE FROM admin_notifications
                             WHERE title LIKE '%Volume%'
                                OR body  LIKE '%Volume%'
                                OR body  LIKE '%Business Pricing%'
                                OR link  LIKE '%view=volume%'");
            } catch (Throwable $e) {}
            setting_set('volume_notif_purge_v4', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Volume Licensing FULLY REMOVED: purge old volume leads (v5) ─────────
       Volume Licensing was removed from the whole site (admin tab, storefront
       blocks, product "Request a Quote"). Delete every leftover volume lead so
       the old fake/bot enquiries don't linger anywhere. Covers both the modal
       subject ('Volume Licensing Request') and the old contact-form spam
       subject ('Volume / Business Pricing'). */
    try {
        if ((string)setting_get('volume_leads_purge_v5', '') !== '1') {
            try {
                db()->exec("DELETE FROM support_messages
                             WHERE subject IN ('Volume Licensing Request','Volume / Business Pricing')");
            } catch (Throwable $e) {}
            setting_set('volume_leads_purge_v5', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Volume Licensing FULLY REMOVED: purge queued volume emails (v6) ─────
       Stuck/retrying "Volume Licensing" admin emails in the send queue kept
       getting re-delivered to the owner's inbox. On deploy, cancel every one
       so none can ever send again. Only targets the volume admin template and
       the old volume subjects — order/receipt emails are never matched. */
    try {
        if ((string)setting_get('volume_outbox_purge_v6', '') !== '1') {
            try {
                db()->exec("UPDATE email_outbox
                               SET status='cancelled', next_retry_at=NULL,
                                   last_error='Volume licensing removed — email suppressed'
                             WHERE status IN ('queued','retrying')
                               AND (template_code='volume_request_admin'
                                    OR subject LIKE '%Volume%'
                                    OR subject LIKE '%Business Pricing%')");
            } catch (Throwable $e) {}
            setting_set('volume_outbox_purge_v6', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Volume emails: cancel in EVERY non-sent state (v7) ─────────────────
       v6 only touched queued/retrying. Failed/bounced volume rows could still
       be revived by a "Retry" click. Cancel them all so no path can resend. */
    try {
        if ((string)setting_get('volume_outbox_purge_v7', '') !== '1') {
            try {
                db()->exec("UPDATE email_outbox
                               SET status='cancelled', next_retry_at=NULL,
                                   last_error='Volume licensing removed — email suppressed'
                             WHERE status <> 'sent'
                               AND (template_code='volume_request_admin'
                                    OR subject LIKE '%Volume%'
                                    OR subject LIKE '%Business Pricing%'
                                    OR subject LIKE '%Bulk Licens%')");
            } catch (Throwable $e) {}
            setting_set('volume_outbox_purge_v7', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Email opens: ignore automated fetches (v1) ──────────────────────────
       Gmail's prefetch bot / Apple Mail privacy proxy / security scanners hit
       the tracking pixel seconds after delivery, so emails showed "Customer
       Opened" the moment they were sent. Re-score every logged open once so
       only real opens remain; the pixel endpoint now scores live hits. */
    /* ── Email templates: hard-coded "M" letter badge → live brand logo (v1) ──
       The seeded templates carried a literal blue "M" tile beside the company
       name. Swap it for the Company Info logo (or company-name monogram) via
       the existing {{brand_logo_src}} placeholder so a logo upload reaches
       every transactional email too. Exact-string DML; nothing else touched. */
    try {
        if ((string)setting_get('email_tpl_brand_mark_v1', '') !== '1') {
            $img = '<img src="{{brand_logo_src}}" alt="" height="28" style="display:inline-block;height:28px;width:auto;max-width:140px;border-radius:7px;margin-right:8px;vertical-align:-6px;">';
            $old = [
                '<span style="display:inline-block;width:28px;height:28px;background:linear-gradient(135deg,#0ea5e9,#2563eb);color:#fff;border-radius:7px;text-align:center;line-height:28px;font-weight:900;margin-right:8px;vertical-align:-6px;">M</span>',
                '<span style="display:inline-block;width:30px;height:30px;background:#fff;color:#2563eb;border-radius:8px;text-align:center;line-height:30px;font-weight:900;margin-right:8px;vertical-align:-8px;">M</span>',
            ];
            foreach ($old as $span) {
                db()->prepare('UPDATE email_templates SET html = REPLACE(html, ?, ?) WHERE html LIKE ?')
                    ->execute([$span, $img, '%' . $span . '%']);
            }
            setting_set('email_tpl_brand_mark_v1', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Privacy Policy: SMS / text-messaging consent language (v1) ──────
       Required for SMS (A2P 10DLC / toll-free) registration: the policy must
       state that mobile numbers + SMS opt-in consent are never sold or shared
       with third parties for marketing, plus opt-in / STOP / HELP / rates
       disclosures. Exact-string DML on the seeded Privacy + Do-Not-Sell pages;
       admin-edited wording elsewhere on those pages is untouched. */
    try {
        if ((string)setting_get('privacy_sms_policy_v1', '') !== '1') {
            $pdo = db();
            $rep = function (string $slug, string $old, string $new) use ($pdo): void {
                $pdo->prepare('UPDATE pages SET content = REPLACE(content, ?, ?) WHERE slug = ? AND content LIKE ? AND content NOT LIKE ?')
                    ->execute([$old, $new, $slug, '%' . $old . '%', '%' . $new . '%']);
            };
            $rep('privacy-policy',
                '<strong>We never sell your personal information.</strong> Data is shared only with the service providers required to complete your order (payment processing, email delivery) — nothing more.',
                '<strong>We never sell your personal and SMS consent information.</strong> Data is shared only with the service providers required to complete your order (payment processing, email delivery) — nothing more. Mobile phone numbers and SMS opt-in consent are never sold, rented or shared with third parties or affiliates for marketing purposes.');
            $rep('privacy-policy',
                '<tr><td><strong>Usage data</strong></td><td>Pages visited, device type</td><td>To improve the store experience</td></tr>',
                '<tr><td><strong>Usage data</strong></td><td>Pages visited, device type</td><td>To improve the store experience</td></tr>' . "\n"
                . '<tr><td><strong>Phone number</strong></td><td>Mobile number you give us at checkout, on the contact form or in chat</td><td>To reach you about your order, a requested call-back, or by text message where you have opted in</td></tr>');
            $rep('privacy-policy',
                '<tr><td><span class="badge text-bg-primary">Opt-out</span></td><td>Unsubscribe from marketing at any time</td></tr>',
                '<tr><td><span class="badge text-bg-primary">Opt-out</span></td><td>Unsubscribe from marketing emails at any time; reply <strong>STOP</strong> to end text messages</td></tr>');
            $rep('privacy-policy',
                '<h2><i class="bi bi-person-fill-check text-primary me-2"></i>Your Rights</h2>',
                '<h2 id="sms-policy"><i class="bi bi-chat-dots-fill text-primary me-2"></i>SMS / Text Messaging Policy</h2>' . "\n"
                . '<p>If you provide your mobile number and opt in (by ticking the SMS consent box on our forms, asking for a call-back or text in chat, or texting us first), {{company_name}} may send you text messages about your order and support requests. Consent to receive texts is <strong>not</strong> a condition of purchase.</p>' . "\n"
                . '<table class="table table-bordered align-middle">' . "\n"
                . '<tbody>' . "\n"
                . '<tr><td style="width:220px;"><strong>What we may text you</strong></td><td>Order confirmations, license-key delivery notices, activation and installation help, call-back scheduling, and replies to your support requests. Promotional texts are sent only if you separately opt in to them.</td></tr>' . "\n"
                . '<tr><td><strong>Message frequency</strong></td><td>Varies — typically 1–5 messages per order or support conversation.</td></tr>' . "\n"
                . '<tr><td><strong>Cost</strong></td><td>Message and data rates may apply according to your mobile plan. Carriers are not liable for delayed or undelivered messages.</td></tr>' . "\n"
                . '<tr><td><strong>Opt out</strong></td><td>Reply <strong>STOP</strong> to any message to cancel at any time; you will receive a one-time confirmation and no further texts. Reply <strong>HELP</strong> for help, or contact <a href="mailto:{{company_email}}">{{company_email}}</a> / <a href="tel:{{support_phone_tel}}">{{support_phone}}</a>.</td></tr>' . "\n"
                . '<tr><td><strong>No sharing of SMS consent</strong></td><td>Your mobile number and SMS opt-in consent are <strong>never sold, rented or shared</strong> with third parties or affiliates for marketing or promotional purposes. They are shared only with the messaging provider that transmits the texts you requested, and only for that purpose.</td></tr>' . "\n"
                . '</tbody>' . "\n"
                . '</table>' . "\n\n"
                . '<h2><i class="bi bi-person-fill-check text-primary me-2"></i>Your Rights</h2>');
            $rep('do-not-sell',
                'we do not sell personal information.',
                'we do not sell personal information — including mobile phone numbers and SMS opt-in consent, which are never shared with third parties or affiliates for marketing.');
            setting_set('privacy_sms_policy_v1', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

    /* ── Terms of Service: "8. Text Messaging (SMS) Terms" (v1) ─────────────
       Inserts the shared {{sms_disclosure}} block (same wording as About Us
       and Contact) just above the closing "Questions about this policy?" card. */
    try {
        if ((string)setting_get('terms_sms_section_v1', '') !== '1') {
            $anchor = '<div class="card p-4 mt-4"><h5 class="fw-bold mb-2">Questions about this policy?</h5>';
            $section = '<h2 id="sms-terms"><span class="badge text-bg-primary me-2">8</span>Text Messaging (SMS) Terms</h2>' . "\n"
                . '<p>Customer-care text messages are an optional convenience. The disclosure below applies whenever you text us or opt in to receive texts from us; the full policy is in our <a href="page.php?slug=privacy-policy#sms-policy">Privacy Policy</a>.</p>' . "\n"
                . '{{sms_disclosure}}' . "\n\n";
            db()->prepare('UPDATE pages SET content = REPLACE(content, ?, ?) WHERE slug = ? AND content LIKE ? AND content NOT LIKE ?')
                ->execute([$anchor, $section . $anchor, 'terms-of-service', '%' . $anchor . '%', '%{{sms_disclosure}}%']);
            setting_set('terms_sms_section_v1', '1');
        }
    } catch (Throwable $e) { /* best-effort */ }

}
