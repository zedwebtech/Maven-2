<?php /* Shared "Email Tracking Details" popup — include once per admin page; buttons use .mv-track-btn[data-email-id] */ ?>
<!-- Email Tracking Details popup (dispute evidence) -->
<div class="modal fade" id="mvTrackModal" tabindex="-1" aria-hidden="true" data-testid="email-tracking-modal">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content" style="border-radius:16px;">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold"><i class="bi bi-shield-check me-2 text-primary"></i>Email Tracking Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body pt-2">
        <ul class="nav nav-tabs mb-3" style="font-size:13px;">
          <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#mvTrackPane" type="button" data-testid="tracking-tab-details"><i class="bi bi-activity me-1"></i>Tracking Details</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#mvContentPane" type="button" id="mvContentTab" data-testid="tracking-tab-content"><i class="bi bi-file-text me-1"></i>Email Content</button></li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane fade show active" id="mvTrackPane"><div id="mvTrackBody" class="text-muted small">Loading…</div></div>
          <div class="tab-pane fade" id="mvContentPane"><iframe id="mvContentFrame" title="Email content" style="width:100%;height:520px;border:1px solid var(--border);border-radius:10px;background:#fff;"></iframe></div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  var esc = function(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };
  var pill = function(st){ var m={Opened:'#dcfce7;color:#166534',Delivered:'#dbeafe;color:#1e40af',Queued:'#f1f5f9;color:#475569'}; var c=m[st]||'#fee2e2;color:#991b1b'; return '<span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:800;background:'+c+'">'+esc(st)+'</span>'; };
  var kv = function(k,v){ return '<div class="col-6 col-md-4 mb-3"><div style="font-size:10px;letter-spacing:1px;color:#64748b;font-weight:700;text-transform:uppercase;">'+k+'</div><div style="font-size:13px;font-weight:600;word-break:break-all;">'+v+'</div></div>'; };
  var modalEl = document.getElementById('mvTrackModal');
  document.querySelectorAll('.mv-track-btn').forEach(function(b){
    b.addEventListener('click', function(){
      var id = b.getAttribute('data-email-id');
      var body = document.getElementById('mvTrackBody'); body.innerHTML = 'Loading…';
      document.getElementById('mvContentFrame').src = 'email-view.php?id=' + id + '&raw=1';
      bootstrap.Modal.getOrCreateInstance(modalEl).show();
      fetch('ajax/email-tracking.php?id=' + id, {credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
        if (!j.ok) { body.innerHTML = '<div class="text-danger">'+esc(j.error||'Could not load tracking details')+'</div>'; return; }
        var h = '<div class="row" data-testid="tracking-summary">' + kv('Recipient', esc(j.recipient)) + kv('Status', pill(j.status)) + kv('Type', '<span style="background:#ede9fe;color:#5b21b6;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;">'+esc(j.type)+'</span>')
          + kv('Subject', esc(j.subject)) + kv('Order number', esc(j.order_number||'—')) + kv('Sent at', esc(j.sent_at))
          + kv('First opened', esc(j.first_opened)) + kv('Confirmed opens', esc(j.total_opens) + (j.auto_fetches>0 ? ' <span class="text-muted fw-normal" style="font-size:11px;">+ '+esc(j.auto_fetches)+' automated fetch(es), not counted</span>' : '')) + kv('Tracking ID', '<code style="font-size:11px;">'+esc(j.tracking_id)+'</code>') + '</div>';
        if (j.last_error) h += '<div class="alert alert-danger py-2 px-3" style="font-size:12px;"><i class="bi bi-exclamation-triangle-fill me-1"></i>'+esc(j.last_error)+'</div>';
        h += '<hr class="my-2"><div class="fw-bold mb-1" style="font-size:13.5px;"><i class="bi bi-eye me-1"></i>Open Events — Dispute Evidence</div><div class="text-muted mb-2" style="font-size:12px;">Each time the recipient opens the email, the following data is captured. Automated image fetches by the recipient\'s mail provider (Gmail prefetch, Apple Mail privacy proxy, security scanners) are shown in gray and are <strong>not</strong> counted as opens.</div>';
        if (!j.events.length) h += '<div class="text-muted small" data-testid="tracking-no-events">No open events recorded yet' + (j.legacy_opens>0 ? ' (' + j.legacy_opens + ' earlier open(s) counted before per-open device logging was enabled).' : '.') + '</div>';
        var n = j.events.length;
        j.events.forEach(function(ev){
          var kindPill = ev.auto
            ? '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:800;background:#f1f5f9;color:#475569;" data-testid="open-event-kind-auto"><i class="bi bi-robot me-1"></i>AUTOMATED FETCH — NOT AN OPEN</span>'
            : '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:800;background:#dcfce7;color:#166534;" data-testid="open-event-kind-human"><i class="bi bi-person-check me-1"></i>CONFIRMED OPEN</span>';
          h += '<div style="border:1px solid var(--border);border-radius:12px;padding:12px 14px;margin-bottom:10px;background:'+(ev.auto ? 'rgba(148,163,184,.08)' : 'rgba(16,185,129,.05)')+';'+(ev.auto ? 'opacity:.85;' : '')+'" data-testid="open-event">'
            + '<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2" style="font-size:12.5px;"><span><strong><i class="bi bi-globe2 me-1"></i>Event #'+n+'</strong> '+kindPill+'</span><span class="text-muted"><i class="bi bi-clock me-1"></i>'+esc(ev.opened_at)+'</span></div>'
            + (ev.auto ? '<div class="text-muted mb-2" style="font-size:11.5px;"><i class="bi bi-info-circle me-1"></i>'+esc(ev.reason)+'</div>' : '')
            + '<div class="row" style="font-size:12.5px;">'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-hdd-network me-1"></i>IP Address</div><div class="fw-semibold">'+esc(ev.ip||'—')+'</div></div>'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-geo-alt me-1"></i>Location</div><div class="fw-semibold">'+esc(ev.location)+'</div></div>'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-wifi me-1"></i>ISP / Network</div><div class="fw-semibold">'+esc(ev.isp)+'</div></div>'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-laptop me-1"></i>Device</div><div class="fw-semibold">'+esc(ev.device)+'</div></div>'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-window me-1"></i>Browser / Email Client</div><div class="fw-semibold">'+esc(ev.client)+'</div></div>'
            + '<div class="col-md-6 mb-2"><div class="text-muted" style="font-size:11px;"><i class="bi bi-code-slash me-1"></i>Full User Agent</div><div style="font-size:11px;word-break:break-all;color:#475569;">'+esc(ev.user_agent||'—')+'</div></div>'
            + '</div></div>';
          n--;
        });
        body.innerHTML = h;
      }).catch(function(){ body.innerHTML = '<div class="text-danger">Could not load tracking details.</div>'; });
    });
  });
})();
</script>
