<?php
/**
 * Follow-up Emails Module
 * ----------------------------------------------------------------------
 * Two automatic, PRODUCT-SPECIFIC post-delivery check-ins for every customer
 * whose license key / download was actually delivered:
 *   Stage 3  — 24 h after delivery  "Is <product> installed & working?"
 *   Stage 1  — 72 h after delivery  "Still need a hand with <product>?"
 * Hours are adjustable via settings followup_hours_checkin (24) and
 * followup_hours_help (72); master switch followup_enabled (1).
 *
 * Skipped automatically (decided at send time, never at schedule time):
 *   • order no longer paid (refunded / voided / cancelled)
 *   • a refund request exists for the order
 *   • the customer already contacted support after buying (contact form,
 *     live chat message) — we never nag someone who is already talking to us
 *   • the address unsubscribed
 *
 * Sending is automatic: includes/autocron.php (page-view scheduler) and
 * cron.php both call send_pending_followups() then drain the SMTP queue.
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/email.php';
require_once __DIR__ . '/install-guides.php';

function ensure_followup_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $pdo = db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS email_followup_schedule (
            id            BIGINT      NOT NULL AUTO_INCREMENT PRIMARY KEY,
            order_id      INT         NOT NULL,
            email         VARCHAR(190) NOT NULL,
            stage         TINYINT     NOT NULL DEFAULT 1,
            scheduled_at  DATETIME    NOT NULL,
            sent_at       DATETIME    NULL DEFAULT NULL,
            status        ENUM('pending','sent','skipped','failed') NOT NULL DEFAULT 'pending',
            note          VARCHAR(255) NOT NULL DEFAULT '',
            created_at    TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_order_stage (order_id, stage),
            KEY idx_status_time (status, scheduled_at),
            KEY idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS email_unsubscribes (
            id             INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
            email          VARCHAR(190) NOT NULL,
            reason         VARCHAR(120) NOT NULL DEFAULT '',
            source         VARCHAR(40)  NOT NULL DEFAULT 'link',
            unsubscribed_at TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) {
        @error_log('[followup schema] ' . $e->getMessage());
    }
}

function followup_enabled(): bool
{
    return setting_get('followup_enabled', '1') === '1';
}

/**
 * Schedule the two follow-up rows for an order — call this when the license
 * key / download has actually been delivered (the clock starts at delivery).
 * UNIQUE(order_id, stage) makes this safe to call multiple times.
 */
function schedule_order_followups(int $orderId, string $email): void
{
    ensure_followup_schema();
    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;
    if (is_email_unsubscribed($email)) return;

    $hCheckin = max(1, (int)setting_get('followup_hours_checkin', '24'));
    $hHelp    = max($hCheckin + 1, (int)setting_get('followup_hours_help', '72'));
    try {
        $pdo = db();
        $stmt = $pdo->prepare('INSERT IGNORE INTO email_followup_schedule
            (order_id, email, stage, scheduled_at, status)
            VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? HOUR), "pending")');
        $stmt->execute([$orderId, $email, 3, $hCheckin]);   // 24 h — installed & working?
        $stmt->execute([$orderId, $email, 1, $hHelp]);      // 72 h — still need a hand?
    } catch (Throwable $e) {
        @error_log('[schedule_order_followups] ' . $e->getMessage());
    }
}

/** Order + its items joined with product data (image, platform, install links). */
function followup_load_order(int $orderId): ?array
{
    try {
        $pdo = db();
        $st = $pdo->prepare('SELECT id, order_number, email, first_name, last_name, total, currency, status, pro_assist, payment_method, card_statement_name, created_at, timeline
                             FROM orders WHERE id = ? LIMIT 1');
        $st->execute([$orderId]);
        $order = $st->fetch(PDO::FETCH_ASSOC);
        if (!$order) return null;
        $it = $pdo->prepare('SELECT oi.product_slug, oi.name, oi.qty, p.image, p.platform, p.brand, p.category,
                                    p.activation_url, p.install_guide_url, p.installer_url
                             FROM order_items oi LEFT JOIN products p ON p.slug = oi.product_slug
                             WHERE oi.order_id = ? ORDER BY oi.id');
        $it->execute([$orderId]);
        $order['items'] = followup_attach_delivery($orderId, followup_decorate_items($it->fetchAll(PDO::FETCH_ASSOC)));
        $tl = json_decode((string)($order['timeline'] ?? ''), true) ?: [];
        $order['delivered_at'] = (string)($tl['email_sent'] ?? $tl['payment_completed'] ?? $order['created_at'] ?? '');
        return $order;
    } catch (Throwable $e) {
        @error_log('[followup_load_order] ' . $e->getMessage());
        return null;
    }
}

/**
 * What the customer ACTUALLY received for each line: the license key that was
 * sent (license_keys row, or the key in the latest delivery email when the
 * admin edited it) and/or the pre-activated download link (lives only in the
 * sent email HTML). Sets $it['key'] and $it['preactivated_url'].
 */
function followup_attach_delivery(int $orderId, array $items): array
{
    $pdo = db();
    $bySlug = [];
    try {
        $st = $pdo->prepare('SELECT product_slug, license_key FROM license_keys WHERE order_id = ? ORDER BY id');
        $st->execute([$orderId]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $k) { if (!isset($bySlug[$k['product_slug']])) $bySlug[$k['product_slug']] = (string)$k['license_key']; }
    } catch (Throwable $e) {}

    $emailKeys = []; $preUrl = '';
    try {
        $st = $pdo->prepare("SELECT html FROM email_outbox WHERE order_id = ? AND template_code = 'order_delivery' AND status <> 'failed' ORDER BY id DESC LIMIT 1");
        $st->execute([$orderId]);
        $html = (string)($st->fetchColumn() ?: '');
        if ($html !== '') {
            if (preg_match_all('#<div\s+style="[^"]*Courier New[^"]*">([^<]+)</div>#i', $html, $m)) {
                foreach ($m[1] as $k) { $k = trim(html_entity_decode($k, ENT_QUOTES, 'UTF-8')); if ($k !== '') $emailKeys[] = $k; }
            }
            if (preg_match('#<a\s+href="([^"]+)"[^>]*>(?:(?!</a>).)*?Download Now(?:(?!</a>).)*?License Included#is', $html, $mm)) {
                $preUrl = trim(html_entity_decode($mm[1], ENT_QUOTES, 'UTF-8'));
            }
        }
    } catch (Throwable $e) {}

    $products = array_filter($items, fn($i) => empty($i['service']));
    $i = 0;
    foreach ($items as &$it) {
        if (!empty($it['service'])) continue;
        // The sent email is what the customer holds: when we have it, its keys win
        // (covers "Edit & Resend" with a corrected key, and link-only deliveries
        // where the key pill was deliberately replaced by the green download block).
        if ($html !== '') {
            $key = count($emailKeys) === count($products) ? ($emailKeys[$i] ?? '') : (count($emailKeys) === 1 && count($products) === 1 ? $emailKeys[0] : ($bySlug[(string)$it['product_slug']] ?? ''));
            if ($preUrl !== '' && !$emailKeys) $key = '';
        } else {
            $key = $bySlug[(string)$it['product_slug']] ?? '';
        }
        $it['key'] = $key;
        $it['preactivated_url'] = $preUrl;
        $i++;
    }
    unset($it);
    return $items;
}

/** Resolve install / download / activation links + guide type for each line. */
function followup_decorate_items(array $items): array
{
    $out = [];
    foreach ($items as $it) {
        $slug = (string)($it['product_slug'] ?? '');
        if (function_exists('is_service_item') && is_service_item($slug)) { $it['service'] = true; $out[] = $it; continue; }
        $links = mv_resolve_install_links($slug, $it);
        $it['service']        = false;
        $it['guide_type']     = followup_guide_type($slug, $it);
        $it['guide_url']      = mv_absolute_url($links['guide'] ?? '');
        $it['installer_url']  = mv_absolute_url($links['installer'] ?? '');
        $it['activation_url'] = activation_url_for_product((string)($it['name'] ?? ''), (string)($it['brand'] ?? ''), (string)($links['activation'] ?? ''));
        $out[] = $it;
    }
    return $out;
}

/** office_key | office_retail | office_mac | windows | antivirus | other */
function followup_guide_type(string $slug, array $it): string
{
    $t = mv_guide_template_for_slug($slug);
    if ($t !== null) return in_array($t, ['office_key', 'office_retail', 'office_mac', 'windows'], true) ? $t : 'antivirus';
    $hay = strtolower(($it['brand'] ?? '') . ' ' . ($it['category'] ?? '') . ' ' . ($it['name'] ?? ''));
    foreach (['mcafee', 'bitdefender', 'norton', 'kaspersky', 'avast', 'avg', 'eset', 'trend micro', 'webroot', 'antivirus', 'vpn', 'security'] as $k) {
        if (strpos($hay, $k) !== false) return 'antivirus';
    }
    if (strpos($hay, 'windows 1') !== false) return 'windows';
    if (strpos($hay, 'office') !== false || strpos($hay, 'project') !== false || strpos($hay, 'visio') !== false) {
        return stripos((string)($it['platform'] ?? ''), 'mac') !== false ? 'office_mac' : 'office_key';
    }
    return 'other';
}

/**
 * '' when the follow-up should go out, otherwise a short human reason that
 * is stored in email_followup_schedule.note.
 */
function followup_skip_reason(array $order): string
{
    $status = strtolower((string)($order['status'] ?? ''));
    if (!in_array($status, ['paid', 'delivered'], true)) return 'order ' . $status;

    $pdo   = db();
    $email = strtolower(trim((string)($order['email'] ?? '')));
    $since = (string)($order['created_at'] ?? '2000-01-01 00:00:00');
    $onum  = (string)($order['order_number'] ?? '');
    try {
        $st = $pdo->prepare('SELECT 1 FROM refund_requests WHERE order_number = ? OR LOWER(email) = ? LIMIT 1');
        $st->execute([$onum, $email]);
        if ($st->fetchColumn()) return 'refund requested';
    } catch (Throwable $e) {}
    try {
        $st = $pdo->prepare('SELECT 1 FROM support_messages WHERE LOWER(email) = ? AND created_at >= ? LIMIT 1');
        $st->execute([$email, $since]);
        if ($st->fetchColumn()) return 'customer already contacted support';
    } catch (Throwable $e) {}
    try {
        $st = $pdo->prepare('SELECT 1 FROM chat_messages m JOIN chat_leads l ON l.id = m.lead_id
                             WHERE LOWER(l.email) = ? AND m.sender = "customer" AND m.sent_at >= ? LIMIT 1');
        $st->execute([$email, $since]);
        if ($st->fetchColumn()) return 'customer already chatted with support';
    } catch (Throwable $e) {}
    return '';
}

/**
 * Scheduler worker — pulls up to $limit due follow-ups, queues them into the
 * email outbox, marks them 'sent' / 'skipped' / 'failed', and returns the
 * count actually queued. Safe to run as often as you like.
 */
function send_pending_followups(int $limit = 25): int
{
    ensure_followup_schema();
    if (!followup_enabled()) return 0;
    $pdo = db();
    $limit = max(1, min(200, $limit));
    $rows = $pdo->query(
        'SELECT s.id, s.order_id, s.email, s.stage
         FROM email_followup_schedule s
         WHERE s.status = "pending"
           AND s.scheduled_at <= NOW()
         ORDER BY s.scheduled_at ASC
         LIMIT ' . $limit
    )->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) return 0;

    $mark = $pdo->prepare('UPDATE email_followup_schedule SET status=?, sent_at=NOW(), note=? WHERE id=?');
    $sent = 0;
    foreach ($rows as $r) {
        $email = strtolower(trim((string)$r['email']));
        $sid   = (int)$r['id'];
        $oid   = (int)$r['order_id'];
        $stage = (int)$r['stage'];

        if (is_email_unsubscribed($email)) { $mark->execute(['skipped', 'unsubscribed', $sid]); continue; }

        $order = followup_load_order($oid);
        if (!$order) { $mark->execute(['skipped', 'order missing', $sid]); continue; }

        $why = followup_skip_reason($order);
        if ($why !== '') { $mark->execute(['skipped', substr($why, 0, 250), $sid]); continue; }

        try {
            [$subject, $html] = build_followup_email($order, $stage);
            // send_email() → email_outbox → smtp_process_queue(). The template
            // code threads it into the order's Email Activity conversation.
            send_email($email, $subject, $html, $oid, followup_template_code($stage), 0);
            $mark->execute(['sent', '', $sid]);
            $sent++;
        } catch (Throwable $e) {
            @error_log('[followup send] ' . $e->getMessage());
            $mark->execute(['failed', substr($e->getMessage(), 0, 240), $sid]);
        }
    }
    return $sent;
}

function followup_template_code(int $stage): string
{
    return $stage === 3 ? 'activation_checkin' : 'followup_' . $stage;
}

function is_email_unsubscribed(string $email): bool
{
    $email = strtolower(trim($email));
    if ($email === '') return false;
    ensure_followup_schema();
    try {
        $stmt = db()->prepare('SELECT 1 FROM email_unsubscribes WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) { return false; }
}

function unsubscribe_email(string $email, string $reason = '', string $source = 'link'): void
{
    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;
    ensure_followup_schema();
    try {
        $stmt = db()->prepare('INSERT INTO email_unsubscribes (email, reason, source)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE reason = VALUES(reason), source = VALUES(source), unsubscribed_at = NOW()');
        $stmt->execute([$email, substr($reason, 0, 120), substr($source, 0, 40)]);
        db()->prepare('UPDATE email_followup_schedule SET status="skipped", sent_at=NOW(), note="unsubscribed"
            WHERE email = ? AND status = "pending"')->execute([$email]);
    } catch (Throwable $e) {
        @error_log('[unsubscribe_email] ' . $e->getMessage());
    }
}

/** Deterministic HMAC token for the unsubscribe link. */
function unsubscribe_token_for(string $email): string
{
    $email = strtolower(trim($email));
    $key = defined('SITE_HMAC_SECRET') ? SITE_HMAC_SECRET
        : (string)(function_exists('setting_get') ? setting_get('cron_token', '') : '');
    if ($key === '') $key = 'maventech-unsub-fallback-key-2026';
    return substr(hash_hmac('sha256', 'unsub:' . $email, $key), 0, 32);
}

function verify_unsubscribe_token(string $email, string $token): bool
{
    return hash_equals(unsubscribe_token_for($email), $token);
}

/** "Microsoft Office 2024 Professional Plus (Windows)" → "Microsoft Office 2024 Professional Plus" */
function followup_short_name(string $name): string
{
    $n = preg_replace('/\s*\((?:Windows|PC|Mac|Windows PC|macOS)\)\s*$/i', '', trim($name));
    $n = preg_replace('/\s+[—–-]+\s+.*$/u', '', $n);
    return trim($n) !== '' ? trim($n) : $name;
}

/** Three product-specific install/activation steps for a line item. */
function followup_steps(array $it): array
{
    if (!empty($it['preactivated_url'])) {
        return [
            'Click the green <strong>Download Now — License Included</strong> button above to download your product.',
            'Run the installer and follow the prompts — your license activates <strong>automatically</strong>, nothing to type.',
            'Done. If the installer did not start or shows an error, reply to this email or call us and we will fix it with you.',
        ];
    }
    $brand = trim((string)($it['brand'] ?? '')) ?: 'the vendor';
    $act   = (string)($it['activation_url'] ?? '');
    $actHost = $act !== '' ? preg_replace('~^https?://(www\.)?~i', '', rtrim((string)parse_url($act, PHP_URL_HOST) . (string)parse_url($act, PHP_URL_PATH), '/')) : '';
    $hasDl = !empty($it['installer_url']);
    switch ((string)($it['guide_type'] ?? 'other')) {
        case 'office_key':
        case 'office_retail':
            return [
                ($hasDl ? 'Click <strong>Download Software</strong> above, then right-click the installer and choose' : 'Right-click the installer and choose') . ' <strong>Run as administrator</strong>.',
                'Open any Office app (Word is fine) → <strong>Activate</strong> → enter your 25-character product key shown above.',
                'Asked to sign in? Go to <strong>setup.office.com</strong>, sign in with your Microsoft account and enter the key there.',
            ];
        case 'office_mac':
            return [
                ($hasDl ? 'Click <strong>Download Software</strong> above to get the Office for Mac installer (.pkg), open it' : 'Open the Office for Mac installer (.pkg)') . ' and follow the prompts.',
                'Visit <strong>setup.office.com</strong>, sign in with your Microsoft account and enter your 25-character product key shown above.',
                'Open Word on your Mac and sign in with that same Microsoft account to finish activation.',
            ];
        case 'windows':
            return [
                'Open <strong>Settings → System → Activation</strong> (Windows 11) or <strong>Update &amp; Security → Activation</strong> (Windows 10).',
                'Click <strong>Change product key</strong> and enter your 25-character key shown above.',
                ($hasDl ? 'Doing a clean install? <strong>Download Software</strong> above gives you the Media Creation Tool — enter the key during setup.' : 'Doing a clean install? Enter the key when Windows setup asks for it.'),
            ];
        case 'antivirus':
            return [
                'Go to <strong>' . esc($actHost ?: $brand) . '</strong> and sign in — or create a free ' . esc($brand) . ' account.',
                'Choose <strong>Redeem / Activate</strong> and enter the activation code shown above.',
                'Download the ' . esc($brand) . ' app and install it on every device you want to protect.',
            ];
        default:
            return [
                ($hasDl ? 'Click <strong>Download Software</strong> above and run the installer.' : 'Run the installer you downloaded.'),
                'Enter the license key shown above when the software asks for it.',
                'Not sure where the key goes? Reply to this email and we will walk you through it.',
            ];
    }
}

/**
 * Build the follow-up email (subject + html).
 *   3 = 24 h after delivery — "Is <product> installed & working?"
 *   1 = 72 h after delivery — "Still need a hand with <product>?"
 *   2 = legacy 30-day touch (no longer scheduled; kept so old rows still render)
 */
function build_followup_email(array $order, int $stage): array
{
    $co = function_exists('company_info') ? company_info() : [];
    $brand   = (string)($co['name']  ?? brand_name());
    $phone   = (string)($co['phone'] ?? (defined('SITE_PHONE') ? SITE_PHONE : ''));
    $support = (string)($co['email'] ?? brand_email());
    $base    = rtrim(email_public_base(), '/');
    $logoSrc = email_brand_logo_src();

    $orderNumber = (string)($order['order_number'] ?? ('#' . ($order['id'] ?? '')));
    $firstName   = trim((string)($order['first_name'] ?? '')) ?: 'there';
    $email       = strtolower(trim((string)($order['email'] ?? '')));
    $items       = is_array($order['items'] ?? null) ? $order['items'] : [];
    $products    = array_values(array_filter($items, fn($i) => empty($i['service'])));
    if (!$products) $products = $items;
    $primary     = $products[0] ?? ['name' => 'your software'];
    $names       = array_map(fn($i) => (string)($i['name'] ?? ''), $products);
    $productLine = $names ? implode(', ', $names) : 'your software';
    $short       = followup_short_name((string)($primary['name'] ?? 'your software'));
    $multi       = count($products) > 1;
    $what        = $multi ? 'your software' : $short;

    $delivered = (string)($order['delivered_at'] ?? $order['created_at'] ?? '');
    $deliveredFmt = $delivered !== '' ? date('F j, Y', strtotime($delivered)) : 'recently';

    $unsubUrl   = $base . '/unsubscribe.php?e=' . urlencode($email) . '&t=' . unsubscribe_token_for($email);
    $supportUrl = $base . '/support.php';
    $trackUrl   = $base . '/track-order.php';
    // Statement notice: the bank shows our payment partner's name, not the brand.
    $pm        = (string)($order['payment_method'] ?? 'card') === 'paypal' ? 'paypal' : 'card';
    $amountFmt = isset($order['total']) ? trim((string)($order['currency'] ?? 'USD')) . ' ' . number_format((float)$order['total'], 2) : '';
    // Name the bank saw AT PAYMENT TIME (snapshotted on the order when it was paid) —
    // never today's setting, so a later gateway change cannot confuse the customer.
    $partnerAtPayment = trim((string)($order['card_statement_name'] ?? ''));
    $partnerHtml = function_exists('mv_payment_partner_block') ? mv_payment_partner_block($pm, 'charged', $amountFmt, $partnerAtPayment) : '';
    $chatUrl    = $base . '/?chat=open';

    if ($stage === 3) {
        $subject  = "Is {$short} installed and working, {$firstName}?";
        $badge    = '24-hour check-in';
        $headline = "Is {$what} up and running?";
        $intro    = "You recently purchased <strong>" . esc($productLine) . "</strong> from " . esc($brand)
                  . " and your license key was delivered on <strong>" . esc($deliveredFmt) . "</strong> (order #" . esc($orderNumber) . "). "
                  . "We just want to make sure it installed and activated without any trouble.";
        $questions = [
            ['Have you installed ' . $what . ' yet?', 'If not, no problem — your key and download are right above, and the quick steps below take about 10 minutes.'],
            ['Did the license key activate?', 'If you saw an activation error or the key was not accepted, tell us and we will fix it straight away.'],
            ['Facing any problem at all?', 'Download not working, wrong version (Windows / Mac), activation questions — just ask.'],
        ];
        $helpTitle = 'Still facing any problem? Give us a call';
        $helpText  = 'Call us on ' . ($phone !== '' ? $phone : 'the number below') . ', reply to this email, or start a live chat — our team will install and activate '
                   . $what . ' with you step by step, free of charge.';
    } elseif ($stage === 1) {
        $subject  = "Still need help with {$short}, {$firstName}? Free installation support";
        $badge    = '3-day follow-up';
        $headline = "Still need a hand with {$what}?";
        $intro    = "It has been three days since we delivered your <strong>" . esc($productLine) . "</strong> license (order #" . esc($orderNumber) . ", delivered " . esc($deliveredFmt) . "). "
                  . "If it is installed and working — wonderful, you can simply ignore this email. If you have not had time to install it yet, or hit any snag, we would love to help you finish.";
        $questions = [
            ["Haven't installed it yet?", 'We can install and activate ' . $what . ' together over the phone or live chat — usually in under 15 minutes.'],
            ['Something not working?', 'Activation error, installer stuck, "key already in use", wrong edition — all quick fixes for our team.'],
            ['Moving to a new computer?', 'Ask us how to transfer your license before you set up the new device.'],
        ];
        $helpTitle = 'Free installation support is included with your purchase';
        $helpText  = 'You paid for software that works. If anything stands between you and that, call us on '
                   . ($phone !== '' ? $phone : 'the number below') . ' or reply to this email and we will sort it out — no extra cost.';
    } else {
        $subject  = "Anything we can help with, {$firstName}? — Order #{$orderNumber}";
        $badge    = '30-day check-in';
        $headline = 'How is ' . $what . ' going?';
        $intro    = "It has been a month since your order #" . esc($orderNumber) . " from " . esc($brand) . ". If everything is working perfectly — brilliant! If you need help with a re-install, activation on a new device, or a license question, our team is one message away.";
        $questions = [];
        $helpTitle = 'Need help with anything?';
        $helpText  = 'Installation, activation, moving your license to a new PC/Mac, or any question — just get in touch.';
    }

    $phoneDigits = preg_replace('/\D/', '', $phone);
    $phoneHtml = $phone !== ''
        ? '<a href="tel:+' . esc($phoneDigits) . '" style="color:#0f172a;text-decoration:none;font-weight:800;font-size:17px;">' . esc($phone) . '</a>'
        : '';
    $emailHtml = $support !== ''
        ? '<a href="mailto:' . esc($support) . '?subject=' . rawurlencode('Help with order #' . $orderNumber) . '" style="color:#0f172a;text-decoration:none;font-weight:700;word-break:break-all;">' . esc($support) . '</a>'
        : '';
    $helpRow = function (string $label, string $value, bool $last = false): string {
        $bb = $last ? '' : 'border-bottom:1px solid #eef2f7;';
        return '<tr><td style="padding:10px 14px;' . $bb . '"><div style="font-size:11px;letter-spacing:.4px;text-transform:uppercase;color:#64748b;font-weight:600;">' . $label . '</div>'
             . '<div style="margin-top:2px;font-size:15px;">' . $value . '</div></td></tr>';
    };

    // ---- Product card(s): name + exactly what was delivered (key and/or
    //      pre-activated link) + the product's own Download Software button ----
    $cards = '';
    foreach ($products as $it) {
        $img = email_image_src((string)($it['image'] ?? ''));
        if ($img === '') $img = $logoSrc;
        $key   = trim((string)($it['key'] ?? ''));
        $pre   = trim((string)($it['preactivated_url'] ?? ''));
        $dlUrl = trim((string)($it['installer_url'] ?? ''));
        $qty   = (int)($it['qty'] ?? 1);
        $body  = '';
        if ($key !== '') {
            $body .= '<div style="margin-top:10px;border:2px dashed #3b82f6;border-radius:10px;background:#eff6ff;padding:12px 14px;text-align:center;">'
                   . '<div style="font-size:10px;color:#64748b;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;font-weight:600;">Your License Key</div>'
                   . '<div style="font-family:\'Courier New\',monospace;font-size:16px;font-weight:bold;color:#1d4ed8;letter-spacing:1.2px;line-height:1.5;">' . esc($key) . '</div>'
                   . ($qty > 1 ? '<div style="margin-top:4px;font-size:12px;color:#059669;font-weight:700;">&#10004; Valid for up to ' . $qty . ' devices</div>' : '')
                   . '</div>';
        }
        if ($pre !== '') {
            $body .= '<div style="margin-top:10px;padding:16px 14px;border:2px solid #16a34a;border-radius:12px;background:#ecfdf5;text-align:center;">'
                   . '<div style="font-size:11px;color:#047857;letter-spacing:1.2px;text-transform:uppercase;font-weight:800;margin-bottom:8px;">&#9989; Your license is already enabled in this download</div>'
                   . '<a href="' . esc($pre) . '" style="display:inline-block;padding:12px 26px;background:#16a34a;color:#ffffff;border-radius:999px;text-decoration:none;font-weight:800;font-size:14px;">&#11015;&#65039; Download Now &mdash; License Included &rarr;</a>'
                   . '</div>';
        }
        if ($dlUrl !== '') {
            $body .= '<div style="margin-top:12px;text-align:center;">'
                   . '<a href="' . esc($dlUrl) . '" download style="display:inline-block;padding:11px 26px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;color:#475569;"><span style="color:#3b82f6;">&#11015;</span>&nbsp; Download Software</a>'
                   . '<div style="font-size:11px;color:#94a3b8;margin-top:5px;">Click to download your software</div>'
                   . '</div>';
        }
        $cards .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:12px;margin:0 0 12px 0;background:#ffffff;"><tr><td style="padding:14px;">'
                . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
                . '<td width="70" valign="middle" style="padding-right:12px;"><img src="' . esc($img) . '" width="64" height="64" alt="' . esc((string)$it['name']) . '" style="display:block;border-radius:10px;background:#f8fafc;object-fit:contain;"></td>'
                . '<td valign="middle"><div style="font-size:15px;font-weight:800;color:#0f172a;line-height:1.3;">' . esc((string)$it['name']) . '</div></td>'
                . '</tr></table>'
                . $body
                . '</td></tr></table>';
    }

    // ---- Quick steps for the primary product ----
    $stepsHtml = '';
    if (!$multi && !empty($primary) && empty($primary['service']) && $stage !== 2) {
        $n = 0;
        foreach (followup_steps($primary) as $s) {
            $n++;
            $stepsHtml .= '<tr><td width="30" valign="top" style="padding:7px 0;"><div style="width:22px;height:22px;border-radius:50%;background:#0a57f2;color:#fff;text-align:center;line-height:22px;font-size:12px;font-weight:800;">' . $n . '</div></td>'
                        . '<td valign="top" style="padding:7px 0 7px 6px;font-size:13.5px;line-height:1.55;color:#334155;">' . $s . '</td></tr>';
        }
        $stepsHtml = '<div style="margin:6px 0 16px 0;padding:14px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;">'
                   . '<div style="font-size:13px;font-weight:800;color:#0f172a;text-transform:uppercase;letter-spacing:.4px;">Quick steps for ' . esc($short) . '</div>'
                   . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:4px;">' . $stepsHtml . '</table></div>';
    }

    $qHtml = '';
    foreach ($questions as [$q, $a]) {
        $qHtml .= '<tr><td width="34" valign="top" style="padding:10px 0;border-bottom:1px solid #eef2f7;">'
                . '<div style="width:26px;height:26px;border-radius:8px;background:#e0f2fe;color:#0369a1;text-align:center;line-height:26px;font-weight:800;font-size:14px;">?</div></td>'
                . '<td valign="top" style="padding:10px 0 10px 8px;border-bottom:1px solid #eef2f7;">'
                . '<div style="font-size:15px;font-weight:700;color:#0f172a;">' . esc($q) . '</div>'
                . '<div style="font-size:13.5px;line-height:1.5;color:#475569;margin-top:2px;">' . esc($a) . '</div></td></tr>';
    }

    $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
          . '<meta name="viewport" content="width=device-width,initial-scale=1">'
          . '<title>' . esc($subject) . '</title></head>'
          . '<body style="margin:0;padding:0;background:#f5f7fb;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#0f172a;">'
          . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;">' . esc(strip_tags($intro)) . '</div>'
          . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f7fb;padding:24px 0;"><tr><td align="center">'
          . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 4px 22px rgba(15,23,42,0.08);">'
          // ---- Header: logo + brand + badge ----
          . '<tr><td style="padding:22px 28px 18px 28px;border-bottom:1px solid #eef2f7;">'
          . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
          . '<td valign="middle" width="56" style="padding-right:12px;"><img src="' . esc($logoSrc) . '" alt="' . esc($brand) . '" width="52" height="52" style="display:block;border-radius:12px;object-fit:contain;"></td>'
          . '<td valign="middle"><div style="font-size:19px;font-weight:800;color:#0f172a;">' . esc($brand) . '</div>'
          . '<div style="font-size:10px;color:#94a3b8;letter-spacing:1.2px;font-weight:600;">GENUINE LICENSES &middot; INDEPENDENT PROVIDER</div></td>'
          . '</tr></table></td></tr>'
          // ---- Body ----
          . '<tr><td style="padding:22px 28px 4px 28px;">'
          . '<div style="margin:0 0 12px 0;"><span style="display:inline-block;padding:5px 11px;background:#e0f2fe;color:#0369a1;border-radius:999px;font-size:11px;font-weight:700;letter-spacing:.4px;text-transform:uppercase;">' . esc($badge) . '</span></div>'
          . '<h1 style="margin:0 0 6px 0;font-size:22px;font-weight:800;line-height:1.25;color:#0f172a;">Hi ' . esc($firstName) . ',</h1>'
          . '<div style="margin:0 0 12px 0;font-size:17px;font-weight:700;color:#0a57f2;">' . esc($headline) . '</div>'
          . '<p style="margin:0 0 16px 0;font-size:15px;line-height:1.6;color:#334155;">' . $intro . '</p>'
          . $cards
          . $partnerHtml
          . ($qHtml !== '' ? '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:6px 0 18px 0;">' . $qHtml . '</table>' : '')
          . $stepsHtml

          // ---- Help box ----
          . '<div style="margin:18px 0;padding:18px;background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;">'
          . '<div style="font-size:16px;font-weight:800;color:#0f172a;">' . esc($helpTitle) . '</div>'
          . '<p style="margin:6px 0 12px 0;font-size:14px;line-height:1.55;color:#334155;">' . esc($helpText) . '</p>'
          . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;border:1px solid #e2e8f0;">'
          . ($phoneHtml !== '' ? $helpRow('Call us', $phoneHtml) : '')
          . ($emailHtml !== '' ? $helpRow('Email us', $emailHtml) : '')
          . $helpRow('Live chat', '<a href="' . esc($chatUrl) . '" style="color:#0f172a;text-decoration:none;font-weight:700;">Chat on our website &rarr;</a>', true)
          . '</table>'
          . '<div style="margin:16px 0 4px 0;text-align:center;">'
          . '<a href="' . esc($supportUrl) . '" style="display:inline-block;padding:12px 24px;background:#0a57f2;color:#ffffff;border-radius:999px;font-size:14px;font-weight:700;text-decoration:none;margin:4px;">Get help now</a>'
          . '</div>'
          . '</div>'

          . '<div style="margin:18px 0;padding:12px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;font-size:13px;color:#475569;">'
          . '<span style="text-transform:uppercase;letter-spacing:.4px;color:#64748b;font-weight:600;font-size:11px;">Your order</span> &nbsp;<strong style="color:#0f172a;">#' . esc($orderNumber) . '</strong> · ' . esc($productLine)
          . ' · <a href="' . esc($trackUrl) . '" style="color:#0a57f2;text-decoration:none;font-weight:600;">Re-send my key / receipt &rarr;</a>'
          . '</div>'

          . '<p style="margin:16px 0 0 0;font-size:14px;line-height:1.55;color:#475569;">If everything is already working, you can simply ignore this email — and thank you for choosing ' . esc($brand) . '.</p>'
          . '<p style="margin:8px 0 26px 0;font-size:14px;color:#334155;">— The ' . esc($brand) . ' Support Team</p>'
          . '</td></tr>'
          // ---- Footer / Unsubscribe ----
          . '<tr><td style="padding:16px 28px 20px 28px;background:#f8fafc;border-top:1px solid #eef2f7;font-size:12px;line-height:1.55;color:#64748b;text-align:center;">'
          . 'You are receiving this check-in because you purchased from ' . esc($brand) . '.<br>'
          . 'No longer want these check-ins? '
          . '<a href="' . esc($unsubUrl) . '" style="color:#0369a1;text-decoration:underline;font-weight:600;">Unsubscribe with one click</a>.'
          . '</td></tr>'
          . '</table></td></tr></table></body></html>';

    return [$subject, $html];
}

/**
 * Order used by the admin "Preview" buttons: a specific order id, else the
 * most recent paid order with items, else a sample built from a real product.
 */
function followup_preview_order(int $orderId = 0): array
{
    $pdo = db();
    if ($orderId <= 0) {
        try {
            $orderId = (int)$pdo->query("SELECT o.id FROM orders o WHERE o.status='paid' AND EXISTS (SELECT 1 FROM order_items oi WHERE oi.order_id=o.id) ORDER BY o.id DESC LIMIT 1")->fetchColumn();
        } catch (Throwable $e) { $orderId = 0; }
    }
    if ($orderId > 0) {
        $o = followup_load_order($orderId);
        if ($o && !empty($o['items'])) { $o['is_sample'] = false; return $o; }
    }
    $p = [];
    try { $p = $pdo->query("SELECT slug AS product_slug, name, image, platform, brand, category, activation_url, install_guide_url, installer_url FROM products WHERE is_active=1 AND archived=0 ORDER BY id LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: []; } catch (Throwable $e) {}
    if (!$p) $p = ['product_slug' => 'sample', 'name' => 'Microsoft Office 2024 Professional Plus (Windows)', 'platform' => 'Windows', 'brand' => 'Microsoft'];
    $p['qty'] = 1;
    $items = followup_decorate_items([$p]);
    $items[0]['key'] = 'XXXXX-XXXXX-XXXXX-XXXXX-XXXXX';
    $items[0]['preactivated_url'] = '';
    return [
        'id' => 0, 'order_number' => 'MV2606SAMPLE', 'email' => 'customer@example.com', 'first_name' => 'Alex', 'payment_method' => 'card', 'total' => 59.99, 'currency' => 'USD', 'card_statement_name' => mv_payment_partner_name('card'),
        'status' => 'paid', 'created_at' => date('Y-m-d H:i:s', time() - 86400), 'delivered_at' => date('Y-m-d H:i:s', time() - 86400),
        'items' => $items, 'is_sample' => true,
    ];
}
