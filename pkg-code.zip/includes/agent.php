<?php
/**
 * Agent / LLM helpers.
 *
 * 1) Markdown content negotiation (acceptmarkdown.com): when a client asks for
 *    `text/markdown` via the Accept header (or ?format=md), we serve a clean
 *    markdown representation of the page instead of the HTML shell, and always
 *    set `Vary: Accept, Accept-Encoding` so CDNs never cross-serve the cached
 *    HTML variant to a markdown request (or vice-versa).
 * 2) A short markdown 404 body that points agents at the sitemap / llms.txt.
 */

require_once __DIR__ . '/functions.php';

/** True when the caller prefers a markdown response. */
function agent_wants_markdown(): bool
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') return false;
    if (isset($_GET['format']) && strtolower((string)$_GET['format']) === 'md') return true;

    $accept = strtolower(trim((string)($_SERVER['HTTP_ACCEPT'] ?? '')));
    if ($accept === '' || strpos($accept, 'text/markdown') === false) return false;

    // Compare q-values: only prefer markdown when it ranks >= html.
    $qOf = static function (string $type) use ($accept): float {
        foreach (explode(',', $accept) as $part) {
            $bits = explode(';', trim($part));
            if (trim($bits[0]) !== $type) continue;
            $q = 1.0;
            for ($i = 1; $i < count($bits); $i++) {
                if (preg_match('/q=([0-9.]+)/', $bits[$i], $m)) $q = (float)$m[1];
            }
            return $q;
        }
        return -1.0;
    };
    $qmd   = $qOf('text/markdown');
    $qhtml = max($qOf('text/html'), $qOf('application/xhtml+xml'), $qOf('*/*'));
    return $qhtml < 0 ? true : ($qmd >= $qhtml);
}

/** Emit a markdown body with the correct headers and stop. */
function agent_md_send(string $markdown, int $status = 200): void
{
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    // Clear any session cache-limiter headers so our caching policy wins.
    header_remove('Cache-Control');
    header_remove('Pragma');
    header_remove('Expires');
    header('Content-Type: text/markdown; charset=utf-8');
    header('Vary: Accept, Accept-Encoding');
    header('X-Content-Type-Options: nosniff');
    header('Access-Control-Allow-Origin: *');
    // Cache successful markdown briefly; never cache error responses (e.g. 404).
    header('Cache-Control: ' . ($status >= 400 ? 'no-store' : 'public, max-age=300'));
    header('Link: </llms.txt>; rel="alternate"; type="text/plain", </sitemap.xml>; rel="sitemap"');
    echo rtrim($markdown) . "\n";
}

/** Absolute, country-prefixed URL for an internal path (matches the HTML links). */
function agent_url(string $path): string
{
    $base = rtrim(site_url(), '/');
    return $base . (function_exists('country_url') ? country_url($path) : '/' . ltrim($path, '/'));
}

/** Regional price string (e.g. "$209.99" or "£165.89"), matching the HTML. */
function agent_price(float $usd): string
{
    return function_exists('format_price') ? format_price($usd) : '$' . number_format($usd, 2);
}

/** Plain-text-ify HTML page content for a markdown body. */
function agent_html_to_text(string $html): string
{
    $html = preg_replace('#<(script|style)[\s\S]*?</\1>#i', '', $html);
    $html = preg_replace('#</(p|div|section|li|h[1-6]|br|tr)\s*>#i', "\n", $html);
    $html = preg_replace('#<li[^>]*>#i', '- ', $html);
    $text = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');
    $text = preg_replace("/[ \t]+/", ' ', $text);
    $text = preg_replace("/\n{3,}/", "\n\n", $text);
    return trim($text);
}

/**
 * Try to render the given path as markdown.
 * Returns true if it handled the request (and already sent output).
 */
function agent_render_markdown(string $path): bool
{
    $brand = brand_name();
    $base  = rtrim(site_url(), '/');
    $p     = rtrim($path, '/');
    if ($p === '') $p = '/';

    $slug = static function (): string {
        return preg_replace('#[^a-z0-9\-]#i', '', (string)($_GET['slug'] ?? ''));
    };

    // -- Product ---------------------------------------------------------
    if ($p === '/product.php' || $p === '/product') {
        $s = $slug();
        $prod = $s !== '' ? get_product($s) : null;
        if (!$prod) return false; // let normal flow 404/redirect
        $md  = "# {$prod['name']}\n\n";
        $md .= "**Price:** " . agent_price((float)$prod['price'])
             . (!empty($prod['original_price']) ? " (was " . agent_price((float)$prod['original_price']) . ")" : "") . "\n\n";
        if (!empty($prod['brand']))    $md .= "- **Brand:** {$prod['brand']}\n";
        if (!empty($prod['platform'])) $md .= "- **Platform:** {$prod['platform']}\n";
        if (!empty($prod['license_type'])) $md .= "- **License:** {$prod['license_type']}\n";
        $md .= "- **Delivery:** Digital license key by email within seconds of payment\n";
        $md .= "- **URL:** " . agent_url('product.php?slug=' . $prod['slug']) . "\n\n";
        if (!empty($prod['description'])) {
            $md .= "## Description\n\n" . agent_html_to_text((string)$prod['description']) . "\n\n";
        }
        $md .= "## Buy / related\n\n- [Add to cart](" . agent_url('product.php?slug=' . $prod['slug']) . ")\n- [Browse all products](" . agent_url('shop.php') . ")\n- [All products (llms.txt)]({$base}/llms.txt)\n";
        agent_md_send($md);
        return true;
    }

    // -- Category --------------------------------------------------------
    if ($p === '/category.php' || $p === '/category') {
        $s = $slug();
        if ($s === '' || !category_slug_exists($s)) {
            // fall through unless it clearly maps to products
            $cats = category_children($s);
            $items = $s !== '' ? get_products($cats ?: [$s]) : [];
            if (!$items) return false;
        } else {
            $items = get_products(category_children($s) ?: [$s]);
        }
        $title = category_title($s);
        $md = "# {$title}\n\n> {$brand} category · " . count($items) . " products\n\n";
        foreach ($items as $it) {
            $md .= "- [{$it['name']}](" . agent_url('product.php?slug=' . $it['slug']) . ") — " . agent_price((float)$it['price']) . "\n";
        }
        $md .= "\n[Shop all](" . agent_url('shop.php') . ") · [Sitemap]({$base}/sitemap.xml)\n";
        agent_md_send($md);
        return true;
    }

    // -- Shop ------------------------------------------------------------
    if ($p === '/shop.php' || $p === '/shop') {
        $items = get_products();
        $md = "# Shop — {$brand}\n\n> Full catalogue · " . count($items) . " products. Digital license keys delivered by email.\n\n";
        foreach ($items as $it) {
            $md .= "- [{$it['name']}](" . agent_url('product.php?slug=' . $it['slug']) . ") — " . agent_price((float)$it['price'])
                 . (!empty($it['platform']) ? " ({$it['platform']})" : "") . "\n";
        }
        $md .= "\n[Homepage]({$base}/) · [llms.txt]({$base}/llms.txt) · [Sitemap]({$base}/sitemap.xml)\n";
        agent_md_send($md);
        return true;
    }

    // -- Homepage --------------------------------------------------------
    if ($p === '/' || $p === '/index.php') {
        $items = get_products();
        $md  = "# {$brand}\n\n";
        $md .= "> {$brand} is an independent software reseller offering genuine, instantly-delivered "
             . "digital license keys for Microsoft Office, Windows, and leading antivirus suites. "
             . "Not affiliated with Microsoft or any trademark holder.\n\n";
        $md .= "## Popular products\n\n";
        foreach (array_slice($items, 0, 12) as $it) {
            $md .= "- [{$it['name']}](" . agent_url('product.php?slug=' . $it['slug']) . ") — " . agent_price((float)$it['price']) . "\n";
        }
        $md .= "\n## Key links\n\n"
             . "- [Shop all products](" . agent_url('shop.php') . ")\n"
             . "- [About]({$base}/about-us.php)\n"
             . "- [Contact]({$base}/contact.php)\n"
             . "- [Refund policy]({$base}/refund-policy.php)\n"
             . "- [llms.txt (agent guide)]({$base}/llms.txt)\n"
             . "- [Sitemap]({$base}/sitemap.xml)\n";
        agent_md_send($md);
        return true;
    }

    // -- Office lifetime-license landing pages --------------------------
    //    (office-<year>-lifetime-license[-mac|-windows]) — these are template
    //    pages with no `pages` row, so give agents a clean markdown summary
    //    instead of falling through to HTML.
    if (preg_match('#^/office-(2019|2021|2024)-lifetime-license(-mac|-windows)?(?:\.php)?$#i', $p, $om)) {
        $yr    = $om[1];
        $isMac = isset($om[2]) && strtolower($om[2]) === '-mac';
        $plat  = $isMac ? 'Mac (macOS)' : 'Windows PC';
        $items = array_filter(get_products(), static function ($it) use ($yr, $isMac) {
            $hay = strtolower(($it['slug'] ?? '') . ' ' . ($it['name'] ?? ''));
            if (strpos($hay, $yr) === false || strpos($hay, 'office') === false) return false;
            $isMacProd = strpos($hay, 'mac') !== false;
            return $isMac ? $isMacProd : !$isMacProd;
        });
        $md  = "# Microsoft Office {$yr}" . ($isMac ? ' for Mac' : '') . " — Lifetime License\n\n";
        $md .= "> {$brand}: genuine one-time-purchase Microsoft Office {$yr} for {$plat}. "
             . "No subscription — instant digital delivery of the product key by email.\n\n";
        if ($items) {
            $md .= "## Editions\n\n";
            foreach ($items as $it) {
                $md .= "- [{$it['name']}](" . agent_url('product.php?slug=' . $it['slug']) . ") — " . agent_price((float)$it['price']) . "\n";
            }
            $md .= "\n";
        }
        $md .= "## Other options\n\n";
        $md .= "- [Office " . ($isMac ? 'for Windows' : 'for Mac') . "](" . agent_url('office-' . $yr . '-lifetime-license-' . ($isMac ? 'windows' : 'mac') . '.php') . ")\n";
        foreach (['2024','2021','2019'] as $oy) {
            if ($oy === $yr) continue;
            $md .= "- [Office {$oy} Lifetime License](" . agent_url('office-' . $oy . '-lifetime-license-' . ($isMac ? 'mac' : 'windows') . '.php') . ")\n";
        }
        $md .= "- [Shop all products](" . agent_url('shop.php') . ") · [llms.txt]({$base}/llms.txt) · [Sitemap]({$base}/sitemap.xml)\n";
        agent_md_send($md);
        return true;
    }

    // -- Static CMS pages (pages table) ---------------------------------
    // Matches /page.php?slug=x, /<slug>, or /<slug>.php when it's a real page row.
    $pageSlug = '';
    if (($p === '/page.php' || $p === '/page')) {
        $pageSlug = $slug();
    } elseif (preg_match('#^/([a-z0-9\-]+)(?:\.php)?$#i', $p, $m)) {
        $pageSlug = strtolower($m[1]);
    }
    if ($pageSlug !== '') {
        try {
            $st = db()->prepare('SELECT title, content FROM pages WHERE slug = ? LIMIT 1');
            $st->execute([$pageSlug]);
            $row = $st->fetch();
            if ($row) {
                $pageHtml = function_exists('company_placeholders_apply') ? company_placeholders_apply((string)$row['content']) : (string)$row['content'];
                $md = "# {$row['title']}\n\n" . agent_html_to_text($pageHtml)
                    . "\n\n---\n[Homepage]({$base}/) · [Shop]({$base}/shop.php) · [Sitemap]({$base}/sitemap.xml)\n";
                agent_md_send($md);
                return true;
            }
        } catch (Throwable $e) { /* fall through to HTML */ }
    }

    return false;
}

/** Short markdown 404 body pointing agents at the sitemap / llms.txt. */
function agent_md_404(): void
{
    $base = rtrim(site_url(), '/');
    $md  = "# 404 — Page Not Found\n\n";
    $md .= "The requested path does not exist on this site.\n\n";
    $md .= "## Where to go next\n\n";
    $md .= "- [Homepage]({$base}/)\n";
    $md .= "- [Shop — all products]({$base}/shop.php)\n";
    $md .= "- [llms.txt — agent guide & product index]({$base}/llms.txt)\n";
    $md .= "- [sitemap.xml — full URL list]({$base}/sitemap.xml)\n";
    $md .= "- [HTML sitemap]({$base}/sitemap.php)\n";
    agent_md_send($md, 404);
}
