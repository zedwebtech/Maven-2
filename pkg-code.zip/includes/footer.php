<?php /* Footer + chat widget + scripts */ ?>
</main><!-- /#main-content (opened in header.php) -->
<!-- ===================== Slide-out mini-cart drawer ===================== -->
<div id="mvCartOverlay" class="mvcart-overlay" hidden></div>
<aside id="mvCartDrawer" class="mvcart-drawer" aria-hidden="true" aria-label="Your cart" role="dialog" data-testid="cart-drawer">
  <div class="mvcart-head">
    <div class="mvcart-title"><i class="bi bi-cart3 me-2"></i>Your Cart <span class="mvcart-count" id="mvCartCount">0</span></div>
    <button type="button" class="mvcart-close" id="mvCartClose" aria-label="Close cart"><i class="bi bi-x-lg"></i></button>
  </div>
  <div class="mvcart-body" id="mvCartBody">
    <!-- items injected by JS -->
  </div>
  <div class="mvcart-empty" id="mvCartEmpty" hidden>
    <i class="bi bi-cart-x"></i>
    <p class="mb-2">Your cart is empty.</p>
    <a href="shop.php" class="btn btn-primary rounded-pill px-4">Browse products</a>
  </div>
  <div class="mvcart-foot" id="mvCartFoot" hidden>
    <div class="mvcart-coupon">
      <input type="text" id="mvCartCoupon" class="form-control" placeholder="Coupon code" autocomplete="off">
      <button type="button" id="mvCartCouponBtn" class="btn btn-outline-secondary">Apply</button>
    </div>
    <div id="mvCartCouponMsg" class="mvcart-coupon-msg"></div>
    <div class="mvcart-save d-none" id="mvCartSaveRow"><span><i class="bi bi-piggy-bank me-1"></i>You save</span><span id="mvCartSave"></span></div>
    <div class="mvcart-line"><span class="text-secondary">Subtotal</span><span id="mvCartSubtotal"></span></div>
    <div class="mvcart-line d-none" id="mvCartDiscRow"><span class="text-success">Discount</span><span class="text-success" id="mvCartDisc"></span></div>
    <div class="mvcart-total"><span>Total</span><span id="mvCartTotal"></span></div>
    <div class="mvcart-note">No subscription, no recurring fees.</div>
    <!-- 2026-07 FIX — Semrush "80 outgoing internal links contain nofollow
         attribute" flagged the drawer's <a href="checkout.php" rel="nofollow">
         on every crawled page. The earlier rel="nofollow" was added to hide a
         302 → /cart.php redirect from bots; that redirect is now removed
         (checkout.php renders a 200 "Your cart is empty" page on empty-cart
         hits and is still noindex,nofollow via meta from includes/header.php).
         With no redirect chain to hide, the internal nofollow becomes pure
         crawl-equity waste — removed. -->
    <a href="checkout.php" class="btn btn-primary w-100 rounded-pill fw-bold mvcart-checkout" data-testid="cart-drawer-checkout">Proceed to Checkout <i class="bi bi-arrow-right ms-1"></i></a>
    <button type="button" class="btn btn-link w-100 mvcart-continue" id="mvCartContinue">Continue Shopping</button>
    <button type="button" class="mvcart-clear" id="mvCartClear">Clear cart</button>
    <div class="mvcart-guarantee"><i class="bi bi-shield-fill-check me-1"></i>Backed by our money-back guarantee</div>
  </div>
</aside>
<style>
.mvcart-overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:1080;opacity:0;transition:opacity .25s;backdrop-filter:blur(2px);}
.mvcart-overlay.show{opacity:1;}
.mvcart-drawer{position:fixed;top:0;right:0;height:100%;width:400px;max-width:92vw;background:#fff;z-index:1090;display:flex;flex-direction:column;box-shadow:-12px 0 40px -12px rgba(2,6,23,.4);transform:translateX(105%);transition:transform .3s cubic-bezier(.4,0,.2,1);}
.mvcart-drawer.open{transform:translateX(0);}
.mvcart-head{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.1rem;border-bottom:1px solid #eef2f7;}
.mvcart-title{font-weight:800;font-size:1.05rem;display:flex;align-items:center;color:#0f172a;}
.mvcart-count{background:#2563eb;color:#fff;font-size:.75rem;font-weight:700;border-radius:999px;padding:.05rem .5rem;margin-left:.5rem;min-width:22px;text-align:center;}
.mvcart-close{background:transparent;border:0;font-size:1.1rem;color:#64748b;cursor:pointer;line-height:1;padding:.3rem;}
.mvcart-close:hover{color:#0f172a;}
.mvcart-body{flex:1 1 auto;overflow-y:auto;padding:.6rem 1.1rem;}
.mvcart-item{display:flex;gap:.7rem;padding:.8rem 0;border-bottom:1px solid #f1f5f9;}
.mvcart-item img{width:56px;height:56px;object-fit:contain;border:1px solid #eef2f7;border-radius:8px;background:#fff;flex-shrink:0;}
.mvcart-item .mvi-name{font-weight:700;font-size:.85rem;color:#0f172a;text-decoration:none;line-height:1.25;display:block;}
.mvcart-item .mvi-name:hover{color:#2563eb;}
.mvcart-item .mvi-price{font-size:.82rem;margin-top:.1rem;}
.mvcart-item .mvi-price .mvi-orig{color:#94a3b8;text-decoration:line-through;margin-left:.35rem;font-size:.76rem;}
.mvcart-qty{display:inline-flex;align-items:center;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;margin-top:.4rem;}
.mvcart-qty button{background:#f8fafc;border:0;width:26px;height:26px;font-weight:700;cursor:pointer;color:#334155;}
.mvcart-qty button:hover{background:#eef2f7;}
.mvcart-qty span{min-width:30px;text-align:center;font-size:.82rem;font-weight:700;}
.mvcart-item .mvi-right{margin-left:auto;text-align:right;display:flex;flex-direction:column;align-items:flex-end;justify-content:space-between;gap:.5rem;}
.mvcart-item .mvi-line{font-weight:800;font-size:.9rem;color:#0f172a;}
.mvcart-item .mvi-remove{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;border:1px solid rgba(220,38,38,.28);background:rgba(220,38,38,.10);color:#dc2626;cursor:pointer;font-size:.9rem;transition:background-color .18s ease,color .18s ease,transform .18s ease,box-shadow .18s ease;}
.mvcart-item .mvi-remove:hover{background:linear-gradient(135deg,#ef4444,#b91c1c);color:#fff;transform:scale(1.08);box-shadow:0 5px 14px rgba(220,38,38,.35);}
.mvcart-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#94a3b8;padding:2rem;}
.mvcart-empty i{font-size:2.6rem;margin-bottom:.6rem;}
.mvcart-foot{border-top:1px solid #eef2f7;padding:1rem 1.1rem;background:#fff;}
.mvcart-coupon{display:flex;gap:.5rem;margin-bottom:.4rem;}
.mvcart-coupon .form-control{border-radius:8px;font-size:.85rem;}
.mvcart-coupon .btn{border-radius:8px;white-space:nowrap;font-size:.82rem;}
.mvcart-coupon-msg{font-size:.78rem;margin-bottom:.5rem;min-height:1px;}
.mvcart-coupon-msg.ok{color:#059669;}.mvcart-coupon-msg.err{color:#dc2626;}
.mvcart-line,.mvcart-save{display:flex;justify-content:space-between;font-size:.86rem;margin-bottom:.35rem;}
.mvcart-save{color:#059669;font-weight:600;}
.mvcart-total{display:flex;justify-content:space-between;font-weight:800;font-size:1.15rem;color:#0f172a;margin:.5rem 0 .1rem;}
.mvcart-note{font-size:.74rem;color:#94a3b8;margin-bottom:.7rem;}
.mvcart-checkout{padding:.7rem;}
.mvcart-continue{font-size:.85rem;text-decoration:none;color:#475569;}
.mvcart-clear{display:block;width:100%;background:transparent;border:0;color:#94a3b8;font-size:.78rem;cursor:pointer;margin-top:.2rem;}
.mvcart-clear:hover{color:#ef4444;}
.mvcart-guarantee{text-align:center;font-size:.74rem;color:#94a3b8;margin-top:.6rem;}
[data-bs-theme="dark"] .mvcart-drawer,[data-bs-theme="dark"] .mvcart-foot{background:#111827;}
[data-bs-theme="dark"] .mvcart-head,[data-bs-theme="dark"] .mvcart-item,[data-bs-theme="dark"] .mvcart-foot{border-color:#1f2937;}
[data-bs-theme="dark"] .mvcart-title,[data-bs-theme="dark"] .mvcart-item .mvi-name,[data-bs-theme="dark"] .mvcart-item .mvi-line,[data-bs-theme="dark"] .mvcart-total{color:#e2e8f0;}
[data-bs-theme="dark"] .mvcart-qty button{background:#1f2937;color:#e2e8f0;}
</style>


<?php if (empty($bareLayout)): ?>
<footer class="footer-dark pt-0 pb-4 mt-5">

  <!-- Newsletter band -->
  <div class="border-bottom border-secondary-subtle" style="border-color: rgba(255,255,255,.12) !important;">
    <div class="container text-center py-5">
      <h2 class="text-white fw-bold fs-2">Join our list for the latest deals &amp; product updates</h2>
      <p class="small mb-4">Subscribe and receive exclusive weekly deals straight to your inbox!</p>
      <form class="d-flex gap-2 mx-auto" style="max-width: 420px;" onsubmit="subscribeNewsletter(event)">
        <input type="email" required class="form-control rounded-pill px-3" placeholder="Enter your email" data-testid="newsletter-email">
        <button class="btn btn-primary rounded-pill px-4 fw-semibold" type="submit" data-testid="newsletter-join">Join</button>
      </form>
      <div class="d-flex justify-content-center gap-4 flex-wrap small mt-4">
        <span><i class="bi bi-patch-check-fill text-success me-1"></i>Genuine Products</span>
        <span><i class="bi bi-shield-check text-primary me-1"></i>30-Day Guarantee</span>
        <span><i class="bi bi-headset text-primary me-1"></i>Expert Support</span>
      </div>
    </div>
  </div>

  <div class="container pt-5">
    <div class="row g-4" id="footer-cols">
      <!-- Brand column -->
      <div class="col-lg-4">
        <div class="d-flex align-items-center gap-2 mb-3">
          <?php if (!empty($brandLogo)): ?>
            <?= brand_logo_html(42, 'width="140" height="42" loading="lazy" decoding="async"') ?>
          <?php else: ?>
            <?= render_logo(42) ?>
          <?php endif; ?>
          <?php if (!brand_logo_is_wordmark()): ?>
          <span>
            <?php
              $bnParts = preg_split('/\s+/', trim($brandName));
              $bnLast  = array_pop($bnParts) ?: '';
              $bnHead  = implode(' ', $bnParts);
            ?>
            <span class="brand-text d-block lh-1 text-white"><?= esc($bnHead) ?><?php if ($bnHead !== ''): ?> <?php endif; ?><span class="brand-grad"><?= esc($bnLast) ?></span></span>
            <?php if (setting_get('show_authorized_reseller_badge', '0') === '1'): ?>
            <small class="brand-tag" data-testid="brand-tag-authorized-reseller-footer">AUTHORIZED RESELLER</small>
            <?php endif; ?>
          </span>
          <?php endif; ?>
        </div>
        <p class="small mb-3" style="line-height:1.55;">Your trusted source for genuine Microsoft software — authentic lifetime licenses at unbeatable prices, delivered instantly with expert support every step of the way.</p>

        <!-- Contact block: tight vertical rhythm, aligned icons -->
        <ul class="list-unstyled small mb-3 footer-contact-list">
          <li><i class="bi bi-telephone-fill text-info"></i><a href="tel:<?= esc(tel_e164($brandPhone)) ?>"><?= esc($brandPhone) ?></a></li>
          <li><i class="bi bi-envelope-fill text-info"></i><?= obf_email_link($brandEmail, '', true) ?></li>
          <li><i class="bi bi-geo-alt-fill text-info"></i><?= esc($brandAddress) ?></li>
          <li><i class="bi bi-clock-fill text-info"></i><?= SITE_HOURS ?></li>
          <?php if ($brandRegNumber): ?><li data-testid="footer-reg-number"><i class="bi bi-patch-check-fill text-info"></i>Company Registration Number: <?= esc($brandRegNumber) ?><?php if (!empty($brandRegDateFiled)): ?> · Filed <?= esc(date('n/j/Y', strtotime((string)$brandRegDateFiled))) ?><?php endif; ?></li><?php endif; ?>
        </ul>

        <!-- Google Maps + socials on the same visual row for compactness -->
        <div class="d-flex align-items-center flex-wrap gap-3 mb-3">
          <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($brandAddress) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-light rounded-pill gmap-btn" data-testid="footer-gmap-btn">
            <span class="gmap-pin"><i class="bi bi-geo-alt-fill"></i></span>View on Google Maps
          </a>
          <div class="d-flex gap-2">
            <?php foreach ([['Facebook', 'bi-facebook'], ['Twitter', 'bi-twitter-x'], ['LinkedIn', 'bi-linkedin'], ['Instagram', 'bi-instagram']] as [$sn, $si]): ?>
              <a href="#top" aria-label="<?= $sn ?>" class="social-circle"><i class="bi <?= $si ?>"></i></a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Products -->
      <div class="col-lg-2 col-md-4 col-6">
        <h3 class="h6 text-white fw-bold mb-3">Products</h3>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="category.php?slug=office-2024-pc">Microsoft Office 2024</a></li>
          <li><a href="category.php?slug=office-2021-pc">Microsoft Office 2021</a></li>
          <li><a href="category.php?slug=office-2019-pc">Microsoft Office 2019</a></li>
          <li><a href="category.php?slug=microsoft-project">Microsoft Project</a></li>
          <li><a href="category.php?slug=microsoft-visio">Microsoft Visio</a></li>
          <li><a href="category.php?slug=office-mac">Office for Mac</a></li>
          <li><a href="category.php?slug=windows">Windows OS</a></li>
        </ul>
      </div>

      <!-- Support -->
      <div class="col-lg-2 col-md-4 col-6">
        <h3 class="h6 text-white fw-bold mb-3">Support</h3>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="account.php">My Account</a></li>
          <li><a href="track-order.php" data-testid="footer-order-history-link">Track Order &amp; Receipts</a></li>
          <li><a href="support.php">Support Center</a></li>
          <li><a href="page.php?slug=help-center">Help Center</a></li>
          <li><a href="page.php?slug=installation-guide">Installation Guide</a></li>
          <li><a href="page.php?slug=activation-help">Activation Help</a></li>
          <li><a href="page.php?slug=faqs">FAQs</a></li>
          <li><a href="contact.php">Contact Us</a></li>
          <li><a href="return-policy.php">Return Policy</a></li>
          <li><a href="protection-hub.php" data-testid="footer-protection-hub"><i class="bi bi-shield-shaded me-1"></i>Protection Hub</a></li>
        </ul>
      </div>

      <!-- Company -->
      <div class="col-lg-2 col-md-4 col-6">
        <h3 class="h6 text-white fw-bold mb-3">Company</h3>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="/about">About Us</a></li>
          <li><a href="press.php">Press &amp; Media</a></li>
          <li><a href="page.php?slug=why-choose-us">Why Choose Us</a></li>
          <li><a href="reviews.php">Customer Reviews</a></li>
          <li><a href="blog.php">Blog</a></li>
          <?php
            // Auto-render a Brands sub-menu so users can reach each brand
            // profile (Microsoft, Bitdefender, McAfee...) and its dedicated
            // Articles tab from any page.
            try {
                $allBrands = db()->query("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL AND brand != '' AND is_active = 1 ORDER BY brand")->fetchAll(PDO::FETCH_COLUMN);
            } catch (Throwable $e) { $allBrands = []; }
            foreach ($allBrands as $bn):
                $bSlug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', (string)$bn));
          ?>
            <li><a href="brand.php?slug=<?= esc($bSlug) ?>" data-testid="footer-brand-<?= esc($bSlug) ?>"><?= esc($bn) ?> Hub</a></li>
          <?php endforeach; ?>
          <li><a href="press-kit.php" data-testid="footer-press-kit">Press Kit &amp; Embeds</a></li>
          <li><a href="sitemap.php" data-testid="footer-company-sitemap">Site Map</a></li>
        </ul>
      </div>

      <!-- Free Tools -->
      <div class="col-lg-2 col-md-4 col-6" data-testid="footer-free-tools">
        <h3 class="h6 text-white fw-bold mb-3">Free Tools</h3>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="/tools/office-version-checker" data-testid="footer-tool-version">Office Version Checker</a></li>
          <li><a href="/tools/windows-product-key-checker" data-testid="footer-tool-key">Windows Key Checker</a></li>
          <li><a href="/tools/office-compatibility-checker" data-testid="footer-tool-compat">Compatibility Checker</a></li>
          <li><a href="/tools/office-deployment-calculator" data-testid="footer-tool-calc">Deployment Calculator</a></li>
          <li><a href="/tools" data-testid="footer-tool-all"><strong>All Free Tools &rarr;</strong></a></li>
        </ul>
      </div>

      <!-- Secure Payments -->
      <div class="col-lg-2 col-md-4 col-12" data-testid="footer-secure-payments">
        <h3 class="h6 text-white fw-bold mb-3"><i class="bi bi-lock-fill text-success me-1"></i>Secure Payments</h3>
        <div class="d-flex flex-wrap gap-2 mb-3" data-testid="footer-pay-icons"><?= render_payment_icons() ?></div>
        <ul class="list-unstyled small mb-3 footer-secure-list">
          <li><i class="bi bi-lock-fill text-success"></i>SSL Encrypted Checkout</li>
          <li><i class="bi bi-shield-fill-check text-info"></i>100% Secure Transactions</li>
        </ul>
        <?php $__fsr = function_exists('site_review_stats') ? site_review_stats() : ['count' => 324, 'avg' => 4.6];
              $__fsc = $__fsr['count'] > 0 ? $__fsr['count'] : 324; $__fsa = $__fsr['avg'] > 0 ? $__fsr['avg'] : 4.6; ?>
        <a href="reviews.php" class="footer-rating d-inline-flex align-items-center gap-2 text-decoration-none" data-testid="footer-rating">
          <span class="footer-rating-badge"><i class="bi bi-shield-check"></i></span>
          <span>
            <span class="footer-rating-stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></span>
            <strong class="text-white ms-1"><?= number_format($__fsa, 1) ?></strong><span class="text-secondary">/5</span>
            <span class="d-block text-secondary" style="font-size:.72rem;"><?= number_format($__fsc) ?>+ verified reviews</span>
          </span>
        </a>
      </div>
    </div>

    <!-- Trademark + legal -->
    <style>
    @media (min-width: 768px) {
      #footer-cols { display: grid !important; grid-template-columns: 2.1fr 1fr 1fr 1fr 1fr 1.5fr; gap: 1.25rem; }
      #footer-cols > [class*="col-"] { width: auto; max-width: none; flex: 0 1 auto; padding-left: 0; padding-right: 0; }
    }
    @media (min-width: 992px) {
      #footer-cols { grid-template-columns: 2.3fr 1.05fr 1.05fr 1.05fr 1.05fr 1.6fr; gap: 2rem; }
    }
    .footer-secure-list { line-height: 1.6; }
    .footer-secure-list li { display: flex; align-items: center; gap: 8px; }
    .footer-rating { padding: 8px 10px; border: 1px solid rgba(255,255,255,.12); border-radius: 10px; }
    .footer-rating:hover { border-color: rgba(255,255,255,.28); }
    .footer-rating-badge { width: 34px; height: 34px; border-radius: 8px; background: rgba(16,185,129,.15); color: #34d399; display: grid; place-items: center; font-size: 1.05rem; flex: 0 0 auto; }
    .footer-rating-stars { color: #fbbf24; font-size: .78rem; letter-spacing: .5px; }
    </style>

    <hr class="border-secondary my-4">

    <p class="small text-center mx-auto" style="max-width: 820px;"><?= esc(trim((string)(company_info()['legal_name'] ?? '')) ?: brand_name()) ?> is an <strong>independent third-party reseller</strong> and marketplace of, unused digital software product keys, resold under the First Sale Doctrine (17 U.S.C. &sect; 109) and its EU equivalents (<em>UsedSoft GmbH v. Oracle Int'l Corp.</em>, CJEU C-128/11). We are <strong>not affiliated with, endorsed by, or sponsored by</strong> Microsoft Corporation, Bitdefender, McAfee, Norton, or any other trademark holder referenced on this site — no official-partner, distributor, franchise, or reseller-of-record relationship exists. All product names, logos and brands are the property of their respective trademark owners and are used strictly for identification and nominative-fair-use purposes.</p>

    <div class="d-flex justify-content-center flex-wrap gap-2 small mb-3">
      <?php
      $legal = [
          ['Privacy Policy', '/privacy'], ['Terms of Service', 'page.php?slug=terms-of-service'],
          ['Refund Policy', 'refund-policy.php'], ['Return Policy', 'return-policy.php'],
          ['Shipping & Delivery', 'shipping-delivery.php'],
          ['Payment Policy', 'page.php?slug=payment-policy'], ['Cookie Policy', 'page.php?slug=cookie-policy'],
          ['Do Not Sell My Info', 'page.php?slug=do-not-sell'], ['Legal Disclaimer', 'page.php?slug=disclaimer'], ['Sitemap', 'sitemap.php'],
      ];
      foreach ($legal as $idx => [$ll, $lh]): ?>
        <a href="<?= $lh ?>"><?= $ll ?></a><?= $idx < count($legal) - 1 ? '<span aria-hidden="true" style="color:#94a3b8;">|</span>' : '' ?>
      <?php endforeach; ?>
      <?php if (function_exists('mv_consent_required') && mv_consent_required()): ?>
        <span aria-hidden="true" style="color:#94a3b8;">|</span><a href="#" onclick="window.mvOpenConsent && window.mvOpenConsent(); return false;" data-testid="footer-cookie-preferences">Cookie Preferences</a>
      <?php endif; ?>
    </div>

    <?php
    /* ================= Google "Preferred Sources" badge =================
       Lets readers add us as a preferred source in Google Search so we show
       up more often in AI Overviews, AI Mode, Top Stories & Discover.
       Standard localized button (Google's recommended embed) + a deeplink
       fallback that renders if the JS button can't (not eligible / blocked).
       Gated by a settings flag (default ON) — zero DDL. */
    $__psOn = function_exists('setting_get') ? (setting_get('preferred_sources_badge', '1') === '1') : true;
    // Change 3 — never load the badge/publisher.js on the checkout or order
    // confirmation pages: it delays the page-load event and has no purpose there.
    $__psPg = basename((string)(parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: ($_SERVER['SCRIPT_NAME'] ?? '')));
    if (in_array($__psPg, ['checkout.php', 'order-success.php'], true)) { $__psOn = false; }
    if ($__psOn):
        $__psHost = '';
        try { $__psHost = (string)parse_url(function_exists('public_base_url') ? public_base_url() : SITE_URL, PHP_URL_HOST); } catch (Throwable $e) {}
        $__psHost = preg_replace('/^www\./i', '', $__psHost) ?: 'maventechsoftware.com';
        $__psDeeplink = 'https://www.google.com/preferences/source?q=' . urlencode($__psHost);
    ?>
    <div class="footer-prefsrc" data-testid="footer-preferred-source">
      <div class="footer-prefsrc-icon"><i class="bi bi-google"></i></div>
      <div class="footer-prefsrc-copy">
        <div class="footer-prefsrc-title">Enjoy our guides &amp; reviews? Make us a Preferred Source</div>
        <div class="footer-prefsrc-sub">One tap tells Google to show more of our content in AI Overviews, Top Stories &amp; Discover.</div>
      </div>
      <div class="footer-prefsrc-btn">
        <div google-add-preferred-source-btn data-theme="light" data-testid="preferred-source-btn"></div>
        <a href="<?= esc($__psDeeplink) ?>" target="_blank" rel="noopener" class="footer-prefsrc-fallback" data-testid="preferred-source-fallback" style="display:none;">
          <i class="bi bi-plus-circle me-1"></i>Add as Preferred Source
        </a>
      </div>
    </div>
    <!-- Preferred Sources badge script — deferred to first interaction/idle so
         it never blocks first paint / LCP on content & landing pages. -->
    <script>(window.__mvTrk||[]).push(function(){var s=document.createElement('script');s.async=true;s.src='https://news.google.com/swg/js/v1/publisher.js';document.head.appendChild(s);});</script>
    <script>
    /* Reveal the styled deeplink fallback only if Google's button never
       painted (e.g. domain not yet eligible, or third-party script blocked). */
    (function(){
      function checkPrefSrc(){
        var host = document.querySelector('[google-add-preferred-source-btn]');
        var fb   = document.querySelector('.footer-prefsrc-fallback');
        if (!host || !fb) return;
        var rendered = host.children.length > 0 || host.getBoundingClientRect().height > 4;
        if (!rendered) fb.style.display = 'inline-flex';
      }
      setTimeout(checkPrefSrc, 3000);
    })();
    </script>
    <style>
    .footer-prefsrc{display:flex;align-items:center;gap:1rem;flex-wrap:wrap;justify-content:center;text-align:left;
      max-width:760px;margin:0 auto 1.25rem;padding:1rem 1.25rem;border:1px solid rgba(255,255,255,.12);
      border-radius:14px;background:rgba(255,255,255,.03);}
    .footer-prefsrc-icon{width:44px;height:44px;border-radius:12px;flex:0 0 auto;display:grid;place-items:center;
      font-size:1.35rem;color:#fff;background:linear-gradient(135deg,#4285F4,#34A853 60%,#FBBC05);
      box-shadow:0 6px 16px rgba(66,133,244,.35);}
    .footer-prefsrc-copy{flex:1 1 260px;min-width:0;}
    .footer-prefsrc-title{color:#fff;font-weight:700;font-size:.95rem;line-height:1.3;}
    .footer-prefsrc-sub{color:#94a3b8;font-size:.78rem;line-height:1.45;margin-top:2px;}
    .footer-prefsrc-btn{flex:0 0 auto;display:flex;align-items:center;min-height:40px;}
    .footer-prefsrc-fallback{display:inline-flex;align-items:center;text-decoration:none;font-weight:700;font-size:.85rem;
      padding:.55rem 1.1rem;border-radius:999px;background:#fff;color:#0b1220;white-space:nowrap;
      transition:transform .15s ease,box-shadow .15s ease;}
    .footer-prefsrc-fallback:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(0,0,0,.25);color:#0b1220;}
    @media (max-width:575.98px){.footer-prefsrc{flex-direction:column;text-align:center;}.footer-prefsrc-copy{flex-basis:auto;}}
    </style>
    <?php endif; ?>

    <div class="text-center small footer-copyright" data-testid="footer-copyright">
      <span class="footer-copyright-main">© <?= date('Y') ?> <?= esc($brandLegalName) ?>. All rights reserved.</span>
      <?php if ($brandRegNumber): ?>
        <span class="footer-copyright-sep" aria-hidden="true"> · </span>
        <span class="footer-copyright-reg" data-testid="footer-copyright-reg">Company Registration Number: <?= esc($brandRegNumber) ?></span>
      <?php endif; ?>
    </div>
  </div>
</footer>
<?php endif; /* bareLayout */ ?>

<?php
/* Google Customer Reviews — seller-rating badge (optional, site-wide).
   Renders only when a Merchant Center ID is configured.  Position defaults
   to BOTTOM_LEFT so it never collides with the bottom-right chat bubble. */
$gcrMid = trim((string)setting_get('google_merchant_id', defined('GOOGLE_MERCHANT_ID') ? GOOGLE_MERCHANT_ID : ''));
$gcrPos = trim((string)setting_get('gcr_badge_position', 'BOTTOM_LEFT'));
if ($gcrMid !== '' && ctype_digit($gcrMid)):
?>
<!-- Google Customer Reviews badge — deferred until first interaction / idle
     (same gate as GTM). Rationale (PageSpeed Mob 2026-07-08): the widget
     runs a 57 ms forced reflow inside its internal init, so leaving it
     with a plain `defer` still ate into LCP. Delaying to the __mvTrk
     interaction/3 s-post-load gate removes it from the initial critical
     path entirely — no visible UX regression (the badge still appears
     within seconds for any real user who scrolls / clicks). -->
<script>
  window.__mvTrk = window.__mvTrk || [];
  window.__mvTrk.push(function () {
    var s = document.createElement('script');
    s.src = 'https://www.gstatic.com/shopping/merchant/merchantwidget.js';
    s.async = true;
    s.id = 'merchantWidgetScript';
    s.onload = function () {
      if (typeof merchantwidget === 'undefined') return;
      merchantwidget.start({
        merchant_id: <?= (int)$gcrMid ?>,
        position: "<?= esc($gcrPos) ?>"
      });
      var _mwT = setInterval(function () {
        var f = document.getElementById('merchantwidgetiframe');
        if (f) { f.setAttribute('title', 'Google Customer Reviews'); clearInterval(_mwT); }
      }, 400);
      setTimeout(function () { clearInterval(_mwT); }, 12000);
    };
    document.head.appendChild(s);
  });
</script>
<!-- end Google Customer Reviews badge -->
<?php endif; ?>

<!-- ============================================================
     Global "Ask AI" modal — real Claude-Haiku-powered Q&A about the store.
     Triggered by the header "Ask AI" button and the hero teaser "Try it" pill.
     Independent from the live-chat widget (which is the human-support flow).
     ============================================================ -->
<div id="ask-ai-modal" class="ask-ai-modal" role="dialog" aria-modal="true" aria-labelledby="ask-ai-modal-title" data-testid="ask-ai-modal">
  <div class="ask-ai-modal-backdrop" onclick="closeAskAiModal()"></div>
  <div class="ask-ai-modal-card">
    <div class="ask-ai-modal-head">
      <div class="ask-ai-modal-avatar"><i class="bi bi-stars"></i></div>
      <div class="ask-ai-modal-meta">
        <div class="ask-ai-modal-title" id="ask-ai-modal-title">Ask <?= esc(brand_name()) ?> AI</div>
        <div class="ask-ai-modal-sub"><span class="ask-ai-dot"></span>Powered by Claude · Instant answers about delivery, licences, refunds &amp; more</div>
      </div>
      <button type="button" class="ask-ai-modal-close" onclick="closeAskAiModal()" aria-label="Close" data-testid="ask-ai-modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="ask-ai-modal-chips" data-testid="ask-ai-modal-chips">
      <button type="button" class="ask-ai-modal-chip" data-q="Which Office is right for my Mac?">Which Office for Mac?</button>
      <button type="button" class="ask-ai-modal-chip" data-q="How long does delivery take?">Delivery time?</button>
      <button type="button" class="ask-ai-modal-chip" data-q="What is your refund policy?">Refund policy?</button>
      <button type="button" class="ask-ai-modal-chip" data-q="Is this a one-time purchase or subscription?">One-time or subscription?</button>
    </div>
    <div id="ask-ai-modal-thread" class="ask-ai-modal-thread" data-testid="ask-ai-modal-thread"></div>
    <form id="ask-ai-modal-form" class="ask-ai-modal-form" onsubmit="askAiModalSubmit(event)" autocomplete="off">
      <input type="text" id="ask-ai-modal-input" name="ask_ai_question" class="form-control" placeholder="Ask anything about our store…" maxlength="500" autocomplete="off" data-testid="ask-ai-modal-input" required>
      <button type="submit" class="ask-ai-modal-send" data-testid="ask-ai-modal-send" aria-label="Send"><i class="bi bi-send-fill"></i></button>
    </form>
    <div class="ask-ai-modal-footer">
      <i class="bi bi-info-circle me-1"></i>For order-specific help, use the <a href="#" onclick="closeAskAiModal(); toggleChat(); return false;">live chat</a>.
    </div>
  </div>
</div>

<style>
.ask-ai-modal {
  position: fixed; inset: 0; z-index: 1090;
  display: none; align-items: flex-end; justify-content: center;
}
.ask-ai-modal.open { display: flex; }
@media (min-width: 768px) { .ask-ai-modal { align-items: center; } }
.ask-ai-modal-backdrop {
  position: absolute; inset: 0;
  background: rgba(2,6,23,.55); backdrop-filter: blur(4px);
  animation: aaFade .25s ease;
}
@keyframes aaFade { from { opacity: 0; } to { opacity: 1; } }
.ask-ai-modal-card {
  position: relative; z-index: 1;
  width: 100%; max-width: 560px;
  max-height: 90vh; display: flex; flex-direction: column;
  background: var(--bs-body-bg, #fff); color: var(--bs-body-color);
  border: 1px solid var(--bs-border-color);
  border-radius: 22px 22px 0 0;
  box-shadow: 0 -20px 60px rgba(2,6,23,.35);
  animation: aaSlide .3s cubic-bezier(.22,.61,.36,1);
  overflow: hidden;
}
@media (min-width: 768px) { .ask-ai-modal-card { border-radius: 22px; margin: 1rem; } }
@keyframes aaSlide { from { transform: translateY(24px); opacity: 0; } to { transform: none; opacity: 1; } }
.ask-ai-modal-head {
  display: flex; align-items: center; gap: .8rem;
  padding: 1rem 1.1rem;
  background: linear-gradient(135deg, rgba(6,182,212,.10), rgba(45,212,191,.06));
  border-bottom: 1px solid var(--bs-border-color);
}
.ask-ai-modal-avatar {
  width: 42px; height: 42px; border-radius: 12px; flex-shrink: 0;
  display: inline-flex; align-items: center; justify-content: center;
  color: #fff; font-size: 1.2rem;
  background: linear-gradient(135deg, #06b6d4, #2dd4bf);
  box-shadow: 0 6px 14px rgba(6,182,212,.35);
}
.ask-ai-modal-meta { flex: 1 1 auto; min-width: 0; line-height: 1.25; }
.ask-ai-modal-title { font-weight: 700; font-size: 1.02rem; }
.ask-ai-modal-sub { font-size: .74rem; color: var(--bs-secondary-color); }
.ask-ai-dot {
  display: inline-block; width: 7px; height: 7px; border-radius: 50%;
  background: #10b981; margin-right: 5px; vertical-align: 1px;
  box-shadow: 0 0 0 3px rgba(16,185,129,.18);
  animation: aaPulse 1.8s ease-in-out infinite;
}
@keyframes aaPulse { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.25);opacity:.7} }
.ask-ai-modal-close {
  background: transparent; border: 0; color: var(--bs-secondary-color);
  font-size: 1.05rem; padding: .3rem .55rem; border-radius: 8px;
  transition: background-color .15s ease, color .15s ease;
}
.ask-ai-modal-close:hover { background: var(--bs-tertiary-bg); color: var(--bs-body-color); }
.ask-ai-modal-chips {
  display: flex; gap: .4rem; padding: .75rem 1.1rem;
  border-bottom: 1px solid var(--bs-border-color);
  overflow-x: auto; scrollbar-width: thin;
}
.ask-ai-modal-chip {
  flex-shrink: 0; font-size: .76rem; font-weight: 600;
  padding: .35rem .8rem; border-radius: 999px;
  background: var(--bs-tertiary-bg); border: 1px solid var(--bs-border-color);
  color: var(--bs-body-color); cursor: pointer;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease;
}
.ask-ai-modal-chip:hover { background: rgba(6,182,212,.1); border-color: rgba(6,182,212,.4); color: #0891b2; }
.ask-ai-modal-thread {
  flex: 1 1 auto; overflow-y: auto; padding: 1rem 1.1rem;
  display: flex; flex-direction: column; gap: .7rem;
  min-height: 180px; max-height: 45vh;
}
.ask-ai-msg {
  display: flex; gap: .55rem; align-items: flex-start;
  animation: aaMsgIn .3s cubic-bezier(.22,.61,.36,1);
}
@keyframes aaMsgIn { from { transform: translateY(6px); opacity: 0; } to { transform: none; opacity: 1; } }
.ask-ai-msg-avatar {
  width: 30px; height: 30px; border-radius: 50%; flex-shrink: 0;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: .8rem; color: #fff;
}
.ask-ai-msg.you { flex-direction: row-reverse; }
.ask-ai-msg.you .ask-ai-msg-avatar { background: linear-gradient(135deg, #64748b, #94a3b8); }
.ask-ai-msg.ai .ask-ai-msg-avatar { background: linear-gradient(135deg, #06b6d4, #2dd4bf); }
.ask-ai-msg-bubble {
  max-width: 78%; padding: .55rem .85rem; border-radius: 14px;
  font-size: .87rem; line-height: 1.5;
  background: var(--bs-tertiary-bg); border: 1px solid var(--bs-border-color);
  white-space: pre-wrap;
}
.ask-ai-msg.you .ask-ai-msg-bubble {
  background: linear-gradient(135deg, #0891b2, #06b6d4); color: #fff; border-color: transparent;
}
.ask-ai-msg.error .ask-ai-msg-bubble {
  background: rgba(239,68,68,.08); border-color: rgba(239,68,68,.35); color: #b91c1c;
}
[data-bs-theme="dark"] .ask-ai-msg.error .ask-ai-msg-bubble { color: #fca5a5; }
.ask-ai-typing { display: inline-flex; gap: 4px; }
.ask-ai-typing span {
  width: 6px; height: 6px; border-radius: 50%; background: #06b6d4;
  animation: aaTypingDot 1.2s ease-in-out infinite;
}
.ask-ai-typing span:nth-child(2) { animation-delay: .15s; }
.ask-ai-typing span:nth-child(3) { animation-delay: .3s; }
@keyframes aaTypingDot { 0%,60%,100%{transform:translateY(0);opacity:.55} 30%{transform:translateY(-5px);opacity:1} }
.ask-ai-modal-form {
  display: flex; gap: .5rem; padding: .8rem 1.1rem;
  border-top: 1px solid var(--bs-border-color);
}
.ask-ai-modal-form .form-control {
  border-radius: 12px; padding: .6rem .9rem; font-size: .92rem;
}
.ask-ai-modal-send {
  border: 0; background: linear-gradient(135deg, #06b6d4, #2dd4bf);
  color: #fff; width: 44px; height: 44px; flex-shrink: 0; border-radius: 12px;
  display: inline-flex; align-items: center; justify-content: center;
  box-shadow: 0 6px 14px rgba(6,182,212,.35);
  transition: transform .15s ease, box-shadow .15s ease;
}
.ask-ai-modal-send:hover { transform: translateY(-1px); box-shadow: 0 10px 22px rgba(6,182,212,.45); }
.ask-ai-modal-send:disabled { opacity: .5; cursor: not-allowed; transform: none; }
.ask-ai-modal-footer {
  padding: .6rem 1.1rem; font-size: .74rem; color: var(--bs-secondary-color);
  border-top: 1px solid var(--bs-border-color); background: var(--bs-tertiary-bg);
}
</style>

<script>
(function () {
  // ============================================================
  // Global Ask AI modal wiring — real LLM Q&A (not the live chat).
  // ============================================================
  var __askAiHasGreeted = false;

  function openAskAiModal(seedQ) {
    var m = document.getElementById('ask-ai-modal');
    if (!m) return;
    m.classList.add('open');
    document.body.style.overflow = 'hidden';
    if (!__askAiHasGreeted) {
      __appendAskAiMsg('ai', "Hi! I'm the store assistant. Ask me anything about products, delivery, licences or refunds — I'll answer instantly.");
      __askAiHasGreeted = true;
    }
    setTimeout(function () {
      var i = document.getElementById('ask-ai-modal-input');
      if (i) i.focus();
      if (seedQ) { i.value = seedQ; __askAiModalSend(seedQ); }
    }, 100);
  }
  window.openAskAiModal = openAskAiModal;
  function closeAskAiModal() {
    var m = document.getElementById('ask-ai-modal');
    if (!m) return;
    m.classList.remove('open');
    document.body.style.overflow = '';
  }
  window.closeAskAiModal = closeAskAiModal;

  function __appendAskAiMsg(who, text, cls) {
    var t = document.getElementById('ask-ai-modal-thread');
    if (!t) return null;
    var wrap = document.createElement('div');
    wrap.className = 'ask-ai-msg ' + who + (cls ? ' ' + cls : '');
    var av  = document.createElement('div');
    av.className = 'ask-ai-msg-avatar';
    av.innerHTML = who === 'you' ? '<i class="bi bi-person-fill"></i>' : '<i class="bi bi-stars"></i>';
    var bub = document.createElement('div');
    bub.className = 'ask-ai-msg-bubble';
    bub.textContent = text;
    wrap.appendChild(av); wrap.appendChild(bub);
    t.appendChild(wrap);
    t.scrollTop = t.scrollHeight;
    return bub;
  }

  async function __askAiModalSend(question) {
    var inp = document.getElementById('ask-ai-modal-input');
    var btn = document.querySelector('.ask-ai-modal-send');
    __appendAskAiMsg('you', question);
    if (inp) inp.value = '';
    if (btn) btn.disabled = true;
    var typing = __appendAskAiMsg('ai', '');
    if (typing) typing.innerHTML = '<span class="ask-ai-typing"><span></span><span></span><span></span></span>';
    try {
      var r = await fetch('ajax/ask-ai-general.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ question: question }),
      });
      var j = await r.json();
      if (typing && typing.parentElement) typing.parentElement.remove();
      if (j.ok && j.answer) {
        __appendAskAiMsg('ai', j.answer);
      } else {
        __appendAskAiMsg('ai', j.error || "Sorry — I couldn't answer that. Please try live chat.", 'error');
      }
    } catch (err) {
      if (typing && typing.parentElement) typing.parentElement.remove();
      __appendAskAiMsg('ai', 'Network hiccup — please try again in a moment.', 'error');
    }
    if (btn) btn.disabled = false;
    if (inp) inp.focus();
  }

  window.askAiModalSubmit = function (ev) {
    ev.preventDefault();
    var inp = document.getElementById('ask-ai-modal-input');
    if (!inp) return false;
    var q = (inp.value || '').trim();
    if (!q) return false;
    __askAiModalSend(q);
    return false;
  };

  // Chip clicks -> seed the input & send.
  document.addEventListener('click', function (e) {
    var chip = e.target.closest('.ask-ai-modal-chip');
    if (chip) {
      var q = chip.getAttribute('data-q') || chip.textContent.trim();
      if (q) __askAiModalSend(q);
    }
  });

  // ESC key closes the modal.
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      var m = document.getElementById('ask-ai-modal');
      if (m && m.classList.contains('open')) closeAskAiModal();
    }
  });

  // Convenience: expose openAskAiModal via a data attribute for buttons that
  // used to call toggleChat().
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open-ask-ai]');
    if (t) { e.preventDefault(); openAskAiModal(t.getAttribute('data-open-ask-ai') || ''); }
  });
})();
</script>

<style>
/* Mobile responsive fixes */
/* Long link-style badge pills must wrap, never push the page wider than the screen */
a.badge { max-width:100%; white-space:normal; word-break:break-word; }
/* While any modal (e.g. Contact Sales / Request a Quote) is open, hide the
   floating chat widget so it can't overlap the slide-to-verify or the buttons */
body.modal-open #chat-bubble,
body.modal-open #chat-panel,
body.modal-open #chat-msg-preview { display:none !important; }
</style>

<!-- AI chat widget -->
<button id="chat-bubble" onclick="toggleChat()" aria-label="Open chat — Hi, how can I help?" data-testid="chat-bubble">
  <span class="chat-bubble-spark"><i class="bi bi-stars"></i></span>
  <span class="chat-bubble-text">Hi, How can I help?</span>
  <!-- Tiny bell + unread count overlay; surfaces the moment an admin replies
       while the panel is closed.  Disappears once the customer opens chat
       or starts typing a reply. -->
  <span id="chat-bell" class="chat-bell" style="display:none;" data-testid="chat-bell" aria-hidden="true">
    <i class="bi bi-bell-fill"></i>
    <span id="chat-bell-count" class="chat-bell-count" data-testid="chat-bell-count">1</span>
  </span>
</button>

<script>
/* ============================================================
   Draggable chat bubble — the customer can drag the "Chat" bubble to any
   edge of the viewport and it snaps to the nearest side. Position is
   persisted per browser via localStorage. Works with both mouse + touch.
   Small movements (< 5px) are treated as clicks (open chat), so accidental
   drag doesn't hijack the click handler.
   ============================================================ */
(function () {
  var bubble = document.getElementById('chat-bubble');
  if (!bubble) return;

  var STORAGE_KEY = 'mv_chat_bubble_pos';
  var MARGIN      = 18;   // min px from any viewport edge
  var CLICK_SLOP  = 5;    // px moved before it's a "drag" not a click

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function applyPos(x, y) {
    // Snap so the bubble stays fully on-screen.
    var w = bubble.offsetWidth, h = bubble.offsetHeight;
    x = clamp(x, MARGIN, window.innerWidth  - w - MARGIN);
    y = clamp(y, MARGIN, window.innerHeight - h - MARGIN);
    bubble.style.left   = x + 'px';
    bubble.style.top    = y + 'px';
    bubble.style.right  = 'auto';
    bubble.style.bottom = 'auto';
  }
  /* 2026-06 — Per UX request the bubble ALWAYS rests at the BOTTOM-RIGHT
     corner. The customer can still drag it around mid-gesture, but on
     release it glides back home to the bottom so it never blocks content
     or gets lost mid-page. No position is persisted. */
  function snapHome() {
    var w = bubble.offsetWidth, h = bubble.offsetHeight;
    bubble.style.left   = (window.innerWidth  - w - MARGIN) + 'px';
    bubble.style.top    = (window.innerHeight - h - MARGIN) + 'px';
    bubble.style.right  = 'auto';
    bubble.style.bottom = 'auto';
  }
  try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}

  var dragging = false, moved = false;
  var startPX = 0, startPY = 0, startBX = 0, startBY = 0;

  function onDown(ev) {
    var t = (ev.touches && ev.touches[0]) || ev;
    dragging = true; moved = false;
    startPX = t.clientX; startPY = t.clientY;
    var r = bubble.getBoundingClientRect();
    startBX = r.left; startBY = r.top;
    bubble.classList.add('is-dragging');
    // Prevent text selection while dragging.
    document.body.style.userSelect = 'none';
  }
  function onMove(ev) {
    if (!dragging) return;
    var t = (ev.touches && ev.touches[0]) || ev;
    var dx = t.clientX - startPX, dy = t.clientY - startPY;
    if (!moved && (Math.abs(dx) > CLICK_SLOP || Math.abs(dy) > CLICK_SLOP)) moved = true;
    if (moved) {
      applyPos(startBX + dx, startBY + dy);
      if (ev.preventDefault) ev.preventDefault();
    }
  }
  function onUp(ev) {
    if (!dragging) return;
    dragging = false;
    bubble.classList.remove('is-dragging');
    document.body.style.userSelect = '';
    if (moved) {
      /* After any drag the bubble auto-glides back HOME (bottom-right).
         A brief CSS transition makes the snap feel intentional. */
      bubble.style.transition = 'left .28s cubic-bezier(.2,.8,.2,1), top .28s cubic-bezier(.2,.8,.2,1)';
      snapHome();
      // Clear transition after the animation so future drags feel snappy.
      setTimeout(function () { bubble.style.transition = ''; }, 320);
      // Consume the click that would otherwise fire (Safari/iOS especially).
      if (ev && ev.type === 'mouseup') {
        var kill = function (e) { e.stopPropagation(); e.preventDefault(); bubble.removeEventListener('click', kill, true); };
        bubble.addEventListener('click', kill, true);
      }
    }
  }

  bubble.addEventListener('mousedown',  onDown);
  bubble.addEventListener('touchstart', onDown, { passive: true });
  document.addEventListener('mousemove', onMove, { passive: false });
  document.addEventListener('touchmove', onMove, { passive: false });
  document.addEventListener('mouseup',   onUp);
  document.addEventListener('touchend',  onUp);
  document.addEventListener('touchcancel', onUp);
  // Keep the bubble at its bottom-right rest slot on resize / rotation.
  window.addEventListener('resize', function () {
    if (bubble.style.left) snapHome();
  });
})();
</script>
<style>
/* Give the chat bubble a subtle visual affordance for drag: the cursor
   changes to grab, and there's a nicer pressed state during a drag. */
#chat-bubble { cursor: grab; touch-action: none; user-select: none; }
#chat-bubble.is-dragging { cursor: grabbing; transform: scale(1.08); box-shadow: 0 14px 32px rgba(6,182,212,.55); transition: none; }
</style>
<!-- Messenger-style admin-reply preview — slides in to the LEFT of the
     chat bubble whenever an admin reply lands while the panel is closed,
     so the customer can see what the agent said before opening chat.
     Clicking it opens the chat immediately.  Auto-fades when the chat
     opens or the customer starts replying. -->
<div id="chat-msg-preview" class="chat-msg-preview" style="display:none;" onclick="openChatFromPreview()" data-testid="chat-msg-preview" role="button" tabindex="0">
  <div class="chat-msg-preview-head">
    <span class="chat-msg-preview-avatar"><i class="bi bi-headset"></i></span>
    <div class="chat-msg-preview-meta">
      <div class="chat-msg-preview-name"><?= esc(brand_name()) ?> Support</div>
      <div class="chat-msg-preview-sub"><span class="chat-online-dot"></span>just now</div>
    </div>
    <button class="chat-msg-preview-close" type="button" onclick="event.stopPropagation(); hideChatMsgPreview();" aria-label="Dismiss preview" data-testid="chat-msg-preview-close"><i class="bi bi-x"></i></button>
  </div>
  <div class="chat-msg-preview-body" id="chat-msg-preview-body" data-testid="chat-msg-preview-body">—</div>
  <div class="chat-msg-preview-cta">Tap to reply →</div>
</div>
<div id="chat-panel" data-testid="chat-panel">
  <div id="chat-head" class="d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
      <button type="button" class="chat-head-btn chat-head-back" onclick="toggleChat()" aria-label="Minimize chat" data-testid="chat-back"><i class="bi bi-chevron-left"></i></button>
      <span class="chat-avatar chat-avatar-photo"><img src="https://images.pexels.com/photos/7709255/pexels-photo-7709255.jpeg?auto=compress&cs=tinysrgb&w=160&h=160&fit=crop" alt="Addie" loading="lazy" decoding="async"></span>
      <div class="lh-sm">
        <div class="chat-head-name" data-testid="chat-head-name">Addie</div>
        <small class="chat-head-sub">The team can also help</small>
      </div>
    </div>
    <div class="d-flex align-items-center gap-1">
      <button type="button" id="chat-startover-btn" class="chat-head-btn chat-startover-btn" style="display:none;" onclick="startOverChat()" aria-label="Start a new chat" title="Start over — begin a new conversation" data-testid="chat-startover-btn"><i class="bi bi-arrow-counterclockwise"></i></button>
      <button type="button" class="chat-head-btn" onclick="toggleChat()" aria-label="Close chat" data-testid="chat-close"><i class="bi bi-x-lg"></i></button>
    </div>
  </div>
  <div id="chat-body">
    <!-- Addie greeting — always shown at the top of the thread.  Mirrors the
         friendly first-touch message; the 3-field contact form sits right
         below it on first open. -->
    <div class="chat-addie-greeting" id="chat-addie-greeting" data-testid="chat-addie-greeting">
      <div class="chat-msg bot chat-addie-bubble"><strong>Need help with your order? 👋</strong><br>Chat with an order specialist about your <?= esc($brandName) ?> order or license delivery.</div>
      <div class="chat-addie-meta">Addie • Just now</div>
    </div>
    <!-- AI welcome + quick chips kept in markup for ProAssist auto-open flows
         but hidden by default until JS detects the customer is already
         identified (proLeadId, returning lead, etc.). -->
    <div class="chat-msg bot" id="chat-welcome-msg" data-testid="chat-default-message" style="display:none;">Need help with your order or license delivery? Chat with an order specialist and we'll help with products, pricing, delivery or activation.</div>
    <div class="chat-chips" id="chat-chips" data-testid="chat-chips" style="display:none;">
      <button class="chat-chip" onclick="quickAsk('Which Office is right for my Mac?')" data-testid="chat-chip-mac"><i class="bi bi-apple me-1"></i>Office for Mac</button>
      <button class="chat-chip" onclick="quickAsk('What is the best deal on Office 2024 right now?')" data-testid="chat-chip-deal"><i class="bi bi-tags me-1"></i>Best deals on Office 2024</button>
      <button class="chat-chip" onclick="quickAsk('How do I activate my license key after purchase?')" data-testid="chat-chip-activate"><i class="bi bi-key me-1"></i>Activation help</button>
      <button class="chat-chip" onclick="quickAsk('Do your licenses expire or need a subscription?')" data-testid="chat-chip-license"><i class="bi bi-infinity me-1"></i>License validity</button>
    </div>

    <!-- ====================================================================
         INITIAL VIEW (iteration 20): chat opens straight to the contact
         form — just 3 fields (full name, email, phone) and ONE blue send
         arrow button.  No "type a message" box yet.  Once the customer
         submits, this card is hidden and we reveal:
           (a) a "Thanks for contacting the support team" agent greeting
           (b) the message input box (chat-input-row below)
         The customer's real question is then routed straight to admin
         lead management — no AI auto-replies in between.
         ==================================================================== -->
    <div id="chat-lead-form" class="chat-lead-card" style="display:block;" data-testid="chat-lead-form">
      <?php if (function_exists('mv_is_admin_session') && mv_is_admin_session()): ?>
      <div class="chat-lead-title" style="background:#fef3c7;color:#92400e;border-radius:10px;padding:8px 10px;font-size:12px;" data-testid="chat-admin-note"><i class="bi bi-shield-lock me-1"></i>Admin session — this widget always starts fresh here and never shows a customer's conversation. Use a private window to test as a customer.</div>
      <?php endif; ?>
      <div class="chat-lead-title" data-testid="chat-lead-title">Tell us how to reach you and what you need help with — a support agent will get right back to you.</div>
      <div class="chat-lead-field-row chat-lead-two">
        <div>
          <label class="chat-lead-label" for="lead-first">First name</label>
          <input id="lead-first" class="form-control form-control-sm chat-lead-input" placeholder="First name" data-testid="lead-first" autocomplete="given-name" maxlength="40">
        </div>
        <div>
          <label class="chat-lead-label" for="lead-last">Last name</label>
          <input id="lead-last" class="form-control form-control-sm chat-lead-input" placeholder="Last name" data-testid="lead-last" autocomplete="family-name" maxlength="40">
        </div>
      </div>
      <div class="chat-lead-field-row">
        <label class="chat-lead-label" for="lead-email">Email address</label>
        <input id="lead-email" type="email" class="form-control form-control-sm chat-lead-input" placeholder="you@example.com" data-testid="lead-email" autocomplete="email">
      </div>
      <div class="chat-lead-field-row">
        <label class="chat-lead-label" for="lead-phone">Phone number</label>
        <input id="lead-phone" type="tel" class="form-control form-control-sm chat-lead-input" placeholder="Phone number"   data-testid="lead-phone" autocomplete="tel">
      </div>
      <div class="chat-lead-field-row">
        <label class="chat-lead-label" for="lead-issue">What do you need help with?</label>
        <textarea id="lead-issue" rows="3" class="form-control form-control-sm chat-lead-input" placeholder="Type your question or issue here (e.g. activation help, wrong key, refund…)" data-testid="lead-issue"></textarea>
      </div>
      <!-- Honeypot: invisible to people, irresistible to form bots. Any value = rejected server-side. -->
      <div class="chat-hp" aria-hidden="true"><label for="lead-website">Website</label><input id="lead-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
      <!-- "Verify you're human": signed challenge + dwell time + proof-of-work (ajax/human-check.php). -->
      <div class="chat-lead-field-row">
        <button type="button" class="chat-human" id="chat-human-btn" onclick="chatHumanVerify()" data-testid="chat-human-check" data-state="idle" role="switch" aria-checked="false" aria-live="polite">
          <span class="chat-human-toggle" aria-hidden="true"><span class="chat-human-knob"><i class="bi bi-check-lg"></i></span></span>
          <span class="chat-human-text"><span class="chat-human-label">Verify you're human</span><span class="chat-human-sub">Tap once — takes a second</span></span>
          <span class="chat-human-shield" aria-hidden="true"><i class="bi bi-shield-check"></i></span>
        </button>
      </div>
      <div class="chat-lead-field-row chat-lead-row-send">
        <button type="button"
                class="chat-lead-send-btn chat-lead-send-btn-wide"
                onclick="submitLead()"
                data-testid="lead-send-btn"
                aria-label="Send to support"
                disabled>
          <i class="bi bi-send-fill me-1"></i><span>Send</span>
        </button>
      </div>
      <div id="chat-lead-error" class="chat-lead-error" style="display:none;" data-testid="chat-lead-error"></div>
      <!-- Backwards-compat hidden button so older test scripts that click
           [data-testid=lead-chat-btn] still trigger the submit. -->
      <button type="button" class="d-none" onclick="submitLead()" data-testid="lead-chat-btn"></button>
    </div>
    <!-- Post-send choice card: shown after the lead form is submitted.
         Customer picks a callback OR to keep chatting live. -->
    <div id="chat-lead-choice" class="chat-lead-card" style="display:none;" data-testid="chat-lead-choice">
      <div class="chat-lead-choice-thanks" data-testid="chat-lead-choice-thanks">
        <div class="chat-lead-choice-icon"><i class="bi bi-check-circle-fill"></i></div>
        <div class="chat-lead-choice-title">You're verified — thanks!</div>
        <div class="chat-lead-choice-sub">Our team has your details. How would you like us to help?</div>
      </div>
      <button type="button" class="chat-lead-choice-btn chat-lead-choice-btn-primary" onclick="chooseCallback()" data-testid="lead-choice-callback">
        <i class="bi bi-telephone-fill me-2"></i>Request a call back
      </button>
      <button type="button" class="chat-lead-choice-btn" onclick="chooseContinueChat()" data-testid="lead-choice-continue">
        <i class="bi bi-chat-dots-fill me-2"></i>Continue with chat
      </button>
    </div>
    <!-- ProAssist install-call scheduler — shown when JS detects a ProAssist
         purchaser with no booking yet.  Customer picks timezone → date → time.
         Bookings convert to IST in the admin panel. -->
    <div id="pa-sched-card" class="pa-sched-card" style="display:none;" data-testid="pa-sched-card">
      <div class="pa-sched-header">
        <i class="bi bi-calendar-check"></i>
        <div>
          <div class="pa-sched-title" data-testid="pa-sched-title">Schedule a callback</div>
          <div class="pa-sched-sub" data-testid="pa-sched-sub">Pick a time that works for you</div>
        </div>
      </div>
      <div class="pa-sched-step">
        <div class="pa-sched-step-label">Your time zone</div>
        <select id="pa-sched-tz" class="pa-sched-tz-select" data-testid="pa-sched-tz-select" aria-label="Time zone"></select>
      </div>
      <div class="pa-sched-step">
        <div class="pa-sched-step-label">Select a date</div>
        <div class="pa-sched-dates" id="pa-sched-dates" data-testid="pa-sched-dates"></div>
      </div>
      <div class="pa-sched-step" id="pa-sched-times-step" style="display:none;">
        <div class="pa-sched-step-label">Available times <span class="pa-sched-tz" id="pa-sched-times-tz"></span></div>
        <div class="pa-sched-times" id="pa-sched-times" data-testid="pa-sched-times"></div>
        <button type="button" class="pa-sched-back" onclick="paSchedBackToDates()" data-testid="pa-sched-back">&larr; Back to dates</button>
      </div>
      <div class="pa-sched-error" id="pa-sched-error" style="display:none;" data-testid="pa-sched-error"></div>
    </div>
    <!-- Confirmed-booking card (shown after a successful book / on reopen). -->
    <div id="pa-sched-confirm" class="pa-sched-confirm" style="display:none;" data-testid="pa-sched-confirm"></div>
  </div>
  <div id="chat-typing" class="chat-typing" style="display:none;" data-testid="chat-admin-typing">
    <div class="chat-typing-bubble">
      <span class="chat-typing-dot"></span>
      <span class="chat-typing-dot"></span>
      <span class="chat-typing-dot"></span>
      <span class="chat-typing-text">Live agent is typing…</span>
    </div>
  </div>
  <form id="chat-input-row" class="chat-input-row d-none p-2" onsubmit="sendChat(event)" data-testid="chat-input-row">
    <div class="chat-composer">
      <input id="chat-input" class="chat-input" placeholder="Ask a question…" autocomplete="off" data-testid="chat-input">
      <div class="chat-composer-tools">
        <button type="button" class="chat-tool-btn" id="chat-attach-btn" onclick="chatAttachClick()" aria-label="Attach a file" title="Attach a file" data-testid="chat-attach-btn"><i class="bi bi-paperclip"></i></button>
        <button type="button" class="chat-tool-btn chat-mic-tip" id="chat-mic-btn" onclick="chatToggleVoice()" aria-label="Voice to text (speak in any language, replies appear in English)" title="🎙️ Speak in any language — replies appear in English" data-tip="Speak in any language — replies appear in English" data-testid="chat-mic-btn"><i class="bi bi-mic-fill"></i></button>
        <button type="button" class="chat-tool-btn" id="chat-emoji-btn" onclick="chatToggleEmoji(event)" aria-label="Insert emoji" title="Insert emoji" data-testid="chat-emoji-btn"><i class="bi bi-emoji-smile"></i></button>
        <span class="chat-voice-timer" id="chat-voice-timer" style="display:none;" data-testid="chat-voice-timer"><span class="chat-voice-rec-dot"></span><span id="chat-voice-time">0:00</span></span>
        <button class="chat-send-btn ms-auto" type="submit" aria-label="Send" data-testid="chat-send"><i class="bi bi-arrow-up"></i></button>
      </div>
    </div>
    <input type="file" id="chat-file-input" class="d-none" data-testid="chat-file-input" accept="image/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip">
    <div class="chat-emoji-panel" id="chat-emoji-panel" style="display:none;" data-testid="chat-emoji-panel"></div>
    <div class="chat-attach-status" id="chat-attach-status" style="display:none;" data-testid="chat-attach-status"></div>
  </form>
  <div class="chat-talk-band" data-testid="chat-talk-band">Prefer to talk?<a href="tel:<?= esc(tel_e164($brandPhone)) ?>" class="chat-talk-phone" data-testid="chat-talk-phone"><i class="bi bi-telephone-fill chat-talk-phone-ring"></i><?= esc($brandPhone) ?></a></div>
</div>

<!--
   Defer non-critical JS so the browser can render the hero + nav before
   parsing/executing.  `defer` keeps the original execution order
   (Bootstrap → main.js) and waits until DOMContentLoaded — same behaviour
   as the previous blocking <script> but with no parser pause.  This is
   the single biggest Core-Web-Vitals win for a server-rendered site.
-->
<script defer src="assets/vendor/bootstrap.bundle.min.js?v=<?= esc(@filemtime(__DIR__ . '/../assets/vendor/bootstrap.bundle.min.js')) ?>"></script>
<script defer src="<?= esc(min_js_url(__DIR__ . '/../assets/js/main.js', 'assets/js/main.js')) ?>"></script>
<!-- 3D scroll effect (assets/js/scroll3d.js) removed per merchant request
     2026-07-16 — the reveal-on-scroll / pointer-tilt animations were
     disabled site-wide. The source file remains on disk so the effect
     can be re-enabled by restoring this <script defer …> tag if ever
     needed (paired with the scroll3d.css include in includes/header.php). -->

<!--
   Lazy-load + async-decode every image that's not already in the initial
   viewport.  Saves bandwidth on long product pages and improves LCP for
   the few images that DO need to load eagerly above the fold.  Runs once
   on DOMContentLoaded; the IntersectionObserver branch upgrades the
   "lazy" attribute to a real observer for browsers that need it.
-->
<script>
(function(){
  function applyLazy(){
    var vh = window.innerHeight || 800;
    document.querySelectorAll('img:not([loading]):not([data-eager])').forEach(function(img){
      var rect = img.getBoundingClientRect();
      // First-viewport images stay eager (LCP candidates); everything else
      // is marked lazy + async-decode so the main thread doesn't block.
      if (rect.top > vh) {
        img.loading = 'lazy';
        img.decoding = 'async';
      } else {
        // Hint to the browser this is high-priority LCP material.
        img.fetchPriority = 'high';
      }
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyLazy, { once: true });
  } else {
    applyLazy();
  }
})();
</script>
<?php
/* Google Customer Reviews site-wide badge — shows the "Google Customer
   Reviews" seal with the seller rating once enough survey responses are
   collected. Gated on the badge flag + a configured Merchant ID. */
$__gcrBadge = function_exists('setting_get') ? (setting_get('gcr_badge', '0') === '1') : false;
$__gmc = function_exists('setting_get')
    ? trim((string)setting_get('google_merchant_id', defined('GOOGLE_MERCHANT_ID') ? GOOGLE_MERCHANT_ID : ''))
    : '';
if ($__gcrBadge && $__gmc !== ''):
?>
<!-- Google Customer Reviews badge -->
<script src="https://apis.google.com/js/platform.js?onload=renderGcrBadge" async defer></script>
<script>
window.renderGcrBadge = function () {
    var c = document.createElement('div');
    document.body.appendChild(c);
    window.gapi.load('ratingbadge', function () {
        window.gapi.ratingbadge.render(c, { "merchant_id": "<?= esc($__gmc) ?>", "position": "BOTTOM_LEFT" });
    });
};
</script>
<!-- end Google Customer Reviews badge -->
<?php endif; ?>
<script>
/* Email-privacy: assemble mailto hrefs client-side so no plain-text address
   sits in the HTML source (visible text uses the &#64; entity + a span, so it
   still reads as an email to humans but not to scraper regexes). */
(function(){
  function initObfEmails(){
    document.querySelectorAll('a[data-obf]').forEach(function(a){
      if(a.dataset.done) return;
      var e=(a.dataset.eu||'')+String.fromCharCode(64)+(a.dataset.ed||'');
      a.setAttribute('href','mailto:'+e);
      a.dataset.done='1';
    });
  }
  if(document.readyState!=='loading') initObfEmails();
  else document.addEventListener('DOMContentLoaded', initObfEmails, {once:true});
})();
</script>
<?php include __DIR__ . '/consent-banner.php'; ?>
</body>
</html>
