<?php
/**
 * Daily Digest — one branded summary email per day to the store owner:
 * new sales, new leads and new install requests in the last 24 hours.
 *
 * Trigger:
 *   - Opportunistic: admin.php calls mv_daily_digest_maybe_send() on load
 *     (cheap: a single settings read + date compare; only does work once/day).
 *   - Cron: cron/daily-digest.php can be scheduled if the host has cron.
 *
 * Zero-DDL: uses only existing tables + a settings flag (daily_digest_sent_date).
 * Never throws into the caller — a mail failure is logged and swallowed.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/email.php';
require_once __DIR__ . '/mailer.php';

if (!function_exists('mv_daily_digest_collect')) {

function mv_daily_digest_collect(): array {
    $pdo = db();
    $out = [
        'sales_count' => 0, 'sales_revenue' => 0.0, 'sales_rows' => [],
        'leads_count' => 0, 'leads_rows' => [],
        'installs_count' => 0, 'installs_rows' => [], 'installs_upcoming' => 0,
    ];
    // --- New paid sales in the last 24h ---
    try {
        $st = $pdo->query(
            "SELECT order_number, COALESCE(email,'') AS email,
                    COALESCE(total,0) AS total, COALESCE(currency,'USD') AS currency, created_at
               FROM orders
              WHERE created_at >= NOW() - INTERVAL 24 HOUR
                AND (LOWER(COALESCE(status,'')) IN ('paid','completed')
                     OR LOWER(COALESCE(payment_status,'')) IN ('succeeded','paid','captured','completed'))
              ORDER BY created_at DESC LIMIT 25"
        );
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $out['sales_rows'] = $rows;
        $out['sales_count'] = count($rows);
        foreach ($rows as $r) $out['sales_revenue'] += (float)$r['total'];
    } catch (Throwable $e) { @error_log('[digest sales] ' . $e->getMessage()); }
    // --- New leads (chat_leads) in the last 24h ---
    try {
        $st = $pdo->query(
            "SELECT COALESCE(name,'Guest') AS name, COALESCE(email,'') AS email,
                    COALESCE(phone,'') AS phone, COALESCE(requested_product,'') AS product,
                    COALESCE(status,'new') AS status, created_at
               FROM chat_leads
              WHERE created_at >= NOW() - INTERVAL 24 HOUR
              ORDER BY created_at DESC LIMIT 25"
        );
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $out['leads_rows'] = $rows;
        $out['leads_count'] = count($rows);
    } catch (Throwable $e) { @error_log('[digest leads] ' . $e->getMessage()); }
    // --- New install requests (proassist_schedules) in the last 24h + upcoming pending ---
    try {
        $st = $pdo->query(
            "SELECT customer_name, COALESCE(customer_email,'') AS customer_email,
                    scheduled_at, tz, COALESCE(status,'pending') AS status, created_at
               FROM proassist_schedules
              WHERE created_at >= NOW() - INTERVAL 24 HOUR
              ORDER BY created_at DESC LIMIT 25"
        );
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $out['installs_rows'] = $rows;
        $out['installs_count'] = count($rows);
        $out['installs_upcoming'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM proassist_schedules
              WHERE status IN ('pending','confirmed') AND scheduled_utc >= NOW()"
        )->fetchColumn();
    } catch (Throwable $e) { @error_log('[digest installs] ' . $e->getMessage()); }
    return $out;
}

function mv_daily_digest_html(array $d): string {
    $base    = rtrim(email_public_base(), '/');
    $logo    = email_brand_logo_src();
    $company = esc(setting_get('company_name', 'Maventech') ?: 'Maventech');
    $today   = date('l, M j, Y');
    $money   = function ($n) { return '$' . number_format((float)$n, 2); };

    $card = function ($label, $value, $accent) {
        return '<td style="padding:0 8px;" width="33%"><div style="background:#f8fafc;border:1px solid #eef2f7;border-top:3px solid ' . $accent . ';border-radius:12px;padding:16px 14px;text-align:center;">'
             . '<div style="font-size:30px;font-weight:800;color:#0f172a;line-height:1;">' . $value . '</div>'
             . '<div style="font-size:11px;color:#64748b;letter-spacing:.6px;text-transform:uppercase;margin-top:6px;">' . $label . '</div>'
             . '</div></td>';
    };

    // Sales rows
    $salesTbl = '';
    if ($d['sales_count'] > 0) {
        $salesTbl .= '<h2 style="font-size:14px;color:#0f172a;margin:26px 0 10px;">🛒 New sales</h2><table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12.5px;">';
        foreach ($d['sales_rows'] as $r) {
            $salesTbl .= '<tr style="border-bottom:1px solid #f1f3f5;">'
                . '<td style="padding:8px 6px;color:#0f172a;font-weight:600;">' . esc($r['order_number']) . '</td>'
                . '<td style="padding:8px 6px;color:#475569;">' . esc($r['email']) . '</td>'
                . '<td style="padding:8px 6px;color:#059669;font-weight:700;text-align:right;">' . $money($r['total']) . '</td></tr>';
        }
        $salesTbl .= '</table>';
    }
    // Leads rows
    $leadsTbl = '';
    if ($d['leads_count'] > 0) {
        $leadsTbl .= '<h2 style="font-size:14px;color:#0f172a;margin:26px 0 10px;">💬 New leads</h2><table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12.5px;">';
        foreach ($d['leads_rows'] as $r) {
            $contact = trim($r['email'] . ($r['phone'] ? ' · ' . $r['phone'] : ''));
            $leadsTbl .= '<tr style="border-bottom:1px solid #f1f3f5;">'
                . '<td style="padding:8px 6px;color:#0f172a;font-weight:600;">' . esc($r['name']) . '</td>'
                . '<td style="padding:8px 6px;color:#475569;">' . esc($contact ?: '—') . '</td>'
                . '<td style="padding:8px 6px;color:#64748b;text-align:right;">' . esc($r['product'] ?: $r['status']) . '</td></tr>';
        }
        $leadsTbl .= '</table>';
    }
    // Install rows
    $instTbl = '';
    if ($d['installs_count'] > 0) {
        $instTbl .= '<h2 style="font-size:14px;color:#0f172a;margin:26px 0 10px;">🛠️ New install requests</h2><table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12.5px;">';
        foreach ($d['installs_rows'] as $r) {
            $when = '';
            try { $when = $r['scheduled_at'] ? date('M j, g:i A', strtotime($r['scheduled_at'])) . ' ' . esc($r['tz']) : ''; } catch (Throwable $e) {}
            $instTbl .= '<tr style="border-bottom:1px solid #f1f3f5;">'
                . '<td style="padding:8px 6px;color:#0f172a;font-weight:600;">' . esc($r['customer_name']) . '</td>'
                . '<td style="padding:8px 6px;color:#475569;">' . esc($r['customer_email']) . '</td>'
                . '<td style="padding:8px 6px;color:#64748b;text-align:right;">' . $when . '</td></tr>';
        }
        $instTbl .= '</table>';
    }

    return '<!doctype html><html><body style="margin:0;padding:0;background:#fbfcfd;font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#1f2937;">'
     . '<div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 6px 28px rgba(15,23,42,.06);">'
     . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#0f172a;">'
     . '<tr><td style="padding:24px 32px;"><table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>'
     . '<td valign="middle" style="padding-right:14px;"><img src="' . esc($logo) . '" alt="' . $company . '" width="48" height="48" style="display:block;border-radius:12px;object-fit:contain;background:#fff;"></td>'
     . '<td valign="middle"><div style="font-size:19px;font-weight:800;color:#fff;">' . $company . '</div>'
     . '<div style="font-size:11px;color:#94a3b8;letter-spacing:1.4px;font-weight:600;">DAILY DIGEST</div></td>'
     . '</tr></table></td></tr></table>'
     . '<div style="padding:28px 32px;">'
     . '<h1 style="margin:0 0 4px;font-size:20px;color:#0f172a;font-weight:700;">Your store yesterday</h1>'
     . '<p style="margin:0 0 22px;font-size:13px;color:#64748b;">' . $today . '</p>'
     . '<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:separate;"><tr>'
     . $card('New sales', (int)$d['sales_count'], '#06b6d4')
     . $card('New leads', (int)$d['leads_count'], '#8b5cf6')
     . $card('Install reqs', (int)$d['installs_count'], '#f59e0b')
     . '</tr></table>'
     . '<div style="margin-top:16px;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:12px;padding:14px 18px;text-align:center;">'
     . '<span style="font-size:13px;color:#065f46;">Revenue in the last 24h: </span>'
     . '<strong style="font-size:18px;color:#047857;">' . $money($d['sales_revenue']) . '</strong></div>'
     . ($d['installs_upcoming'] > 0 ? '<p style="margin:12px 0 0;font-size:12px;color:#92400e;">📅 ' . (int)$d['installs_upcoming'] . ' upcoming install' . ($d['installs_upcoming'] == 1 ? '' : 's') . ' still pending/confirmed.</p>' : '')
     . $salesTbl . $leadsTbl . $instTbl
     . '<div style="margin-top:26px;text-align:center;"><a href="' . esc($base) . '/admin.php" style="display:inline-block;background:#06b6d4;color:#fff;text-decoration:none;font-weight:700;font-size:13px;padding:12px 26px;border-radius:999px;">Open the admin dashboard</a></div>'
     . '</div>'
     . '<div style="background:#f8fafc;padding:18px 32px;border-top:1px solid #f1f3f5;font-size:11px;color:#94a3b8;">You receive this once a day because you own the store. &copy; ' . date('Y') . ' ' . $company . '.</div>'
     . '</div></body></html>';
}

/**
 * Send the digest now if it hasn't been sent today. Returns a status array.
 * $force = true bypasses the once-a-day guard (used by the admin "preview" test).
 */
function mv_daily_digest_maybe_send(bool $force = false): array {
    try {
        $today = date('Y-m-d');
        if (!$force && setting_get('daily_digest_sent_date', '') === $today) {
            return ['ok' => true, 'skipped' => 'already-sent-today'];
        }
        // Serialize: only one request sends per day.
        $pdo = db();
        if (!$force) {
            try { $pdo->query("SELECT GET_LOCK('mv_daily_digest', 2)")->fetchColumn(); } catch (Throwable $e) {}
            if (setting_get('daily_digest_sent_date', '') === $today) {
                try { $pdo->query("SELECT RELEASE_LOCK('mv_daily_digest')"); } catch (Throwable $e) {}
                return ['ok' => true, 'skipped' => 'already-sent-today'];
            }
        }

        $to = trim((string)setting_get('company_email', ''));
        if ($to === '') { return ['ok' => false, 'error' => 'No company_email set — cannot send digest.']; }

        $d = mv_daily_digest_collect();
        $hasActivity = ($d['sales_count'] + $d['leads_count'] + $d['installs_count']) > 0;

        // On a fully quiet day, stamp the date but don't send (avoid inbox noise)
        // — unless forced (preview/test always sends).
        if (!$hasActivity && !$force) {
            setting_set('daily_digest_sent_date', $today);
            try { $pdo->query("SELECT RELEASE_LOCK('mv_daily_digest')"); } catch (Throwable $e) {}
            return ['ok' => true, 'skipped' => 'quiet-day'];
        }

        $subject = 'Daily digest — ' . $d['sales_count'] . ' sales, ' . $d['leads_count'] . ' leads, ' . $d['installs_count'] . ' installs';
        $html = mv_daily_digest_html($d);
        $res = smtp_send($to, $subject, $html, ['category' => 'daily_digest']);

        if (!$force) {
            setting_set('daily_digest_sent_date', $today);
            try { $pdo->query("SELECT RELEASE_LOCK('mv_daily_digest')"); } catch (Throwable $e) {}
        }
        return $res['ok']
            ? ['ok' => true, 'sent_to' => $to, 'sales' => $d['sales_count'], 'leads' => $d['leads_count'], 'installs' => $d['installs_count']]
            : ['ok' => false, 'error' => $res['error'] ?? 'send failed'];
    } catch (Throwable $e) {
        @error_log('[daily-digest] ' . $e->getMessage());
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

} // guard
