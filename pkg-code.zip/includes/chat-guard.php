<?php
// Shared visitor-side chat guard — used by every customer chat endpoint
// (chat-customer / chat-upload / proassist-schedule) so the isolation rules
// are identical everywhere:
//   1. the per-browser chat_token is the ONLY key when supplied (no session
//      fallback for an unknown token → the widget resets instead of attaching
//      to whatever lead the PHP session last touched);
//   2. an admin/staff browser may only talk to a lead it created itself
//      (same per-browser session id) — never a customer's thread;
//   3. hard IP lock: the chat continues only from the IP it started on; a new
//      IP must re-verify with the email used to open the chat.
// On failure the function emits the JSON error and exits.
require_once __DIR__ . '/functions.php';

function chat_guard_resolve(PDO $pdo, string $token, string $sessionId, string $action, array $in): int
{
    $token     = trim($token);
    $sessionId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionId), 0, 64);
    $leadId = 0; $lock = null;
    if ($token !== '') {
        try {
            $st = $pdo->prepare('SELECT id, session_id, email, client_ip FROM chat_leads WHERE chat_token=? LIMIT 1');
            $st->execute([$token]); $lock = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Throwable $e) {
            $st = $pdo->prepare('SELECT id, session_id, email FROM chat_leads WHERE chat_token=? LIMIT 1');
            $st->execute([$token]); $lock = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            if ($lock) $lock['client_ip'] = null;
        }
        $leadId = (int)($lock['id'] ?? 0);
        if (!$leadId) { echo json_encode(['ok'=>false,'error'=>'No lead','reset'=>true]); exit; }
        $_SESSION['lead_id'] = $leadId;
    }
    if (!$leadId) $leadId = (int)($_SESSION['lead_id'] ?? 0);
    if (!$leadId) { echo json_encode(['ok'=>false,'error'=>'No lead']); exit; }

    if (mv_is_admin_session()) {
        $ownSid = (string)($lock['session_id'] ?? '');
        if ($lock === null || $sessionId === '' || $ownSid === '' || !hash_equals($ownSid, $sessionId)) {
            unset($_SESSION['lead_id'], $_SESSION['chat_token']);
            echo json_encode(['ok'=>false,'error'=>'admin_isolated','reset'=>true]); exit;
        }
    }

    if ($lock !== null) {
        $ip      = client_ip();
        $boundIp = trim((string)($lock['client_ip'] ?? ''));
        if ($boundIp === '') {
            try { $pdo->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([$ip, $leadId]); } catch (Throwable $e) {}
        } elseif (!hash_equals($boundIp, $ip)) {
            if ($action === 'verify') {
                $em     = strtolower(trim((string)($in['email'] ?? '')));
                $leadEm = strtolower(trim((string)($lock['email'] ?? '')));
                if ($em !== '' && $leadEm !== '' && hash_equals($leadEm, $em)) {
                    try { $pdo->prepare('UPDATE chat_leads SET client_ip=? WHERE id=?')->execute([$ip, $leadId]); } catch (Throwable $e) {}
                    echo json_encode(['ok'=>true,'verified'=>true]); exit;
                }
                echo json_encode(['ok'=>false,'error'=>'verify_failed']); exit;
            }
            echo json_encode(['ok'=>false,'error'=>'ip_mismatch','verify'=>true]); exit;
        }
    }
    if ($action === 'verify') { echo json_encode(['ok'=>true,'verified'=>true]); exit; }
    return $leadId;
}
