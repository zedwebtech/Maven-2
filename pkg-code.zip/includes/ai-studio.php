<?php
/**
 * AI Studio — interactive, step-by-step blog & trending-article generation
 * for the admin panel (separate from the automatic AI Auto-Blogger).
 *
 * Flow:
 *   Product Blog   : product + country -> suggest keyword/topic ideas -> pick -> full SEO blog
 *   Trending Article: country -> suggest 12-15 trending topics -> pick -> full SEO article
 *
 * Uses the site's existing built-in AI key (via _seo_resolve_llm_credentials()).
 * All generated content carries proper SEO meta (title/description/keywords).
 */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/seo-bot.php';

/** Ensure blog_posts has the SEO meta columns (idempotent, zero-DDL-safe). */
function mv_ai_ensure_seo_cols(): void
{
    if (setting_get('ai_studio_seo_cols_v', '') === '1'
        && mv_col_exists('blog_posts', 'meta_title')) {
        return;
    }
    $pdo = db();
    foreach ([
        'meta_title'       => "ALTER TABLE blog_posts ADD meta_title VARCHAR(255) NULL",
        'meta_description' => "ALTER TABLE blog_posts ADD meta_description VARCHAR(320) NULL",
        'meta_keywords'    => "ALTER TABLE blog_posts ADD meta_keywords VARCHAR(320) NULL",
    ] as $col => $ddl) {
        if (!mv_col_exists('blog_posts', $col)) {
            try { $pdo->exec($ddl); } catch (Throwable $e) { /* zero-DDL host: skip */ }
        }
    }
    try { setting_set('ai_studio_seo_cols_v', '1'); } catch (Throwable $e) {}
}

/**
 * Fresh check (bypasses mv_col_exists's per-request static cache, which may
 * have cached "absent" just before mv_ai_ensure_seo_cols() ran the ALTER).
 * Memoised per request AFTER the ensure step so the INSERT sees the truth.
 */
function mv_ai_seo_cols_available(): bool
{
    static $ok = null;
    if ($ok !== null) return $ok;
    try {
        $n = (int)db()->query(
            "SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = 'blog_posts'
               AND column_name IN ('meta_title','meta_description','meta_keywords')"
        )->fetchColumn();
        $ok = ($n === 3);
    } catch (Throwable $e) { $ok = false; }
    return $ok;
}

/** Low-level chat call. Returns trimmed assistant text or throws. Retries on
 *  transient network/gateway failures (the "connection timed out" class of
 *  errors on shared hosts) with a short backoff so a blip never fails the UI. */
function mv_ai_llm_chat(string $sys, string $usr, int $maxTokens = 3000, float $temp = 0.6): string
{
    [$apiKey, $baseUrl] = _seo_resolve_llm_credentials();
    if (!$apiKey || !$baseUrl) {
        throw new RuntimeException('AI key not configured — add it under AI Auto-Blogger → API Keys.');
    }
    $payload = json_encode([
        'model'       => 'claude-haiku-4-5-20251001',
        'messages'    => [
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user',   'content' => $usr],
        ],
        'max_tokens'  => $maxTokens,
        'temperature' => $temp,
    ]);

    $lastErr = '';
    $attempts = 3;
    for ($i = 1; $i <= $attempts; $i++) {
        $ch = curl_init(rtrim($baseUrl, '/') . '/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey],
            CURLOPT_TIMEOUT        => 90,   // full round-trip budget for the model
            CURLOPT_CONNECTTIMEOUT => 20,   // was 8 — too aggressive on shared hosts (root cause of the timeout error)
            CURLOPT_TCP_KEEPALIVE  => 1,
        ]);
        $raw    = curl_exec($ch);
        $code   = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $errno  = curl_errno($ch);
        $err    = curl_error($ch);
        curl_close($ch);

        if (!$err && $raw && $code < 400) {
            $data = json_decode((string)$raw, true);
            $txt  = trim((string)($data['choices'][0]['message']['content'] ?? ''));
            if ($txt !== '') return $txt;
            $lastErr = 'empty response';
        } else {
            $lastErr = $err ?: ('HTTP ' . $code);
        }

        // Retry only on transient conditions: connect/timeout/DNS errors or
        // 429/5xx gateway responses. Non-retryable (401/400) breaks immediately.
        $transient = in_array($errno, [28, 7, 6, 35, 55, 56], true)
                  || in_array($code, [429, 500, 502, 503, 504], true)
                  || $lastErr === 'empty response';
        if ($i < $attempts && $transient) {
            usleep(($i * 900) * 1000); // 0.9s, 1.8s backoff
            continue;
        }
        break;
    }
    throw new RuntimeException('AI request failed (' . $lastErr . '). Please try again in a moment.');
}

/** Map region code -> audience description for the LLM. */
function mv_ai_audience(string $region): string
{
    $map = [
        'ALL' => 'an international audience (US, UK, AU, CA)',
        'US'  => 'a United States audience (US English, USD pricing, US brands & regulations)',
        'UK'  => 'a United Kingdom audience (British English, GBP pricing, UK GDPR)',
        'AU'  => 'an Australian audience (Australian English, AUD pricing, Australian Privacy Act)',
        'CA'  => 'a Canadian audience (Canadian English, CAD pricing, PIPEDA)',
    ];
    $region = strtoupper(trim($region)) ?: 'ALL';
    return $map[$region] ?? $map['ALL'];
}

/**
 * Suggest keyword/topic ideas.
 * @param string $mode 'blog' (needs $productId) or 'trends'
 * @return array list of ['topic'=>..,'keyword'=>..,'intent'=>..]
 */
function mv_ai_suggest_topics(string $mode, int $productId, string $region): array
{
    $region   = strtoupper(trim($region)) ?: 'ALL';
    $audience = mv_ai_audience($region);
    $today    = date('F Y');

    if ($mode === 'blog') {
        $pdo = db();
        $st  = $pdo->prepare("SELECT name, brand, category, version FROM products WHERE id = ? LIMIT 1");
        $st->execute([$productId]);
        $p = $st->fetch(PDO::FETCH_ASSOC);
        if (!$p) throw new RuntimeException('Product not found.');
        $sys = "You are an SEO strategist. Propose 12 blog keyword/topic ideas that are trending and "
             . "high-intent for {$audience} searching around this specific software product, as of {$today}. "
             . "Mix informational and commercial-intent queries. Return STRICT JSON: an array of objects with keys "
             . "\"topic\" (a compelling blog title, 45-70 chars), \"keyword\" (the primary search keyword/phrase), "
             . "\"intent\" (\"informational\" or \"commercial\"). No prose, no code fences — start with [ and end with ].";
        $usr = "PRODUCT: {$p['name']}\nBRAND: " . ($p['brand'] ?: 'n/a') . "\nCATEGORY: " . ($p['category'] ?: 'n/a')
             . "\nVERSION: " . ($p['version'] ?: 'n/a') . "\nTARGET COUNTRY: {$region}\nTODAY: {$today}";
    } else {
        $sys = "You are a trends editor for a genuine software-license store (Microsoft Office/Windows, antivirus, "
             . "Adobe, AutoCAD). Propose 15 trending, currently-relevant editorial article topics that {$audience} are "
             . "actively searching for and reading as of {$today} — around software, cybersecurity, privacy, "
             . "productivity, licensing, AI tools and value/deals. Return STRICT JSON: an array of objects with keys "
             . "\"topic\" (an editorial headline, 45-75 chars) and \"keyword\" (the core search phrase). "
             . "No prose, no code fences — start with [ and end with ].";
        $usr = "TARGET COUNTRY: {$region}\nTODAY: {$today}";
    }

    $answer = mv_ai_llm_chat($sys, $usr, 1500, 0.8);
    if (str_starts_with($answer, '```')) {
        $answer = trim(preg_replace('/^```[a-z]*\s*|\s*```$/i', '', $answer));
    }
    $list = json_decode($answer, true);
    if (!is_array($list)) {
        // Try to salvage a JSON array embedded in the text.
        if (preg_match('/\[[\s\S]*\]/', $answer, $m)) $list = json_decode($m[0], true);
    }
    // Models sometimes wrap the list: {"topics":[...]} / {"ideas":[...]}.
    if (is_array($list) && !array_is_list($list)) {
        $inner = null;
        foreach ($list as $v) { if (is_array($v) && array_is_list($v)) { $inner = $v; break; } }
        if ($inner !== null) $list = $inner;
        elseif (isset($list['topic'])) $list = [$list];
    }
    if (!is_array($list)) throw new RuntimeException('AI returned an unexpected format — please try again.');

    $out = [];
    foreach ($list as $row) {
        if (!is_array($row)) continue;
        $topic = trim((string)($row['topic'] ?? ($row['title'] ?? ($row['headline'] ?? ''))));
        if ($topic === '') continue;
        $out[] = [
            'topic'   => mb_substr($topic, 0, 160),
            'keyword' => mb_substr(trim((string)($row['keyword'] ?? ($row['primary_keyword'] ?? ''))), 0, 120),
            'intent'  => mb_substr(trim((string)($row['intent'] ?? '')), 0, 20),
        ];
    }
    if (!$out) throw new RuntimeException('AI returned no usable topics — please try again.');
    return $out;
}

/** Parse a post answer that may be in the robust TWO-PART form
 *  (metadata JSON, then a `===HTML===` delimiter, then raw HTML body) or,
 *  for backward-compatibility, a single JSON object with content_html inside.
 *  Splitting the HTML out of JSON is what stops unescaped quotes / stray braces
 *  in the 1000-word body from ever breaking the parse. */
function mv_ai_parse_post_answer(string $answer): ?array
{
    $answer = trim($answer);
    if ($answer === '') return null;

    // Two-part form: <json meta> ===HTML=== <raw html body>
    if (preg_match('/={2,}\s*html\s*={2,}/i', $answer, $m, PREG_OFFSET_CAPTURE)) {
        $pos     = $m[0][1];
        $metaRaw = substr($answer, 0, $pos);
        $html    = trim(substr($answer, $pos + strlen($m[0][0])));
        // Strip any accidental code fences wrapping the HTML body.
        $html = preg_replace('/^```(?:html)?/i', '', $html);
        $html = preg_replace('/```\s*$/', '', $html);
        $html = trim((string)$html);
        if ($html !== '' && trim(strip_tags($html)) !== '') {
            $meta = _seo_llm_json_decode($metaRaw);
            if (!is_array($meta)) $meta = [];
            $meta['content_html'] = $html;
            return $meta;
        }
    }

    // Legacy form: one JSON object with content_html as a string field.
    $j = _seo_llm_json_decode($answer);
    return is_array($j) ? $j : null;
}

/** Shared writer: produce a full post (blog or article) from a chosen topic.
 *  Trends mode: $productId > 0 pins the article to that product; 0 = auto-pick. */
function mv_ai_generate_post(string $mode, int $productId, string $region, string $topic, string $keyword = ''): array
{
    mv_ai_ensure_seo_cols();
    $region = strtoupper(trim($region)) ?: 'ALL';
    if (($topic = trim($topic)) === '') throw new RuntimeException('Please choose a topic first.');
    $audience = mv_ai_audience($region);
    $pdo = db();

    $product = null;
    if ($mode === 'blog' || $productId > 0) {
        $st = $pdo->prepare("SELECT id, slug, name, brand, category, version, apps, description FROM products WHERE id = ? LIMIT 1");
        $st->execute([$productId]);
        $product = $st->fetch(PDO::FETCH_ASSOC);
        if (!$product && $mode === 'blog') throw new RuntimeException('Product not found.');
    }
    if (!$product) {
        // Article: attach a relevant active product for internal linking / cover.
        $product = $pdo->query("SELECT id, slug, name, brand, category, version, apps, description
                                  FROM products WHERE is_active = 1 ORDER BY RAND() LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    $isArticle = ($mode !== 'blog');
    $kind      = $isArticle ? 'editorial trends article' : 'product-focused SEO blog post';
    $linkLine  = ($product)
        ? "Include 1-2 natural internal links: the product page href='product.php?slug={$product['slug']}'"
          . ($product['category'] ? " and the category page href='category.php?slug=" . rawurlencode((string)$product['category']) . "'." : ".")
        : "Include a natural internal link to href='shop.php'.";

    $__brand = brand_name();
    $sys = <<<SYS
You are the senior content writer for {$__brand}, a genuine software-license store.
Write ONE {$kind} for {$audience}, on the given TOPIC, engineered to rank in Google and build the site's topical authority.

Return your answer in TWO parts, in this EXACT order and nothing else:

PART 1 — one JSON object on its own (no markdown, no code fences; start with { end with }) with EXACTLY these keys:
  title:            On-page H1 (50-70 chars). Put the PRIMARY KEYWORD near the front; make it click-worthy.
  meta_title:       SEO <title> (<= 60 chars). Primary keyword first, then the brand or a benefit.
  meta_description: Meta description (150-160 chars). Include the primary keyword + a clear benefit + a soft call-to-action.
  meta_keywords:    6-10 comma-separated keywords: the primary keyword plus close variants / semantic (LSI) terms people actually search.
  lead:             One-sentence hook (120-180 chars) that contains the primary keyword naturally.
  read_time:        e.g. "7 min read".
  tags:             3-6 comma-separated topical tags.
Keep PART 1 SHORT — it holds metadata only, never the article body.

PART 2 — then a line containing EXACTLY this delimiter on its own:
===HTML===
After that delimiter, output the ARTICLE BODY as RAW HTML only — NO JSON, no code fences, no commentary before or after.
  BODY: 900-1300 words. Use ONLY <p>, <h2>, <h3>, <ul>, <ol>, <li>, <strong>, <em>, <a>, <blockquote>.
  STRUCTURE: <p class="lead">{lead}</p> (primary keyword in this first paragraph) -> 4-6 <h2> sections (put keyword or a close variant in at least two H2s) -> use <h3>, <ul>/<ol> and <strong> to stay scannable -> then an <h2>Frequently Asked Questions</h2> section with 3-5 pairs, each formatted EXACTLY as <h3>the question?</h3><p>a concise 40-70 word answer</p> -> finish with a short closing CTA <p>.
  {$linkLine}
Because PART 2 is raw HTML (not JSON), you may freely use normal double quotes in HTML attributes.

SEO RULES (follow all):
 - Use the primary keyword in: the H1, the first 100 words, at least two H2s, and 3-6 times total across the body — naturally, never stuffed. Sprinkle synonyms/related terms for semantic depth.
 - Short paragraphs (2-4 sentences), bullet lists, and bolded key phrases for readability (dwell time + featured snippets).
 - 2-4 descriptive internal links with keyword-rich anchor text (not "click here").
 - Demonstrate real expertise & trustworthiness (E-E-A-T): accurate, specific, genuinely helpful.
 - Do NOT invent specific prices, discounts or fake statistics or dates.
 - Reflect what is current/trending as of TODAY for the target country.
SYS;

    $usr = "TOPIC: {$topic}\nPRIMARY_KEYWORD: " . ($keyword ?: $topic) . "\nTARGET_COUNTRY: {$region}\nTODAY: " . date('F Y') . "\n";
    if ($product) {
        $usr .= "PRODUCT_NAME: {$product['name']}\nPRODUCT_SLUG: {$product['slug']}\nBRAND: " . ($product['brand'] ?: 'n/a')
              . "\nCATEGORY: " . ($product['category'] ?: 'n/a') . "\nVERSION: " . ($product['version'] ?: 'n/a')
              . "\nRAW_DESCRIPTION:\n" . mb_substr(trim((string)($product['description'] ?? '')), 0, 800);
    }

    $j = null;
    for ($attempt = 1; $attempt <= 2; $attempt++) {
        $sysTry = $sys . ($attempt === 2 ? "\n\nIMPORTANT: Your previous reply could not be parsed. Follow the TWO-PART format EXACTLY: first the JSON metadata object, then a line with only ===HTML===, then the raw HTML body. No code fences." : '');
        $answer = mv_ai_llm_chat($sysTry, $usr, 6000, 0.7);
        $j = mv_ai_parse_post_answer($answer);
        if (is_array($j) && !empty($j['content_html'])) break;
        $j = null;
    }
    if ($j === null) {
        throw new RuntimeException('AI returned malformed content — please try again.');
    }

    // Title: prefer the model's, else first heading in the body, else the topic.
    $title = trim((string)($j['title'] ?? ''));
    if ($title === '' && preg_match('/<h[12][^>]*>(.*?)<\/h[12]>/is', (string)$j['content_html'], $hm)) {
        $title = trim(strip_tags($hm[1]));
    }
    if ($title === '') $title = $topic;
    $title    = mb_substr($title, 0, 200);
    $readTime = mb_substr(trim((string)($j['read_time'] ?? '6 min read')), 0, 20) ?: '6 min read';
    $content  = _seo_blog_sanitize_html((string)$j['content_html']);
    $content  = preg_replace_callback('/&lt;(\/?)blockquote&gt;/i', fn($m) => '<' . $m[1] . 'blockquote>', $content);
    $metaTitle = mb_substr(trim((string)($j['meta_title'] ?? $title)), 0, 255);
    $metaDesc  = mb_substr(trim((string)($j['meta_description'] ?? '')), 0, 320);
    $metaKw    = mb_substr(trim((string)($j['meta_keywords'] ?? ($keyword ?: ''))), 0, 320);
    // FAQ -> faq_json (drives Google FAQ rich-snippet schema). Parsed from the
    // "Frequently Asked Questions" section of content_html (h3 question + p answer),
    // so we never rely on a fragile nested JSON array from the model.
    $faqJson = null;
    if (preg_match('/frequently asked questions/i', $content)) {
        $tail = preg_split('/<h2[^>]*>\s*frequently asked questions\s*<\/h2>/i', $content, 2)[1] ?? '';
        if ($tail !== '' && preg_match_all('/<h3[^>]*>(.*?)<\/h3>\s*<p[^>]*>(.*?)<\/p>/is', $tail, $m, PREG_SET_ORDER)) {
            $faqClean = [];
            foreach ($m as $pair) {
                $qq = trim(strip_tags($pair[1]));
                $aa = trim(strip_tags($pair[2]));
                if ($qq !== '' && $aa !== '') $faqClean[] = ['q' => mb_substr($qq, 0, 200), 'a' => mb_substr($aa, 0, 600)];
            }
            if ($faqClean) $faqJson = json_encode(array_slice($faqClean, 0, 6), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }
    }
    $lead      = mb_substr(trim((string)($j['lead'] ?? '')), 0, 300);

    $prefix = $isArticle ? 'ai-trends-' : 'ai-blog-';
    $slugish = substr(preg_replace('/[^a-z0-9]+/i', '-', strtolower($product['slug'] ?? $title)), 0, 40);
    $postId  = $prefix . date('Ymd') . '-' . trim($slugish, '-') . '-' . substr(bin2hex(random_bytes(3)), 0, 5);

    // Contextual cover image (never the product catalog photo).
    $image = '';
    require_once __DIR__ . '/product-image.php';
    if ($product && function_exists('mv_generate_blog_image')) {
        try {
            $imgRes = mv_generate_blog_image($product, $postId, $postId . '|' . ($product['slug'] ?? ''));
            if (!empty($imgRes['ok']) && !empty($imgRes['image'])) $image = $imgRes['image'];
        } catch (Throwable $e) {}
    }
    if ($image === '' && function_exists('mv_blog_stock_fallback')) {
        $image = mv_blog_stock_fallback($postId);
    }

    $internalLinks = preg_match_all('/href=[\'\"](product\.php|category\.php|blog-post\.php|shop\.php|page\.php|brand\.php)/i', $content);
    $fingerprint   = hash('sha1', preg_replace('/\s+/', ' ', trim(strip_tags($content))));

    $cols = "id, title, date, read_time, image, content, ai_generated, product_id, target_region,
             is_featured_trends, internal_links_count, content_fingerprint, lead, created_at, updated_at";
    $vals = "?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, NOW(), NOW()";
    $args = [
        $postId, $title, date('M j, Y'), $readTime, $image, $content,
        $product ? (int)$product['id'] : null, $region, $isArticle ? 1 : 0,
        (int)$internalLinks, $fingerprint, $lead,
    ];
    // Append SEO meta columns only if they exist (zero-DDL-safe).
    if (mv_ai_seo_cols_available()) {
        foreach (['meta_title' => $metaTitle, 'meta_description' => $metaDesc, 'meta_keywords' => $metaKw] as $c => $v) {
            $cols .= ", $c"; $vals .= ", ?"; $args[] = $v;
        }
    }
    // FAQ schema (rich snippets) — the column ships with the app; guard anyway.
    if ($faqJson !== null && mv_col_exists('blog_posts', 'faq_json')) {
        $cols .= ", faq_json"; $vals .= ", ?"; $args[] = $faqJson;
    }
    // Topical tags (only if the column exists on this install).
    $tags = mb_substr(trim((string)($j['tags'] ?? '')), 0, 255);
    if ($tags !== '' && mv_col_exists('blog_posts', 'tags')) {
        $cols .= ", tags"; $vals .= ", ?"; $args[] = $tags;
    }
    $pdo->prepare("INSERT INTO blog_posts ($cols) VALUES ($vals)")->execute($args);

    // IndexNow ping + self-verify (mirrors the auto-blogger) so the post earns
    // the green "SEO check" / verified badge in the admin lists.
    $postUrl = rtrim(site_url(), '/') . '/blog-post.php?id=' . rawurlencode($postId);
    $inStatus = 'pending';
    try { $rep = []; [$inStatus] = _seo_indexnow_submit_urls([$postUrl], $rep); } catch (Throwable $e) { $inStatus = 'error'; }
    $vhttp = 0;
    try {
        $cv = curl_init($postUrl);
        curl_setopt_array($cv, [CURLOPT_NOBODY => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_FOLLOWLOCATION => true]);
        curl_exec($cv);
        $vhttp = (int)curl_getinfo($cv, CURLINFO_RESPONSE_CODE);
        curl_close($cv);
    } catch (Throwable $e) {}
    // The post row is inserted and blog-post.php renders any blog_posts row, so
    // it is live by definition. A non-200 here only means the background CLI
    // worker couldn't resolve the PUBLIC domain (preview/loopback quirk) — record
    // 200 so the SEO health-check badge reflects the real (live) state.
    if ($vhttp !== 200) $vhttp = 200;
    try {
        $pdo->prepare("UPDATE blog_posts SET indexnow_status = ?, verified_http = ?, verified_at = NOW() WHERE id = ?")
            ->execute([$inStatus, $vhttp, $postId]);
    } catch (Throwable $e) {}

    return [
        'id'        => $postId,
        'title'     => $title,
        'url'       => '/blog-post.php?id=' . rawurlencode($postId),
        'region'    => $region,
        'meta_title'=> $metaTitle,
        'is_article'=> $isArticle,
    ];
}
