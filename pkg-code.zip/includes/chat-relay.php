<?php
// Offline chat → email relay.
// When an admin replies in Lead Management but the customer is no longer on
// the website, the reply is delivered to the customer's email address instead
// of sitting unseen in the widget.  Messages are bundled per lead with a
// 2-minute debounce so a quick burst of replies becomes ONE email.
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/email.php';

const CHAT_RELAY_OFFLINE_SEC  = 120; // same window the admin UI uses for "online"
const CHAT_RELAY_DEBOUNCE_SEC = 120;

/** Email every pending admin message of one lead (if the customer is offline). */
function chat_relay_lead(int $leadId): bool
{
    $pdo = db();
    $st = $pdo->prepare("SELECT id, name, email, agent_name, last_seen, email_relay_at,
                                TIMESTAMPDIFF(SECOND, last_seen, NOW())      AS seen_age,
                                TIMESTAMPDIFF(SECOND, email_relay_at, NOW()) AS relay_age
                         FROM chat_leads WHERE id=? LIMIT 1");
    $st->execute([$leadId]);
    $lead = $st->fetch(PDO::FETCH_ASSOC);
    if (!$lead || !filter_var((string)$lead['email'], FILTER_VALIDATE_EMAIL)) return false;

    $online = $lead['seen_age'] !== null && (int)$lead['seen_age'] >= 0 && (int)$lead['seen_age'] <= CHAT_RELAY_OFFLINE_SEC;
    if ($online) return false;
    if ($lead['relay_age'] !== null && (int)$lead['relay_age'] >= 0 && (int)$lead['relay_age'] < CHAT_RELAY_DEBOUNCE_SEC) return false;

    $ms = $pdo->prepare("SELECT id, message, attachment_url, attachment_type, attachment_name, sent_at
                         FROM chat_messages
                         WHERE lead_id=? AND sender='admin' AND read_at IS NULL AND relayed_at IS NULL
                           AND sent_at >= (NOW() - INTERVAL 2 DAY)
                         ORDER BY id ASC LIMIT 50");
    $ms->execute([$leadId]);
    $msgs = $ms->fetchAll(PDO::FETCH_ASSOC);
    if (!$msgs) return false;

    $co    = company_info();
    $brand = (string)($co['name'] ?? brand_name());
    $base  = rtrim(site_url(), '/');
    $agent = trim((string)($lead['agent_name'] ?? '')) ?: 'Our support team';
    $first = trim((string)explode(' ', trim((string)($lead['name'] ?? '')))[0]) ?: 'there';
    $supportEmail = trim((string)setting_get('company_support_email', '')) ?: trim((string)($co['email'] ?? ''));

    $bubbles = '';
    foreach ($msgs as $m) {
        $when = date('M j · g:i A', strtotime((string)$m['sent_at']));
        if (!empty($m['attachment_url'])) {
            $url  = htmlspecialchars((strpos((string)$m['attachment_url'], 'http') === 0 ? '' : $base . '/') . ltrim((string)$m['attachment_url'], '/'), ENT_QUOTES, 'UTF-8');
            $name = htmlspecialchars((string)($m['attachment_name'] ?: 'attachment'), ENT_QUOTES, 'UTF-8');
            $body = '<a href="' . $url . '" style="color:#1d4ed8;text-decoration:none;font-weight:600;">&#128206; ' . $name . '</a>';
        } else {
            $body = nl2br(htmlspecialchars((string)$m['message'], ENT_QUOTES, 'UTF-8'));
        }
        $bubbles .= '<tr><td style="padding:0 0 12px;">'
            . '<div style="display:inline-block;max-width:92%;background:#eff6ff;border:1px solid #bfdbfe;border-radius:14px 14px 14px 4px;padding:12px 16px;font-size:14.5px;line-height:1.6;color:#0f172a;">' . $body . '</div>'
            . '<div style="font-size:11px;color:#94a3b8;margin-top:4px;">' . htmlspecialchars($agent, ENT_QUOTES, 'UTF-8') . ' · ' . $when . '</div>'
            . '</td></tr>';
    }
    $count   = count($msgs);
    $subject = $agent . ' replied to your chat — ' . $brand;
    $brandH  = htmlspecialchars($brand, ENT_QUOTES, 'UTF-8');
    $agentH  = htmlspecialchars($agent, ENT_QUOTES, 'UTF-8');
    $firstH  = htmlspecialchars($first, ENT_QUOTES, 'UTF-8');
    $link    = $base . '/?chat=open';
    $logo    = function_exists('email_brand_logo_src') ? email_brand_logo_src() : ($base . '/assets/images/brand-watermarks/maventech.png');
    $replyLine = $supportEmail !== ''
        ? 'You can also simply reply to this email and it will reach the same team.'
        : 'Open the website and the chat picks up right where you left off.';

    $html = <<<HTML
<!doctype html><html><body style="margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#1f2937;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f1f5f9;padding:32px 0;"><tr><td align="center">
  <table width="580" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 6px 24px rgba(15,23,42,.08);">
    <tr><td style="background:linear-gradient(135deg,#1e3a8a 0%,#2563eb 100%);padding:22px 30px;color:#fff;">
      <table cellpadding="0" cellspacing="0" border="0"><tr>
        <td valign="middle" width="64"><img src="{$logo}" alt="{$brandH}" height="56" style="display:block;height:56px;width:auto;max-width:180px;border-radius:12px;"></td>
        <td valign="middle" style="padding-left:14px;">
          <div style="font-size:11px;letter-spacing:2.5px;text-transform:uppercase;opacity:.9;font-weight:700;">New reply in your chat</div>
          <div style="font-size:20px;font-weight:800;margin-top:3px;">{$agentH} · {$brandH}</div>
        </td>
      </tr></table>
    </td></tr>
    <tr><td style="padding:26px 30px 10px;">
      <p style="margin:0 0 18px;font-size:15px;color:#334155;line-height:1.55;">Hi {$firstH}, you stepped away from our website so we're sending our {$count} new chat message(s) here so you don't miss them:</p>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">{$bubbles}</table>
      <div style="text-align:center;margin:18px 0 6px;">
        <a href="{$link}" style="display:inline-block;padding:13px 32px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;box-shadow:0 8px 22px rgba(29,78,216,.35);">Continue the conversation &rarr;</a>
      </div>
      <p style="text-align:center;font-size:12px;color:#94a3b8;margin:12px 0 0;line-height:1.6;">{$replyLine}</p>
    </td></tr>
    <tr><td style="background:#0f172a;padding:16px 30px;color:#94a3b8;font-size:11.5px;text-align:center;line-height:1.55;">
      <div style="color:#e2e8f0;font-weight:700;font-size:13px;margin-bottom:4px;">{$brandH}</div>
      Live-chat reply delivered by email because you were offline.
    </td></tr>
  </table>
</td></tr></table>
</body></html>
HTML;

    $ids = array_map(fn($m) => (int)$m['id'], $msgs);
    $ph  = implode(',', array_fill(0, count($ids), '?'));
    // Mark BEFORE sending so a slow SMTP can never double-email the same bubbles.
    $pdo->prepare("UPDATE chat_messages SET relayed_at=NOW() WHERE id IN ($ph)")->execute($ids);
    $pdo->prepare("UPDATE chat_leads SET email_relay_at=NOW() WHERE id=?")->execute([$leadId]);

    $override = ['name' => $brand];
    if ($supportEmail !== '') $override['reply_to'] = $supportEmail;
    // force=true: each relay carries different bubbles, so the outbox's 60s
    // same-subject duplicate suppression must not swallow a follow-up bundle.
    send_email((string)$lead['email'], $subject, $html, null, 'chat_reply_relay', 0, [], true, $override);
    return true;
}

/** Sweep every lead with pending (unread + un-emailed) admin messages. */
function chat_relay_sweep(int $limit = 20): int
{
    $limit = max(1, min(100, $limit));
    try {
        $rows = db()->query("SELECT DISTINCT m.lead_id
            FROM chat_messages m
            JOIN chat_leads l ON l.id = m.lead_id
            WHERE m.sender='admin' AND m.read_at IS NULL AND m.relayed_at IS NULL
              AND m.sent_at >= (NOW() - INTERVAL 2 DAY)
              AND l.email IS NOT NULL AND l.email <> ''
              AND (l.last_seen IS NULL OR l.last_seen < (NOW() - INTERVAL " . CHAT_RELAY_OFFLINE_SEC . " SECOND))
              AND (l.email_relay_at IS NULL OR l.email_relay_at < (NOW() - INTERVAL " . CHAT_RELAY_DEBOUNCE_SEC . " SECOND))
            LIMIT $limit")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) { return 0; }
    $n = 0;
    foreach ($rows as $lid) {
        try { if (chat_relay_lead((int)$lid)) $n++; }
        catch (Throwable $e) { @error_log('[chat-relay] lead ' . $lid . ': ' . $e->getMessage()); }
    }
    return $n;
}
