<?php
/*
 * Receipt + Invoice PDF generators — used by send_email() to attach
 * proper, professionally-formatted PDFs to every paid order email.
 *
 * Layout closely mirrors the reference Emergent receipt / invoice style
 * the product owner provided: clean sans-serif, two-column header with
 * company info on the left + brand logo / receipt number on the right,
 * "Bill to" customer block, single line-items table with right-aligned
 * currency, summary totals, payment-history table (for the receipt
 * variant only), and a clear statement-name line so the customer knows
 * what to look for on their bank statement.
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/functions.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Resolve the company logo to a local file path that Dompdf can embed.
 * Falls back to the bundled email logo if no company logo is configured
 * (or the configured URL points to an external host — Dompdf is sandboxed
 * to the local filesystem via isRemoteEnabled=false).
 */
function _pdf_company_logo_path(): string
{
    // No usable upload → the generated square brand mark (uploaded logo or
    // company-name monogram), identical to the favicon.
    $fallback = function_exists('brand_icon_png_path') ? brand_icon_png_path(256) : __DIR__ . '/../assets/images/brand/email-logo.gif';
    $logoSetting = function_exists('company_info') ? (string)(company_info()['logo'] ?? '') : '';
    if ($logoSetting === '') return $fallback;

    // Already an absolute filesystem path?
    if ($logoSetting[0] === '/' && file_exists($logoSetting)) return $logoSetting;

    // Strip the site URL prefix if the operator pasted a full URL.
    $rel = $logoSetting;
    $candidates = [
        function_exists('site_url') ? rtrim((string)site_url(), '/') : '',
        function_exists('base_url') ? rtrim((string)base_url(), '/') : '',
    ];
    foreach (array_filter($candidates) as $c) {
        if (str_starts_with($rel, $c)) { $rel = substr($rel, strlen($c)); break; }
    }
    $rel = ltrim((string)$rel, '/');
    $abs = __DIR__ . '/../' . $rel;
    return (file_exists($abs) && !is_dir($abs)) ? $abs : $fallback;
}

/**
 * Build a Dompdf instance with sane defaults for our receipts/invoices.
 */
function _pdf_dompdf(): Dompdf
{
    $o = new Options();
    $o->set('defaultFont',           'DejaVu Sans');   // ships with Dompdf
    $o->set('isHtml5ParserEnabled',  true);
    $o->set('isRemoteEnabled',       false);           // we never load remote assets
    $o->set('chroot',                __DIR__ . '/..'); // keep file access local
    return new Dompdf($o);
}

/**
 * Number → currency formatter that matches what we show on the site
 * (uses the symbol of the order's currency, not the active session one).
 */
function _pdf_money(float $amount, string $cur = 'USD'): string
{
    $sym = ['USD'=>'$','GBP'=>'£','EUR'=>'€','CAD'=>'CA$','AUD'=>'A$','INR'=>'₹','AED'=>'د.إ'][$cur] ?? '';
    return $sym . number_format($amount, 2);
}

/**
 * Detect the dominant brand for an order from its line items.
 * Used to pick the right watermark on the Receipt / Invoice.
 *
 * Order of precedence:
 *   1) products.brand column (DB-authoritative)
 *   2) keyword scan of the product name
 *   3) generic 'maventech' fallback (our own brand mark)
 */
function _pdf_brand_for_items(array $items): string
{
    if (empty($items)) return 'maventech';
    // Honour an explicit `brand` field if the caller passes it.
    foreach ($items as $it) {
        $b = strtolower(trim((string)($it['brand'] ?? '')));
        if ($b !== '') {
            foreach (['microsoft','bitdefender','mcafee','norton','kaspersky','eset','adobe','autodesk','corel','parallels'] as $known) {
                if (str_contains($b, $known)) return $known;
            }
        }
    }
    // Fall back to keyword scan on the first item's name.
    $name = strtolower(trim((string)($items[0]['name'] ?? $items[0]['product_name'] ?? '')));
    foreach ([
        'bitdefender' => ['bitdefender'],
        'mcafee'      => ['mcafee'],
        'norton'      => ['norton'],
        'kaspersky'   => ['kaspersky'],
        'eset'        => ['eset'],
        'adobe'       => ['adobe', 'acrobat', 'photoshop'],
        'autodesk'    => ['autocad', 'autodesk'],
        'corel'       => ['corel'],
        'parallels'   => ['parallels'],
        'microsoft'   => ['microsoft', 'office', 'windows', 'visio', 'project', 'excel', 'word', 'powerpoint', 'outlook'],
    ] as $brandKey => $needles) {
        foreach ($needles as $n) {
            if (str_contains($name, $n)) return $brandKey;
        }
    }
    return 'maventech';
}

/**
 * Build the HTML for a colourful product-icon "scatter" watermark.
 *
 * For Microsoft orders we tile actual app icons (Word/Excel/PowerPoint/
 * Outlook/OneNote/Teams/Windows) in their real brand colours at ~14%
 * opacity, rotated lightly and positioned at deterministic but
 * scattered-looking coordinates across the page.  Feels like a Microsoft
 * marketing piece rather than a sterile invoice.
 *
 * For non-Microsoft brands we fall back to repeating the single brand
 * silhouette (already pre-rendered in /assets/images/brand-watermarks/)
 * in a softer scatter — still adds the "brand feel" but without 7 different
 * logos that don't exist for non-Microsoft brands.
 */
function _pdf_brand_scatter_html(string $brandKey): string
{
    $brandKey = strtolower($brandKey);
    // Deterministic scatter positions (top, left in %).  Picked by hand to
    // look balanced across the page — slight rotation per piece adds life.
    // Format: [top_pct, left_pct, size_px, rotate_deg, icon_filename].
    if ($brandKey === 'microsoft') {
        $dir = __DIR__ . '/../assets/images/brand-watermarks/microsoft-suite';
        $scatter = [
            // Top band
            [ 7,  6, 56, -10, 'word.png'],
            [12, 78, 68,   6, 'excel.png'],
            // Upper-middle
            [22, 32, 60,  12, 'outlook.png'],
            [27, 64, 54,  -8, 'powerpoint.png'],
            // Middle band
            [38, 12, 64,  -4, 'teams.png'],
            [42, 50, 70,  18, 'windows.png'],
            [48, 84, 56,  -6, 'onenote.png'],
            // Lower-middle
            [60, 22, 58,   8, 'access.png'],
            [64, 70, 62, -14, 'word.png'],
            // Bottom band
            [78, 10, 54,  10, 'excel.png'],
            [82, 46, 60,  -3, 'powerpoint.png'],
            [86, 78, 56,  16, 'outlook.png'],
        ];
        $items = [];
        foreach ($scatter as $s) {
            [$top, $left, $size, $rot, $icon] = $s;
            $path = $dir . '/' . $icon;
            if (!is_file($path)) continue;
            $items[] = sprintf(
                '<img class="scatter-icon" style="top:%d%%;left:%d%%;width:%dpx;height:%dpx;transform:rotate(%ddeg);" src="%s" alt="">',
                $top, $left, $size, $size, $rot, $path
            );
        }
        return '<div class="scatter-wrap">' . implode('', $items) . '</div>';
    }

    // Non-Microsoft brands — softer 5-icon scatter using the single brand
    // silhouette.  Still adds branded feel; no need to manufacture fake
    // sub-brand icons.
    $path = _pdf_brand_watermark_path($brandKey);
    if (!is_file($path)) return '';
    $scatter = [
        [10, 12, 72, -10],
        [22, 70, 84,  12],
        [44, 32, 96,  -5],
        [62, 76, 80,  16],
        [78, 18, 76,  -8],
    ];
    $items = [];
    foreach ($scatter as $s) {
        [$top, $left, $size, $rot] = $s;
        $items[] = sprintf(
            '<img class="scatter-icon" style="top:%d%%;left:%d%%;width:%dpx;height:%dpx;transform:rotate(%ddeg);" src="%s" alt="">',
            $top, $left, $size, $size, $rot, $path
        );
    }
    return '<div class="scatter-wrap">' . implode('', $items) . '</div>';
}

/**
 * Return the absolute filesystem path to the brand-watermark PNG for the
 * given brand key.  All watermarks are 600×600 dark-grey silhouettes
 * pre-rendered into /assets/images/brand-watermarks/ so Dompdf can embed
 * them locally (we keep `isRemoteEnabled` false).  Unknown brand keys
 * fall back to the Maventech "M" mark.
 */
function _pdf_brand_watermark_path(string $brandKey): string
{
    $dir = __DIR__ . '/../assets/images/brand-watermarks';
    $key = strtolower(trim($brandKey));
    $path = $dir . '/' . $key . '.png';
    if (is_file($path)) return $path;
    // Fallback to our own brand mark for any unknown / missing brand.
    return $dir . '/maventech.png';
}

/**
 * Generate a QR-code PNG (base64-encoded data URI) that links to the
 * customer's Order History entry pre-filled with their email + order
 * number.  Returned as a `data:image/png;base64,...` URI so Dompdf can
 * embed it directly without a remote fetch (and without writing yet
 * another tmp file on disk).  Returns '' if encoding fails — caller
 * gracefully omits the QR in that case.
 */
function _pdf_order_history_qr(array $order): string
{
    if (empty($order['email']) || empty($order['order_number'])) return '';
    if (!class_exists(\chillerlan\QRCode\QRCode::class)) return '';
    $url = rtrim(function_exists('site_url') ? site_url() : '', '/')
         . '/order-history.php?email=' . rawurlencode((string)$order['email'])
         . '&order=' . rawurlencode((string)$order['order_number']);
    try {
        $opts = new \chillerlan\QRCode\QROptions([
            // Auto-size QR to fit any URL length — version 1..10 covers up
            // to a few hundred chars at ECC level M, plenty for our URL.
            'versionMin'          => 5,
            'versionMax'          => 10,
            'eccLevel'            => \chillerlan\QRCode\Common\EccLevel::M,
            'scale'               => 4,
            'imageBase64'         => true,
            'imageTransparent'    => false,
            // PNG via GD — yields a `data:image/png;base64,...` URI that
            // Dompdf embeds without needing remote-fetch.
            'outputInterface'     => \chillerlan\QRCode\Output\QRGdImagePNG::class,
        ]);
        return (new \chillerlan\QRCode\QRCode($opts))->render($url);
    } catch (Throwable $e) {
        error_log('[pdf-qr] ' . $e->getMessage());
        return '';
    }
}

/**
 * Shared HTML head + brand header used by both Receipt and Invoice.
 * Variant: 'receipt' or 'invoice' — only the title + sub-line change.
 */
function _pdf_shell(array $ctx, string $bodyHtml): string
{
    $co       = $ctx['co'];
    $brand    = htmlspecialchars($co['name']    ?? 'Maventech', ENT_QUOTES, 'UTF-8');
    $brandAddr= nl2br(htmlspecialchars($co['address'] ?? '',             ENT_QUOTES, 'UTF-8'));
    $brandEm  = htmlspecialchars($co['email']   ?? '',                   ENT_QUOTES, 'UTF-8');
    $logoUrl  = $ctx['logo']  ?? '';   // local file path is fine for Dompdf
    $docTitle = htmlspecialchars($ctx['title'] ?? 'Document',            ENT_QUOTES, 'UTF-8');
    $invNo    = htmlspecialchars($ctx['invoice_number'] ?? '',           ENT_QUOTES, 'UTF-8');
    // Brand-specific colourful scattered watermark (Microsoft suite icons
    // for Microsoft orders; soft repeated brand mark for other brands).
    $brandKey  = $ctx['brand_key'] ?? 'maventech';
    $scatterHtml = _pdf_brand_scatter_html($brandKey);
    // Personalised greeting at the top of the document — pulled from the
    // customer's first name.  Adds a human touch without changing any
    // structural layout.
    $firstName = trim((string)($ctx['first_name'] ?? ''));
    $greetHtml = '';
    if ($firstName !== '') {
        $greetHtml = '<div class="thank-you">Thank you, '
                   . htmlspecialchars($firstName, ENT_QUOTES, 'UTF-8')
                   . '!</div>';
    }
    // Diagonal "PAID" / "INVOICE" / "DUE" stamp under the brand logo —
    // accounting-software vibe.  Caller passes `stamp_text` + `stamp_color`
    // (defaults to dark grey; green for PAID, amber for DUE).
    $stampText  = trim((string)($ctx['stamp_text']  ?? ''));
    $stampColor = (string)($ctx['stamp_color'] ?? '#1f2937');
    $stampHtml  = '';
    if ($stampText !== '') {
        $stampHtml = '<div class="stamp" style="color:' . htmlspecialchars($stampColor, ENT_QUOTES, 'UTF-8') . ';border-color:' . htmlspecialchars($stampColor, ENT_QUOTES, 'UTF-8') . ';">'
                   . htmlspecialchars($stampText, ENT_QUOTES, 'UTF-8')
                   . '</div>';
    }
    // Bottom-right QR — links to the customer's Order History entry with
    // email + order number pre-filled.  Anyone holding the printed copy
    // (accountant, auditor, finance team) can scan and get a fresh PDF
    // on the spot — no need to email support.
    $qrDataUri = (string)($ctx['qr_data_uri'] ?? '');
    $qrHtml    = '';
    if ($qrDataUri !== '') {
        $qrHtml = '<div class="qr-stamp">'
                . '  <img src="' . $qrDataUri . '" alt="QR code">'
                . '  <div class="qr-label">Scan to re-download<br>Receipt &amp; Invoice</div>'
                . '</div>';
    }
    // Active vibe-schedule promo banner — admin-defined label + optional
    // logo upload.  Renders as a thin red bar at the top of every PDF
    // generated while the schedule is live (e.g. "BLACK FRIDAY SALE").
    $promoBarHtml = '';
    if (function_exists('active_vibe_promo')) {
        $promo = active_vibe_promo();
        if ($promo && trim((string)$promo['label']) !== '') {
            $promoLabel = htmlspecialchars((string)$promo['label'], ENT_QUOTES, 'UTF-8');
            $promoLogo  = '';
            $promoLogoFile = (string)($promo['logo_file'] ?? '');
            if ($promoLogoFile !== '' && is_file($promoLogoFile) && !preg_match('/\.svg$/i', $promoLogoFile)) {
                $promoLogo = '<img src="' . htmlspecialchars($promoLogoFile, ENT_QUOTES, 'UTF-8') . '" alt="" style="height:22px;width:auto;vertical-align:middle;background:#fff;border-radius:4px;padding:2px;margin-right:8px;">';
            }
            $promoCoupon = '';
            $code = strtoupper(trim((string)($promo['coupon_code'] ?? '')));
            $pct  = (int)($promo['coupon_percent'] ?? 0);
            if ($code !== '' && $pct > 0) {
                $promoCoupon = '<span style="display:inline-block;margin-left:12px;font-size:10pt;font-weight:600;letter-spacing:.4px;text-transform:none;color:#fcd34d;">Use <span style="background:#fbbf24;color:#0f172a;padding:1px 6px;border-radius:4px;">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</span> · ' . $pct . '% off</span>';
            }
            $promoBarHtml = '<div class="promo-bar" style="background:#0f172a;color:#fff;padding:8px 14px;border-radius:8px;text-align:center;font-weight:800;letter-spacing:.6px;font-size:11pt;margin:0 0 14px;text-transform:uppercase;border-left:3px solid #fbbf24;">'
                          . $promoLogo . $promoLabel . $promoCoupon . '</div>';
        }
    }
    $secondRow= '';
    if (!empty($ctx['receipt_number'])) {
        $secondRow .= '<tr><td>Receipt number</td><td class="r">' . htmlspecialchars($ctx['receipt_number'], ENT_QUOTES, 'UTF-8') . '</td></tr>';
    }
    if (!empty($ctx['date_paid'])) {
        $secondRow .= '<tr><td>Date paid</td><td class="r">' . htmlspecialchars($ctx['date_paid'], ENT_QUOTES, 'UTF-8') . '</td></tr>';
    }
    if (!empty($ctx['date_issued'])) {
        $secondRow .= '<tr><td>Date of issue</td><td class="r">' . htmlspecialchars($ctx['date_issued'], ENT_QUOTES, 'UTF-8') . '</td></tr>';
    }
    if (!empty($ctx['date_due'])) {
        $secondRow .= '<tr><td>Date due</td><td class="r">'  . htmlspecialchars($ctx['date_due'], ENT_QUOTES, 'UTF-8')  . '</td></tr>';
    }
    $billLines = '';
    foreach ((array)($ctx['bill_to'] ?? []) as $line) {
        $billLines .= '<div>' . htmlspecialchars((string)$line, ENT_QUOTES, 'UTF-8') . '</div>';
    }
    $logoTag = $logoUrl && file_exists($logoUrl)
        ? '<img src="' . $logoUrl . '" alt="' . $brand . '" style="height:44px;width:auto;vertical-align:top;">'
        : '<div style="font-size:18px;font-weight:800;color:#06b6d4;letter-spacing:.5px;">' . $brand . '</div>';

    return <<<HTML
<!doctype html>
<html><head><meta charset="utf-8">
<style>
  @page { margin: 56px 48px; }
  body  { font-family: 'DejaVu Sans', Helvetica, Arial, sans-serif; font-size: 10.5pt; color: #1f2937; }
  h1    { font-size: 22pt; font-weight: 700; margin: 0 0 14px; color: #0f172a; letter-spacing: .3px; }
  .head-grid { width: 100%; border-collapse: collapse; margin-bottom: 26px; }
  .head-grid td { vertical-align: top; }
  .head-meta { width: 50%; }
  .head-meta table { width: 100%; border-collapse: collapse; font-size: 9.5pt; color: #475569; }
  .head-meta table td { padding: 2px 0; }
  .head-meta table td.r { text-align: right; color: #0f172a; font-weight: 600; }
  .head-brand { width: 50%; text-align: right; }
  .head-brand .brand-line { margin-top: 6px; font-size: 9pt; color: #64748b; line-height: 1.45; }

  .from-bill { width: 100%; border-collapse: collapse; margin-bottom: 22px; }
  .from-bill td { vertical-align: top; width: 50%; padding-right: 12px; font-size: 9.5pt; color: #1f2937; }
  .from-bill .label { font-size: 8pt; text-transform: uppercase; letter-spacing: 1.2px; color: #94a3b8; font-weight: 700; margin-bottom: 4px; }
  .from-bill .bold  { color: #0f172a; font-weight: 700; }

  .amount-banner { background: #f8fafc; border-left: 4px solid #06b6d4; padding: 14px 16px; margin-bottom: 22px; }
  .amount-banner .amt { font-size: 18pt; font-weight: 700; color: #0f172a; }
  .amount-banner .sub { font-size: 9pt; color: #64748b; margin-top: 2px; }

  table.items, table.payhist { width: 100%; border-collapse: collapse; margin-bottom: 22px; }
  table.items th, table.items td, table.payhist th, table.payhist td { padding: 9px 4px; font-size: 9.5pt; }
  table.items thead, table.payhist thead { border-bottom: 2px solid #0f172a; }
  table.items th, table.payhist th { text-align: left; font-weight: 700; color: #0f172a; font-size: 9pt; text-transform: uppercase; letter-spacing: .5px; }
  table.items td, table.payhist td { border-bottom: 1px solid #e2e8f0; }
  table.items td.num, table.items th.num, table.payhist td.num, table.payhist th.num { text-align: right; }
  .totals { width: 50%; margin-left: 50%; border-collapse: collapse; font-size: 10pt; }
  .totals td { padding: 5px 4px; }
  .totals td.label { color: #475569; }
  .totals td.value { text-align: right; color: #0f172a; font-weight: 600; }
  .totals tr.total-row td { border-top: 2px solid #0f172a; padding-top: 9px; font-size: 11.5pt; font-weight: 700; color: #0f172a; }
  .totals tr.amount-paid td { padding-top: 9px; color: #047857; font-weight: 700; }
  .totals tr.amount-due td { padding-top: 9px; color: #b91c1c; font-weight: 700; }

  .statement {
    background: #fff7ed; border: 1px solid #fdba74; border-left: 4px solid #f59e0b;
    padding: 10px 14px; border-radius: 10px; margin: 22px 0; font-size: 9.5pt; color: #7c2d12;
  }
  .statement .lbl { font-weight: 700; color: #7c2d12; }
  .statement .hl { background: #fde68a; color: #9a3412; font-weight: 700; padding: 1px 7px; border-radius: 5px; }

  .footer {
    margin-top: 14px; padding-top: 10px; border-top: 1px solid #e2e8f0;
    font-size: 8pt; color: #94a3b8; line-height: 1.6;
  }

  /* Colourful scattered brand watermark — Microsoft suite icons (or the
     single brand silhouette for non-Microsoft) tiled at low opacity behind
     the content.  Position:absolute on each <img> with deterministic top/
     left % values gives a "scattered marketing piece" feel without hurting
     readability.  Light opacity (≈14%) keeps text fully legible. */
  .scatter-wrap {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    width: 100%; height: 100%;
  }
  .scatter-icon {
    position: absolute;
    opacity: 0.14;
  }

  /* Personalised greeting above the doc title — friendly, premium touch. */
  .thank-you {
    font-size: 11pt;
    font-weight: 600;
    color: #0f766e;        /* teal — picks up the brand accent */
    margin: 0 0 4px;
    letter-spacing: .2px;
  }

  /* Diagonal "PAID" / "INVOICE" / "DUE" stamp sitting underneath the
     brand watermark — accounting-software vibe.  Subtle (12% opacity)
     and rotated -22° so it reads naturally without screaming.  Border +
     padding form the classic rubber-stamp look. */
  .stamp {
    position: absolute;
    top: 480px; left: 50%;
    margin-left: -130px;
    width: 260px;
    text-align: center;
    font-family: 'DejaVu Sans', Helvetica, Arial, sans-serif;
    font-weight: 900;
    font-size: 44pt;
    letter-spacing: 6px;
    padding: 10px 16px;
    border: 6px solid #1f2937;
    border-radius: 12px;
    opacity: 0.12;
    transform: rotate(-22deg);
  }
  /* QR — sits in its own block at the very bottom of the document so a
     printed copy can be scanned back to the customer's Order History
     (email + order# pre-filled).  Right-aligned via a single-cell
     table so Dompdf (which is finicky with floats) renders it reliably. */
  /* QR — sits in the empty right cell next to the "Bill to" block so a
     printed copy can be scanned back to the customer's Order History
     (email + order# pre-filled).  This keeps it inside the existing
     2-column header layout and guarantees it fits on page 1. */
  .from-bill td.qr-cell { text-align: right; vertical-align: top; }
  .qr-stamp {
    display: inline-block;
    width: 90px;
    text-align: center;
    font-family: Helvetica, Arial, sans-serif;
  }
  .qr-stamp img {
    width: 78px; height: 78px;
    display: block; margin: 0 auto;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 2px;
    background: #ffffff;
  }
  .qr-stamp .qr-label {
    margin-top: 4px;
    font-size: 6.5pt;
    color: #64748b;
    line-height: 1.25;
    letter-spacing: .2px;
  }
</style>
</head>
<body>
  {$scatterHtml}
  {$promoBarHtml}
  {$stampHtml}
  {$greetHtml}
  <h1>{$docTitle}</h1>
  <table class="head-grid"><tr>
    <td class="head-meta">
      <table>
        <tr><td>Invoice number</td><td class="r">{$invNo}</td></tr>
        {$secondRow}
      </table>
    </td>
    <td class="head-brand">
      {$logoTag}
      <div class="brand-line">
        <strong style="color:#0f172a;">{$brand}</strong><br>
        {$brandAddr}<br>
        {$brandEm}
      </div>
    </td>
  </tr></table>

  <table class="from-bill"><tr>
    <td><div class="label">Bill to</div>{$billLines}</td>
    <td class="qr-cell">{$qrHtml}</td>
  </tr></table>

  {$bodyHtml}

  <div class="footer">
    Questions? Reply to this email or visit our support page. Thanks for choosing {$brand}.
  </div>
</body></html>
HTML;
}

/**
 * Active vibe-schedule promo banner (shared by Receipt + Invoice).
 * Renders a thin coloured bar at the very top of the document when a
 * promo schedule is live.  Returns '' when there is none.
 */
function _pdf_promo_bar_html(): string
{
    if (!function_exists('active_vibe_promo')) return '';
    $promo = active_vibe_promo();
    if (!$promo || trim((string)$promo['label']) === '') return '';
    $promoLabel = htmlspecialchars((string)$promo['label'], ENT_QUOTES, 'UTF-8');
    $promoLogo  = '';
    $promoLogoFile = (string)($promo['logo_file'] ?? '');
    if ($promoLogoFile !== '' && is_file($promoLogoFile) && !preg_match('/\.svg$/i', $promoLogoFile)) {
        $promoLogo = '<img src="' . htmlspecialchars($promoLogoFile, ENT_QUOTES, 'UTF-8') . '" alt="" style="height:20px;width:auto;vertical-align:middle;background:#fff;border-radius:4px;padding:2px;margin-right:8px;">';
    }
    $promoCoupon = '';
    $code = strtoupper(trim((string)($promo['coupon_code'] ?? '')));
    $pct  = (int)($promo['coupon_percent'] ?? 0);
    if ($code !== '' && $pct > 0) {
        $promoCoupon = '<span style="display:inline-block;margin-left:12px;font-size:9.5pt;font-weight:600;color:#fcd34d;">Use <span style="background:#fbbf24;color:#0f172a;padding:1px 6px;border-radius:4px;">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</span> · ' . $pct . '% off</span>';
    }
    return '<div style="background:#0f172a;color:#fff;padding:8px 14px;border-radius:8px;text-align:center;font-weight:800;letter-spacing:.6px;font-size:10.5pt;margin:0 0 14px;text-transform:uppercase;border-left:3px solid #fbbf24;">'
         . $promoLogo . $promoLabel . $promoCoupon . '</div>';
}

/**
 * Resolve a human "payment method" label + processing gateway for an order.
 * Returns [methodLabel, gatewayName].
 */
function _pdf_is_no_charge(array $order): bool
{
    $pm = strtolower(trim((string)($order['payment_method'] ?? '')));
    return $pm === 'offline' || (float)($order['total'] ?? 0) <= 0.0;
}

function _pdf_payment_method(array $order, ?array $payment = null): array
{
    // Manual/offline deliveries and any $0 order were never charged to a card —
    // show a clear "Offline / no charge" instead of a fake card/gateway line.
    if (_pdf_is_no_charge($order)) {
        return ['Offline / no charge', ''];
    }
    $pmRaw   = strtolower(trim((string)($order['payment_method'] ?? 'card')));
    $gateway = $pmRaw === 'paypal'
        ? (setting_get('gw_paypal_provider', 'PayPal') ?: 'PayPal')
        : (setting_get('gw_card_provider', 'Stripe') ?: 'Stripe');
    if ($payment && !empty($payment['method'])) {
        $label = (string)$payment['method'];
    } elseif (!empty($order['card_brand'])) {
        $label = (string)$order['card_brand'] . (!empty($order['card_last4']) ? ' ····' . $order['card_last4'] : '');
    } elseif ($pmRaw === 'paypal') {
        $label = 'PayPal';
    } else {
        $label = 'Card' . (!empty($order['card_last4']) ? ' ····' . $order['card_last4'] : '');
    }
    return [$label, $gateway];
}

/**
 * Generate a Receipt PDF (paid orders) — a PAYMENT CONFIRMATION document,
 * intentionally styled completely differently from the tax Invoice: an
 * emerald "paid in full" hero, a payment-details card, and a light purchase
 * summary.  Returns the binary PDF string.  Throws on rendering failure.
 */
function generate_receipt_pdf(array $order, array $items, ?array $payment = null, string $extraBodyHtml = ''): string
{
    $e   = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $co  = function_exists('company_info') ? company_info() : ['name' => 'Maventech'];
    $co['phone'] = function_exists('company_phone_for_country') ? company_phone_for_country($order['country'] ?? null) : ($co['phone'] ?? '');
    $cur = (string)($order['currency'] ?? 'USD');

    $orderNo   = (string)($order['order_number'] ?? '');
    $invoiceNo = function_exists('mv_invoice_number') ? mv_invoice_number($order) : $orderNo;
    $receiptNo = function_exists('mv_receipt_number') ? mv_receipt_number($order) : $orderNo;

    $datePaidRaw = $order['paid_at'] ?? $order['created_at'] ?? date('Y-m-d H:i:s');
    $datePaid    = date('F j, Y', strtotime($datePaidRaw));

    $custName = trim((string)($order['first_name'] ?? '') . ' ' . (string)($order['last_name'] ?? ''));
    $first    = trim((string)($order['first_name'] ?? ''));

    // Bill-to lines.
    $billTo = array_filter([
        $custName,
        (string)($order['email'] ?? ''),
        trim(((string)($order['address']  ?? '')) . (empty($order['address2']) ? '' : ', ' . $order['address2'])),
        trim(((string)($order['city']     ?? '')) . ', ' . ((string)($order['state'] ?? '')) . ' ' . ((string)($order['zip'] ?? ''))),
        (string)($order['country'] ?? ''),
    ], fn($l) => trim((string)$l) !== '');

    $stmtName = !empty($order['card_statement_name'])
        ? (string)$order['card_statement_name']
        : (function_exists('statement_name_for')
            ? (string)statement_name_for((string)($order['payment_method'] ?? 'card'))
            : (string)($co['name'] ?? 'Maventech'));

    [$payLabel, $gateway] = _pdf_payment_method($order, $payment);
    $noCharge     = _pdf_is_no_charge($order);
    $payMethodVal = $gateway !== '' ? ($payLabel . ' · via ' . $gateway) : $payLabel;
    $rcNote       = $noCharge
        ? '<strong>Billing note:</strong> this order was delivered manually at no charge — no card was billed.'
        : '<strong>Billing note:</strong> this charge appears as <span class="hl">' . $stmtName . '</span> on your card statement, processed securely via ' . $gateway . '.';

    // Gateway transaction / reference ID (NMI or PayPal capture id). Shown on
    // the receipt so customers can reconcile the charge with their bank/PayPal.
    $txnId  = trim((string)($order['transaction_id'] ?? ($payment['transaction_id'] ?? '')));
    $txnRow = $txnId !== ''
        ? '<tr><td class="k">Transaction ID</td><td class="v mono">' . $e($txnId) . '</td></tr>'
        : '';

    // Light purchase summary (chip rows, NOT a formal ledger).
    $subtotal = 0.0;
    $summaryRows = '';
    foreach ($items as $it) {
        $qty  = (int)($it['quantity'] ?? $it['qty'] ?? 1);
        $unit = (float)($it['unit_price'] ?? $it['price'] ?? 0);
        $amt  = $qty * $unit;
        $subtotal += $amt;
        $summaryRows .= '<tr>'
            . '<td class="ps-name">' . $e($it['name'] ?? $it['product_name'] ?? '—')
            . ($qty > 1 ? ' <span class="ps-qty">&#215;' . $qty . '</span>' : '') // hide "×1" — clutter + dompdf's default font can't render U+00D7 cleanly (renders as "-" / ".")
            . '</td>'
            . '<td class="ps-amt">' . _pdf_money($amt, $cur) . '</td>'
            . '</tr>';
    }
    $total = (float)($order['total'] ?? $subtotal);
    $rcDiscount = max(0, $subtotal - $total);
    $rcTotalsExtra = '';
    if ($rcDiscount > 0.009) {
        $rcTotalsExtra = '<tr class="ps-t-min"><td class="lbl2">Subtotal</td><td class="val2">' . _pdf_money($subtotal, $cur) . '</td></tr>'
                       . '<tr class="ps-t-min"><td class="lbl2">Discount</td><td class="val2" style="color:#16a34a;">−' . _pdf_money($rcDiscount, $cur) . '</td></tr>';
    }

    $logoPath = _pdf_company_logo_path();
    $logoTag  = ($logoPath && file_exists($logoPath))
        ? '<img src="' . $logoPath . '" alt="' . $e($co['name'] ?? '') . '" style="height:40px;width:auto;">'
        : '<div style="font-size:17px;font-weight:800;color:#059669;">' . $e($co['name'] ?? 'Maventech') . '</div>';

    $promoBar   = _pdf_promo_bar_html();
    $scatter    = _pdf_brand_scatter_html(_pdf_brand_for_items($items));
    $qr         = _pdf_order_history_qr($order);
    $qrHtml     = $qr !== '' ? '<div class="rc-qr"><img src="' . $qr . '" alt="QR"><div class="rc-qr-lbl">Scan to view<br>your order online</div></div>' : '';

    $brandName = $e($co['name'] ?? 'Maventech');
    $brandAddr = nl2br($e($co['address'] ?? ''));
    $brandEm   = $e($co['email'] ?? '');
    $money     = fn($v) => _pdf_money($v, $cur);
    $amtBig    = $money($total);
    $billHtml  = implode('<br>', array_map($e, $billTo));

    $html = <<<HTML
<!doctype html><html><head><meta charset="utf-8"><style>
  @page { margin: 22px 36px; size: letter portrait; }
  body { font-family:'DejaVu Sans',Helvetica,Arial,sans-serif; font-size:9.5pt; color:#1f2937; }
  .scatter-wrap { position:absolute; top:0; left:0; right:0; bottom:0; width:100%; height:100%; }
  .scatter-icon { position:absolute; opacity:0.09; }
  .rc-top { width:100%; border-collapse:collapse; margin-bottom:5px; }
  .rc-top td { vertical-align:top; }
  .rc-top .rc-co { font-size:7pt; color:#64748b; line-height:1.35; margin-top:2px; }
  .rc-tag { text-align:right; }
  .rc-tag .lbl { font-size:8pt; letter-spacing:2px; font-weight:700; color:#059669; text-transform:uppercase; }
  .rc-hero { background:#ecfdf5; border:1px solid #a7f3d0; border-radius:10px; padding:7px 14px 8px; margin-bottom:6px; text-align:center; }
  .rc-check { width:24px; height:24px; line-height:22px; border-radius:50%; background:#059669; color:#fff; font-size:12pt; font-weight:700; margin:0 auto 2px; }
  .rc-badge { display:inline-block; background:#059669; color:#fff; font-size:6.5pt; font-weight:700; letter-spacing:1.3px; text-transform:uppercase; padding:1.5px 8px; border-radius:999px; }
  .rc-amt { font-size:17pt; font-weight:800; color:#047857; margin:3px 0 1px; letter-spacing:.3px; }
  .rc-amt-sub { font-size:8pt; color:#059669; }
  .rc-card { border:1px solid #e2e8f0; border-radius:9px; padding:0; margin-bottom:6px; }
  .rc-card table { width:100%; border-collapse:collapse; }
  .rc-card td { padding:3px 12px; font-size:8pt; vertical-align:top; border-bottom:1px solid #eef2f7; }
  .rc-card tr:last-child td { border-bottom:0; }
  .rc-card .k { color:#64748b; width:38%; }
  .rc-card .v { color:#0f172a; font-weight:700; text-align:right; }
  .rc-card .v.mono { font-family:'DejaVu Sans Mono',monospace; letter-spacing:.3px; }
  .sec-label { font-size:6.5pt; letter-spacing:1.3px; text-transform:uppercase; color:#94a3b8; font-weight:700; margin:0 0 2px; }
  .ps { width:100%; border-collapse:collapse; margin-bottom:3px; }
  .ps td { padding:4px 2px; font-size:8.5pt; border-bottom:1px dashed #e2e8f0; }
  .ps .ps-name { color:#1f2937; }
  .ps .ps-qty { color:#94a3b8; font-size:7.5pt; }
  .ps .ps-amt { text-align:right; color:#0f172a; font-weight:700; white-space:nowrap; }
  .ps-total { width:100%; border-collapse:collapse; }
  .ps-total td { padding:4px 2px; font-size:10.5pt; font-weight:800; }
  .ps-total .lbl { color:#065f46; }
  .ps-total .val { text-align:right; color:#047857; }
  .ps-total .ps-t-min td { padding:1px 2px; font-size:8.5pt; font-weight:600; }
  .ps-total .ps-t-min .lbl2 { color:#64748b; }
  .ps-total .ps-t-min .val2 { text-align:right; color:#334155; }
  .rc-note { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:5px 11px; font-size:8pt; color:#166534; margin:6px 0; }
  .rc-note .hl { background:#dcfce7; color:#14532d; font-weight:700; padding:1px 6px; border-radius:4px; }
  .rc-cols { width:100%; border-collapse:collapse; margin-top:5px; }
  .rc-cols td { vertical-align:top; width:50%; padding-right:12px; font-size:8pt; color:#334155; line-height:1.35; }
  .rc-qr { text-align:right; }
  .rc-qr img { width:54px; height:54px; border:1px solid #e2e8f0; border-radius:6px; padding:2px; background:#fff; }
  .rc-qr-lbl { font-size:5.5pt; color:#64748b; margin-top:2px; line-height:1.2; }
  .rc-footer { margin-top:6px; padding-top:5px; border-top:1px solid #e2e8f0; font-size:7pt; color:#94a3b8; line-height:1.4; }
</style></head><body>
  {$scatter}
  {$promoBar}
  <table class="rc-top"><tr>
    <td>{$logoTag}<div class="rc-co"><strong style="color:#0f172a;">{$brandName}</strong><br>{$brandAddr}<br>{$brandEm}</div></td>
    <td class="rc-tag"><div class="lbl">Payment Receipt</div></td>
  </tr></table>

  <div class="rc-hero">
    <div class="rc-check">&#10003;</div>
    <div class="rc-badge">Paid in full</div>
    <div class="rc-amt">{$amtBig}</div>
    <div class="rc-amt-sub">Paid on {$datePaid} · Thank you, {$first}!</div>
  </div>

  <div class="rc-card"><table>
    <tr><td class="k">Receipt number</td><td class="v mono">{$receiptNo}</td></tr>
    <tr><td class="k">Order number</td><td class="v mono">{$orderNo}</td></tr>
    <tr><td class="k">Invoice reference</td><td class="v mono">{$invoiceNo}</td></tr>
    <tr><td class="k">Payment method</td><td class="v">{$payMethodVal}</td></tr>
    {$txnRow}
    <tr><td class="k">Date paid</td><td class="v">{$datePaid}</td></tr>
    <tr><td class="k">Amount paid</td><td class="v" style="color:#047857;">{$amtBig}</td></tr>
  </table></div>

  <div class="sec-label">What you paid for</div>
  <table class="ps"><tbody>{$summaryRows}</tbody></table>
  <table class="ps-total">{$rcTotalsExtra}<tr><td class="lbl">Total paid</td><td class="val">{$amtBig}</td></tr></table>

  <div class="rc-note">{$rcNote}</div>

  <table class="rc-cols"><tr>
    <td><div class="sec-label">Billed to</div>{$billHtml}</td>
    <td>{$qrHtml}</td>
  </tr></table>

  <div class="rc-footer">This receipt confirms payment has been received in full. A detailed tax invoice is attached separately. Questions? Reply to this email or contact {$brandEm}. — {$brandName}</div>
  {$extraBodyHtml}
</body></html>
HTML;

    $dompdf = _pdf_dompdf();
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('letter', 'portrait');
    $dompdf->render();
    return $dompdf->output();
}

/**
 * Generate an Invoice PDF — a formal TAX INVOICE (issued at order time,
 * works for both paid and pending orders).  Deliberately different from the
 * Receipt: a document-style header, a bordered reference/meta box (Invoice #,
 * Order #, dates, status), a From/Bill-To split, a full itemised ledger with
 * a dark header, and terms.  Returns the binary PDF string.
 */
function generate_invoice_pdf(array $order, array $items): string
{
    $e   = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $co  = function_exists('company_info') ? company_info() : ['name' => 'Maventech'];
    $co['phone'] = function_exists('company_phone_for_country') ? company_phone_for_country($order['country'] ?? null) : ($co['phone'] ?? '');
    $cur = (string)($order['currency'] ?? 'USD');

    $orderNo   = (string)($order['order_number'] ?? '');
    $invoiceNo = function_exists('mv_invoice_number') ? mv_invoice_number($order) : $orderNo;

    $dateIssued = date('F j, Y', strtotime((string)($order['created_at'] ?? 'now')));
    $dateDue    = $dateIssued;  // Digital goods — due on issue.
    $isPaid     = (string)($order['status'] ?? '') === 'paid';

    $billTo = array_filter([
        trim((string)($order['first_name'] ?? '') . ' ' . (string)($order['last_name'] ?? '')),
        (string)($order['email'] ?? ''),
        trim(((string)($order['address']  ?? '')) . (empty($order['address2']) ? '' : ', ' . $order['address2'])),
        trim(((string)($order['city']     ?? '')) . ', ' . ((string)($order['state'] ?? '')) . ' ' . ((string)($order['zip'] ?? ''))),
        (string)($order['country'] ?? ''),
    ], fn($l) => trim((string)$l) !== '');
    $billHtml = implode('<br>', array_map($e, $billTo));

    $stmtName = !empty($order['card_statement_name'])
        ? (string)$order['card_statement_name']
        : (function_exists('statement_name_for')
            ? (string)statement_name_for((string)($order['payment_method'] ?? 'card'))
            : (string)($co['name'] ?? 'Maventech'));

    // Payment method + gateway transaction id, shown on the invoice so it can
    // be reconciled against the NMI / PayPal record.
    [$invPayLabel, $invGateway] = _pdf_payment_method($order, null);
    $invNoCharge = _pdf_is_no_charge($order);
    $invTxnId  = trim((string)($order['transaction_id'] ?? ''));
    $invTxnRow = $invTxnId !== ''
        ? '<tr><td class="k">Transaction ID</td><td class="v mono">' . $e($invTxnId) . '</td></tr>'
        : '';
    $invPayVal = $invGateway !== '' ? ($e($invPayLabel) . ' · via ' . $e($invGateway)) : $e($invPayLabel);
    $invPayRow = '<tr><td class="k">Payment method</td><td class="v">' . $invPayVal . '</td></tr>';

    $itemsHtml = '';
    $subtotal = 0.0;
    foreach ($items as $it) {
        $qty  = (int)($it['quantity'] ?? $it['qty'] ?? 1);
        $unit = (float)($it['unit_price'] ?? $it['price'] ?? 0);
        $amt  = $qty * $unit;
        $subtotal += $amt;
        $itemsHtml .= '<tr><td>' . $e($it['name'] ?? $it['product_name'] ?? '—')
                   . '</td><td class="num">' . $qty
                   . '</td><td class="num">' . _pdf_money($unit, $cur)
                   . '</td><td class="num">' . _pdf_money($amt, $cur) . '</td></tr>';
    }
    $total = (float)($order['total'] ?? $subtotal);
    $discount = max(0, $subtotal - $total);
    $discountRow = $discount > 0.009
        ? '<tr><td class="label">Discount</td><td class="value" style="color:#16a34a;">−' . _pdf_money($discount, $cur) . '</td></tr>'
        : '';

    $logoPath = _pdf_company_logo_path();
    $logoTag  = ($logoPath && file_exists($logoPath))
        ? '<img src="' . $logoPath . '" alt="' . $e($co['name'] ?? '') . '" style="height:42px;width:auto;">'
        : '<div style="font-size:17px;font-weight:800;color:#4f46e5;">' . $e($co['name'] ?? 'Maventech') . '</div>';

    $promoBar = _pdf_promo_bar_html();
    $scatter  = _pdf_brand_scatter_html(_pdf_brand_for_items($items));
    $qr       = _pdf_order_history_qr($order);
    $qrHtml   = $qr !== '' ? '<div class="inv-qr"><img src="' . $qr . '" alt="QR"><div class="inv-qr-lbl">Scan to re-download<br>this invoice</div></div>' : '';

    $brandName = $e($co['name'] ?? 'Maventech');
    $brandAddr = nl2br($e($co['address'] ?? ''));
    $brandEm   = $e($co['email'] ?? '');
    $brandPh   = $e($co['phone'] ?? '');
    $subTotalS = _pdf_money($subtotal, $cur);
    $totalS    = _pdf_money($total, $cur);
    $curE      = $e($cur);
    $stmtE     = $e($stmtName);

    $statusBadge = $isPaid
        ? '<span style="background:#dcfce7;color:#166534;font-weight:800;font-size:8.5pt;padding:3px 12px;border-radius:999px;letter-spacing:1px;">PAID</span>'
        : '<span style="background:#fee2e2;color:#991b1b;font-weight:800;font-size:8.5pt;padding:3px 12px;border-radius:999px;letter-spacing:1px;">DUE</span>';
    $amountRow = $isPaid
        ? '<tr class="amount-paid"><td class="label">Amount paid</td><td class="value">' . $totalS . ' ' . $curE . '</td></tr>'
        : '<tr class="amount-due"><td class="label">Amount due</td><td class="value">' . $totalS . ' ' . $curE . '</td></tr>';
    $stampText  = $isPaid ? 'PAID' : 'DUE';
    $stampColor = $isPaid ? '#16a34a' : '#dc2626';
    $termsLine  = $invNoCharge
        ? 'This invoice was settled at no charge — no payment was taken. Keep it for your records.'
        : ($isPaid
        ? 'This invoice has been settled in full — no payment is due. Keep it for your records. The charge appears as <strong>' . $stmtE . '</strong> on your statement.'
        : 'Payment is due on receipt. Your license keys are delivered once payment is confirmed. The charge will appear as <strong>' . $stmtE . '</strong> on your statement.');

    $html = <<<HTML
<!doctype html><html><head><meta charset="utf-8"><style>
  @page { margin: 28px 40px; size: letter portrait; }
  body { font-family:'DejaVu Sans',Helvetica,Arial,sans-serif; font-size:10pt; color:#1f2937; }
  .scatter-wrap { position:absolute; top:0; left:0; right:0; bottom:0; width:100%; height:100%; }
  .scatter-icon { position:absolute; opacity:0.08; }
  .inv-stamp { position:absolute; top:400px; left:50%; margin-left:-120px; width:240px; text-align:center;
      font-weight:900; font-size:38pt; letter-spacing:7px; padding:6px 12px; border:6px solid {$stampColor};
      color:{$stampColor}; border-radius:12px; opacity:0.11; transform:rotate(-20deg); }
  .inv-head { width:100%; border-collapse:collapse; margin-bottom:12px; }
  .inv-head td { vertical-align:top; }
  .inv-title { font-size:22pt; font-weight:800; color:#312e81; letter-spacing:1px; line-height:1; }
  .inv-sub { font-size:8pt; letter-spacing:2.5px; color:#6366f1; font-weight:700; text-transform:uppercase; margin-top:2px; }
  .inv-brand { text-align:right; }
  .inv-brand .co { font-size:8pt; color:#64748b; line-height:1.45; margin-top:4px; }
  .inv-meta { width:100%; border-collapse:collapse; border:1px solid #e0e7ff; border-radius:10px; margin-bottom:12px; background:#f5f3ff; }
  .inv-meta td { padding:5px 14px; font-size:8.5pt; border-bottom:1px solid #e0e7ff; }
  .inv-meta tr:last-child td { border-bottom:0; }
  .inv-meta .k { color:#64748b; }
  .inv-meta .v { text-align:right; color:#0f172a; font-weight:700; }
  .inv-meta .v.mono { font-family:'DejaVu Sans Mono',monospace; }
  .parties { width:100%; border-collapse:collapse; margin-bottom:12px; }
  .parties td { vertical-align:top; width:50%; padding-right:14px; font-size:8.5pt; color:#334155; line-height:1.4; }
  .parties .label { font-size:7.5pt; text-transform:uppercase; letter-spacing:1.2px; color:#94a3b8; font-weight:700; margin-bottom:3px; }
  .parties .bold { color:#0f172a; font-weight:700; }
  .parties .inv-qr { text-align:left; margin-top:4px; }
  .parties .inv-qr img { width:55px; height:55px; border:1px solid #e2e8f0; border-radius:6px; padding:2px; background:#fff; }
  .parties .inv-qr-lbl { font-size:6pt; color:#64748b; margin-top:2px; line-height:1.2; }
  table.items { width:100%; border-collapse:collapse; margin-bottom:10px; }
  table.items th, table.items td { padding:6px 6px; font-size:9pt; }
  table.items thead th { background:#312e81; color:#fff; text-align:left; font-weight:700; font-size:8pt; text-transform:uppercase; letter-spacing:.5px; }
  table.items thead th:first-child { border-top-left-radius:6px; }
  table.items thead th:last-child { border-top-right-radius:6px; }
  table.items td { border-bottom:1px solid #e2e8f0; }
  table.items td.num, table.items th.num { text-align:right; }
  .totals { width:52%; margin-left:48%; border-collapse:collapse; font-size:9.5pt; }
  .totals td { padding:4px 6px; }
  .totals td.label { color:#475569; }
  .totals td.value { text-align:right; color:#0f172a; font-weight:600; }
  .totals tr.total-row td { border-top:2px solid #312e81; padding-top:6px; font-size:11pt; font-weight:800; color:#312e81; }
  .totals tr.amount-paid td { padding-top:5px; color:#047857; font-weight:800; }
  .totals tr.amount-due td { padding-top:5px; color:#b91c1c; font-weight:800; }
  .inv-terms { margin-top:10px; background:#eef2ff; border:1px solid #c7d2fe; border-radius:8px; padding:7px 12px; font-size:8.5pt; color:#3730a3; }
  .inv-footer { margin-top:8px; padding-top:6px; border-top:1px solid #e2e8f0; font-size:7.5pt; color:#94a3b8; line-height:1.5; }
</style></head><body>
  {$scatter}
  {$promoBar}
  <div class="inv-stamp">{$stampText}</div>
  <table class="inv-head"><tr>
    <td><div class="inv-title">INVOICE</div><div class="inv-sub">Tax Invoice</div></td>
    <td class="inv-brand">{$logoTag}<div class="co"><strong style="color:#0f172a;">{$brandName}</strong><br>{$brandAddr}<br>{$brandEm}<br>{$brandPh}</div></td>
  </tr></table>

  <table class="inv-meta">
    <tr><td class="k">Invoice number</td><td class="v mono">{$invoiceNo}</td></tr>
    <tr><td class="k">Order number</td><td class="v mono">{$orderNo}</td></tr>
    <tr><td class="k">Date of issue</td><td class="v">{$dateIssued}</td></tr>
    <tr><td class="k">Date due</td><td class="v">{$dateDue}</td></tr>
    {$invPayRow}
    {$invTxnRow}
    <tr><td class="k">Status</td><td class="v">{$statusBadge}</td></tr>
  </table>

  <table class="parties"><tr>
    <td><div class="label">From</div><span class="bold">{$brandName}</span><br>{$brandAddr}<br>{$brandEm}</td>
    <td><div class="label">Bill to</div>{$billHtml}{$qrHtml}</td>
  </tr></table>

  <table class="items">
    <thead><tr><th>Description</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead>
    <tbody>{$itemsHtml}</tbody>
  </table>

  <table class="totals">
    <tr><td class="label">Subtotal</td><td class="value">{$subTotalS}</td></tr>
    {$discountRow}
    <tr class="total-row"><td class="label">Total</td><td class="value">{$totalS} {$curE}</td></tr>
    {$amountRow}
  </table>

  <div class="inv-terms"><strong>Terms:</strong> {$termsLine}</div>
  <div class="inv-footer">This is a computer-generated tax invoice for order {$orderNo}. A separate payment receipt confirms funds received. Questions? Contact {$brandEm}. — {$brandName}</div>
</body></html>
HTML;

    $dompdf = _pdf_dompdf();
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('letter', 'portrait');
    $dompdf->render();
    return $dompdf->output();
}

/**
 * Mask a license key for any THIRD-PARTY / PDF document (bank, gateway, dispute
 * evidence). Reveals only the last 4 alphanumerics; everything else becomes •,
 * preserving the dash formatting so it still reads as a key but can't be used.
 * Admin on-screen views keep the full key — this is only applied in PDFs.
 */
function mv_mask_license_key(string $key): string
{
    $key = trim($key);
    if ($key === '') return '';
    $chars = str_split($key);
    $alnumTotal = 0;
    foreach ($chars as $c) { if (ctype_alnum($c)) $alnumTotal++; }
    $reveal = $alnumTotal > 6 ? 4 : 0; // short codes fully masked
    $out = ''; $seen = 0;
    foreach ($chars as $c) {
        if (ctype_alnum($c)) {
            $seen++;
            $out .= ($seen > $alnumTotal - $reveal) ? $c : '•';
        } else {
            $out .= $c;
        }
    }
    return $out;
}

/**
 * Friendly label for an email template_code — shared by the on-screen
 * Email Activity log and the PDF proof documents so the wording matches.
 */
function mv_email_type_label(string $tc, string $html = ''): string
{
    $map = [
        'order_confirmation' => 'Order Confirmation',
        'order_pending'      => 'Payment Pending',
        'order_awaiting'     => 'Order Received — key coming',
        'order_delivery'     => 'License Delivery',
        'order_email_bounced'=> 'Delivery-failure alert (admin)',
        'review_request'     => 'Review Request',
        'refund_confirm'     => 'Refund Confirmation',
        'activation_checkin' => '24h Activation Check-in',
        'followup_1'         => '72h Installation Follow-up',
        'followup_2'         => 'Follow-up · 30-day check-in',
        'followup_3'         => '24h Activation Check-in',
        'newsletter'         => 'Newsletter',
    ];
    if (isset($map[$tc])) {
        if ($tc === 'order_delivery' && stripos($html, 'being prepared') !== false) {
            return 'Order Received — key coming';
        }
        return $map[$tc];
    }
    return $tc !== '' ? ucwords(str_replace('_', ' ', $tc)) : 'Email';
}

/**
 * Plain-text, readable preview of an email body (tags stripped, entities
 * decoded, whitespace collapsed, tracking pixels + preheaders removed).
 */
function mv_email_text_preview(string $html, int $max = 420): string
{
    if ($html === '') return '';
    // Drop style/script and the invisible tracking pixel / preheader.
    $t = preg_replace('#<(style|script)[^>]*>.*?</\1>#is', ' ', $html);
    $t = preg_replace('#<img[^>]*>#i', ' ', (string)$t);
    $t = preg_replace('#<[^>]+>#', ' ', (string)$t);
    $t = html_entity_decode((string)$t, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $t = preg_replace('/\s+/u', ' ', (string)$t);
    $t = trim((string)$t);
    if (function_exists('mb_strimwidth')) $t = mb_strimwidth($t, 0, $max, '…');
    return $t;
}

/**
 * Build the self-contained HTML block that documents every email sent for an
 * order, in thread order, with subject, type, date, delivery + open status,
 * order number and a readable preview of the actual content the customer saw.
 * Used by BOTH dispute-evidence.php and email-thread-proof.php. Inline styles
 * keep it rendering identically regardless of the host page's CSS.
 */
function mv_email_thread_proof_html(int $orderId): string
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    try {
        $stmt = db()->prepare('SELECT * FROM email_outbox WHERE order_id=? ORDER BY created_at ASC, id ASC');
        $stmt->execute([$orderId]);
        $rows = $stmt->fetchAll();
    } catch (Throwable $ex) { $rows = []; }
    if (!$rows) {
        return '<div style="font-size:8.5pt;color:#94a3b8;padding:4px 8px;">No emails recorded for this order.</div>';
    }
    // Fetch this order's license keys so we can MASK them anywhere they appear
    // in the thread (subject or content preview) — this is a third-party PDF.
    $keyList = [];
    try {
        $ks = db()->prepare('SELECT license_key FROM license_keys WHERE order_id=?');
        $ks->execute([$orderId]);
        foreach ($ks->fetchAll() as $kr) {
            $kv = trim((string)($kr['license_key'] ?? ''));
            if ($kv !== '') $keyList[$kv] = mv_mask_license_key($kv);
        }
    } catch (Throwable $ex) {}
    $redact = function (string $t) use ($keyList): string {
        foreach ($keyList as $full => $masked) { $t = str_ireplace($full, $masked, $t); }
        return $t;
    };
    $cards = '';
    $step = 0; $total = count($rows);
    foreach ($rows as $em) {
        $step++;
        $tc      = (string)($em['template_code'] ?? '');
        $label   = mv_email_type_label($tc, (string)($em['html'] ?? ''));
        $status  = strtolower((string)($em['status'] ?? ''));
        $opened  = !empty($em['opened_at']);
        $badgeTxt = $opened ? 'OPENED' : ($status === 'failed' || $status === 'bounced' ? strtoupper($status) : ($status === 'sent' ? 'DELIVERED' : strtoupper($status ?: 'QUEUED')));
        $badgeBg  = $opened ? '#dbeafe' : (($status === 'failed' || $status === 'bounced') ? '#fee2e2' : '#dcfce7');
        $badgeFg  = $opened ? '#1e40af' : (($status === 'failed' || $status === 'bounced') ? '#991b1b' : '#166534');
        $sent     = $em['created_at'] ? date('M j, Y · H:i', strtotime((string)$em['created_at'])) . ' UTC' : '—';
        $deliv    = !empty($em['delivered_at']) ? date('M j, Y · H:i', strtotime((string)$em['delivered_at'])) . ' UTC' : '—';
        $openInfo = $opened ? (date('M j, Y · H:i', strtotime((string)$em['opened_at'])) . ' UTC (' . (int)$em['opened_count'] . '× open' . ((int)$em['opened_count'] === 1 ? '' : 's') . ')') : '—';
        $preview  = $redact(mv_email_text_preview((string)($em['html'] ?? '')));
        $subject  = $redact((string)$em['subject']);
        $attachLine = '';
        $aj = (string)($em['attachments_json'] ?? '');
        if ($aj !== '') {
            $names = [];
            $arr = json_decode($aj, true);
            if (is_array($arr)) {
                foreach ($arr as $a) {
                    $n = is_array($a) ? ($a['name'] ?? ($a['filename'] ?? basename((string)($a['path'] ?? '')))) : basename((string)$a);
                    if ($n) $names[] = $n;
                }
            }
            if ($names) $attachLine = '<div style="margin-top:4px;font-size:7.5pt;color:#475569;"><strong>Attachments:</strong> ' . $e(implode(', ', $names)) . '</div>';
        }
        $cards .= '<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;margin:0 0 7px;page-break-inside:avoid;">'
            . '<table style="width:100%;border-collapse:collapse;"><tr>'
            . '<td style="font-size:7pt;color:#64748b;font-weight:700;">STEP ' . $step . ' OF ' . $total . ' · ' . $e($label) . '</td>'
            . '<td style="text-align:right;"><span style="background:' . $badgeBg . ';color:' . $badgeFg . ';font-size:7pt;font-weight:800;letter-spacing:.4px;padding:2px 8px;border-radius:999px;">' . $e($badgeTxt) . '</span></td>'
            . '</tr></table>'
            . '<div style="font-size:9pt;font-weight:700;color:#0f172a;margin:4px 0 2px;">' . $e($subject) . '</div>'
            . '<table style="width:100%;border-collapse:collapse;font-size:7.5pt;color:#475569;margin:2px 0 4px;">'
            . '<tr><td style="padding:1px 0;width:50%;"><strong>Sent:</strong> ' . $e($sent) . '</td><td style="padding:1px 0;"><strong>Delivered:</strong> ' . $e($deliv) . '</td></tr>'
            . '<tr><td style="padding:1px 0;"><strong>To:</strong> ' . $e((string)$em['recipient']) . '</td><td style="padding:1px 0;"><strong>Opened:</strong> ' . $e($openInfo) . '</td></tr>'
            . '</table>'
            . ($preview !== '' ? '<div style="background:#f8fafc;border-left:3px solid #cbd5e1;border-radius:4px;padding:6px 9px;font-size:8pt;color:#334155;line-height:1.5;">' . $e($preview) . '</div>' : '')
            . $attachLine
            . '</div>';
    }
    return $cards;
}

/**
 * Render the "Email Thread & Delivery Proof" PDF for an order and return the
 * binary PDF string. Shared by email-thread-proof.php (direct download) and
 * order-docs.php (one-click all-documents ZIP).
 */
function mv_render_email_thread_proof_pdf(array $o): string
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $id = (int)($o['id'] ?? 0);
    $co = function_exists('company_info') ? company_info() : ['name' => 'Maventech'];
    $siteUrl = rtrim(function_exists('site_url') ? site_url() : '', '/');
    $custName = trim((string)($o['first_name'] ?? '') . ' ' . (string)($o['last_name'] ?? ''));
    $orderNo  = $e((string)($o['order_number'] ?? ''));
    $genAt    = gmdate('F j, Y H:i') . ' UTC';

    $deliveredCount = 0; $totalEmails = 0; $keyDelivered = false;
    try {
        $r = db()->prepare('SELECT status, template_code FROM email_outbox WHERE order_id=?');
        $r->execute([$id]);
        foreach ($r->fetchAll() as $row) {
            $totalEmails++;
            $st = strtolower((string)$row['status']);
            if (in_array($st, ['sent', 'delivered'], true)) {
                $deliveredCount++;
                if (($row['template_code'] ?? '') === 'order_delivery') $keyDelivered = true;
            }
        }
    } catch (Throwable $ex) {}

    $statusTxt = $keyDelivered ? 'LICENSE DELIVERED' : ($deliveredCount > 0 ? 'EMAILS DELIVERED' : 'NOT DELIVERED');
    $statusBg  = $keyDelivered ? '#059669' : ($deliveredCount > 0 ? '#0f766e' : '#b91c1c');
    $threadHtml = mv_email_thread_proof_html($id);

    $logoPath = _pdf_company_logo_path();
    $logoTag  = ($logoPath && file_exists($logoPath))
        ? '<img src="' . $logoPath . '" style="height:38px;width:auto;">'
        : '<div style="font-size:16px;font-weight:800;color:#0f172a;">' . $e($co['name'] ?? 'Maventech') . '</div>';
    $brandName = $e($co['name'] ?? 'Maventech');
    $addr = trim(implode(', ', array_filter([
        (string)($o['address'] ?? ''), (string)($o['address2'] ?? ''), (string)($o['city'] ?? ''),
        trim((string)($o['state'] ?? '') . ' ' . (string)($o['zip'] ?? '')), (string)($o['country'] ?? ''),
    ])));
    $email = $e((string)($o['email'] ?? ''));
    $created = $e((string)($o['created_at'] ?? ''));
    $coEmail = $e((string)($co['email'] ?? ''));

    $html = <<<HTML
<!doctype html><html><head><meta charset="utf-8"><style>
  @page { margin: 34px 40px; size: letter portrait; }
  body { font-family:'DejaVu Sans',Helvetica,Arial,sans-serif; font-size:9pt; color:#1f2937; }
  .doc-head { width:100%; border-collapse:collapse; margin-bottom:10px; }
  .doc-head td { vertical-align:top; }
  .doc-title { font-size:16pt; font-weight:800; color:#0f172a; letter-spacing:.5px; }
  .doc-sub { font-size:8pt; letter-spacing:2px; color:#0f766e; font-weight:700; text-transform:uppercase; margin-top:2px; }
  .doc-meta { font-size:7.5pt; color:#64748b; margin-top:4px; line-height:1.4; }
  .brand-cell { text-align:right; font-size:7.5pt; color:#64748b; line-height:1.4; }
  .status-pill { display:inline-block; color:#fff; font-size:9pt; font-weight:800; letter-spacing:.6px; padding:5px 14px; border-radius:999px; }
  h2 { font-size:10pt; font-weight:800; color:#0f172a; margin:14px 0 5px; padding:4px 8px; background:#f1f5f9; border-left:4px solid #0f766e; }
  table.kv { width:100%; border-collapse:collapse; margin-bottom:4px; }
  table.kv td { padding:3.5px 8px; font-size:8.5pt; border-bottom:1px solid #eef2f7; vertical-align:top; }
  table.kv td.k { color:#64748b; width:28%; }
  table.kv td.v { color:#0f172a; font-weight:700; }
  .cap { font-size:7.5pt; color:#64748b; margin:2px 0 6px; }
  .cert { margin-top:12px; padding-top:8px; border-top:2px solid #0f172a; font-size:7.5pt; color:#475569; line-height:1.55; }
</style></head><body>
<table class="doc-head"><tr>
  <td>
    <div class="doc-title">EMAIL THREAD &amp; DELIVERY PROOF</div>
    <div class="doc-sub">Customer communication record — Order #{$orderNo}</div>
    <div class="doc-meta">Generated {$genAt} · Every message sent to the customer, with delivery &amp; open tracking and content preview</div>
  </td>
  <td class="brand-cell">{$logoTag}<br><strong style="color:#0f172a;">{$brandName}</strong><br>{$siteUrl}</td>
</tr></table>
<div style="margin:6px 0 10px;"><span class="status-pill" style="background:{$statusBg};">{$statusTxt}</span></div>
<h2>Customer &amp; order</h2>
<table class="kv">
  <tr><td class="k">Name</td><td class="v">{$custName}</td></tr>
  <tr><td class="k">Email address</td><td class="v">{$email}</td></tr>
  <tr><td class="k">Order number</td><td class="v">{$orderNo}</td></tr>
  <tr><td class="k">Order placed (UTC)</td><td class="v">{$created}</td></tr>
  <tr><td class="k">Billing address</td><td class="v">{$addr}</td></tr>
  <tr><td class="k">Emails sent</td><td class="v">{$totalEmails} total · {$deliveredCount} delivered</td></tr>
</table>
<h2>Email thread (chronological)</h2>
<p class="cap">Each card below is one email we sent, in the order it was sent, showing the subject, delivery &amp; open status and a readable preview of exactly what the customer received.</p>
{$threadHtml}
<div class="cert"><strong>Certification:</strong> this document is a true and unaltered extract of the email-delivery log (email_outbox table) held by the {$brandName} order-management system for order #{$orderNo}, produced on {$genAt}. Delivery and open timestamps are recorded automatically by the mail system and shown in UTC. Contact: {$coEmail}</div>
</body></html>
HTML;

    $dompdf = _pdf_dompdf();
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('letter', 'portrait');
    $dompdf->render();
    return $dompdf->output();
}

/**
 * Render the full "Proof of Fulfillment" (chargeback/dispute evidence) PDF for
 * an order and return the binary PDF string. Shared by dispute-evidence.php
 * (direct download) and order-docs.php (one-click all-documents ZIP).
 */
function mv_render_proof_of_fulfillment_pdf(array $o): string
{
    $pdo = db();
    $id  = (int)($o['id'] ?? 0);
    $e   = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $co  = function_exists('company_info') ? company_info() : ['name' => 'Maventech', 'email' => ''];
    $cur = (string)($o['currency'] ?? 'USD');
    $siteUrl = rtrim(function_exists('site_url') ? site_url() : '', '/');

    $items = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?'); $items->execute([$id]); $items = $items->fetchAll();
    $keys  = $pdo->prepare('SELECT * FROM license_keys WHERE order_id=?'); $keys->execute([$id]);  $keys  = $keys->fetchAll();
    $emails= $pdo->prepare('SELECT * FROM email_outbox WHERE order_id=? ORDER BY created_at ASC'); $emails->execute([$id]); $emails = $emails->fetchAll();

    $fx = !empty($o['forensics']) ? (json_decode((string)$o['forensics'], true) ?: []) : [];
    $ip = (string)($fx['ip'] ?? ($o['ip_address'] ?? ''));

    $trail = [];
    if ($ip !== '') {
        try {
            $t = $pdo->prepare("SELECT visited_at, page_url, device, browser, country FROM visitor_log
                                WHERE ip_hash = ? AND visited_at <= DATE_ADD(?, INTERVAL 1 HOUR)
                                ORDER BY visited_at DESC LIMIT 30");
            $t->execute([hash('sha256', $ip . '|maventech-salt'), (string)$o['created_at']]);
            $trail = array_reverse($t->fetchAll());
        } catch (Throwable $ex) { $trail = []; }
    }

    $timeline = json_decode((string)($o['timeline'] ?? 'null'), true) ?: [];
    $stmtName = !empty($o['card_statement_name']) ? (string)$o['card_statement_name']
        : (function_exists('statement_name_for') ? (string)statement_name_for((string)($o['payment_method'] ?? 'card')) : (string)($co['name'] ?? 'Maventech'));
    [$payLabel, $gateway] = _pdf_payment_method($o);
    $invoiceNo = function_exists('mv_invoice_number') ? mv_invoice_number($o) : (string)$o['order_number'];

    $kv = function (array $rows) use ($e): string {
        $h = '';
        foreach ($rows as $k => $v) {
            if ($v === '' || $v === null) continue;
            $h .= '<tr><td class="k">' . $e($k) . '</td><td class="v">' . $e($v) . '</td></tr>';
        }
        return $h !== '' ? '<table class="kv">' . $h . '</table>' : '<div class="none">No data recorded.</div>';
    };

    $sum = $kv([
        'Order number'          => $o['order_number'],
        'Invoice number'        => $invoiceNo,
        'Gateway transaction ID'=> $o['transaction_id'] ?: '—',
        'Payment method'        => $payLabel . ' · processed via ' . $gateway,
        'Card' => (!empty($o['card_brand']) ? $o['card_brand'] . ' ····' . ($o['card_last4'] ?? '') . (!empty($o['card_country']) ? ' · issued in ' . $o['card_country'] : '') : ''),
        'Statement descriptor'  => $stmtName,
        'Amount charged'        => _pdf_money((float)$o['total'], $cur) . ' ' . $cur,
        'Order placed (UTC)'    => $o['created_at'],
        'Order status'          => strtoupper((string)$o['status']) . (($o['payment_status'] ?? '') !== '' ? ' · payment ' . $o['payment_status'] : ''),
    ]);

    $addr = trim(implode(', ', array_filter([
        (string)$o['address'], (string)($o['address2'] ?? ''), (string)$o['city'],
        trim((string)$o['state'] . ' ' . (string)$o['zip']), (string)$o['country'],
    ])));
    $ident = $kv([
        'Name'            => trim((string)$o['first_name'] . ' ' . (string)$o['last_name']),
        'Email address'   => $o['email'],
        'Phone'           => $o['phone'] ?: '—',
        'Company'         => $o['company_name'] ?? '',
        'Billing address' => $addr,
    ]);

    $geoLine = trim(implode(', ', array_filter([(string)($fx['geo_city'] ?? ''), (string)($fx['geo_state'] ?? ''), (string)($fx['geo_zip'] ?? ''), (string)($fx['geo_country'] ?? '')])));
    $forensic = $kv([
        'IP address'        => $ip ?: '—',
        'IP geolocation'    => $geoLine,
        'Network / ISP'     => trim(implode(' · ', array_filter([(string)($fx['isp'] ?? ''), (string)($fx['org'] ?? '')]))),
        'Timezone'          => $fx['timezone'] ?? '',
        'Device'            => trim(($fx['device'] ?? '') . (!empty($fx['os']) ? ' · ' . $fx['os'] : '') . (!empty($fx['browser']) ? ' · ' . $fx['browser'] : '')),
        'Full user agent'   => $fx['user_agent'] ?? '',
        'Evidence captured' => $fx['captured_at'] ?? '',
    ]);
    $geoMatch = '';
    $cNames = ['us'=>'united states','usa'=>'united states','uk'=>'united kingdom','gb'=>'united kingdom','ca'=>'canada','au'=>'australia','de'=>'germany','fr'=>'france','in'=>'india','nz'=>'new zealand','ie'=>'ireland','es'=>'spain','it'=>'italy','nl'=>'netherlands','mx'=>'mexico','br'=>'brazil','sg'=>'singapore','ae'=>'united arab emirates'];
    $billCountry = strtolower(trim((string)$o['country'])); $billCountry = $cNames[$billCountry] ?? $billCountry;
    $geoCountry  = strtolower(trim((string)($fx['geo_country'] ?? ''))); $geoCountry = $cNames[$geoCountry] ?? $geoCountry;
    if ($billCountry !== '' && $geoCountry !== '') {
        $match = ($billCountry === $geoCountry) || str_contains($geoCountry, $billCountry) || str_contains($billCountry, $geoCountry);
        $geoMatch = $match
            ? '<div class="hl-good">&#10003; MATCH — the IP geolocation country (' . $e($fx['geo_country']) . ') matches the billing address country (' . $e($o['country']) . '), consistent with the genuine cardholder placing this order.</div>'
            : '<div class="hl-warn">IP geolocation country (' . $e($fx['geo_country']) . ') differs from the billing country (' . $e($o['country']) . ').</div>';
    }

    $trailHtml = '<div class="none">No pre-purchase page views recorded for this visitor.</div>';
    if ($trail) {
        $tr = '';
        foreach ($trail as $v) {
            $tr .= '<tr><td>' . $e($v['visited_at']) . '</td><td>' . $e(mb_strimwidth((string)$v['page_url'], 0, 70, '…')) . '</td><td>' . $e(trim($v['device'] . ' · ' . $v['browser'], ' ·')) . '</td><td>' . $e($v['country']) . '</td></tr>';
        }
        $trailHtml = '<table class="grid"><thead><tr><th>Time (UTC)</th><th>Page visited</th><th>Device</th><th>Geo</th></tr></thead><tbody>' . $tr . '</tbody></table>'
                   . '<p class="cap">' . count($trail) . ' page view(s) from the same IP leading up to the purchase — demonstrates deliberate shopping behaviour, not an automated or unwitting transaction.</p>';
    }

    $itemRows = ''; $subtotal = 0.0;
    foreach ($items as $it) {
        $qty = (int)($it['qty'] ?? $it['quantity'] ?? 1);
        $unit = (float)($it['price'] ?? $it['unit_price'] ?? 0);
        $amt = $qty * $unit; $subtotal += $amt;
        $itemRows .= '<tr><td>' . $e($it['name']) . '</td><td class="num">' . $qty . '</td><td class="num">' . _pdf_money($unit, $cur) . '</td><td class="num">' . _pdf_money($amt, $cur) . '</td></tr>';
    }
    $total = (float)($o['total'] ?? $subtotal);
    $discount = max(0, $subtotal - $total);
    $discountRow = $discount > 0.009 ? '<tr><td colspan="3" class="num k2">Discount</td><td class="num">&#8722;' . _pdf_money($discount, $cur) . '</td></tr>' : '';

    $keyRows = '';
    foreach ($keys as $k) {
        $keyRows .= '<tr><td class="mono">' . $e(mv_mask_license_key((string)$k['license_key'])) . '</td><td>' . $e($k['product_slug']) . '</td><td>' . $e(strtoupper((string)$k['status'])) . '</td><td>' . $e($k['assigned_at'] ?? '') . '</td></tr>';
    }
    $keysHtml = $keyRows !== ''
        ? '<table class="grid"><thead><tr><th>License key issued</th><th>Product</th><th>Status</th><th>Assigned (UTC)</th></tr></thead><tbody>' . $keyRows . '</tbody></table><div class="cap" style="font-size:7.5pt;color:#64748b;margin-top:3px;">License keys are intentionally masked (only the last 4 characters shown) to protect the delivered product. The full key was sent to the customer and is on record; it can be provided confidentially on request.</div>'
        : '<div class="none">No license keys recorded on this order.</div>';

    $emailRows = ''; $openProof = '';
    foreach ($emails as $em) {
        $st = strtoupper((string)$em['status']);
        $opened = !empty($em['opened_at']) ? $em['opened_at'] . ' (' . (int)$em['opened_count'] . '&#215;)' : '—';
        if (!empty($em['opened_at']) && $openProof === '' && ($em['template_code'] ?? '') === 'order_delivery') {
            $openProof = '<div class="hl-good">&#10003; OPEN-TRACKING PROOF — the customer OPENED the product delivery email on ' . $e($em['opened_at']) . ' UTC (' . (int)$em['opened_count'] . ' recorded open(s)), confirming receipt of the goods at the address they provided.</div>';
        }
        $emailRows .= '<tr><td>' . $e($em['created_at']) . '</td><td>' . $e(mb_strimwidth((string)$em['subject'], 0, 55, '…')) . '</td><td>' . $e($em['recipient']) . '</td><td>' . $e($st) . '</td><td>' . $opened . '</td></tr>';
    }
    $emailHtml = $emailRows !== ''
        ? '<table class="grid"><thead><tr><th>Queued (UTC)</th><th>Subject</th><th>Recipient</th><th>Status</th><th>Opened</th></tr></thead><tbody>' . $emailRows . '</tbody></table>'
        : '<div class="none">No emails recorded on this order.</div>';

    $tlRows = '';
    foreach ($timeline as $evt => $ts) {
        if (!is_string($ts)) continue;
        $tlRows .= '<tr><td class="k">' . $e(ucwords(str_replace('_', ' ', (string)$evt))) . '</td><td class="v">' . $e($ts) . '</td></tr>';
    }
    $tlHtml = $tlRows !== '' ? '<table class="kv">' . $tlRows . '</table>' : '';

    $threadHtml = mv_email_thread_proof_html($id);

    $logoPath = _pdf_company_logo_path();
    $logoTag = ($logoPath && file_exists($logoPath))
        ? '<img src="' . $logoPath . '" style="height:38px;width:auto;">'
        : '<div style="font-size:16px;font-weight:800;color:#0f172a;">' . $e($co['name'] ?? 'Maventech') . '</div>';
    $brandName = $e($co['name'] ?? 'Maventech');
    $genAt = gmdate('F j, Y H:i') . ' UTC';
    $orderNo = $e($o['order_number']);
    $totalS = _pdf_money($total, $cur);
    $subS = _pdf_money($subtotal, $cur);
    $curE = $e($cur);
    $coEmail = $e((string)($co['email'] ?? ''));

    $html = <<<HTML
<!doctype html><html><head><meta charset="utf-8"><style>
  @page { margin: 34px 40px; size: letter portrait; }
  body { font-family:'DejaVu Sans',Helvetica,Arial,sans-serif; font-size:9pt; color:#1f2937; }
  .doc-head { width:100%; border-collapse:collapse; margin-bottom:10px; }
  .doc-head td { vertical-align:top; }
  .doc-title { font-size:16pt; font-weight:800; color:#0f172a; letter-spacing:.5px; }
  .doc-sub { font-size:8pt; letter-spacing:2px; color:#b91c1c; font-weight:700; text-transform:uppercase; margin-top:2px; }
  .doc-meta { font-size:7.5pt; color:#64748b; margin-top:4px; line-height:1.4; }
  .brand-cell { text-align:right; font-size:7.5pt; color:#64748b; line-height:1.4; }
  h2 { font-size:10pt; font-weight:800; color:#0f172a; margin:14px 0 5px; padding:4px 8px; background:#f1f5f9; border-left:4px solid #0f172a; }
  table.kv { width:100%; border-collapse:collapse; margin-bottom:4px; }
  table.kv td { padding:3.5px 8px; font-size:8.5pt; border-bottom:1px solid #eef2f7; vertical-align:top; }
  table.kv td.k { color:#64748b; width:32%; }
  table.kv td.v { color:#0f172a; font-weight:700; }
  table.grid { width:100%; border-collapse:collapse; margin-bottom:4px; }
  table.grid th { background:#0f172a; color:#fff; text-align:left; font-size:7.5pt; text-transform:uppercase; letter-spacing:.4px; padding:4px 7px; }
  table.grid td { padding:3.5px 7px; font-size:8pt; border-bottom:1px solid #e2e8f0; }
  table.grid td.num, table.grid th.num { text-align:right; }
  .mono { font-family:'DejaVu Sans Mono',monospace; font-size:7.5pt; letter-spacing:.3px; }
  .num { text-align:right; }
  .k2 { color:#64748b; font-weight:600; }
  .totals td { font-weight:800; border-top:2px solid #0f172a; }
  .hl-good { background:#ecfdf5; border:1px solid #a7f3d0; border-left:4px solid #059669; border-radius:6px; padding:6px 10px; font-size:8.5pt; color:#065f46; font-weight:700; margin:5px 0; }
  .hl-warn { background:#fffbeb; border:1px solid #fde68a; border-left:4px solid #d97706; border-radius:6px; padding:6px 10px; font-size:8.5pt; color:#92400e; font-weight:700; margin:5px 0; }
  .none { font-size:8.5pt; color:#94a3b8; padding:4px 8px; }
  .cap { font-size:7.5pt; color:#64748b; margin:2px 0 0; }
  .terms { background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px 12px; font-size:8pt; color:#334155; line-height:1.55; }
  .cert { margin-top:12px; padding-top:8px; border-top:2px solid #0f172a; font-size:7.5pt; color:#475569; line-height:1.55; }
</style></head><body>
<table class="doc-head"><tr>
  <td>
    <div class="doc-title">PROOF OF FULFILLMENT</div>
    <div class="doc-sub">Transaction &amp; delivery record — Order #{$orderNo}</div>
    <div class="doc-meta">Generated {$genAt} · Documented record of purchase, digital delivery &amp; customer session</div>
  </td>
  <td class="brand-cell">{$logoTag}<br><strong style="color:#0f172a;">{$brandName}</strong><br>{$siteUrl}</td>
</tr></table>
<h2>1. Transaction summary</h2>
{$sum}
<h2>2. Customer-supplied identity &amp; billing details</h2>
{$ident}
<h2>3. Session &amp; device evidence (captured at checkout)</h2>
{$forensic}
{$geoMatch}
<h2>4. Pre-purchase browsing session</h2>
{$trailHtml}
<h2>5. Goods purchased (itemised invoice)</h2>
<table class="grid">
  <thead><tr><th>Description</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead>
  <tbody>{$itemRows}
    <tr><td colspan="3" class="num k2">Subtotal</td><td class="num">{$subS}</td></tr>
    {$discountRow}
    <tr class="totals"><td colspan="3" class="num">TOTAL CHARGED</td><td class="num">{$totalS} {$curE}</td></tr>
  </tbody>
</table>
<h2>6. Proof of digital delivery</h2>
{$keysHtml}
{$emailHtml}
{$openProof}
{$tlHtml}
<h2>7. Email thread &amp; content delivered to the customer</h2>
<p class="cap">Every message sent to the customer for this order, in order, with the exact subject, delivery &amp; open status, and a readable preview of the content they received.</p>
{$threadHtml}
<h2>8. Terms acceptance &amp; policies</h2>
<div class="terms">
  To complete checkout on {$siteUrl}, the customer must affirmatively submit the order form, which constitutes acceptance of the
  published Terms of Service and Refund Policy. The goods are <strong>digital software licenses delivered electronically</strong> to the
  email address supplied by the customer; delivery is fulfilled the moment the license key / activation link is issued (documented in
  section 6). A 30-day money-back guarantee and support channel (email + phone) were available to the customer at all times —
  no refund request or support contact preceded this dispute unless otherwise noted.
</div>
<div class="cert">
  <strong>Certification:</strong> the information in this document is a true and unaltered extract from the {$brandName}
  order-management system database (orders, license_keys, email_outbox, visitor_log tables) for order #{$orderNo},
  produced on {$genAt}. Timestamps are UTC. Contact: {$coEmail}
</div>
</body></html>
HTML;

    $dompdf = _pdf_dompdf();
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('letter', 'portrait');
    $dompdf->render();
    return $dompdf->output();
}

/**
 * Save both PDFs to /uploads/order-pdfs/{order_id}/ and return their
 * absolute paths so send_email() can attach them.  Idempotent — overwrites
 * existing files if called repeatedly for the same order.
 */
function generate_order_pdfs(array $order, array $items): array
{
    // Write the receipt + invoice to a TEMPORARY folder (not the persistent
    // /uploads tree) so the website's disk usage never grows as sales pile up.
    // These copies are only needed briefly to attach to the delivery email —
    // every download regenerates them on-demand from the order record, and the
    // full order data lives permanently in the database. Nothing is ever lost;
    // we simply don't keep redundant PDF files sitting around taking space.
    $dir = rtrim(sys_get_temp_dir(), "/\\") . '/mv-order-pdfs/' . (int)($order['id'] ?? 0);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $rcptPath = $dir . '/Receipt-'   . (string)($order['order_number'] ?? 'X') . '.pdf';
    $invPath  = $dir . '/Invoice-'   . (string)($order['order_number'] ?? 'X') . '.pdf';
    try {
        @file_put_contents($rcptPath, generate_receipt_pdf($order, $items));
    } catch (Throwable $e) { @error_log('[pdf receipt] ' . $e->getMessage()); $rcptPath = ''; }
    try {
        @file_put_contents($invPath,  generate_invoice_pdf($order, $items));
    } catch (Throwable $e) { @error_log('[pdf invoice] ' . $e->getMessage()); $invPath  = ''; }
    return array_values(array_filter([$rcptPath, $invPath]));
}
