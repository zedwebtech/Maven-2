<?php
// Installed-app (Home Screen / "bookmark app") navigation — storefront AND admin.
// A standalone web app has no browser chrome, so once you open any page there
// is no way back. This adds, only when running installed:
//   · a floating ‹ Back / ⌂ Home pill (storefront) or drives the admin top-bar
//     Back button when the page has one (#admBackBtn)
//   · "Home" = the page the app was opened on this session (admin.php or the store)
//   · links that leave the site open in a separate window so the phone offers
//     its own Done / back-to-app control instead of trapping you in Safari.
?>
<style>
  .mv-pwa-nav { position: fixed; left: 12px; bottom: calc(14px + env(safe-area-inset-bottom, 0px)); z-index: 5000;
    display: none; gap: 2px; padding: 4px; border-radius: 999px; background: rgba(15,23,42,.92); color: #fff;
    box-shadow: 0 10px 30px rgba(0,0,0,.35); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); }
  .mv-pwa-nav.on { display: inline-flex; }
  .mv-pwa-nav button { appearance: none; border: 0; background: transparent; color: #fff; font: 600 13px/1 system-ui, -apple-system, "Segoe UI", sans-serif;
    padding: 10px 14px; border-radius: 999px; display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
  .mv-pwa-nav button:active { background: rgba(255,255,255,.14); }
  .mv-pwa-nav button svg { width: 15px; height: 15px; }
  .mv-pwa-nav button + button { border-left: 1px solid rgba(255,255,255,.12); border-radius: 0 999px 999px 0; }
  html.mv-pwa-pill body { padding-bottom: calc(60px + env(safe-area-inset-bottom, 0px)); }
</style>
<script>
(function () {
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)
                || window.navigator.standalone === true || /[?&]standalone=1/.test(location.search);
  if (!standalone) return;
  document.documentElement.classList.add('mv-standalone');
  // Remember where this app session started — that is "Home".
  var start = null;
  try {
    start = sessionStorage.getItem('mv_pwa_start');
    if (!start) { start = location.href; sessionStorage.setItem('mv_pwa_start', start); }
  } catch (e) { start = location.pathname.indexOf('admin') !== -1 ? '/admin.php' : '/'; }
  var isAdminPage = /\/(admin[^\/]*\.php|order-view\.php|email-view\.php|inventory\.php|seo-audit\.php)/.test(location.pathname);
  var home = isAdminPage ? '/admin.php' : start;
  function atHome() { try { return location.href.split('#')[0] === start.split('#')[0]; } catch (e) { return false; } }
  function goBack() { if (history.length > 1) history.back(); else location.href = home; }
  function goHome() { location.href = home; }

  function mount() {
    var admBtn = document.getElementById('admBackBtn');
    if (admBtn) {
      // Admin top bar already has a Back control — just drive it.
      if (history.length > 1 || !atHome()) admBtn.classList.remove('d-none');
      admBtn.addEventListener('click', goBack);
      return;
    }
    if (history.length <= 1 && atHome()) return;        // nothing to go back to
    var bar = document.createElement('div');
    bar.className = 'mv-pwa-nav on';
    bar.setAttribute('data-testid', 'pwa-nav');
    bar.innerHTML =
      '<button type="button" data-testid="pwa-nav-back" aria-label="Back"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3 5 8l5 5"/></svg>Back</button>' +
      '<button type="button" data-testid="pwa-nav-home" aria-label="Home"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8.5 8 3l6 5.5M4 7.5V13h8V7.5"/></svg>' + (isAdminPage ? 'Admin' : 'Home') + '</button>';
    bar.children[0].addEventListener('click', goBack);
    bar.children[1].addEventListener('click', goHome);
    document.body.appendChild(bar);
    document.documentElement.classList.add('mv-pwa-pill');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();

  // Links that leave the site → separate window (phone shows Done / back-to-app).
  // Everything on this site stays inside the app, where Back works.
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a || a.hasAttribute('download')) return;
    var href = a.getAttribute('href') || '';
    if (href.charAt(0) === '#' || /^(javascript:|mailto:|tel:|sms:)/i.test(href)) return;
    var url; try { url = new URL(a.href, location.href); } catch (err) { return; }
    if (url.origin === location.origin) {
      // Keep same-site pages in the app even if the markup says _blank (PDFs / docs excluded).
      var isDoc = /(\.(pdf|zip|csv|xlsx?|docx?)$|\/(order-docs?|dispute-evidence|email-thread-proof|og-product|app-icon)\.php$)/i.test(url.pathname);
      if (a.target === '_blank' && !isDoc) a.target = '_self';
      return;
    }
    e.preventDefault();
    window.open(url.href, '_blank', 'noopener');
  }, true);
})();
</script>
