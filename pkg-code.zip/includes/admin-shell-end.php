  </main>
</div>
<script>
/* Mobile tables: label every cell with its column header so the CSS can
   stack rows into cards on phones, plus a persisted "Cards | Table" switch. */
(function(){
  var KEY = 'adm_mobile_table_mode';
  var mode = 'cards';
  try { mode = localStorage.getItem(KEY) === 'table' ? 'table' : 'cards'; } catch(e){}
  document.documentElement.setAttribute('data-tblmode', mode);

  function labelize(){
    var found = 0;
    document.querySelectorAll('.adm-content table').forEach(function(t){
      if (t.closest('.modal, .adm-chat-panel, .email-prev, [data-no-resp]')) return;
      var thead = t.tHead; if (!thead || !thead.rows.length) return;
      found++;
      if (t.__labeled) return;
      t.__labeled = true;
      t.classList.add('adm-resp');
      var hdr = thead.rows[thead.rows.length - 1];
      var labels = [];
      Array.prototype.forEach.call(hdr.cells, function(th){
        var txt = (th.textContent || '').replace(/\s+/g,' ').trim();
        var span = th.colSpan || 1;
        for (var k=0; k<span; k++) labels.push(k === 0 ? txt : '');
      });
      Array.prototype.forEach.call(t.tBodies, function(tb){
        Array.prototype.forEach.call(tb.rows, function(tr){
          var i = 0, cells = tr.cells, full = 0;
          Array.prototype.forEach.call(cells, function(td){
            var span = td.colSpan || 1;
            if (span > 1) { td.classList.add('adm-resp-full'); full++; i += span; return; }
            var l = labels[i] || ''; i++;
            var hasContent = (td.textContent || '').trim() !== '' || td.querySelector('input,button,a,img,select,i,span,code,form,div,audio,video');
            if (!hasContent) { td.classList.add('adm-resp-empty'); return; }
            if (l) td.setAttribute('data-label', l); else td.classList.add('adm-resp-nolabel');
          });
          if (cells.length === 1 && full === 1) tr.classList.add('adm-resp-fullrow');
        });
      });
      var wrap = t.closest('.tbl-e, .table-responsive');
      if (wrap && !wrap.querySelector(':scope > .adm-swipe-hint')) {
        var h = document.createElement('div'); h.className = 'adm-swipe-hint';
        h.innerHTML = '<i class="bi bi-arrows-expand" style="transform:rotate(90deg);display:inline-block;"></i> Swipe sideways to see every column';
        wrap.appendChild(h);
      }
    });
    return found;
  }

  function mountSwitch(){
    var main = document.querySelector('.adm-content');
    if (!main || document.getElementById('admTblModeSwitch')) return;
    var sw = document.createElement('div');
    sw.className = 'adm-tblmode-switch'; sw.id = 'admTblModeSwitch'; sw.setAttribute('data-testid','adm-table-mode-switch');
    sw.innerHTML = '<span class="lbl">Lists</span><span class="seg">'
      + '<button type="button" data-mode="cards" data-testid="adm-table-mode-cards"><i class="bi bi-view-stacked"></i> Cards</button>'
      + '<button type="button" data-mode="table" data-testid="adm-table-mode-table"><i class="bi bi-table"></i> Table</button></span>';
    main.insertBefore(sw, main.firstChild);
    function paint(){ sw.querySelectorAll('button').forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-mode') === mode); }); }
    sw.addEventListener('click', function(e){
      var b = e.target.closest('button[data-mode]'); if (!b) return;
      mode = b.getAttribute('data-mode');
      try { localStorage.setItem(KEY, mode); } catch(err){}
      document.documentElement.setAttribute('data-tblmode', mode);
      paint();
    });
    paint();
  }

  function run(){
    if (labelize() > 0 && window.matchMedia('(max-width: 767.98px)').matches) mountSwitch();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run); else run();
  // Rows injected later (AJAX reloads, pagination) get labelled too.
  var pending = null;
  new MutationObserver(function(){ if (pending) return; pending = setTimeout(function(){ pending = null; labelize(); }, 150); })
    .observe(document.body, { childList:true, subtree:true });
})();
</script>
<script src="/assets/vendor/bootstrap.bundle.min.js?v=532"></script>

<!-- Flatpickr — calendar + time-picker UI for every <input type="date">
     and <input type="datetime-local"> in the admin.  Native browser date
     widgets are inconsistent across OSes (and ugly in dark mode), so we
     enhance them globally with one tiny library (~25 KB minified). -->
<link rel="stylesheet" href="/assets/vendor/flatpickr.min.css?v=4613">
<link rel="stylesheet" href="/assets/vendor/flatpickr-airbnb.css?v=4613">
<script src="/assets/vendor/flatpickr.min.js?v=4613"></script>
<script>
(function () {
  if (typeof flatpickr === 'undefined') return;
  // Auto-enhance every date input across admin tabs.  We use the
  // original HTML5 input attributes (min/max/value) so existing forms
  // submit the same ISO strings — flatpickr is purely a visual upgrade.
  function enhance(scope) {
    (scope || document).querySelectorAll('input[type="date"]:not(.fp-enhanced), input[type="datetime-local"]:not(.fp-enhanced)').forEach(function (el) {
      var withTime = el.type === 'datetime-local';
      el.classList.add('fp-enhanced');
      try {
        flatpickr(el, {
          enableTime: withTime,
          time_24hr: true,
          dateFormat: withTime ? 'Y-m-d\\TH:i' : 'Y-m-d',
          altInput: true,
          altFormat: withTime ? 'D, M j Y · H:i' : 'D, M j Y',
          allowInput: true,
          // Range pairing: any pair of inputs where one is name="from"/"starts_at"
          // and the next is name="to"/"ends_at" gets its min set from the start.
          onChange: function (sel, dStr, fp) {
            if (!sel.length) return;
            var name = el.getAttribute('name') || '';
            if (name === 'starts_at' || name.endsWith('_from') || name === 'vh_from') {
              var partner = document.querySelector('input[name="ends_at"], input[name="' + name.replace('_from', '_to') + '"], input[name="vh_to"]');
              if (partner && partner._flatpickr) partner._flatpickr.set('minDate', sel[0]);
            }
          },
          disableMobile: true,   // use flatpickr even on touch devices
        });
      } catch (e) { console.warn('flatpickr init failed', e); }
    });
  }
  enhance(document);
  // Catch any inputs that get inserted dynamically (modals, drawers).
  var mo = new MutationObserver(function (muts) { muts.forEach(function (m) { m.addedNodes.forEach(function (n) { if (n.nodeType === 1) enhance(n); }); }); });
  mo.observe(document.body, { childList: true, subtree: true });
})();
</script>

<script>
// Instant theme toggle — no page redirect, persists via cookie for 1 year
// AND fires a fire-and-forget POST to /ajax/user-theme.php so the choice
// is also saved to the logged-in user's row.  Multi-device admins toggle
// once and the preference follows them everywhere.
function toggleAdmTheme(ev){
  if(ev) ev.preventDefault();
  var html = document.documentElement;
  var cur  = html.getAttribute('data-bs-theme') || 'light';
  var next = cur === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-bs-theme', next);
  document.cookie = 'adm_mode=' + next + '; path=/; max-age=' + (365*86400) + '; SameSite=Lax';
  var icon = document.getElementById('admThemeIcon');
  if (icon) icon.className = 'bi ' + (next === 'dark' ? 'bi-sun' : 'bi-moon-stars');
  // Persist server-side for the logged-in user (silently — UI doesn't
  // wait for the response and falls back to cookie if the call fails).
  try {
    fetch('ajax/user-theme.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ theme: next })
    }).catch(function(){ /* offline / 5xx — cookie still works */ });
  } catch (_) {}
}
</script>
</body>
</html>
