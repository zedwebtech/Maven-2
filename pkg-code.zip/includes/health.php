<?php
/**
 * System health checks (Admin → API Management → "System health").
 *   mv_health_nmi_verify($mode)  — proves the saved NMI security key works
 *                                  (Query API, read-only: no card, no $0 auth,
 *                                  nothing appears in the gateway's reports)
 *   mv_health_run()              — Domain & Feed health: public URLs, feed,
 *                                  sitemap, email queue, scheduler, gateway
 *                                  config, PHP/OPcache, disk, DB.
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/email.php';
require_once __DIR__ . '/autocron.php';

/** GET a URL (follows redirects) → [http_code, body, content_type, ms, final_url, error]. */
function mv_health_get(string $url, int $timeout = 12): array
{
    $t0 = microtime(true);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'MaventechHealth/1.0 (+admin self-check)',
        CURLOPT_HTTPHEADER => ['Accept: */*'],
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $type = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $err = curl_error($ch);
    curl_close($ch);
    return [$code, $body, $type, (int)round((microtime(true) - $t0) * 1000), $final, $err];
}

/** The host the admin is actually using right now (what "live" means to them). */
function mv_health_base(): string
{
    // Behind a proxy/CDN the public name arrives in X-Forwarded-Host.
    $host = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? '')));
    if ($host !== '' && strpos($host, ',') !== false) $host = trim(explode(',', $host)[0]);
    if ($host === '') $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($host === '') return rtrim(email_public_base(), '/');
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
        || stripos((string)($_SERVER['HTTP_CF_VISITOR'] ?? ''), 'https') !== false;
    return ($https ? 'https' : 'http') . '://' . $host;
}

/**
 * Verify the saved NMI security key for $mode ('live'|'test') via the Query
 * API. Returns ['ok'=>bool, 'status'=>ok|fail|warn, 'message'=>..., 'facts'=>[...]].
 */
function mv_health_nmi_verify(string $mode): array
{
    $mode = $mode === 'test' ? 'test' : 'live';
    $key  = trim((string)setting_get('gw_nmi_security_key_' . $mode, ''));
    if ($key === '') return ['ok' => false, 'status' => 'fail', 'message' => 'No ' . $mode . ' security key is saved yet.', 'facts' => []];
    $endpoint = trim((string)setting_get('gw_nmi_endpoint', '')) ?: 'https://secure.nmi.com/api/transact.php';
    $queryUrl = preg_replace('~/api/transact\.php$~', '/api/query.php', $endpoint) ?: 'https://secure.nmi.com/api/query.php';
    if ($queryUrl === $endpoint) $queryUrl = 'https://secure.nmi.com/api/query.php';

    $t0 = microtime(true);
    $ch = curl_init($queryUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => http_build_query(['security_key' => $key, 'start_date' => date('Ymd', strtotime('-30 days')) . '000000', 'result_limit' => 200]),
        CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $xml = (string)curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    $ms = (int)round((microtime(true) - $t0) * 1000);

    $facts = ['Gateway endpoint' => parse_url($queryUrl, PHP_URL_HOST), 'Response time' => $ms . ' ms', 'Key (masked)' => substr($key, 0, 4) . '…' . substr($key, -4)];
    if ($err !== '' || $http === 0) return ['ok' => false, 'status' => 'fail', 'message' => 'Could not reach the gateway: ' . ($err ?: 'no response') . '. Check outbound HTTPS / firewall on the server.', 'facts' => $facts];
    if (stripos($xml, 'Invalid Security Key') !== false || stripos($xml, 'invalid security') !== false || stripos($xml, '<error_response>') !== false) {
        preg_match('~<error_response>(.*?)</error_response>~is', $xml, $m);
        return ['ok' => false, 'status' => 'fail', 'message' => 'The gateway REJECTED this key: ' . trim(strip_tags($m[1] ?? 'Invalid Security Key')) . '. Paste the API security key from your NMI/PaymentCloud portal (Settings → Security Keys).', 'facts' => $facts];
    }
    if (stripos($xml, '<nm_response') === false) {
        return ['ok' => false, 'status' => 'warn', 'message' => 'Unexpected answer from the gateway (HTTP ' . $http . '). The key may still work for charges — retry in a minute.', 'facts' => $facts + ['HTTP' => $http]];
    }
    $count = 0; $approved = 0; $declined = 0; $last = ''; $lastType = ''; $lastCond = ''; $lastAmt = '';
    try {
        $doc = @simplexml_load_string($xml);
        if ($doc && isset($doc->transaction)) {
            foreach ($doc->transaction as $tx) {
                $count++;
                $cond = strtolower((string)($tx->condition ?? ''));
                if (in_array($cond, ['complete', 'pendingsettlement', 'pending', 'settled'], true)) $approved++;
                if (in_array($cond, ['failed', 'canceled', 'cancelled', 'abandoned'], true)) $declined++;
                foreach ($tx->action as $a) {
                    $d = (string)($a->date ?? '');
                    if ($d !== '' && $d > $last) { $last = $d; $lastType = (string)$a->action_type; $lastCond = $cond; $lastAmt = (string)$a->amount; }
                }
            }
        }
    } catch (Throwable $e) {}
    $facts['Transactions (30 days)'] = (string)$count;
    $facts['Approved / declined'] = $approved . ' / ' . $declined;
    if ($last !== '' && preg_match('/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/', $last, $p)) {
        $facts['Most recent'] = "{$p[1]}-{$p[2]}-{$p[3]} {$p[4]}:{$p[5]} · " . strtoupper($lastType) . ' $' . $lastAmt . ' · ' . $lastCond;
    }
    $facts['Mode in use'] = strtoupper((string)setting_get('gw_mode', 'test')) . (strtolower((string)setting_get('gw_mode', 'test')) === $mode ? ' (this key)' : ' (other key is active)');
    $pub = function_exists('mv_nmi_public_key') ? mv_nmi_public_key() : '';
    $facts['Collect.js public key'] = $pub !== '' ? 'saved' : 'not saved';
    return ['ok' => true, 'status' => 'ok', 'message' => 'Key accepted by the gateway — the account answered in ' . $ms . ' ms.' . ($count === 0 ? ' No transactions in the last 30 days.' : ''), 'facts' => $facts];
}

/** Run every Domain & Feed health check. */
function mv_health_run(): array
{
    if (function_exists('mv_sync_public_domain')) mv_sync_public_domain();
    $base = mv_health_base();
    $host = (string)parse_url($base, PHP_URL_HOST);
    $checks = [];
    $add = function (string $group, string $label, string $status, string $detail, string $url = '') use (&$checks) {
        $checks[] = ['group' => $group, 'label' => $label, 'status' => $status, 'detail' => $detail, 'url' => $url];
    };
    $fmtBytes = fn(float $b) => $b >= 1073741824 ? number_format($b / 1073741824, 2) . ' GB' : ($b >= 1048576 ? number_format($b / 1048576, 1) . ' MB' : number_format($b / 1024) . ' KB');

    // ---- Domain ----
    [$c, $b, $ct, $ms, $fin] = mv_health_get($base . '/');
    $add('Domain', 'Homepage', $c === 200 ? ($ms > 3000 ? 'warn' : 'ok') : 'fail',
        $c === 200 ? "HTTP 200 in {$ms} ms" . (stripos($b, '<title') !== false ? '' : ' — no <title> found') : "HTTP {$c}" . ($fin && $fin !== $base . '/' ? " → {$fin}" : ''), $base . '/');
    $add('Domain', 'HTTPS', str_starts_with($base, 'https://') ? 'ok' : 'warn', str_starts_with($base, 'https://') ? 'Secure connection in use' : 'You are on plain HTTP — enable SSL in cPanel', '');
    if (!preg_match('/localhost|127\.0\.0\.1/', $host)) {
        [$c2, , , , $fin2] = mv_health_get('http://' . $host . '/', 8);
        $add('Domain', 'HTTP → HTTPS redirect', str_starts_with((string)$fin2, 'https://') ? 'ok' : 'warn', str_starts_with((string)$fin2, 'https://') ? 'Plain http:// redirects to https://' : 'http:// does not redirect to https:// (HTTP ' . $c2 . ')', 'http://' . $host . '/');
    }
    $emailHost = (string)parse_url(rtrim(email_public_base(), '/'), PHP_URL_HOST);
    $savedHost = strtolower((string)parse_url((string)setting_get('site_domain_url', ''), PHP_URL_HOST));
    $sameHost  = fn(string $a, string $b) => strcasecmp(preg_replace('/^www\./i', '', $a), preg_replace('/^www\./i', '', $b)) === 0;
    $liveOk = $sameHost($emailHost, $host);
    $cronOk = $savedHost !== '' && $sameHost($savedHost, $host);
    if (mv_is_nonpublic_host($host)) {
        // Preview / dev address: emails must never link here — they deliberately
        // keep pointing at the saved live domain. Nothing for the admin to do.
        $add('Domain', 'Domain used in emails', 'ok',
            mv_is_nonpublic_host($emailHost)
                ? "You are viewing a preview/development address ({$host}). Emails never link to it — the real domain is picked up automatically the first time the site is opened on it. Nothing to set."
                : "You are viewing a preview/development address ({$host}), so emails deliberately keep linking to your live domain {$emailHost}. On the live site this follows the domain automatically — nothing to set.", '');
    } else
    $add('Domain', 'Domain used in emails', $liveOk && $cronOk ? 'ok' : ($liveOk ? 'warn' : 'fail'),
        $liveOk && $cronOk ? "Links in emails point to {$host} — auto-detected from the domain this site runs on (saved for background/cron emails too)"
        : (!$liveOk ? "Emails link to {$emailHost} but you are on {$host}"
            : "Emails sent while you browse use {$host}, but background (cron) emails would use " . ($savedHost !== '' ? $savedHost : 'the built-in default') . " — the saved domain could not be updated, check that the settings table is writable"), '');
    [$c, $b, , $ms] = mv_health_get($base . '/robots.txt');
    $add('Domain', 'robots.txt', $c === 200 ? (stripos($b, 'sitemap:') !== false ? 'ok' : 'warn') : 'fail', $c === 200 ? (stripos($b, 'sitemap:') !== false ? 'Served, lists the sitemap' : 'Served but no Sitemap: line') : "HTTP {$c}", $base . '/robots.txt');
    [$c, $b, , $ms] = mv_health_get($base . '/sitemap.xml');
    $n = $c === 200 ? preg_match_all('~<url>~i', $b) : 0;
    $add('Domain', 'sitemap.xml', $c === 200 && $n > 0 ? 'ok' : 'fail', $c === 200 ? ($n > 0 ? "{$n} URLs listed ({$ms} ms)" : 'Served but contains no <url> entries') : "HTTP {$c}", $base . '/sitemap.xml');
    [$c, $b, $ct] = mv_health_get($base . '/manifest.webmanifest');
    $mj = $c === 200 ? json_decode($b, true) : null;
    $add('Domain', 'PWA manifest', is_array($mj) && !empty($mj['name']) ? 'ok' : 'warn', is_array($mj) ? ('“' . ($mj['name'] ?? '?') . '” · ' . count($mj['icons'] ?? []) . ' icons') : "HTTP {$c}", $base . '/manifest.webmanifest');

    // ---- Feed ----
    [$c, $b, $ct, $ms] = mv_health_get($base . '/merchant-feed.xml', 20);
    $items = 0; $bad = []; $sample = '';
    if ($c === 200 && stripos($b, '<item') !== false) {
        $doc = @simplexml_load_string($b);
        if ($doc) {
            $doc->registerXPathNamespace('g', 'http://base.google.com/ns/1.0');
            $its = $doc->xpath('//item') ?: [];
            $items = count($its);
            foreach (array_slice($its, 0, 50) as $it) {
                $g = $it->children('http://base.google.com/ns/1.0');
                $id = (string)($g->id ?? ''); $price = (string)($g->price ?? ''); $avail = (string)($g->availability ?? '');
                $link = trim((string)($g->link ?? '')) ?: trim((string)($it->link ?? '')); $img = (string)($g->image_link ?? '');
                if ($sample === '') $sample = trim((string)($g->title ?? $it->title));
                if ($id === '' || $price === '' || $avail === '' || !str_starts_with($link, 'https://') || $img === '') $bad[] = $id ?: 'item';
                elseif (strcasecmp((string)parse_url($link, PHP_URL_HOST), $host) !== 0) $bad[] = $id . ' (link → ' . parse_url($link, PHP_URL_HOST) . ')';
            }
        }
    }
    $add('Feed', 'Google Merchant feed', $c === 200 && $items > 0 ? ($bad ? 'warn' : 'ok') : 'fail',
        $c === 200 ? ($items > 0 ? "{$items} products · {$ms} ms" . ($bad ? ' · ' . count($bad) . ' item(s) missing id/price/availability/image or linking elsewhere: ' . implode(', ', array_slice($bad, 0, 3)) : ' · every item has id, price, availability, image and an https link on this domain') : 'Served but contains no <item>') : "HTTP {$c}", $base . '/merchant-feed.xml');
    try {
        $pdo = db();
        $active = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1 AND archived=0")->fetchColumn();
        $noImg = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1 AND archived=0 AND (image IS NULL OR image='')")->fetchColumn();
        $add('Feed', 'Products in catalogue', $noImg > 0 ? 'warn' : 'ok', "{$active} active" . ($noImg > 0 ? " · {$noImg} without an image" : ''), '');
    } catch (Throwable $e) {}

    // ---- Email ----
    try {
        $pdo = db();
        $q = (int)$pdo->query("SELECT COUNT(*) FROM email_outbox WHERE status IN ('queued','retrying')")->fetchColumn();
        $oldest = $pdo->query("SELECT TIMESTAMPDIFF(MINUTE, MIN(created_at), NOW()) FROM email_outbox WHERE status IN ('queued','retrying')")->fetchColumn();
        $failed24 = (int)$pdo->query("SELECT COUNT(*) FROM email_outbox WHERE status IN ('failed','bounced') AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetchColumn();
        $sent24 = (int)$pdo->query("SELECT COUNT(*) FROM email_outbox WHERE status='sent' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetchColumn();
        $add('Email', 'Email queue', $q === 0 ? 'ok' : ((int)$oldest > 30 ? 'fail' : 'warn'), $q === 0 ? "Empty · {$sent24} sent in 24 h" : "{$q} waiting (oldest {$oldest} min) · {$sent24} sent in 24 h", '');
        $add('Email', 'Delivery failures (24 h)', $failed24 === 0 ? 'ok' : ($failed24 > 5 ? 'fail' : 'warn'), $failed24 === 0 ? 'None' : "{$failed24} failed/bounced — see Email Activity", '');
    } catch (Throwable $e) {}
    $smtpOn = setting_get('smtp_enabled', '0') === '1' && trim((string)setting_get('smtp_host', '')) !== '' && trim((string)setting_get('smtp_username', '')) !== '';
    $add('Email', 'SMTP server', $smtpOn ? 'ok' : 'fail', $smtpOn ? setting_get('smtp_host', '') . ' · ' . setting_get('smtp_username', '') . (trim((string)setting_get('smtp_cc', '')) !== '' ? ' · CC → ' . setting_get('smtp_cc', '') : '') : 'Not configured — emails cannot be sent', '');
    $st = mv_autocron_status();
    $age = $st['last_run'] ? (int)round((time() - strtotime($st['last_run'])) / 60) : null;
    $add('Email', 'Automatic scheduler', $age === null ? 'warn' : ($age <= 15 ? 'ok' : ($age <= 120 ? 'warn' : 'fail')),
        $age === null ? 'Has not run yet (runs on the first page view after upload)' : "Last run {$age} min ago · {$st['followups_pending']} follow-ups scheduled" . ($st['cron_seen'] ? ' · cron.php also seen' : ''), '');
    [$c, , $ct] = mv_health_get($base . '/track-open.php?t=healthcheck', 8);
    $add('Email', 'Open-tracking pixel', $c === 200 && stripos($ct, 'image') !== false ? 'ok' : 'warn', $c === 200 ? "Serves {$ct}" : "HTTP {$c}", '');

    // ---- Payments ----
    $mode = strtolower((string)setting_get('gw_mode', 'test'));
    $prov = strtolower((string)setting_get('gw_card_provider', 'stripe'));
    $keyOk = function_exists('card_provider_configured') ? card_provider_configured($prov, $mode) : trim((string)setting_get('gw_nmi_security_key_' . $mode, '')) !== '';
    $add('Payments', 'Card gateway', $mode === 'live' ? ($keyOk ? 'ok' : 'fail') : 'warn', strtoupper($prov) . ' · ' . strtoupper($mode) . ' mode · ' . ($keyOk ? 'credentials saved' : 'NO credentials for this mode') . ' — use "Verify NMI key" for a live check', '');
    $pp = setting_get('gw_paypal_status', 'inactive') === 'active';
    $add('Payments', 'PayPal', $pp ? 'ok' : 'warn', $pp ? 'Enabled' : 'Disabled', '');
    $cardName = trim((string)setting_get('gw_card_merchant_name', ''));
    $add('Payments', 'Statement / partner name', $cardName !== '' ? 'ok' : 'warn', $cardName !== '' ? "Customers are told: {$cardName}" : 'Not set — Billing Notes → Card statement name', '');

    // ---- Server ----
    try { $pdo = db(); $pdo->query('SELECT 1'); $tables = (int)$pdo->query('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()')->fetchColumn(); $add('Server', 'Database', 'ok', "Connected · {$tables} tables", ''); }
    catch (Throwable $e) { $add('Server', 'Database', 'fail', 'Connection failed: ' . $e->getMessage(), ''); }
    $add('Server', 'PHP', version_compare(PHP_VERSION, '8.1', '>=') ? 'ok' : 'fail', 'PHP ' . PHP_VERSION, '');
    $missing = array_filter(['pdo_mysql', 'curl', 'mbstring', 'openssl', 'json', 'dom', 'gd'], fn($e) => !extension_loaded($e));
    $add('Server', 'PHP extensions', $missing ? 'fail' : 'ok', $missing ? 'Missing: ' . implode(', ', $missing) : 'pdo_mysql, curl, mbstring, openssl, json, dom, gd all loaded', '');
    if (function_exists('opcache_get_status')) {
        $oc = @opcache_get_status(false);
        $add('Server', 'OPcache', !empty($oc['opcache_enabled']) ? 'ok' : 'warn', !empty($oc['opcache_enabled']) ? 'Enabled · ' . number_format((float)($oc['opcache_statistics']['opcache_hit_rate'] ?? 0), 1) . '% hit rate · remember /opcache-reset.php after every upload' : 'Disabled', '');
    }
    $up = __DIR__ . '/../uploads';
    $free = @disk_free_space($up); $tot = @disk_total_space($up);
    $pdfBytes = 0; $pdfCount = 0;
    $pdfDir = $up . '/order-pdfs';
    if (is_dir($pdfDir)) { foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($pdfDir, FilesystemIterator::SKIP_DOTS)) as $f) { if ($f->isFile()) { $pdfBytes += $f->getSize(); $pdfCount++; } } }
    $add('Server', 'Disk space', $free !== false && $tot ? ($free / $tot < 0.1 ? 'fail' : ($free / $tot < 0.25 ? 'warn' : 'ok')) : 'warn', $free !== false && $tot ? $fmtBytes((float)$free) . ' free of ' . $fmtBytes((float)$tot) . " · cached order PDFs: {$pdfCount} files, " . $fmtBytes((float)$pdfBytes) : 'Could not read disk usage', '');
    $add('Server', 'Uploads writable', is_writable($up) ? 'ok' : 'fail', is_writable($up) ? '/uploads is writable' : '/uploads is NOT writable — PDFs and product images will fail', '');

    $summary = ['ok' => 0, 'warn' => 0, 'fail' => 0];
    foreach ($checks as $ch) $summary[$ch['status']] = ($summary[$ch['status']] ?? 0) + 1;
    $result = ['ran_at' => date('Y-m-d H:i:s'), 'base' => $base, 'summary' => $summary, 'checks' => $checks];
    try { setting_set('health_last_json', json_encode($result)); } catch (Throwable $e) {}
    return $result;
}

function mv_health_last(): ?array
{
    $j = json_decode((string)setting_get('health_last_json', ''), true);
    return is_array($j) && !empty($j['checks']) ? $j : null;
}
