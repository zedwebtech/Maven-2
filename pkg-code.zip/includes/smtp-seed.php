<?php
/**
 * includes/smtp-seed.php
 * ---------------------------------------------------------------------------
 * Baked-in Gmail SMTP mail-server config so a fresh deploy on ANY host
 * (cPanel / shared hosting / new pod) sends transactional email out of the
 * box with ZERO re-entry — same self-heal pattern as gateways + marketing.
 *
 * Account: adsmaventechsoftware@gmail.com (Gmail App Password).
 *
 * mv_seed_smtp() is SEED-IF-EMPTY (unless forced) and version-guarded, so
 * anything the admin later edits in Admin → SMTP / Mail Server is ALWAYS
 * preserved across restarts and re-deploys. The password is stored base64
 * in `smtp_password_b64` exactly as smtp_config() expects.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!defined('MV_SMTP_SEED_VERSION')) define('MV_SMTP_SEED_VERSION', '1');

function mv_smtp_seed_values(): array {
    // Gmail App Password — spaces are display-only, strip them for auth.
    $gmailPass = preg_replace('/\s+/', '', 'bnic nuol akbf islu');
    return [
        'smtp_enabled'       => '1',
        'smtp_host'          => 'smtp.gmail.com',
        'smtp_port'          => '587',
        'smtp_username'      => 'adsmaventechsoftware@gmail.com',
        'smtp_password_b64'  => base64_encode($gmailPass),
        'smtp_encryption'    => 'tls',
        // Gmail rewrites the From header to the authenticated mailbox, so the
        // From address must match the SMTP username to avoid 5.7.x rejections.
        'smtp_from_email'    => 'adsmaventechsoftware@gmail.com',
        'smtp_from_name'     => trim((string)setting_get('company_name', '')) ?: 'Maventech Software',
        'smtp_reply_to'      => trim((string)setting_get('company_email', '')) ?: 'services@maventechsoftware.com',
        'smtp_verify_peer'   => '1',
    ];
}

/** Seed Gmail SMTP config. $force overwrites; otherwise seed-if-empty. */
function mv_seed_smtp(bool $force = false): array {
    $log = [];
    if (!$force && (string)setting_get('smtp_seed_v', '') === MV_SMTP_SEED_VERSION) {
        return ['skipped: already seeded'];
    }
    foreach (mv_smtp_seed_values() as $k => $v) {
        $cur = trim((string)setting_get($k, ''));
        if ($force || $cur === '') { setting_set($k, $v); $log[] = 'SET   ' . $k; }
        else                       { $log[] = 'KEEP  ' . $k; }
    }
    setting_set('smtp_seed_v', MV_SMTP_SEED_VERSION);
    return $log;
}

/** Silent, guarded web auto-heal. Never throws. */
function mv_autoheal_smtp(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting_get('smtp_seed_v', '') !== MV_SMTP_SEED_VERSION) {
            mv_seed_smtp(false);
        }
    } catch (Throwable $e) { /* DB not ready — retry next request */ }
}
