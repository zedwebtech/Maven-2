<?php
/**
 * PHP-native product-image generator.
 *
 * Generates a product card image via the Emergent images endpoint
 * (gpt-image-1) using plain cURL + GD — NO Python, NO emergentintegrations.
 * This means "Regenerate image with AI" works on ANY host (cPanel/Plesk
 * shared hosting included), not only inside the Emergent pod.
 */

if (!function_exists('mv_generate_product_image')) {

/** Resolve [apiKey, baseUrl] for the images endpoint. */
function mv_product_image_creds(): array
{
    // 1) SEO resolver (honours admin-selected provider + custom base URL).
    if (function_exists('_seo_resolve_llm_credentials')) {
        [$k, $b] = _seo_resolve_llm_credentials();
        if (trim((string)$k) !== '') return [trim((string)$k), $b ?: 'https://integrations.emergentagent.com/llm/v1'];
    }
    // 2) DB setting, then env vars.
    $k = (string)(function_exists('setting_get') ? setting_get('ai_blogger_llm_key', '') : '');
    if ($k === '') $k = (string)(getenv('EMERGENT_LLM_KEY') ?: (getenv('OPENAI_API_KEY') ?: ''));
    // 3) Read the .env file directly (cPanel/shared hosting without env vars).
    if ($k === '') {
        $envPath = __DIR__ . '/../.env';
        if (is_file($envPath)) {
            foreach (file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#') continue;
                if (preg_match('/^(EMERGENT_LLM_KEY|OPENAI_API_KEY)\s*=\s*(.+)$/', $line, $m)) {
                    $k = trim($m[2], "\"' \t\r\n");
                    if ($k !== '') break;
                }
            }
        }
    }
    // 4) The key config.php already resolved into the OPENAI_API_KEY constant.
    if ($k === '' && defined('OPENAI_API_KEY')) $k = (string)OPENAI_API_KEY;
    $k = trim($k);

    // Base URL: an explicit OpenAI-compatible base (e.g. api.openai.com/v1 for a
    // direct OpenAI key) if config set one, otherwise the Emergent LLM gateway.
    $base = (defined('OPENAI_BASE_URL') && OPENAI_BASE_URL !== '') ? OPENAI_BASE_URL : 'https://integrations.emergentagent.com/llm/v1';
    return [$k, $base];
}

/**
 * Product-specific visual vocabulary shared by every generator (main image,
 * Google-Ads image, gallery). Derived from name/category/apps/platform so the
 * picture is unmistakably THIS product — never a random laptop — while staying
 * free of readable text, logos and trademarks (Google Ads image-asset policy).
 *   emblem : glossy 3D "product emblem" composition for the storefront main image
 *   screen : what the device screen shows in the device/lifestyle scenes
 *   device : the device used in scenes (silver laptop = Mac, graphite = Windows)
 */
function mv_product_visual(array $p): array
{
    $name  = strtolower((string)($p['name'] ?? ''));
    $cat   = strtolower((string)($p['category'] ?? ''));
    $plat  = strtolower((string)($p['platform'] ?? ''));
    $apps  = array_values(array_filter(array_map('trim', explode(',', strtolower((string)($p['apps'] ?? ''))))));
    $isMac = ($plat === 'mac' || strpos($name, 'mac') !== false);
    $hay   = $name . ' ' . $cat;

    $device = $isMac
        ? 'a slim silver aluminium laptop with thin dark bezels (premium Mac-style notebook)'
        : 'a slim dark-graphite premium Windows-style laptop with thin bezels';

    $tileMap = [
        'word'       => 'a royal-blue rounded 3D tile with a bold white letter W',
        'excel'      => 'a rich green rounded 3D tile with a bold white letter X',
        'powerpoint' => 'an orange-red rounded 3D tile with a bold white letter P',
        'outlook'    => 'a sky-blue rounded 3D tile with a bold white letter O',
        'access'     => 'a magenta-red rounded 3D tile with a bold white letter A',
    ];
    $screenMap = [
        'word'       => 'a blue document page',
        'excel'      => 'a green spreadsheet grid',
        'powerpoint' => 'an orange presentation slide',
        'outlook'    => 'a light-blue email inbox panel',
        'access'     => 'a magenta database table',
    ];

    if (preg_match('/anti\s*virus|security|defender|bitdefender|norton|mcafee|kaspersky|eset|avast|vpn/', $hay)) {
        $shieldColor = (strpos($hay, 'mcafee') !== false) ? 'bright red' : 'deep crimson red';
        $devices = $device;
        if (preg_match('/3\s*mac|3\s*devices|3\s*pc/', $name)) $devices = 'three slim ' . ($isMac ? 'silver aluminium Mac-style laptops' : 'dark-graphite Windows-style laptops') . ' staggered side by side';
        if (preg_match('/small office|5\s*devices|10\s*devices|unlimited devices/', $name)) $devices = $device . ', a tablet and a smartphone arranged neatly together';
        if (strpos($hay, 'vpn') !== false) {
            $emblem = 'a glossy 3D shield in ' . $shieldColor . ' with a small white padlock, beside a translucent glowing blue globe wrapped in thin connection arcs';
            $screen = 'a glowing translucent blue globe with connection arcs and a small ' . $shieldColor . ' shield of light hovering in front of the screen';
        } else {
            $emblem = 'a glossy 3D protection shield in ' . $shieldColor . ' with a clean white checkmark' . (preg_match('/small office|devices/', $name) ? ', protecting a small set of devices (laptop, tablet, smartphone)' : ($isMac ? ', standing in front of ' . $device : ''));
            $screen = 'a large glowing translucent ' . $shieldColor . ' shield of light with a white checkmark hovering in front of the screen (an abstract security concept, not a logo)';
        }
        return ['emblem' => $emblem, 'screen' => $screen, 'device' => $devices, 'family' => 'security'];
    }
    if (preg_match('/windows\s*1[01]|windows-1[01]|operating system/', $hay)) {
        $eleven = (strpos($hay, '11') !== false);
        $pro    = (strpos($name, 'pro') !== false);
        $blue   = $pro ? 'deep royal-blue' : 'bright royal-blue';
        $base   = $pro ? ' resting on a subtle dark-navy base plate' : '';
        $emblem = $eleven
            ? 'a glossy 3D four-pane window emblem — four equal ' . $blue . ' squares in a neat 2×2 grid with a thin gap — floating above a soft shadow' . $base . ', with a soft translucent blue bloom-like ribbon of light curling behind it'
            : 'a glossy 3D four-pane window emblem in ' . $blue . ', the four panes shown in slight perspective, floating above a soft shadow' . $base . ' with a soft blue glow behind it';
        $screen = $eleven
            ? 'a flowing blue abstract bloom-style wallpaper with a centred row of small colourful abstract squares along the bottom (no logos)'
            : 'a deep-blue abstract light-ray wallpaper with a slim abstract taskbar along the bottom (no logos)';
        return ['emblem' => $emblem, 'screen' => $screen, 'device' => 'a slim dark-graphite premium laptop or all-in-one desktop PC with thin bezels', 'family' => 'windows'];
    }
    if (preg_match('/project/', $hay)) {
        return ['emblem' => 'a rich green rounded 3D app tile with a bold white letter P, beside a small floating 3D Gantt-chart motif of three staggered green horizontal bars',
                'screen' => 'a green Gantt-style project timeline of staggered horizontal bars and milestones (no readable text)',
                'device' => $device, 'family' => 'project'];
    }
    if (preg_match('/visio/', $hay)) {
        return ['emblem' => 'a deep-blue/indigo rounded 3D app tile with a bold white letter V, beside a small floating 3D flowchart motif of three connected shapes',
                'screen' => 'a blue-and-purple flowchart diagram of connected boxes, diamonds and arrows (no readable text)',
                'device' => $device, 'family' => 'visio'];
    }
    // Office family (suites + single apps)
    if (!$apps) $apps = ['word', 'excel', 'powerpoint'];
    $tiles = []; $screens = [];
    foreach ($apps as $a) { if (isset($tileMap[$a])) { $tiles[] = $tileMap[$a]; $screens[] = $screenMap[$a]; } }
    if (!$tiles) { $tiles = [$tileMap['word'], $tileMap['excel'], $tileMap['powerpoint']]; $screens = [$screenMap['word'], $screenMap['excel'], $screenMap['powerpoint']]; }
    $single = count($tiles) === 1;
    $emblem = $single
        ? 'one large ' . $tiles[0] . ', with a subtle matching-colour ' . ($apps[0] === 'excel' ? 'spreadsheet grid' : 'document sheet') . ' peeking out behind it'
        : 'a neat row of ' . count($tiles) . ' glossy app tiles — ' . implode(', ', $tiles) . ' — evenly spaced';
    if ($isMac) $emblem .= ', floating in front of ' . $device . ' shown at a slight angle with a soft light-grey abstract desktop on screen';
    $screen = 'an abstract colourful productivity workspace made of overlapping soft windows: ' . implode(', ', $screens) . ' (blurred, no readable text)';
    return ['emblem' => $emblem, 'screen' => $screen, 'device' => $device, 'family' => 'office'];
}

/** Shared "clean studio" rules — plain white, no box/card/frame, no text. */
function mv_image_clean_rules(): string
{
    return 'Plain, seamless, pure-white (#FFFFFF) background across the ENTIRE frame — no backdrop box, card, panel, frame, border, rounded rectangle or cream/beige/grey square behind the subject, no vignette; only a soft natural contact shadow. Full colour and photorealistic (never grayscale, sketch or line-art). No physical retail box, packaging, DVD case or shrink-wrap. No brand logos or trademarks, no readable words or sentences, no people or hands, no watermark, no collage or split panels.';
}

/** Build the storefront MAIN image prompt — clean product emblem on pure white. */
function mv_build_image_prompt(array $p): string
{
    $v = mv_product_visual($p);
    return 'Premium photorealistic 3D e-commerce product visual: ' . $v['emblem'] . '. '
         . 'Centred, front-facing, filling about 75% of the frame; studio product lighting, rich saturated colours, glossy reflections, crisp detail, elegant clean catalogue style. '
         . mv_image_clean_rules()
         . ' The only letters allowed are the single bold letters described on the app tiles (if any).';
}

/** Build the Google-Ads / gallery DEVICE-SCENE prompt (text-free, logo-free, product-specific). */
function mv_build_ads_image_prompt(array $p, string $angle = 'photographed straight-on, front-facing'): string
{
    $v = mv_product_visual($p);
    $plural = (strpos($v['device'], 'three ') === 0 || strpos($v['device'], ' and a ') !== false);
    return 'Premium photorealistic product photograph: ' . $v['device'] . ', powered on, ' . $angle . ', ' . ($plural ? 'the screens showing ' : 'its screen showing ') . $v['screen'] . '. '
         . 'The ' . ($plural ? 'devices fill' : 'device fills') . ' about 75% of the frame with a small natural margin — do NOT leave large empty areas. '
         . 'Realistic studio lighting, rich saturated colours, crisp detail, sharp focus, trustworthy modern e-commerce look. '
         . mv_image_clean_rules()
         . ' Google Ads image-asset safe: no text, letters or numbers anywhere; no logos (never the Microsoft, Windows, Office, Apple, Bitdefender or McAfee logo); no app-icon tiles with letters, badges, buttons or overlays; sharp, not distorted; one clear subject.';
}

/**
 * Generate + save the image. Returns ['ok'=>bool, 'image'=>'/uploads/...', 'error'=>'...'].
 */
function mv_generate_product_image(array $prod): array
{
    $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower((string)($prod['slug'] ?? '')));
    if ($slug === '') return ['ok' => false, 'error' => 'Missing product slug.'];

    [$key, $base] = mv_product_image_creds();
    if ($key === '') return ['ok' => false, 'error' => 'No AI key configured — add it under API Keys & Settings.'];

    $payload = json_encode([
        'model'  => 'gpt-image-1',
        'prompt' => mv_build_image_prompt($prod),
        'size'   => '1024x1024',
        'n'      => 1,
    ]);
    $ch = curl_init(rtrim($base, '/') . '/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 95,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $key],
        CURLOPT_POSTFIELDS     => $payload,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    if ($resp === false || $code < 200 || $code >= 300) {
        $msg = 'Image service error (' . ($code ?: 'network') . ')';
        $j = json_decode((string)$resp, true);
        if (isset($j['error']['message'])) {
            $m = (string)$j['error']['message'];
            if (stripos($m, 'budget') !== false || stripos($m, 'quota') !== false || stripos($m, 'insufficient') !== false) {
                $msg = 'Universal Key budget exceeded — top up in Profile → Universal Key → Add Balance.';
            } else {
                $msg = $m;
            }
        } elseif ($cerr !== '') {
            $msg = $cerr;
        }
        return ['ok' => false, 'error' => $msg];
    }

    $j   = json_decode((string)$resp, true);
    $b64 = $j['data'][0]['b64_json'] ?? '';
    $url = $j['data'][0]['url'] ?? '';
    $bin = '';
    if ($b64 !== '') $bin = base64_decode($b64);
    elseif ($url !== '') $bin = (string)@file_get_contents($url);
    if ($bin === '') return ['ok' => false, 'error' => 'No image was returned by the AI.'];

    $dir = __DIR__ . '/../uploads/products';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (!is_writable($dir)) return ['ok' => false, 'error' => 'uploads/products is not writable on this server.'];

    $webPath = '/uploads/products/' . $slug . '.webp';
    $fsPath  = $dir . '/' . $slug . '.webp';
    $saved   = false;

    // Prefer WebP (smaller) when GD supports it; resize to max 900px.
    if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
        $im = @imagecreatefromstring($bin);
        if ($im) {
            $w = imagesx($im); $h = imagesy($im); $mx = 900; $sc = min(1, $mx / max($w, $h));
            if ($sc < 1) {
                $nw = (int)($w * $sc); $nh = (int)($h * $sc);
                $r = imagecreatetruecolor($nw, $nh);
                imagefilledrectangle($r, 0, 0, $nw, $nh, imagecolorallocate($r, 255, 255, 255));
                imagecopyresampled($r, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagedestroy($im); $im = $r;
            }
            $saved = @imagewebp($im, $fsPath, 82);
            imagedestroy($im);
        }
    }
    // Fallback: save the raw bytes (PNG) when WebP isn't available.
    if (!$saved) {
        $webPath = '/uploads/products/' . $slug . '.png';
        $fsPath  = $dir . '/' . $slug . '.png';
        $saved   = (bool)@file_put_contents($fsPath, $bin);
    }
    if (!$saved) return ['ok' => false, 'error' => 'Could not save the generated image.'];
    @chmod($fsPath, 0644);

    // Always keep a JPG sibling next to a WebP product image: many email
    // clients (Gmail, Outlook, Apple Mail) can't render WebP, so the delivery
    // email's email_image_src() serves the .jpg. Without this, product images
    // show up broken in customers' inboxes.
    if (preg_match('/\.webp$/i', $fsPath) && function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
        $jpgFs = preg_replace('/\.webp$/i', '.jpg', $fsPath);
        $src   = @imagecreatefromstring($bin);
        if ($src) {
            $w = imagesx($src); $h = imagesy($src);
            $flat = imagecreatetruecolor($w, $h);
            imagefilledrectangle($flat, 0, 0, $w, $h, imagecolorallocate($flat, 255, 255, 255));
            imagecopy($flat, $src, 0, 0, 0, 0, $w, $h);
            @imagejpeg($flat, $jpgFs, 88);
            @chmod($jpgFs, 0644);
            imagedestroy($src); imagedestroy($flat);
        }
    }

    return ['ok' => true, 'image' => $webPath];
}

} // guard

if (!function_exists('mv_gallery_for')) {
/**
 * Resolve a product's gallery image paths.
 *  1) the gallery_images JSON column when populated, else
 *  2) auto-discover shipped files on disk: uploads/products/gallery/{slug}-*.
 * The disk fallback means a deployed build (with the image FILES in the ZIP)
 * shows all images even if the target database still has a NULL column.
 * Returns web paths (max 5).
 */
function mv_gallery_for(array $p): array
{
    $out = [];
    if (!empty($p['gallery_images'])) {
        $d = json_decode((string)$p['gallery_images'], true);
        if (is_array($d)) $out = array_values(array_filter(array_map(fn($x) => trim((string)$x), $d)));
    }
    if (!$out) {
        $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower((string)($p['slug'] ?? '')));
        if ($slug !== '') {
            $dir = __DIR__ . '/../uploads/products/gallery';
            $hits = glob($dir . '/' . $slug . '-*.{webp,png,jpg,jpeg}', GLOB_BRACE) ?: [];
            sort($hits);
            foreach ($hits as $f) $out[] = '/uploads/products/gallery/' . basename($f);
        }
    }
    return array_slice(array_values(array_unique($out)), 0, 5);
}
} // guard mv_gallery_for


if (!function_exists('mv_generate_gallery_image')) {
/**
 * Generate + save a UNIQUE additional gallery image for a product, in the
 * approved product-showcase style (brand-neutral, no logos). Each call varies
 * the composition (via a random shot descriptor) AND gpt-image-1 is
 * non-deterministic, so no two gallery images match. Saves to
 * uploads/products/gallery/{slug}-uN.webp and returns ['ok','image','error'].
 */
function mv_generate_gallery_image(array $prod): array
{
    $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower((string)($prod['slug'] ?? '')));
    if ($slug === '') return ['ok' => false, 'error' => 'Missing product slug.'];

    [$key, $base] = mv_product_image_creds();
    if ($key === '') return ['ok' => false, 'error' => 'No AI key configured — add it under API Keys & Settings.'];

    $name     = trim((string)($prod['name'] ?? 'Software'));
    $angles = [
        'photographed straight-on, front-facing',
        'at a slight three-quarter angle with a soft realistic shadow',
        'close-up with a shallow depth of field, the device large and sharp',
        'from a slightly elevated front angle, the screen clearly visible',
    ];
    $angle  = $angles[random_int(0, count($angles) - 1)];
    // Product-specific device scene (Office windows / Windows wallpaper / Gantt /
    // flowchart / shield of light) on pure white — text-free & logo-free.
    $prompt = mv_build_ads_image_prompt($prod, $angle);

    $payload = json_encode(['model' => 'gpt-image-1', 'prompt' => $prompt, 'size' => '1024x1024', 'n' => 1]);
    $ch = curl_init(rtrim($base, '/') . '/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 95,
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $key],
        CURLOPT_POSTFIELDS => $payload,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    if ($resp === false || $code < 200 || $code >= 300) {
        $msg = 'Image service error (' . ($code ?: 'network') . ')';
        $j = json_decode((string)$resp, true);
        if (isset($j['error']['message'])) {
            $m = (string)$j['error']['message'];
            $msg = (stripos($m, 'budget') !== false || stripos($m, 'quota') !== false || stripos($m, 'insufficient') !== false)
                 ? 'Universal Key budget exceeded — top up in Profile → Universal Key → Add Balance.' : $m;
        } elseif ($cerr !== '') { $msg = $cerr; }
        return ['ok' => false, 'error' => $msg];
    }
    $j   = json_decode((string)$resp, true);
    $b64 = $j['data'][0]['b64_json'] ?? '';
    $url = $j['data'][0]['url'] ?? '';
    $bin = $b64 !== '' ? base64_decode($b64) : ($url !== '' ? (string)@file_get_contents($url) : '');
    if ($bin === '') return ['ok' => false, 'error' => 'No image was returned by the AI.'];

    $dir = __DIR__ . '/../uploads/products/gallery';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (!is_writable($dir)) return ['ok' => false, 'error' => 'uploads/products/gallery is not writable on this server.'];

    // Unique filename that won't collide with the seeded {slug}-g1/-g2 files.
    $stamp   = $slug . '-u' . time() . random_int(100, 999);
    $webPath = '/uploads/products/gallery/' . $stamp . '.webp';
    $fsPath  = $dir . '/' . $stamp . '.webp';
    $saved   = false;
    if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
        $im = @imagecreatefromstring($bin);
        if ($im) {
            $w = imagesx($im); $h = imagesy($im); $mx = 900; $sc = min(1, $mx / max($w, $h));
            if ($sc < 1) {
                $nw = (int)($w * $sc); $nh = (int)($h * $sc);
                $r = imagecreatetruecolor($nw, $nh);
                imagefilledrectangle($r, 0, 0, $nw, $nh, imagecolorallocate($r, 255, 255, 255));
                imagecopyresampled($r, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagedestroy($im); $im = $r;
            }
            $saved = @imagewebp($im, $fsPath, 82);
            imagedestroy($im);
        }
    }
    if (!$saved) {
        $webPath = '/uploads/products/gallery/' . $stamp . '.png';
        $fsPath  = $dir . '/' . $stamp . '.png';
        $saved   = (bool)@file_put_contents($fsPath, $bin);
    }
    if (!$saved) return ['ok' => false, 'error' => 'Could not save the generated image.'];
    @chmod($fsPath, 0644);
    return ['ok' => true, 'image' => $webPath];
}

} // guard

if (!function_exists('mv_whiten_image')) {
/* ---------------------------------------------------------------------------
 * GD helpers shared by the product-image clean-up and the Ads asset saver.
 * ------------------------------------------------------------------------- */

/**
 * Turn every light, near-neutral pixel (white/cream/light-grey backgrounds, card
 * borders, soft shadows, grey footer bands) into pure #FFFFFF. Pixels with
 * luminance in [$from,$white) are stretched smoothly so no hard edge appears;
 * saturated colours (icons, tiles, logos) are never touched.
 */
function mv_whiten_image($im, int $white = 205, int $from = 170, int $maxSat = 30): void
{
    $w = imagesx($im); $h = imagesy($im);
    $k = ($white > $from) ? (255 - $from) / ($white - $from) : 1.0;
    $cache = [];
    for ($y = 0; $y < $h; $y++) {
        for ($x = 0; $x < $w; $x++) {
            $c = imagecolorat($im, $x, $y);
            $r = ($c >> 16) & 255; $g = ($c >> 8) & 255; $b = $c & 255;
            $mx = max($r, $g, $b); $mn = min($r, $g, $b);
            if ($mn < $from || ($mx - $mn) > $maxSat) continue;
            if (isset($cache[$c])) { imagesetpixel($im, $x, $y, $cache[$c]); continue; }
            $l = ($r + $g + $b) / 3;
            if ($l >= $white) { $nc = 0xFFFFFF; }
            else {
                $nl = $from + ($l - $from) * $k;               // stretch toward white
                $d  = $nl - $l;                                // same shift on all channels → keeps the tint direction
                $nr = min(255, (int)round($r + $d)); $ng = min(255, (int)round($g + $d)); $nb = min(255, (int)round($b + $d));
                $nc = ($nr << 16) | ($ng << 8) | $nb;
            }
            $cache[$c] = $nc;
            imagesetpixel($im, $x, $y, $nc);
        }
    }
}

/** Bounding box [x0,y0,x1,y1] of everything that is not (near-)white, measured on a downscaled copy. */
function mv_content_bbox($im, int $thresh = 236): array
{
    $w = imagesx($im); $h = imagesy($im);
    $sw = 220; $sh = max(1, (int)round($h * $sw / $w));
    $s = imagecreatetruecolor($sw, $sh);
    imagecopyresampled($s, $im, 0, 0, 0, 0, $sw, $sh, $w, $h);
    $x0 = $sw; $y0 = $sh; $x1 = -1; $y1 = -1;
    for ($y = 0; $y < $sh; $y++) {
        for ($x = 0; $x < $sw; $x++) {
            $c = imagecolorat($s, $x, $y);
            if (min(($c >> 16) & 255, ($c >> 8) & 255, $c & 255) < $thresh) {
                if ($x < $x0) $x0 = $x; if ($x > $x1) $x1 = $x; if ($y < $y0) $y0 = $y; if ($y > $y1) $y1 = $y;
            }
        }
    }
    imagedestroy($s);
    if ($x1 < 0) return [0, 0, $w, $h];
    $f = $w / $sw;
    return [max(0, (int)floor($x0 * $f) - 2), max(0, (int)floor($y0 * $f) - 2), min($w, (int)ceil(($x1 + 1) * $f) + 2), min($h, (int)ceil(($y1 + 1) * $f) + 2)];
}

/** Place the content box of $im centred on a $cw×$ch pure-white canvas, filling $fill of the shorter side. */
function mv_fit_on_white($im, array $bb, int $cw, int $ch, float $fill = 0.86, float $maxUp = 1.35)
{
    [$x0, $y0, $x1, $y1] = $bb;
    $bw = max(1, $x1 - $x0); $bh = max(1, $y1 - $y0);
    $scale = min($cw * $fill / $bw, $ch * $fill / $bh, $maxUp);
    $dw = max(1, (int)round($bw * $scale)); $dh = max(1, (int)round($bh * $scale));
    $canvas = imagecreatetruecolor($cw, $ch);
    imagefilledrectangle($canvas, 0, 0, $cw, $ch, imagecolorallocate($canvas, 255, 255, 255));
    imagecopyresampled($canvas, $im, (int)(($cw - $dw) / 2), (int)(($ch - $dh) / 2), $x0, $y0, $dw, $dh, $bw, $bh);
    return $canvas;
}

} // guard mv_whiten_image

if (!function_exists('mv_generate_ads_image')) {
/**
 * Google Ads image asset for ONE product — a product-specific, text-free,
 * logo-free device scene on pure white. Saved as
 *   uploads/products/ads/{slug}.webp            (1:1  square, 1024px)
 *   uploads/products/ads/{slug}-landscape.webp  (1.91:1, cropped from the same render)
 * No DB column needed (zero-DDL): mv_ads_image_for() discovers the file on disk.
 */
function mv_ads_image_for(array $p): array
{
    $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower((string)($p['slug'] ?? '')));
    $dir  = __DIR__ . '/../uploads/products/ads';
    $out  = ['square' => '', 'landscape' => ''];
    if ($slug === '') return $out;
    foreach (['webp', 'png', 'jpg'] as $ext) {
        if ($out['square'] === '' && is_file("$dir/$slug.$ext")) $out['square'] = "/uploads/products/ads/$slug.$ext";
        if ($out['landscape'] === '' && is_file("$dir/$slug-landscape.$ext")) $out['landscape'] = "/uploads/products/ads/$slug-landscape.$ext";
    }
    return $out;
}

/** Save raw image bytes as the product's Ads assets (square + 1.91:1 landscape crop). */
function mv_save_ads_image(string $slug, string $bin): array
{
    $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));
    if ($slug === '' || $bin === '') return ['ok' => false, 'error' => 'Nothing to save.'];
    $dir = __DIR__ . '/../uploads/products/ads';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (!is_writable($dir)) return ['ok' => false, 'error' => 'uploads/products/ads is not writable on this server.'];
    if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
        $ok = (bool)@file_put_contents("$dir/$slug.png", $bin);
        return $ok ? ['ok' => true, 'square' => "/uploads/products/ads/$slug.png", 'landscape' => ''] : ['ok' => false, 'error' => 'Could not save the image.'];
    }
    $im = @imagecreatefromstring($bin);
    if (!$im) return ['ok' => false, 'error' => 'The AI returned an unreadable image.'];
    imagepalettetotruecolor($im);
    // Guarantee a pure-white backdrop (no cream tint), then place the WHOLE device —
    // never a clipped crop — centred on white canvases: 1200×1200 (1:1) and 1200×628 (1.91:1).
    mv_whiten_image($im, 236, 214, 30);
    $bb = mv_content_bbox($im, 236);
    $sq = mv_fit_on_white($im, $bb, 1200, 1200, 0.88);
    mv_whiten_image($sq, 244, 232, 30);
    $okS = @imagewebp($sq, "$dir/$slug.webp", 88); imagedestroy($sq);
    $ls = mv_fit_on_white($im, $bb, 1200, 628, 0.90);
    mv_whiten_image($ls, 244, 232, 30);
    $okL = @imagewebp($ls, "$dir/$slug-landscape.webp", 88); imagedestroy($ls);
    imagedestroy($im);
    if (!$okS) return ['ok' => false, 'error' => 'Could not save the Google Ads image.'];
    @chmod("$dir/$slug.webp", 0644); if ($okL) @chmod("$dir/$slug-landscape.webp", 0644);
    return ['ok' => true, 'square' => "/uploads/products/ads/$slug.webp", 'landscape' => $okL ? "/uploads/products/ads/$slug-landscape.webp" : ''];
}

function mv_generate_ads_image(array $prod): array
{
    $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower((string)($prod['slug'] ?? '')));
    if ($slug === '') return ['ok' => false, 'error' => 'Missing product slug.'];
    [$key, $base] = mv_product_image_creds();
    if ($key === '') return ['ok' => false, 'error' => 'No AI key configured — add it under API Keys & Settings.'];

    // Landscape render, subject kept inside the central square so BOTH the 1:1
    // and the 1.91:1 crops contain the whole device.
    $prompt = mv_build_ads_image_prompt($prod, 'photographed straight-on, front-facing')
            . ' COMPOSITION: the device is centred and fully contained within the central square of this wide frame (about 70% of the frame height), leaving clean white space on the far left and far right.';
    $payload = json_encode(['model' => 'gpt-image-1', 'prompt' => $prompt, 'size' => '1536x1024', 'n' => 1]);
    $ch = curl_init(rtrim($base, '/') . '/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 110,
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $key],
        CURLOPT_POSTFIELDS => $payload,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    if ($resp === false || $code < 200 || $code >= 300) {
        $msg = 'Image service error (' . ($code ?: 'network') . ')';
        $j = json_decode((string)$resp, true);
        if (isset($j['error']['message'])) {
            $m = (string)$j['error']['message'];
            $msg = (stripos($m, 'budget') !== false || stripos($m, 'quota') !== false || stripos($m, 'insufficient') !== false)
                 ? 'Universal Key budget exceeded — top up in Profile → Universal Key → Add Balance.' : $m;
        } elseif ($cerr !== '') { $msg = $cerr; }
        return ['ok' => false, 'error' => $msg];
    }
    $j   = json_decode((string)$resp, true);
    $b64 = $j['data'][0]['b64_json'] ?? '';
    $url = $j['data'][0]['url'] ?? '';
    $bin = $b64 !== '' ? base64_decode($b64) : ($url !== '' ? (string)@file_get_contents($url) : '');
    if ($bin === '') return ['ok' => false, 'error' => 'No image was returned by the AI.'];
    return mv_save_ads_image($slug, $bin);
}

/**
 * Every image file that belongs to a product (main + email JPG sibling + gallery
 * + Google Ads assets) as [zipEntryName => absolute path]. Used by the admin
 * "Download images" ZIP.
 */
function mv_product_image_files(array $p): array
{
    $root  = realpath(__DIR__ . '/..');
    $files = [];
    $add = static function (string $web, string $label) use (&$files, $root): void {
        $rel = ltrim((string)parse_url($web, PHP_URL_PATH), '/');
        if ($rel === '' || strpos($rel, 'uploads/') !== 0) return;
        $abs = $root . '/' . $rel;
        if (is_file($abs)) $files[$label . '-' . basename($abs)] = $abs;
    };
    $main = trim((string)($p['image'] ?? ''));
    if ($main !== '') {
        $add($main, 'main');
        foreach (['jpg', 'png'] as $ext) $add(preg_replace('/\.\w+$/', '.' . $ext, $main), 'main');
    }
    $i = 0;
    foreach (mv_gallery_for($p) as $g) { $i++; $add($g, 'gallery-' . $i); }
    $ads = mv_ads_image_for($p);
    if ($ads['square'] !== '')    $add($ads['square'], 'google-ads-square');
    if ($ads['landscape'] !== '') $add($ads['landscape'], 'google-ads-landscape');
    return $files;
}
} // guard mv_generate_ads_image

if (!function_exists('mv_generate_blog_image')) {

/**
 * Build a VARIED, contextual lifestyle prompt for a blog cover image.
 * Never a plain product box — instead the software shown in real use
 * (on a laptop, a person working, a desk scene, etc). The scene is
 * picked deterministically from $seed so the same post is stable, but
 * different posts get visibly different images.
 */
function mv_build_blog_image_prompt(array $p, string $seed): string
{
    $name     = trim((string)($p['name'] ?? 'productivity software'));
    $brand    = trim((string)($p['brand'] ?? ''));
    $category = trim((string)($p['category'] ?? 'software'));
    $lc       = strtolower($name . ' ' . $category);

    // Visual STYLE pool — rotates for uniqueness, but every concept below is
    // tied directly to what the product actually DOES.
    $styles = [
        'Clean photorealistic still-life photograph, studio lighting, shallow depth of field',
        'Modern 3D render, soft global illumination, subtle glass and metal materials',
        'Isometric digital illustration, crisp vector-style shapes, pleasing colour palette',
        'Minimal flat-design editorial illustration with bold geometric shapes',
        'Cinematic close-up photograph with dramatic side lighting and bokeh',
        'Premium tech-editorial 3D artwork with depth, glow accents and floating UI elements',
    ];

    // PRODUCT-SPECIFIC concepts — the imagery must instantly say what the
    // product is (spreadsheets for Excel, window panes for Windows, shield
    // for antivirus…), using the product's signature colour, no logos/text.
    if (str_contains($lc, 'excel')) {
        $accent = 'signature spreadsheet-green colour palette';
        $concepts = [
            'a glowing 3D spreadsheet grid rising off a monitor like a city of green data columns, bar charts and pie charts floating above the cells',
            'a large monitor on a tidy desk showing an abstract green spreadsheet full of cells, charts and graphs, calculator and coffee beside it, no people',
            'giant translucent green spreadsheet cells and ascending bar charts orbiting a laptop, numbers turning into an upward growth arrow',
            'a financial analyst desk scene: printed green-tinted charts, a monitor with an abstract grid of cells and a rising line graph, no people',
        ];
    } elseif (str_contains($lc, 'word')) {
        $accent = 'signature deep-blue document colour palette';
        $concepts = [
            'crisp white document pages with blue heading bars flowing out of a laptop screen and stacking into a neat pile, fountain pen beside it',
            'a monitor showing an abstract blue-and-white text document with paragraphs and cursor, tidy writing desk with notebook and pen, no people',
            'a giant 3D sheet of paper with elegant typographic lines curling gracefully above a keyboard, soft blue accent lighting',
            'a writers desk still-life: stack of clean typed pages, blue bookmark ribbons, glasses and a screen with an abstract document editor, no people',
        ];
    } elseif (str_contains($lc, 'powerpoint')) {
        $accent = 'signature warm orange-red presentation colour palette';
        $concepts = [
            'floating 3D presentation slides with charts and title bars fanning out of a laptop like cards, warm orange accent lighting',
            'a conference-room screen showing an abstract orange slide with a bold headline block and a pie chart, empty modern boardroom',
            'a projector beam turning into a cascade of orange slide thumbnails above a desk, cinematic light',
        ];
    } elseif (str_contains($lc, 'outlook')) {
        $accent = 'signature azure-blue mail colour palette';
        $concepts = [
            'paper envelopes transforming into glowing blue email icons flying out of a laptop screen into an organised inbox grid',
            'a monitor with an abstract blue email inbox layout, calendar pages and clock beside it on a clean desk, no people',
        ];
    } elseif (str_contains($lc, 'office')) {
        $accent = 'Microsoft Office multicolour palette (blue, green, orange, red) as abstract accents';
        $concepts = [
            'a trio of floating 3D panels — a blue text document, a green spreadsheet with charts, an orange presentation slide — hovering above a laptop',
            'a productive desk scene: monitor showing a split view of an abstract document, spreadsheet and slides, coffee and notebook beside it, no people',
            'colour-coded folders in blue, green and orange opening to release documents, charts and slides above a keyboard, studio light',
            'a 3D isometric home-office desk where document pages, spreadsheet grids and presentation slides stack into a tidy productivity workspace',
        ];
    } elseif (preg_match('/\bwindows\b/', $lc)) {
        $accent = 'signature Windows blue colour palette';
        $concepts = [
            'four glowing blue glass panes arranged in a classic 2x2 window grid floating above a sleek modern PC on a desk, soft rim light',
            'a premium desktop PC setup at dusk, ultrawide monitor glowing with an abstract blue tiled interface and a soft light-blue wallpaper swirl, no people',
            'a 2x2 arrangement of luminous blue squares hovering over a motherboard landscape, symbolising an operating system powering the hardware',
            'a doorway of four blue glass window panes opening from a dark room into a bright modern digital desktop landscape, upgrade concept',
        ];
    } elseif (str_contains($lc, 'project')) {
        $accent = 'signature project-green colour palette';
        $concepts = [
            'an elegant 3D Gantt chart with green timeline bars and milestone diamonds floating above a boardroom table, no people',
            'a monitor showing an abstract green project timeline with task bars and dependency arrows, sticky notes and calendar on the desk, no people',
            'wooden blocks arranged as an ascending project roadmap with tiny milestone flags connected by a green timeline ribbon, macro shot',
        ];
    } elseif (str_contains($lc, 'visio')) {
        $accent = 'signature Visio indigo-blue colour palette';
        $concepts = [
            'a glowing indigo flowchart of connected shapes — diamonds, rectangles, arrows — assembling itself above a drafting desk',
            'a monitor with an abstract indigo network diagram of nodes and connectors, engineering rulers and blueprints beside it, no people',
            'an isometric blueprint table where 3D flowchart shapes snap together into an organised process diagram, indigo accent light',
        ];
    } elseif (str_contains($lc, 'vpn')) {
        $accent = 'secure teal-and-navy colour palette';
        $concepts = [
            'a glowing encrypted tunnel of light connecting a laptop to a globe of secure server nodes, dark navy scene with teal accents',
            'a laptop wrapped in a translucent protective sphere while data streams pass safely around it, world map of connection points behind',
        ];
    } elseif (str_contains($lc, 'antivirus') || str_contains($lc, 'security') || str_contains($lc, 'bitdefender') || str_contains($lc, 'mcafee') || str_contains($lc, 'norton') || str_contains($lc, 'total protection') || str_contains($lc, 'internet security')) {
        $accent = 'protective red-and-dark-navy security colour palette';
        $concepts = [
            'a glowing digital shield deflecting streams of red malware particles away from a laptop and smartphone on a desk, dark navy background',
            'a laptop protected inside a translucent force-field dome while virus particles bounce off, cyan and red accent lighting',
            'a padlock made of light standing on a motherboard landscape, guarding family devices — laptop, phone, tablet — behind it',
            'a scanning beam sweeping across a screen of files, flagging red threat icons and turning them into green safe checkmarks',
        ];
    } else {
        $accent = 'modern blue tech colour palette';
        $concepts = [
            'a laptop on a clean desk with abstract app windows and productivity icons floating above the screen, no people',
            'a 3D scene of software boxes transforming into glowing digital download arrows above a keyboard',
        ];
    }

    $h       = md5($seed);
    $style   = $styles[(int)(hexdec(substr($h, 0, 6)) % count($styles))];
    $concept = $concepts[(int)(hexdec(substr($h, 6, 6)) % count($concepts))];

    $subject = trim(($brand !== '' ? $brand . ' ' : '') . $name);
    return $style . '. Blog cover artwork about ' . $subject . ' (' . $category . '): '
         . $concept . '. Use a ' . $accent . '. '
         . 'No readable brand text, no logos, no words, no captions, no watermark, no borders. '
         . 'Wide 16:9 composition, professional colour grading, high detail.';
}

/** Varied curated workspace/laptop stock fallback, picked from $seed. */
function mv_blog_stock_fallback(string $seed): string
{
    $pool = [
        'photo-1498050108023-c5249f4df085', // laptop code desk
        'photo-1531297484001-80022131f5a1', // laptop on surface
        'photo-1517336714731-489689fd1ca8', // macbook desk
        'photo-1486312338219-ce68d2c6f44d', // person at laptop
        'photo-1454165804606-c3d57bc86b40', // team laptops desk
        'photo-1488998427799-e3362cec87c3', // working on laptop cafe
        'photo-1542744173-8e7e53415bb0',    // workspace planning
        'photo-1521737711867-e3b97375f902', // team working
        'photo-1499951360447-b19be8fe80f5', // laptop closeup typing
        'photo-1497032628192-86f99bcd76bc', // office desk monitor
        'photo-1434030216411-0b793f4b4173', // student studying laptop
        'photo-1531403009284-440f080d1e12', // home office laptop
    ];
    $idx = (int)(hexdec(substr(md5($seed), 0, 6)) % count($pool));
    return 'https://images.unsplash.com/' . $pool[$idx] . '?q=80&w=1200&auto=format&fit=crop';
}

/**
 * Generate + save a NEW contextual blog cover image for a post.
 * Returns ['ok'=>bool, 'image'=>'/uploads/blog/...', 'error'=>'...'].
 * On any failure the caller should fall back to mv_blog_stock_fallback().
 */
function mv_generate_blog_image(array $prod, string $postId, string $seed = ''): array
{
    $fname = preg_replace('/[^a-z0-9\-]/', '', strtolower($postId));
    if ($fname === '') return ['ok' => false, 'error' => 'Missing post id.'];
    if ($seed === '') $seed = $postId . '|' . ($prod['slug'] ?? '');

    [$key, $base] = mv_product_image_creds();
    if ($key === '') return ['ok' => false, 'error' => 'No AI key configured.'];

    $payload = json_encode([
        'model'  => 'gpt-image-1',
        'prompt' => mv_build_blog_image_prompt($prod, $seed),
        'size'   => '1536x1024',
        'n'      => 1,
    ]);
    $ch = curl_init(rtrim($base, '/') . '/images/generations');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 95,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $key],
        CURLOPT_POSTFIELDS     => $payload,
    ]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($resp === false || $code < 200 || $code >= 300) {
        return ['ok' => false, 'error' => 'Image service error (' . ($code ?: 'network') . ')'];
    }

    $j   = json_decode((string)$resp, true);
    $b64 = $j['data'][0]['b64_json'] ?? '';
    $url = $j['data'][0]['url'] ?? '';
    $bin = $b64 !== '' ? base64_decode($b64) : ($url !== '' ? (string)@file_get_contents($url) : '');
    if ($bin === '') return ['ok' => false, 'error' => 'No image returned.'];

    $dir = __DIR__ . '/../uploads/blog';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (!is_writable($dir)) return ['ok' => false, 'error' => 'uploads/blog not writable.'];

    $webPath = '/uploads/blog/' . $fname . '.webp';
    $fsPath  = $dir . '/' . $fname . '.webp';
    $saved   = false;
    if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
        $im = @imagecreatefromstring($bin);
        if ($im) {
            $w = imagesx($im); $h = imagesy($im); $mx = 1200; $sc = min(1, $mx / max($w, $h));
            if ($sc < 1) {
                $nw = (int)($w * $sc); $nh = (int)($h * $sc);
                $r = imagecreatetruecolor($nw, $nh);
                imagefilledrectangle($r, 0, 0, $nw, $nh, imagecolorallocate($r, 255, 255, 255));
                imagecopyresampled($r, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagedestroy($im); $im = $r;
            }
            $saved = @imagewebp($im, $fsPath, 82);
            imagedestroy($im);
        }
    }
    if (!$saved) {
        $webPath = '/uploads/blog/' . $fname . '.png';
        $fsPath  = $dir . '/' . $fname . '.png';
        $saved   = (bool)@file_put_contents($fsPath, $bin);
    }
    if (!$saved) return ['ok' => false, 'error' => 'Could not save image.'];
    @chmod($fsPath, 0644);

    // Deploy-proof copy: persist the saved bytes in the DB (blog_media) so a
    // future code re-upload (which overwrites /uploads) can never wipe this
    // blog's cover — blog_image_src() will serve it via /blog-image.php.
    if (function_exists('blog_media_store')) {
        $storeMime = (substr($webPath, -4) === '.png') ? 'image/png' : 'image/webp';
        $storeBin  = @file_get_contents($fsPath);
        if ($storeBin !== false && $storeBin !== '') {
            blog_media_store($postId, $storeBin, $storeMime);
        }
    }

    return ['ok' => true, 'image' => $webPath];
}

} // guard