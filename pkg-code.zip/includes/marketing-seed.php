<?php
/**
 * includes/marketing-seed.php
 * ---------------------------------------------------------------------------
 * Baked-in analytics / advertising / verification IDs so a fresh deploy on
 * ANY host is "ready" with zero re-entry (same pattern as gateways + reviews).
 *
 *  - GA4 Measurement ID .............. ga4_measurement_id
 *  - Google Ads Conversion ID ........ google_ads_tag_id
 *  - Google Merchant Center ID ....... google_merchant_id
 *  - Google Search Console token ..... google_site_verification_token
 *  - Bing Webmaster token ............ bing_site_verification_token
 *  - Google tag loader / GTM ......... google_tag_id / gtm_container_id
 *
 * mv_seed_marketing() is SEED-IF-EMPTY (unless forced), so anything the admin
 * later edits in Admin → Company → Tracking / SEO is always preserved. The
 * storefront <head> reads these settings first (admin value → then constant),
 * so once seeded every tag + verification meta renders automatically.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!defined('MV_MARKETING_SEED_VERSION')) define('MV_MARKETING_SEED_VERSION', '3');

function mv_marketing_seed_values(): array {
    return [
        'ga4_measurement_id'             => 'G-9824E82NN1',
        'google_ads_tag_id'              => 'AW-18263028048',
        'google_ads_purchase_label'      => 'C5r4CPzev-QcENDivoRE',
        'google_merchant_id'             => '5815017210',
        'google_site_verification_token' => 'LFLfhfiA2pQuNPIvUus7TuLMUqKs6jq9TVnOlUkczMQ',
        'bing_site_verification_token'   => 'AF7E1FB430EA67709B92D54FA12FBEB7',
        'google_tag_id'                  => 'GT-TQV4X72G',
        'gtm_container_id'               => 'GTM-N6Q7FKS2',
        // Google Business "write a review" link — powers the post-review
        // "Post my review on Google" button on order-success.php.
        'google_review_url'              => 'https://g.page/r/CY0H1wdUhWorEBM/review',
    ];
}

/** Seed marketing IDs. $force overwrites; otherwise seed-if-empty. */
function mv_seed_marketing(bool $force = false): array {
    $log = [];
    if (!$force && (string)setting_get('marketing_seed_v', '') === MV_MARKETING_SEED_VERSION) {
        return ['skipped: already seeded'];
    }
    foreach (mv_marketing_seed_values() as $k => $v) {
        $cur = trim((string)setting_get($k, ''));
        if ($force || $cur === '') { setting_set($k, $v); $log[] = 'SET   ' . $k; }
        else                       { $log[] = 'KEEP  ' . $k; }
    }
    setting_set('marketing_seed_v', MV_MARKETING_SEED_VERSION);
    return $log;
}

/** Silent, guarded web auto-heal. Never throws. */
function mv_autoheal_marketing(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting_get('marketing_seed_v', '') !== MV_MARKETING_SEED_VERSION) {
            mv_seed_marketing(false);
        }
    } catch (Throwable $e) { /* DB not ready — retry next request */ }
}
