<?php
/**
 * Order-summary partial — used by checkout.php for the initial render
 * AND by ajax/checkout-summary.php to refresh the summary in-place when
 * the customer applies a coupon or changes the quantity. Re-using the
 * exact same PHP avoids drift between the first render and refreshes.
 *
 * Expected in scope:
 *   $items, $proAssist, $subtotal, $savings,
 *   $couponCode, $couponPct, $discount, $total
 */
if (!isset($items)) { return; }
?>
<span class="co-watermark" aria-hidden="true"><?= render_logo(300) ?></span>
<div class="co-summary-head text-center">
  <div class="d-flex justify-content-center mb-2">
    <span class="co-banner-secure badge rounded-pill text-bg-success-subtle text-success border border-success-subtle" style="z-index:2;"><i class="bi bi-lock-fill me-1"></i>Secure Checkout</span>
  </div>
  <a href="/" class="logo-3d d-inline-flex align-items-center justify-content-center gap-2 mb-1 text-decoration-none" data-testid="co-banner-brand">
    <?= render_logo(36) ?>
    <span class="text-start">
      <span class="brand-text d-block lh-1"><span class="brand-grad"><?= esc(brand_name()) ?></span></span>
      <?php if (setting_get('show_authorized_reseller_badge', '0') === '1'): ?>
      <small class="brand-tag" data-testid="brand-tag-authorized-reseller-checkout">AUTHORIZED RESELLER</small>
      <?php endif; ?>
    </span>
  </a>
  <small class="text-secondary d-block">Pay <?= brand_legal() ?></small>
  <div class="receipt-amount fw-bold" data-testid="checkout-amount-banner"><?= format_price($total) ?></div>
  <small class="text-secondary d-block mb-2"><?= count($items) + ($proAssist ? 1 : 0) ?> item<?= (count($items) + ($proAssist ? 1 : 0)) !== 1 ? 's' : '' ?> · Digital delivery by email</small>
  <?php
    // Statement-clarity note, driven by the BILLING COUNTRY the shopper picked
    // ($fxCountry, from checkout.php / ?cc= on the ajax refresh). Falls back to
    // the storefront's display currency when no country is known yet.
    $__fxCC = strtoupper(trim((string)($fxCountry ?? '')));
    if ($__fxCC === '') { $__fxCC = ['USD'=>'US','CAD'=>'CA','GBP'=>'UK','AUD'=>'AU','EUR'=>'FR'][local_currency()['code']] ?? 'US'; }
    $__fx = function_exists('mv_fx_note_for_country') ? mv_fx_note_for_country($__fxCC, (float)$total) : null;
  ?>
    <div class="mv-fx-note" id="mvFxNote" data-testid="summary-approx-note" role="note"<?= $__fx ? '' : ' style="display:none"' ?>>
      <span class="mv-fx-ico"><i class="bi bi-info-circle-fill"></i></span>
      <span class="mv-fx-txt">
        You'll be charged <strong><span id="mvFxCharge"><?= $__fx ? esc($__fx['charge_fmt'] . ' ' . $__fx['charge_code']) : '' ?></span></strong>.<br>
        <span id="mvFxApproxLine"<?= ($__fx && $__fx['approx_fmt'] !== '') ? '' : ' style="display:none"' ?>>That's approximately <strong><span id="mvFxApprox"><?= $__fx ? esc($__fx['approx_fmt'] . ' ' . $__fx['approx_code']) : '' ?></span></strong> — shown so there's no confusion on your <span id="mvFxCode"><?= $__fx ? esc($__fx['approx_code']) : '' ?></span> statement.</span>
        <span id="mvFxGenericLine"<?= ($__fx && $__fx['approx_fmt'] === '') ? '' : ' style="display:none"' ?>>The amount is in <span id="mvFxChargeName"><?= $__fx ? esc($__fx['charge_code']) : '' ?></span> — your bank converts it to your local currency at its own rate, so the figure on your statement may differ slightly.</span>
      </span>
    </div>
    <style>
      .mv-fx-note{display:flex;gap:.55rem;align-items:flex-start;text-align:left;margin:.35rem 0 .1rem;
        background:linear-gradient(135deg,#fff7ed,#fef3c7);border:1px solid #f59e0b;
        border-left:4px solid #f59e0b;border-radius:10px;padding:.6rem .7rem;
        font-size:.76rem;line-height:1.35;color:#7c2d12;box-shadow:0 2px 8px rgba(245,158,11,.15);}
      .mv-fx-note .mv-fx-ico{color:#f59e0b;font-size:1rem;line-height:1;margin-top:1px;}
      .mv-fx-note strong{color:#111827;font-weight:800;}
      [data-bs-theme="dark"] .mv-fx-note{background:rgba(245,158,11,.12);border-color:#f59e0b;color:#fde68a;}
      [data-bs-theme="dark"] .mv-fx-note strong{color:#fff;}
    </style>
</div>
<hr class="my-2">
<?php
/* --- Protection Hub badge (rendered when a `sub-*` plan is in the cart) ---
 * Purpose: give the customer a large, visible confirmation that their
 * purchase includes an active Protection Hub subscription (shield / medal
 * icon + plan name + benefits chip).  The exact same visual is mirrored in
 * the delivery email hero (see build_protection_hub_hero_email() in
 * includes/email.php) so the badge the customer sees at checkout matches
 * what lands in their inbox after payment. */
$_planItem = null;
foreach ($items as $__it) {
    if (strpos((string)$__it['slug'], 'sub-') === 0) { $_planItem = $__it; break; }
}
if ($_planItem):
    $_planImg = $_planItem['image'] ?: '/assets/images/subscriptions/pro-shield.png';
?>
  <div class="protection-hub-badge d-flex align-items-center gap-3 p-3 mb-3 rounded-3 position-relative overflow-hidden"
       style="background:linear-gradient(135deg,#eef2ff 0%,#dbeafe 60%,#e0e7ff 100%);border:1px solid #a5b4fc;"
       data-testid="checkout-protection-hub-badge">
    <span aria-hidden="true" style="position:absolute;top:-24px;right:-18px;width:110px;height:110px;background:radial-gradient(circle,rgba(59,130,246,.28) 0%,rgba(59,130,246,0) 70%);"></span>
    <img src="<?= esc($_planImg) ?>"
         onerror="this.onerror=null;this.src='/assets/images/subscriptions/pro-shield.png';"
         alt="<?= esc($_planItem['name']) ?> — Protection Hub | <?= brand_name() ?>"
         style="width:64px;height:64px;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(30,64,175,.25));flex-shrink:0;">
    <div class="flex-grow-1" style="position:relative;">
      <div style="font-size:.66rem;font-weight:800;letter-spacing:1.6px;text-transform:uppercase;color:#3730a3;"><?= esc(brand_name()) ?> Protection Hub</div>
      <div class="fw-bold" style="color:#1e293b;font-size:.95rem;line-height:1.2;"><?= esc($_planItem['name']) ?></div>
      <div class="d-flex flex-wrap gap-1 mt-1">
        <span class="badge rounded-pill" style="background:#1e40af;color:#fff;font-size:.62rem;font-weight:600;letter-spacing:.3px;"><i class="bi bi-shield-check me-1"></i>Priority support</span>
        <span class="badge rounded-pill" style="background:#0f766e;color:#fff;font-size:.62rem;font-weight:600;letter-spacing:.3px;"><i class="bi bi-lightning-charge-fill me-1"></i>Faster resolution</span>
        <span class="badge rounded-pill" style="background:#7c3aed;color:#fff;font-size:.62rem;font-weight:600;letter-spacing:.3px;"><i class="bi bi-patch-check-fill me-1"></i>Genuine keys guarantee</span>
      </div>
    </div>
  </div>
<?php endif; ?>
<?php foreach ($items as $i): ?>
  <?php $isPlanRow = (strpos((string)$i['slug'], 'sub-') === 0); ?>
  <div class="d-flex gap-2 mb-2 align-items-center" data-testid="summary-item-<?= esc($i['slug']) ?>">
    <?php if ($isPlanRow): ?>
      <img src="<?= esc($i['image'] ?: '/assets/images/product-placeholder.svg') ?>"
           onerror="this.onerror=null;this.src='/assets/images/product-placeholder.svg';"
           alt="<?= esc($i['name']) ?> — Protection Hub plan | <?= brand_name() ?>"
           style="width:56px;height:56px;object-fit:contain;padding:4px;background:linear-gradient(135deg,#eff6ff,#dbeafe);border:1px solid #bfdbfe;border-radius:12px;flex-shrink:0;"
           data-testid="summary-plan-icon-<?= esc($i['slug']) ?>">
    <?php else: ?>
      <img src="<?= esc($i['image'] ?: '/assets/images/product-placeholder.svg') ?>" onerror="this.onerror=null;this.src='/assets/images/product-placeholder.svg';" alt="<?= esc($i['name']) ?> — one-time purchase license key | <?= brand_name() ?>" style="width:40px;height:40px;object-fit:contain;" class="bg-body-tertiary rounded p-1">
    <?php endif; ?>
    <div class="flex-grow-1">
      <div class="small fw-semibold"><?= esc($i['name']) ?></div>
      <?php
        // Multi-seat hint right under the product name so the customer
        // sees "1 key, 5 PCs" before they hit Proceed to Pay.
        $_seats = max(1, (int)$i['qty']);
        if ($_seats > 1) {
            $_isMS = (stripos((string)($i['brand'] ?? ''), 'microsoft') !== false)
                  || (stripos((string)$i['name'], 'microsoft') !== false)
                  || (stripos((string)$i['name'], 'office')    !== false)
                  || (stripos((string)$i['name'], 'windows')   !== false);
            $_noun = $_isMS ? 'PC' : 'device';
      ?>
        <div class="mt-1" data-testid="summary-seats-<?= esc($i['slug']) ?>">
          <span style="display:inline-flex;align-items:center;gap:.25rem;background:linear-gradient(135deg,#e0f2fe,#bae6fd);color:#075985;border:1px solid #7dd3fc;border-radius:999px;padding:1px 8px;font-size:.66rem;font-weight:700;letter-spacing:.2px;line-height:1.3;">
            <i class="bi bi-shield-check"></i>1 key · <?= $_seats ?> <?= $_noun ?>s
          </span>
        </div>
      <?php } ?>
      <div class="d-flex justify-content-between align-items-center mt-1">
        <?php
          // Protection Hub plans are one-time purchases fixed at qty=1 — hide
          // the +/- stepper for those and show a plain "1 × one-time" chip
          // instead.  Regular product SKUs keep the interactive stepper.
        ?>
        <?php if ($isPlanRow): ?>
          <span class="badge rounded-pill text-bg-secondary-subtle text-secondary border border-secondary-subtle" style="font-size:.68rem;font-weight:600;letter-spacing:.02em;" data-testid="summary-plan-qty-<?= esc($i['slug']) ?>">
            <i class="bi bi-check-lg me-1"></i>One-time purchase
          </span>
        <?php else: ?>
          <div class="input-group input-group-sm" style="width: 96px;">
            <button type="button" class="btn btn-outline-secondary px-2" data-cart-qty="<?= $i['qty'] - 1 ?>" data-slug="<?= esc($i['slug']) ?>">−</button>
            <span class="form-control text-center px-1"><?= (int)$i['qty'] ?></span>
            <button type="button" class="btn btn-outline-secondary px-2" data-cart-qty="<?= $i['qty'] + 1 ?>" data-slug="<?= esc($i['slug']) ?>">+</button>
          </div>
        <?php endif; ?>
        <div class="d-flex align-items-center gap-2">
          <?php $__hasSave = (!empty($i['original_price']) && $i['original_price'] > $i['price']); ?>
          <div class="d-flex flex-column align-items-end" style="line-height:1.15;" data-testid="summary-price-<?= esc($i['slug']) ?>">
            <?php if ($__hasSave): ?>
              <span class="text-secondary text-decoration-line-through" style="font-size:.72rem;"><?= format_price($i['original_price'] * $i['qty']) ?></span>
            <?php endif; ?>
            <span class="fw-bold text-primary small"><?= format_price($i['price'] * $i['qty']) ?></span>
            <?php if ($__hasSave): ?>
              <span class="text-success" style="font-size:.64rem;font-weight:700;letter-spacing:.2px;" data-testid="summary-save-<?= esc($i['slug']) ?>"><i class="bi bi-tag-fill" style="font-size:.6rem;"></i> Save <?= format_price(($i['original_price'] - $i['price']) * $i['qty']) ?></span>
            <?php endif; ?>
          </div>
          <button type="button" class="co-remove-btn" data-cart-remove="<?= esc($i['slug']) ?>" data-testid="summary-remove-<?= esc($i['slug']) ?>" title="Remove this item" aria-label="Remove <?= esc($i['name']) ?>"><i class="bi bi-trash3"></i></button>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>
<?php if ($proAssist): ?>
  <div class="d-flex gap-2 mb-3 border-top pt-3 align-items-center" data-testid="checkout-proassist-line">
    <span class="logo-mark" style="width:48px;height:48px;"><i class="bi bi-headset"></i></span>
    <div class="flex-grow-1">
      <div class="small fw-semibold">ProAssist Premium Installation</div>
      <div class="d-flex justify-content-between align-items-center small mt-1">
        <span class="text-secondary">Qty 1</span>
        <div class="d-flex align-items-center gap-2">
          <span class="fw-bold text-primary"><?= format_price(proassist_price()) ?></span>
          <button type="button" class="co-remove-btn" data-cart-proassist-remove data-testid="checkout-proassist-remove" title="Remove installation add-on" aria-label="Remove ProAssist Premium Installation"><i class="bi bi-trash3"></i></button>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>
<hr class="my-2">
<!-- Coupon -->
<?php if ($couponCode): ?>
  <div class="d-flex justify-content-between align-items-center small mb-2 text-success" data-testid="coupon-applied">
    <span><i class="bi bi-tag-fill me-1"></i>Coupon <strong><?= esc($couponCode) ?></strong> applied</span>
    <button type="button" class="btn btn-sm btn-link text-danger p-0" onclick="applyCoupon('')" data-testid="coupon-remove">Remove</button>
  </div>
<?php else: ?>
  <div class="input-group input-group-sm mb-2" style="max-width: 320px;">
    <input id="coupon-input" name="coupon_code" class="form-control" placeholder="Coupon code" autocomplete="off" data-testid="coupon-input" aria-label="Coupon code">
    <button type="button" class="btn btn-outline-primary" onclick="applyCoupon(document.getElementById('coupon-input').value)" data-testid="coupon-apply">Apply</button>
  </div>
<?php endif; ?>
<?php /* Per-product savings are shown inline on each line above; the summary
         stays clean with just the Subtotal so there's no confusing aggregate. */ ?>
<div class="d-flex justify-content-between small mb-2"><span class="text-secondary">Subtotal</span><span class="fw-semibold"><?= format_price($subtotal) ?></span></div>
<?php if ($discount > 0): ?>
  <div class="d-flex justify-content-between small mb-2 text-success"><span>Coupon (<?= esc($couponCode) ?> — <?= $couponPct ?>% off)</span><span data-testid="checkout-discount">-<?= format_price($discount) ?></span></div>
<?php endif; ?>
<div class="summary-total d-flex justify-content-between align-items-center p-2 px-3 rounded-3 mt-1">
  <span class="fw-bold">Total</span><span class="fw-bold text-primary fs-5" data-testid="checkout-total"><?= format_price($total) ?></span>
</div>
