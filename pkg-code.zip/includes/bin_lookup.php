<?php
/**
 * includes/bin_lookup.php
 *
 * Derives card FUNDING (credit / debit / prepaid) and ISSUING COUNTRY from the
 * PCI-safe 6–8 digit BIN we already store on each order.
 *
 * WHY: Stripe returns funding + country via its API, so Stripe orders fill the
 * "Funding" / "Issuing Country" admin fields automatically. NMI / Authorize.Net
 * / Custom direct-charge responses DON'T return those two data points, so those
 * orders showed "Unknown" / "—". We resolve them here from the stored BIN.
 *
 * Strategy (option C — offline first, API fallback, cached):
 *   1. Per-BIN cache held in ONE settings row (`card_bin_cache`, JSON) so we
 *      never re-hit the network for a BIN we've already seen and stay well
 *      inside binlist's free rate limit. Zero-DDL — no schema change.
 *   2. A small bundled offline table for common issuers/test BINs so the
 *      feature still works when the host blocks outbound HTTPS.
 *   3. binlist.net (https://lookup.binlist.net/{bin}) as the broad fallback.
 *
 * All lookups are best-effort: on any failure we return empty strings and the
 * caller simply leaves the existing value untouched.
 */

require_once __DIR__ . '/settings.php';

/** Settings key that stores the whole {bin: {...}} cache as one JSON blob. */
const MV_BIN_CACHE_KEY   = 'card_bin_cache';
const MV_BIN_CACHE_MAX   = 800; // cap entries so the settings row can't grow unbounded

/**
 * Resolve funding + issuing country + issuing bank for a BIN.
 * @return array{funding:string,country:string,brand:string,bank:string}
 */
function mv_bin_lookup(string $bin): array
{
    $empty = ['funding' => '', 'country' => '', 'brand' => '', 'bank' => ''];
    $digits = preg_replace('/\D/', '', $bin);
    $key6   = substr($digits, 0, 6);
    if (strlen($key6) < 6) return $empty;

    // 1) cache
    $cache = mv_bin_cache_read();
    if (isset($cache[$key6]) && is_array($cache[$key6])) {
        $c = $cache[$key6];
        if (($c['funding'] ?? '') !== '' || ($c['country'] ?? '') !== '' || ($c['bank'] ?? '') !== '') {
            return [
                'funding' => (string)($c['funding'] ?? ''),
                'country' => (string)($c['country'] ?? ''),
                'brand'   => (string)($c['brand'] ?? ''),
                'bank'    => (string)($c['bank'] ?? ''),
            ];
        }
    }

    // 2) offline dataset (never wrong, just incomplete)
    $off = mv_bin_offline_lookup($key6);
    if (($off['funding'] ?? '') !== '' || ($off['country'] ?? '') !== '' || ($off['bank'] ?? '') !== '') {
        mv_bin_cache_write($key6, $off);
        return $off;
    }

    // 3) binlist API fallback
    $api = mv_bin_api_lookup($key6);
    if (($api['funding'] ?? '') !== '' || ($api['country'] ?? '') !== '' || ($api['bank'] ?? '') !== '') {
        mv_bin_cache_write($key6, $api);
        return $api;
    }

    return $empty;
}

/** Read the per-BIN cache blob from settings. */
function mv_bin_cache_read(): array
{
    $raw = setting_get(MV_BIN_CACHE_KEY, '', true);
    if ($raw === '') return [];
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

/** Merge one BIN result into the cache blob (with a simple FIFO cap). */
function mv_bin_cache_write(string $key6, array $data): void
{
    try {
        $cache = mv_bin_cache_read();
        $cache[$key6] = [
            'funding' => (string)($data['funding'] ?? ''),
            'country' => (string)($data['country'] ?? ''),
            'brand'   => (string)($data['brand'] ?? ''),
            'bank'    => (string)($data['bank'] ?? ''),
            'ts'      => time(),
        ];
        if (count($cache) > MV_BIN_CACHE_MAX) {
            $cache = array_slice($cache, -MV_BIN_CACHE_MAX, null, true);
        }
        setting_set(MV_BIN_CACHE_KEY, json_encode($cache, JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) {
        @error_log('[mv_bin_cache_write] ' . $e->getMessage());
    }
}

/**
 * Bundled offline BIN table. Keys are 6-digit BINs; values are
 * [funding, country(ISO-2), brand]. Kept intentionally small and only holds
 * entries we are confident about (common issuers + the Stripe/processor test
 * cards) so the feature degrades gracefully with zero network access.
 */
function mv_bin_offline_lookup(string $key6): array
{
    static $table = [
        // --- processor / gateway TEST cards --- [funding, country, brand, bank]
        '424242' => ['credit',  'GB', 'Visa',             ''],       // Stripe/NMI test Visa
        '400000' => ['credit',  'US', 'Visa',             ''],
        '400005' => ['credit',  'US', 'Visa',             ''],
        '555555' => ['credit',  'US', 'Mastercard',       ''],       // Stripe test Mastercard
        '510510' => ['credit',  'AU', 'Mastercard',       ''],
        '378282' => ['credit',  'US', 'American Express',  ''],
        '371449' => ['credit',  'US', 'American Express',  ''],
        '601111' => ['credit',  'US', 'Discover',          ''],
        '620000' => ['credit',  'CN', 'UnionPay',          ''],
        // --- real issuer BINs seen in production ---
        '410039' => ['credit',  'US', 'Visa', 'Citibank, N.A. - Costco'],
    ];
    if (isset($table[$key6])) {
        [$f, $c, $b, $bank] = $table[$key6];
        return ['funding' => $f, 'country' => $c, 'brand' => $b, 'bank' => $bank];
    }
    return ['funding' => '', 'country' => '', 'brand' => '', 'bank' => ''];
}

/** binlist.net lookup. Best-effort; returns empty strings on any error/limit. */
function mv_bin_api_lookup(string $key6): array
{
    $empty = ['funding' => '', 'country' => '', 'brand' => '', 'bank' => ''];
    if (!function_exists('curl_init')) return $empty;
    try {
        $ch = curl_init('https://lookup.binlist.net/' . $key6);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Accept: application/json', 'Accept-Version: 3'],
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'MaventechBinLookup/1.0',
        ]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http !== 200 || !is_string($body) || $body === '') return $empty;
        $d = json_decode($body, true);
        if (!is_array($d)) return $empty;

        $funding = strtolower((string)($d['type'] ?? ''));           // credit|debit|prepaid
        if (!in_array($funding, ['credit', 'debit', 'prepaid'], true)) $funding = '';
        $country = strtoupper((string)($d['country']['alpha2'] ?? '')); // ISO-2
        if (strlen($country) !== 2) $country = '';
        $schemeMap = [
            'visa' => 'Visa', 'mastercard' => 'Mastercard', 'amex' => 'American Express',
            'american express' => 'American Express', 'discover' => 'Discover',
            'diners club' => 'Diners Club', 'jcb' => 'JCB', 'unionpay' => 'UnionPay',
        ];
        $scheme = strtolower((string)($d['scheme'] ?? ''));
        $brand  = $schemeMap[$scheme] ?? ($scheme !== '' ? ucfirst($scheme) : '');
        $bank   = trim((string)($d['bank']['name'] ?? ''));

        return ['funding' => $funding, 'country' => $country, 'brand' => $brand, 'bank' => $bank];
    } catch (Throwable $e) {
        @error_log('[mv_bin_api_lookup] ' . $e->getMessage());
        return $empty;
    }
}
