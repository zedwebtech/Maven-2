<?php
// Pure-PHP backup helpers for the admin "Download …" buttons. No shell, no
// mysqldump — works on locked-down shared hosting (Namecheap / cPanel).
// The SQL dump is written mysqldump-style so it imports cleanly through
// phpMyAdmin on MySQL 5.7 / 8 and MariaDB 10 / 11.

/** Make a SHOW CREATE … statement portable across MySQL/MariaDB versions. */
function mv_sql_portable_ddl(string $ddl): string
{
    $ddl = preg_replace('/utf8mb4_uca1400[a-z0-9_]*/i', 'utf8mb4_unicode_ci', $ddl); // MariaDB 11 only
    $ddl = preg_replace('/utf8mb4_0900[a-z0-9_]*/i', 'utf8mb4_unicode_ci', $ddl);    // MySQL 8 only
    $ddl = preg_replace('/utf8mb3/i', 'utf8', $ddl);                                  // MySQL 5.7 doesn't know utf8mb3
    $ddl = preg_replace('/\s+DEFINER=`[^`]*`@`[^`]*`/i', '', $ddl);                    // other host's DB user → "access denied"
    return trim((string)$ddl);
}

/** One SQL literal for a cell value (binary-safe, single-line). */
function mv_sql_literal(PDO $pdo, $v): string
{
    if ($v === null) return 'NULL';
    if (is_int($v) || is_float($v)) return (string)$v;
    $s = (string)$v;
    if ($s !== '' && (strpos($s, "\0") !== false || !mb_check_encoding($s, 'UTF-8'))) return '0x' . bin2hex($s);
    return str_replace(["\r", "\n", "\x1a"], ['\\r', '\\n', '\\Z'], $pdo->quote($s));
}

/**
 * Write a complete, re-importable dump of the whole database. $out receives
 * string chunks (echo for streaming, fwrite for a file). Returns stats.
 */
function mv_sql_dump(PDO $pdo, callable $out): array
{
    $stats = ['tables' => 0, 'rows' => 0, 'views' => 0];
    $q = fn(string $id) => '`' . str_replace('`', '``', $id) . '`';
    try { $pdo->exec("SET time_zone = '+00:00'"); } catch (Throwable $e) { /* TIMESTAMPs then dump in server tz */ }
    $ver = '';
    try { $ver = (string)$pdo->query('SELECT VERSION()')->fetchColumn(); } catch (Throwable $e) {}

    $out("-- " . brand_name() . " database backup\n-- Database: " . DB_NAME . "\n-- Source server: " . $ver . "\n-- Generated: " . gmdate('Y-m-d H:i:s') . " UTC\n");
    $out("-- Restore: phpMyAdmin → select the database → Import → choose this file → Go\n--          or: mysql -u USER -p DBNAME < database.sql\n\n");
    $out("SET NAMES utf8mb4;\nSET time_zone = '+00:00';\nSET FOREIGN_KEY_CHECKS = 0;\nSET UNIQUE_CHECKS = 0;\nSET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n");

    $tables = []; $views = [];
    foreach ($pdo->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM) as $r) {
        if (strtoupper((string)$r[1]) === 'VIEW') $views[] = (string)$r[0]; else $tables[] = (string)$r[0];
    }

    foreach ($tables as $t) {
        $create = $pdo->query('SHOW CREATE TABLE ' . $q($t))->fetch(PDO::FETCH_ASSOC);
        $ddl = mv_sql_portable_ddl((string)($create['Create Table'] ?? ''));
        if ($ddl === '') continue;
        $out("\n-- ----- Table: {$t} -----\nDROP TABLE IF EXISTS " . $q($t) . ";\n" . $ddl . ";\n\n");
        $stats['tables']++;
        $cols = $pdo->query('SHOW COLUMNS FROM ' . $q($t))->fetchAll(PDO::FETCH_COLUMN);
        $head = 'INSERT INTO ' . $q($t) . ' (' . implode(',', array_map($q, $cols)) . ") VALUES\n";

        // Unbuffered read so BLOB-heavy tables never load fully into PHP memory.
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
        $rows = $pdo->query('SELECT * FROM ' . $q($t));
        $buf = []; $bytes = 0;
        foreach ($rows as $row) {
            $vals = [];
            foreach ($row as $v) $vals[] = mv_sql_literal($pdo, $v);
            $line = '(' . implode(',', $vals) . ')';
            $buf[] = $line; $bytes += strlen($line) + 2; $stats['rows']++;
            // Keep each INSERT well under typical max_allowed_packet (phpMyAdmin / shared hosts).
            if (count($buf) >= 250 || $bytes >= 512 * 1024) {
                $out($head . implode(",\n", $buf) . ";\n");
                $buf = []; $bytes = 0;
            }
        }
        $rows->closeCursor();
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
        if ($buf) $out($head . implode(",\n", $buf) . ";\n");
    }

    foreach ($views as $v) {
        try {
            $create = $pdo->query('SHOW CREATE VIEW ' . $q($v))->fetch(PDO::FETCH_ASSOC);
            $ddl = mv_sql_portable_ddl((string)($create['Create View'] ?? ''));
            if ($ddl === '') continue;
            $ddl = preg_replace('/^CREATE\s+/i', 'CREATE OR REPLACE ', $ddl, 1);
            $out("\n-- ----- View: {$v} -----\nDROP VIEW IF EXISTS " . $q($v) . ";\n" . $ddl . ";\n");
            $stats['views']++;
        } catch (Throwable $e) { $out("\n-- view {$v} skipped: " . $e->getMessage() . "\n"); }
    }

    $out("\nSET FOREIGN_KEY_CHECKS = 1;\nSET UNIQUE_CHECKS = 1;\n-- End of backup — " . $stats['tables'] . " tables, " . $stats['rows'] . " rows\n");
    return $stats;
}

/** gzip a file on disk in chunks (phpMyAdmin imports .sql.gz directly). */
function mv_gzip_file(string $src, string $dst): bool
{
    $in = @fopen($src, 'rb'); $gz = @gzopen($dst, 'wb6');
    if (!$in || !$gz) { if ($in) fclose($in); if ($gz) gzclose($gz); return false; }
    while (!feof($in)) { $chunk = fread($in, 1 << 20); if ($chunk === false) break; gzwrite($gz, $chunk); }
    fclose($in); gzclose($gz);
    return is_file($dst);
}

/**
 * Add the project tree to a zip. The archive is closed and re-opened every
 * few hundred files so shared hosts with a low open-file limit never fail
 * half-way (ZipArchive keeps every added file open until close()).
 * $skip(string $relPath) → true to leave a file/dir out.
 */
function mv_zip_add_tree(string $zipPath, string $root, callable $skip, string &$warning): int
{
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE) !== true) { $warning = 'Could not open the archive for writing.'; return 0; }
    $added = 0; $pending = 0;
    try {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($it as $file) {
            $abs  = $file->getPathname();
            $relN = str_replace('\\', '/', substr($abs, strlen($root)));
            if ($relN === '' || $skip($relN, $file->isDir())) continue;
            $entry = ltrim($relN, '/');
            if ($file->isDir()) { $zip->addEmptyDir($entry); continue; }
            if (!$file->isFile() || !$file->isReadable()) continue;
            $zip->addFile($abs, $entry); $added++; $pending++;
            if ($pending >= 300) {
                $zip->close(); $pending = 0;
                if ($zip->open($zipPath, ZipArchive::CREATE) !== true) { $warning = 'Archive re-open failed after ' . $added . ' files.'; return $added; }
            }
        }
    } catch (Throwable $e) {
        $warning = 'File scan error: ' . $e->getMessage();
    }
    $zip->close();
    return $added;
}

/** Quick facts shown next to the backup buttons so the admin knows what's inside. */
function mv_backup_db_facts(PDO $pdo): array
{
    $f = ['orders' => 0, 'paid' => 0, 'latest_sale' => null, 'customers' => 0, 'keys' => 0];
    try {
        $f['orders'] = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
        $f['paid']   = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('paid','delivered')")->fetchColumn();
        $f['latest_sale'] = $pdo->query("SELECT MAX(created_at) FROM orders WHERE status IN ('paid','delivered')")->fetchColumn() ?: null;
        $f['customers'] = (int)$pdo->query("SELECT COUNT(DISTINCT LOWER(email)) FROM orders WHERE status IN ('paid','delivered')")->fetchColumn();
        $f['keys'] = (int)$pdo->query('SELECT COUNT(*) FROM license_keys')->fetchColumn();
    } catch (Throwable $e) {}
    return $f;
}
