<?php
// Shared "leads needing attention" counters — used by ajax/chat-admin.php
// (action=unread) and the consolidated admin.php?ajax=heartbeat poll.
if (!function_exists('mv_chat_relay_arm_background')) {
function mv_chat_relay_arm_background(): void
{
    static $armed = false;
    if ($armed || PHP_SAPI === 'cli') return;
    $armed = true;
    $canDetach = function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');
    if (!$canDetach) return;
    try {
        $lastSweep = (int)setting_get('chat_relay_sweep_at', '0');
        if (time() - $lastSweep < 30) return;
        setting_set('chat_relay_sweep_at', (string)time());
    } catch (Throwable $e) { return; }
    register_shutdown_function(static function (): void {
        @ignore_user_abort(true);
        @set_time_limit(60);
        while (ob_get_level() > 0) { @ob_end_flush(); }
        @flush();
        if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
        elseif (function_exists('litespeed_finish_request')) { @litespeed_finish_request(); }
        try { require_once __DIR__ . '/chat-relay.php'; chat_relay_sweep(5); } catch (Throwable $e) { /* best-effort */ }
    });
}
}
if (!function_exists('mv_chat_admin_unread')) {
function mv_chat_admin_unread(PDO $pdo): array
{
    // The offline e-mail relay sweep used to run INLINE here — up to 10 SMTP
    // sends inside a poll that fired every 5 s. With a slow/failing mailbox that
    // held the admin app for 10-30 s at a time (the "frozen" feeling). It now runs
    // only after the response has been handed to the browser, and only on hosts
    // that can detach (PHP-FPM / LiteSpeed); otherwise the 5-minute autocron does it.
    mv_chat_relay_arm_background();
    try {
        $r = $pdo->query("
            SELECT COUNT(*) FROM chat_leads l
            WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.lead_id=l.id AND m.sender='customer' AND m.read_at IS NULL)
               OR (l.callback_requested=1 AND l.admin_seen_at IS NULL)
        ")->fetchColumn();
    } catch (Throwable $e) {
        $r = $pdo->query("SELECT COUNT(DISTINCT lead_id) FROM chat_messages WHERE sender='customer' AND read_at IS NULL")->fetchColumn();
    }
    try {
        $alarm = (int)$pdo->query("SELECT COUNT(DISTINCT lead_id) FROM chat_messages WHERE sender='customer' AND read_at IS NULL")->fetchColumn();
    } catch (Throwable $e) { $alarm = 0; }
    try {
        $typing = (int)$pdo->query("SELECT COUNT(*) FROM chat_leads WHERE typing_customer_at IS NOT NULL AND typing_customer_at >= (NOW() - INTERVAL 15 SECOND)")->fetchColumn();
    } catch (Throwable $e) { $typing = 0; }
    $latest = null;
    if ($alarm > 0) {
        try {
            $latest = $pdo->query("SELECT cm.lead_id, cm.message, cl.name
                                    FROM chat_messages cm LEFT JOIN chat_leads cl ON cl.id=cm.lead_id
                                    WHERE cm.sender='customer' AND cm.read_at IS NULL
                                    ORDER BY cm.id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Throwable $e) { $latest = null; }
    }
    return ['ok' => true, 'unread' => (int)$r, 'alarm' => (int)$alarm, 'typing' => (int)$typing, 'latest' => $latest];
}
}
