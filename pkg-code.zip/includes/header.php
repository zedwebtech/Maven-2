<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/agent.php';
/* Change 6 — capture Google click IDs (gclid/gbraid/wbraid) + landing URL on
   the FIRST page of the visit so they can be stored on the order at checkout
   (server-side offline-conversion import + ad-blocker-proof attribution).
   Harmless + read-only here; the order write happens in checkout.php. */
if (session_status() === PHP_SESSION_ACTIVE) {
    foreach (['gclid', 'gbraid', 'wbraid'] as $__ck) {
        if (!empty($_GET[$__ck]) && empty($_SESSION['mv_click_ids'][$__ck])) {
            $_SESSION['mv_click_ids'][$__ck] = substr((string)$_GET[$__ck], 0, 200);
        }
    }
    if (!isset($_SESSION['mv_click_ids']['landing']) && !empty($_SERVER['REQUEST_URI'])) {
        $_SESSION['mv_click_ids']['landing'] = substr((string)$_SERVER['REQUEST_URI'], 0, 300);
        $_SESSION['mv_click_ids']['at']      = gmdate('c');
    }
}
// --- Agent markdown content negotiation (works on Apache AND the dev preview).
//     Runs before any output so a `text/markdown` request gets a clean markdown
//     view of this page. Uses SCRIPT_NAME (the resolved .php file, e.g.
//     /product.php, /index.php, /refund-policy.php) so it is front-controller
//     independent. Unhandled pages fall through to normal HTML. ---
if (agent_wants_markdown()) {
    $__mdPath = (string)($_SERVER['SCRIPT_NAME'] ?? '');
    if ($__mdPath === '') { $__mdPath = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH); }
    if (agent_render_markdown($__mdPath)) { exit; }
}
// Declare Accept as a cache key so CDNs never cross-serve the HTML variant to
// a `text/markdown` request (agent markdown negotiation — acceptmarkdown.com).
if (!headers_sent()) { header('Vary: Accept, Accept-Encoding'); }
// RFC 8288 Link headers — point AI agents at the discovery documents (mirrors
// the .htaccess mod_headers rules so the dev preview emits them too).
if (!headers_sent()) {
    header('Link: </.well-known/api-catalog>; rel="api-catalog"; type="application/linkset+json"', false);
    header('Link: </llms.txt>; rel="llms-txt"; type="text/plain"', false);
    header('Link: </llms-full.txt>; rel="llms-full-txt"; type="text/plain"', false);
    header('Link: </openapi.json>; rel="service-desc"; type="application/json"', false);
    header('Link: </agents.json>; rel="service-desc"; type="application/json"', false);
    header('Link: </.well-known/mcp.json>; rel="mcp-server"; type="application/json"', false);
}
// Capture the whole page so the company-branding filter can swap default
// name/phone/email for the current Company Info values site-wide.
if (function_exists('apply_company_branding')) { ob_start('apply_company_branding'); }
require_once __DIR__ . '/regions.php';
require_once __DIR__ . '/visitor_track.php';
// Track this public page-view (silently skipped for bots / admin / CLI).
track_visitor();
// Self-heal the public domain settings on the first real production page view
// so cron/CLI order emails + PDF receipts build correct absolute image URLs.
if (function_exists('mv_sync_public_domain')) { mv_sync_public_domain(); }

// Self-cron heartbeat — if the AI Auto-Blogger is overdue (>24 h), fire it
// in the background after this page has finished rendering. Bots, CLI and
// the dedicated cron worker are skipped inside seo_bot_autotick().
require_once __DIR__ . '/seo-bot.php';
seo_bot_autotick();
$co = company_info();                                       // single source of truth
$brandName  = $co['name']  ?: brand_name();
// alternateName — disambiguates the (generic) brand word from the exact
// domain entity for brand-name search (e.g. "Maventech" -> "Maventech
// Software", derived from maventechsoftware.com). Only added when the apex
// domain literally extends the brand word, so it stays accurate if the brand
// is renamed. Helps search engines tie the brand query to THIS domain.
$brandAltName = (static function () use ($brandName) {
    $host = preg_replace('/^www\./i', '', strtolower((string)($_SERVER['HTTP_HOST'] ?? '')));
    $apex = explode('.', $host)[0] ?? '';                 // e.g. "maventechsoftware"
    $key  = preg_replace('/[^a-z0-9]/', '', strtolower($brandName)); // e.g. "maventech"
    if ($key !== '' && $apex !== '' && strpos($apex, $key) === 0 && strlen($apex) > strlen($key)) {
        $suffix = substr($apex, strlen($key));            // e.g. "software"
        return trim($brandName . ' ' . ucfirst($suffix)); // -> "Maventech Software"
    }
    return null;
})();
// Legal entity name (from EIN / articles-of-organization).  Used ONLY in the
// footer copyright line, printable Receipt/Invoice PDFs, and any
// court-of-law-safe block.  Falls back to "$brandName LLC" when not set.
$brandLegalName = $co['legal_name'] ?: ($brandName !== '' ? ($brandName . ' LLC') : 'Maventech LLC');
$brandEmail = $co['email'] ?: brand_email();
$brandPhone = company_phone_for_country() ?: (defined('SITE_PHONE') ? SITE_PHONE : '');
$brandLogo  = $co['logo']  ?: '';
$brandAddress = $co['address'] ?: (defined('SITE_ADDRESS') ? SITE_ADDRESS : '');
$brandRegNumber      = $co['reg_number'] ?? '';
$brandRegDateFiled   = $co['reg_date_filed'] ?? '';
$brandRegCertUrl     = $co['reg_certificate_url'] ?? '';
$brandRegJurisdiction = $co['reg_jurisdiction'] ?? 'California, USA';
$pageTitle = $pageTitle ?? ($brandName . ' | Software Product Keys — Genuine & Instant');
$cur = local_currency();
$checkoutHeader = $checkoutHeader ?? false;

/* ---- SEO defaults (pages may override before including this header) ---- */
$pageDescription = $pageDescription ?? 'Shop original Microsoft Office, Windows 11 & antivirus software product keys from ' . brand_name() . ', an independent third-party reseller — one-time purchase, no subscription, 30-day money-back guarantee. Not affiliated with Microsoft, Norton, McAfee or any other trademark holder.';
/* Auto-clamp every page title (50-60 chars) and description (120-160 chars)
   so admin-edited copy can never blow past Google's SERP cut-off. */
$pageTitle       = seo_clamp_title($pageTitle, 60);
$pageDescription = seo_clamp_description($pageDescription, 158);
$pageTitleShort  = $pageTitleShort ?? seo_clamp_title(preg_replace('/\s+\|\s+.*$/u', '', $pageTitle), 55);
$script = basename($_SERVER['SCRIPT_NAME'] ?? '');
$noIndex = $noIndex ?? in_array($script, [
    // Transactional / session-bound pages — never surface these in Bing/Google.
    // We rely on the `<meta name="robots" content="noindex,nofollow">` tag
    // rather than a `Disallow:` line in robots.txt so Semrush no longer
    // fires the "blocked from crawling" notice (2026-07 fix).
    'cart.php', 'checkout.php', 'order-success.php', 'order-view.php', 'order-history.php',
    // Auth / account flow — nothing crawlable behind login.
    'login.php', 'register.php', 'user.php', 'account.php',
    'forgot-password.php', 'reset-password.php', 'logout.php',
    // Admin panels — private staff tools.
    'admin.php', 'admin-email-preview.php', 'inventory.php',
    // Utility / thin form pages that would otherwise inherit the site-wide
    // default meta and get flagged by Bing as "identical description".
    'review.php',
    // System pages.
    '404.php',
], true);
// CONTRACT: a page may pre-set $canonicalUrl before including this header to
// force a clean canonical (e.g. privacy.php/about.php serve DB/legacy content
// at /privacy and /about). Only compute the default when it is NOT already set.
if (!isset($canonicalUrl)) {
    $canonicalPath = $script === 'index.php' ? '/' : '/' . $script;
    $canonicalSlug = isset($_GET['slug']) && $_GET['slug'] !== '' ? '?slug=' . urlencode($_GET['slug']) : '';
    $canonicalPathBare = $canonicalPath . $canonicalSlug;            // unprefixed, for hreflang
    // Canonical ALWAYS points at the bare (US) URL. The /ca /uk /au /eu region
    // prefixes differ only by displayed currency (same language + products), so
    // Google consolidates them onto the bare URL anyway — declaring the bare URL
    // as canonical makes the page AGREE with Google and clears the GSC
    // "Duplicate, Google chose a different canonical than the user" report.
    $canonicalUrl = site_url() . $canonicalPathBare;
}
/* ===== Open Graph / Twitter / social card resolution ===========================
 * Per-page overrides (set BEFORE including this header):
 *   $ogImage         absolute or relative URL of the share image
 *   $ogImageAlt      alt text for screen-readers + LinkedIn
 *   $ogImageWidth    pixel width (default 1200)
 *   $ogImageHeight   pixel height (default 630)
 *   $ogType          'website' (default) | 'article' | 'product' | 'profile'
 *   $ogLocale        e.g. 'en_US' (default)
 *   $articlePublishedTime / $articleModifiedTime / $articleAuthor / $articleSection
 *   $productPriceAmount / $productPriceCurrency / $productAvailability
 *   $twitterCard     'summary_large_image' (default) | 'summary' | 'app' | 'player'
 * Defaults below produce a 1200×630 generated brand card that's social-bot
 * friendly out of the box — no SVG (Facebook & WhatsApp ignore SVG OGs).
 * ============================================================================== */
$_defaultOgImg   = site_url() . '/og-default.png';
// Absolute brand logo for JSON-LD (Google requires an absolute Organization
// logo URL): the Company Info logo, else the generated company-name mark.
$brandLogoAbs = brand_logo_absolute_url();
$ogImage         = $ogImage         ?? $_defaultOgImg;
// Normalise relative paths → absolute (social bots require absolute URLs).
if (!preg_match('~^https?://~i', $ogImage)) {
    $ogImage = rtrim(site_url(), '/') . '/' . ltrim($ogImage, '/');
}
// Heal any absolute foreign/preview host (e.g. matrixuiuxsoftware.com from a
// sibling deploy) baked into a per-page OG image → current public host.
$ogImage = (string)to_public_url($ogImage);
$ogImageAlt      = $ogImageAlt      ?? $pageTitle;
$ogImageWidth    = $ogImageWidth    ?? 1200;
$ogImageHeight   = $ogImageHeight   ?? 630;
$ogLocale        = $ogLocale        ?? 'en_US';
$twitterCard     = $twitterCard     ?? 'summary_large_image';
$twitterSite     = setting_get('twitter_site_handle', '');     // optional, e.g. "@maventechsw"
$fbAppId         = setting_get('facebook_app_id', '');         // optional, all-digits
?>
<!DOCTYPE html>
<html lang="en"<?php
// Server-rendered theme attribute — kills the light→dark flicker on
// navigation for logged-in users.  Source of truth, in priority order:
//   1. uc_theme cookie  (set ONLY by the storefront toggle via
//      /ajax/user-theme.php — the visitor's explicit choice for THIS site
//      in THIS browser; also covers anon visitors)
//   2. users.theme_pref (DB-persisted per-account choice; multi-device-
//      friendly — but the ADMIN PANEL toggle writes it too, so it must
//      never beat a storefront cookie or the shop would flip to the
//      admin panel's dark theme)
//   3. localStorage uc_theme (read inside the inline boot script below
//      for users on a brand-new server roundtrip)
// Whatever is decided here is FINAL for the page — main.js only mirrors it.
$initialTheme = '';
$ck = $_COOKIE['uc_theme'] ?? '';
if (in_array($ck, ['dark', 'light'], true)) $initialTheme = $ck;
if ($initialTheme === '' && !empty($_SESSION['user_id'])) {
    try {
        $st = db()->prepare('SELECT theme_pref FROM users WHERE id = ?');
        $st->execute([(int)$_SESSION['user_id']]);
        $tp = trim((string)($st->fetchColumn() ?: ''));
        if (in_array($tp, ['dark', 'light'], true)) $initialTheme = $tp;
    } catch (Throwable $e) { /* column might not exist yet — ignore */ }
}
echo $initialTheme !== '' ? ' data-bs-theme="' . esc($initialTheme) . '"' : '';
?>>
<head>
  <meta charset="UTF-8">
  <?php /* Kills the BLACK navigation flash on dark-OS devices. During the
           gap between clicking a link and the new page's CSS parsing, the
           browser paints its UA default canvas — BLACK on a dark-mode OS —
           which showed as a "black page" flicker just before (heavy) pages
           like checkout rendered. This store is LIGHT by default, so we pin
           the UA canvas to light for EVERYONE: the gap is always white, never
           black. (A visitor who opted into dark theme still gets the dark
           site chrome via data-bs-theme + the pre-paint CSS below; only the
           brief inter-page UA gap stays light, which is far less jarring than
           a black flash.) Must sit right after <meta charset>. */ ?>
  <?php /* Theme-aware canvas colour. The UA paints its inter-page / loading
           gap using `color-scheme`. Light-theme visitors (the default) get a
           WHITE gap; visitors who opted into dark get a BLACK gap instead of a
           jarring white flash. $initialTheme is the server-resolved choice
           (uc_theme cookie / logged-in preference); anon → light. */
        $__uaScheme = ($initialTheme === 'dark') ? 'dark' : 'light'; ?>
  <meta name="color-scheme" content="<?= $__uaScheme ?>">
  <?php /* Pages served under a virtual sub-path (e.g. the topic hubs at
           /hub/<slug>) must set $baseHref so the browser resolves every
           relative URL — CSS/JS assets, nav links, AJAX — against the real
           site root instead of /hub/. Without it those requests land at
           /hub/assets/…, /hub/shop.php, … and 404 on production. Must come
           BEFORE the first relative <link>/<script>. */
        if (!empty($baseHref)): ?><base href="<?= esc($baseHref) ?>"><?php endif; ?>
  <!-- Consent Mode v2 — defaults MUST run before any tag. Denied by default for
       UK/EEA visitors, granted elsewhere; a cookie banner can grant later via
       gtag('consent','update',…). Required for Google Ads in those regions. -->
  <?php
    $__consentChoice = mv_consent_choice();
    $__consentNeeded = mv_consent_required();
    $__trkMode = mv_tracking_mode();
    $GLOBALS['MV_TRK_MODE'] = $__trkMode;
  ?>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){ dataLayer.push(arguments); }
    gtag('consent','default',{ 'ad_storage':'denied','ad_user_data':'denied','ad_personalization':'denied','analytics_storage':'denied','wait_for_update':500,
      'region':<?= json_encode(mv_consent_regions()) ?> });
    gtag('consent','default',{ 'ad_storage':'granted','ad_user_data':'granted','ad_personalization':'granted','analytics_storage':'granted' });
    <?php if ($__consentChoice !== ''): /* returning visitor already chose on the banner */ ?>
    gtag('consent','update',{ 'ad_storage':'<?= $__consentChoice ?>','ad_user_data':'<?= $__consentChoice ?>','ad_personalization':'<?= $__consentChoice ?>','analytics_storage':'<?= $__consentChoice ?>' });
    <?php endif; ?>
    window.MV_CONSENT = { required: <?= $__consentNeeded ? 'true' : 'false' ?>, choice: <?= json_encode($__consentChoice) ?> };
    window.MV_TRK_MODE = <?= json_encode($__trkMode) ?>;
  </script>
  <?php $gtmId = mv_tracking_id('gtm_container_id', defined('GTM_CONTAINER_ID') ? GTM_CONTAINER_ID : '', '/^GTM-[A-Z0-9]+$/i'); ?>
  <?php if ($__trkMode === 'gtm'): ?>
  <!-- Google Tag Manager — the ONLY Google tag installation on the page (GTM mode).
       Loaded immediately (async) — NOT deferred — so the gclid is stored and
       page_view fires even when a mobile visitor taps away within a second. -->
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','<?= esc($gtmId) ?>');</script>
  <!-- End Google Tag Manager -->
  <?php endif; ?>
  <script>
    /* Performance: defer only NON-CRITICAL third parties (Microsoft Clarity,
       Bing UET, Merchant Center badge, Google publisher.js) until the FIRST
       user interaction or idle after load. Google tags (GTM / gtag.js) are
       NOT deferred — tracking audit 2026-09: deferral lost the gclid on fast
       mobile taps and pushed view_item before the tag was configured.
       Deferred scripts register a fn via window.__mvTrk.push(fn). */
    (function(){
      // Buffering stub so gtag() calls fired before the tag loads are queued in
      // dataLayer and flushed later. (No uetq stub here — the Bing UET array is
      // created only by the UET loader below, and only when a UET tag id is set.)
      window.dataLayer = window.dataLayer || [];
      window.gtag = window.gtag || function(){ window.dataLayer.push(arguments); };

      window.__mvTrk = window.__mvTrk || [];
      var fired = false;
      /* PERF 2026-06 — only load the (heavy) third-party tracker bundle on a
         DELIBERATE interaction. 'scroll' and 'mousemove' were removed because
         they fire continuously the instant a visitor nudges the mouse or
         scrolls, dumping GTM + Clarity session-replay + gtag + Merchant Center
         onto the main thread mid-gesture — which the user experienced as the
         page "freezing when I scroll or move the mouse". Deliberate events
         (tap/click/key) plus the idle/6s fallback still give full coverage. */
      var evts = ['mousedown','touchstart','keydown','pointerdown'];
      function cleanup(){ evts.forEach(function(e){ window.removeEventListener(e, run, true); }); }
      function run(){
        if (fired) return; fired = true; cleanup();
        var q = window.__mvTrk;
        window.__mvTrk = { push: function(fn){ try { fn(); } catch(e){} } };
        /* Process the queue ONE tracker per idle slice instead of a tight
           synchronous loop, so injecting/initialising several third parties
           never blocks the main thread long enough to freeze the page. */
        var i = 0;
        (function next(){
          if (i >= q.length) return;
          try { q[i](); } catch(e){}
          i++;
          if (i < q.length) {
            if ('requestIdleCallback' in window) requestIdleCallback(next, { timeout: 400 });
            else setTimeout(next, 30);
          }
        })();
      }
      evts.forEach(function(e){ window.addEventListener(e, run, {passive:true, capture:true}); });
      /* 2026-07 FIX — Semrush Web Vitals reported homepage TBT of 1,667ms
         (Poor) because the 3s post-load fallback fired the tracker stack
         (GTM/gtag, Merchant Center, Clarity) INSIDE Semrush's ~5s TBT
         measurement window. Push the safety-net past the window (6s) and
         use requestIdleCallback so the browser can pick the quietest
         moment. Real users still trigger run() on first interaction, so
         analytics coverage on real traffic is unchanged. */
      window.addEventListener('load', function(){
        var deadline = 6000;
        if ('requestIdleCallback' in window) {
          requestIdleCallback(run, { timeout: deadline });
        } else {
          setTimeout(run, deadline);
        }
      });
      window.__mvLoadTrackers = run;
    })();
  </script>
  <?php
    /* On the confirmation + checkout pages, start the deferred (non-Google)
       trackers IMMEDIATELY instead of waiting for interaction/idle. Deferral
       stays in place on all other pages (Core Web Vitals). */
    $__pgFile = basename((string)(parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: ($_SERVER['SCRIPT_NAME'] ?? '')));
    /* order-success.php is the ONLY page that must eager-load the heavy
       non-Google tracker stack (the purchase conversion + Merchant Center
       badge fire there). checkout.php was removed 2026-06: eager-loading
       Clarity session-replay + the Merchant Center merchantverse iframe +
       Bing UET synchronously during checkout load stole the main thread and
       left the shopper staring at the blank/dark canvas for seconds before
       the form painted. Those trackers still fire on the shopper's first
       interaction (tap/click/keypress) or 6s idle, so coverage is unchanged. */
    $__eagerTrack = in_array($__pgFile, ['order-success.php'], true);
    if ($__eagerTrack):
  ?>
  <script>window.__mvLoadTrackers && window.__mvLoadTrackers();</script>
  <?php endif; ?>
  <?php
    /* ================================================================
       Plausible Analytics — privacy-friendly traffic tracking.
       Admin pastes the full snippet from plausible.io under
       Admin → Company Info → Plausible Analytics, and it lands here
       inside every page's <head>.

       Safety: we only echo the raw snippet when
         (a) the admin toggle is ON, AND
         (b) the stored text references plausible.io or plausible.js
       so a compromised setting row cannot inject arbitrary JS.
       Plausible's own script is intentionally NOT deferred through
       __mvTrk because pageview accuracy depends on the tag being
       present at first paint (Plausible auto-tracks pageviews).
    ================================================================ */
    $plausibleEnabled = (setting_get('plausible_enabled', '0') === '1');
    $plausibleScript  = (string)setting_get('plausible_script', '');
    $plausibleOk      = ($plausibleScript !== '' &&
        (stripos($plausibleScript, 'plausible.io') !== false ||
         stripos($plausibleScript, 'plausible.js') !== false));
  ?>
  <?php if ($plausibleEnabled && $plausibleOk): ?>
  <!-- Plausible Analytics (admin → Company Info → Plausible Analytics) -->
  <?php
    /* ================================================================
       Output the admin's pasted Plausible snippet EXACTLY as-is.

       This is a classic server-rendered, multi-page PHP site: every
       navigation (home, /shop.php, /category.php, /product.php?slug=…,
       etc.) is a FULL page load, so Plausible's standard script.js
       auto-fires one pageview per page using the real window.location.
       That reliably tracks the WHOLE website — every path shows up in
       Plausible → Top Pages.

       (We used to rewrite the snippet to script.manual.js + a custom
       plausible('pageview',{u:…}) call to surface query strings, but the
       current Plausible engine needs plausible.init({autoCapturePageviews:
       false}) + the `url` key — the old `u` manual call silently stopped
       registering pageviews on many pages, so traffic collapsed onto the
       root domain.  Standard auto-tracking is the robust fix.)

       To see individual product/category URLs that differ only by the
       ?slug= query string, enable query-parameter tracking in the
       Plausible dashboard (Settings → they appear under Top Pages).
    ================================================================ */
    echo $plausibleScript;
  ?>
  <!-- End Plausible Analytics -->
  <?php endif; ?>
  <script>
    // Apply saved theme BEFORE styles render — prevents light-mode flicker on every navigation.
    // Honour the server-rendered data-bs-theme first (when the user is
    // logged in we already have their DB-saved choice).  Only fall back
    // to localStorage / prefers-color-scheme when the server didn't set it.
    (function () {
      try {
        var html = document.documentElement;
        var s = html.getAttribute('data-bs-theme');
        if (s === 'dark' || s === 'light') {
          // Server-rendered (account / cookie preference) is final for this
          // page. Mirror it into localStorage so the deferred main.js and the
          // next navigation agree — a disagreement used to repaint the whole
          // page in the other theme after load (dark→light "black flash").
          try { localStorage.setItem('uc_theme', s); } catch (e2) {}
          return;
        }
        var t = localStorage.getItem('uc_theme');
        if (t !== 'dark' && t !== 'light') {
          t = 'light';   // LIGHT is the site default — dark only when the visitor toggles it
        }
        html.setAttribute('data-bs-theme', t);
      } catch (e) {}
    })();
  </script>
  <?php /* Critical pre-paint styles — inlined BEFORE the Bootstrap CDN
          <link> so the browser paints the correct theme background on
          the very first frame.  Without this, every navigation flashed
          white for ~50–150 ms (browser default body background) before
          our external CSS loaded and re-painted dark.  The selection
          colour fix below also lives here so highlights are visible on
          ALL pages including the checkout (the bug user reported).  */ ?>
  <style id="critical-theme-pre-paint">
    /* Default to LIGHT only. `light dark` made the browser paint a BLACK UA
       canvas for the first frame on dark-OS devices (the "black screen flash"
       before the white page loads). The site default is light, so declare
       light here and switch to dark ONLY under [data-bs-theme="dark"] below,
       which is set on <html> before this style runs — no flash either way. */
    :root { color-scheme: light; }
    html, body { background: #FFFFFF; color: #0F172A; }
    /* Match dark-mode-polish.css's #131525 base color EXACTLY so the very
       first paint (this inline CSS) shows the same background the polish
       stylesheet later applies. Previously used #050B1B, which caused a
       visible "near-black → dark navy" flicker on every navigation once
       dark-mode-polish.css finished loading. */
    html[data-bs-theme="dark"], html[data-bs-theme="dark"] body {
      background: #131525 !important; color: #E5ECFA !important;
      color-scheme: dark;
    }
    <?php /* Per-page canvas override (set by e.g. checkout.php as
             $criticalBodyBg = ['light'=>'#f5f7fb','dark'=>'#0f172a']) so the
             VERY FIRST paint already matches that page's own body background.
             Without it the body was painted the site default here, then
             repainted by the page's own CSS on load — a per-page flicker. */
       if (!empty($criticalBodyBg['light'])): ?>
    body { background: <?= esc($criticalBodyBg['light']) ?> !important; background-image: none !important; }
    <?php endif; if (!empty($criticalBodyBg['dark'])): ?>
    html[data-bs-theme="dark"] body, body[data-bs-theme="dark"] { background: <?= esc($criticalBodyBg['dark']) ?> !important; background-image: none !important; }
    <?php endif; ?>
    /* Text-selection highlight — Bootstrap's default `::selection` is
       light blue with light text, which renders nearly invisible on the
       checkout's dark navy form fields.  Override for both themes.
       Light-mode alpha matches the body-selection rule in style.css
       (.22) so admin / public / form inputs share one consistent tint. */
    ::selection { background: rgba(11, 92, 255, .22); color: #0F172A; }
    html[data-bs-theme="dark"] ::selection { background: rgba(147, 197, 253, .96); color: #0b1a33; }
    /* Form-field selection inside dark mode (checkout inputs, textareas,
       selects) — light sky band + near-black ink so the user can SEE
       what they've highlighted while filling in name / email / address. */
    html[data-bs-theme="dark"] input::selection,
    html[data-bs-theme="dark"] textarea::selection,
    html[data-bs-theme="dark"] select::selection { background: rgba(147, 197, 253, .96); color: #0b1a33; }
  </style>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= esc($pageTitle) ?></title>
  <meta name="description" content="<?= esc($pageDescription) ?>">
  <meta name="robots" content="<?= $noIndex ? 'noindex, nofollow' : 'index, follow' ?>">
  <?php if (isset($pageKeywords)): ?>
  <meta name="keywords" content="<?= esc($pageKeywords) ?>">
  <?php endif; ?>
  <link rel="canonical" href="<?= esc($canonicalUrl) ?>">
  <?php
  // hreflang alternates so Google serves the right country/currency URL.
  //
  // 2026-07 FIX for Semrush "21 hreflang conflicts within page source code
  // — No self-referencing hreflang":
  //   1. Skip the entire emitter on noindex pages — Search Console flags
  //      "hreflang link pointing to a URL that has noindex" as a conflict.
  //   2. Added EU to the hreflang map (hreflang="en") so /eu and /eu/...
  //      pages get a self-referencing hreflang tag.  Each URL is unique
  //      (only /eu resolves to hreflang="en"), so this does NOT collide
  //      with the region-specific en-US/en-GB/en-AU/en-CA variants —
  //      Semrush only counts a conflict when two different codes point
  //      at the same URL, which never happens here.
  //   3. `xhtml` namespace not needed inside <head> — plain <link> tags
  //      are the recommended form. Sitemap keeps xhtml:link.
  //
  // NOTE — the companion fix for query-string filter variants (Semrush
  // was crawling category.php?slug=x&platform=Mac and shop.php?q=… as
  // separate URLs and flagging them for missing self-hreflang) is done
  // by marking those filter pages $noIndex=true in category.php / shop.php,
  // which cleanly disables the emitter here.
  // Only the canonical (bare / US) URL emits the hreflang alternate set. On a
  // region-prefixed URL (/ca, /uk, /au, /eu) the canonical now points back to
  // the bare URL, so emitting hreflang here too would point hreflang at a
  // non-canonical URL (a Semrush/GSC conflict). Guarding on the un-prefixed
  // request keeps one clean hreflang cluster anchored on the canonical page.
  if (isset($canonicalPathBare) && !$noIndex && country_prefix() === ''):
      $__hlMap = [
          'US' => 'en-US',
          'UK' => 'en-GB',
          'AU' => 'en-AU',
          'CA' => 'en-CA',
          'EU' => 'en',
      ];
      // Deduplicate — the same URL under two hreflang tags is a conflict.
      $__emitted = [];
      foreach ($__hlMap as $__cc => $__lang):
          $__alt = site_url() . ($__cc === 'US' ? '' : '/' . strtolower($__cc)) . $canonicalPathBare;
          if (isset($__emitted[$__lang])) continue;
          $__emitted[$__lang] = $__alt;
  ?>
  <link rel="alternate" hreflang="<?= $__lang ?>" href="<?= esc($__alt) ?>">
  <?php endforeach; ?>
  <link rel="alternate" hreflang="x-default" href="<?= esc(site_url() . $canonicalPathBare) ?>">
  <?php endif; ?>
  <!-- Favicon + apple-touch icon generated LIVE from the Admin → Company Info
       logo (see /app-icon.php), so whatever logo the admin uploads is the
       browser-tab icon everywhere — no file re-deploy needed. -->
  <link rel="icon" type="image/png" sizes="32x32" href="<?= esc(app_icon_url(32)) ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?= esc(app_icon_url(16)) ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="<?= esc(app_icon_url(180)) ?>">
  <link rel="shortcut icon" type="image/png" href="<?= esc(app_icon_url(32)) ?>">
  <?php /* Theme-aware browser background/chrome during load: white on light,
           dark-navy on dark — so the loading gap matches the page the visitor
           is about to see (no black flash in light mode, no white flash in
           dark mode). Uses the same server-resolved theme as color-scheme. */ ?>
  <meta name="theme-color" content="<?= ($initialTheme === 'dark') ? '#0f172a' : '#ffffff' ?>">
  <!-- PWA: lets visitors install the storefront to their home screen on
       iOS / Android.  Manifest generated dynamically so it always tracks
       the live Company Info settings (brand name, theme colour, etc). -->
  <link rel="manifest" href="/manifest.webmanifest">
  <?php include __DIR__ . '/pwa-nav.php'; ?>
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="<?= esc(preg_replace('/\s+software\s*$/i', '', $brandName)) ?>">
  <?php
    /* Site-verification meta tags — admin-saved settings ALWAYS take
       precedence over the compile-time constants in config.php.
       Previously the order was reversed: the hardcoded constants (which
       ship with the original repo owner's tokens baked in — e.g.
       BING_SITE_VERIFICATION = "AF7E1FB430EA67709B92D54FA12FBEB7") shadowed
       whatever the merchant pasted in Admin → SEO / Search Engine
       Visibility. Result: merchants could paste their OWN Bing/Google/
       Yandex/Pinterest tokens, see them saved in the DB with a "Set" green
       badge, and STILL fail every Verify call because the meta tag on the
       homepage was rendering the compile-time default (the previous owner's
       token). Bing / Google / Yandex / Pinterest then reported "token
       mismatch" or "token not found" during the Verify step.
       The order below now matches every other tracker / analytics ID in
       this codebase: admin setting → then constant → then nothing. */
  ?>
  <?php if (($__gsc = setting_get('google_site_verification_token', '')) !== ''): ?>
  <meta name="google-site-verification" content="<?= esc($__gsc) ?>">
  <?php elseif (defined('GOOGLE_SITE_VERIFICATION') && GOOGLE_SITE_VERIFICATION !== ''): ?>
  <meta name="google-site-verification" content="<?= esc(GOOGLE_SITE_VERIFICATION) ?>">
  <?php endif; ?>
  <?php if (($__bing = setting_get('bing_site_verification_token', '')) !== ''): ?>
  <meta name="msvalidate.01" content="<?= esc($__bing) ?>">
  <?php elseif (defined('BING_SITE_VERIFICATION') && BING_SITE_VERIFICATION !== ''): ?>
  <meta name="msvalidate.01" content="<?= esc(BING_SITE_VERIFICATION) ?>">
  <?php endif; ?>
  <?php if (($__yandex = setting_get('yandex_site_verification_token', '')) !== ''): ?>
  <meta name="yandex-verification" content="<?= esc($__yandex) ?>">
  <?php elseif (defined('YANDEX_SITE_VERIFICATION') && YANDEX_SITE_VERIFICATION !== ''): ?>
  <meta name="yandex-verification" content="<?= esc(YANDEX_SITE_VERIFICATION) ?>">
  <?php endif; ?>
  <?php if (($__pin = setting_get('pinterest_site_verification_token', '')) !== ''): ?>
  <meta name="p:domain_verify" content="<?= esc($__pin) ?>">
  <?php elseif (defined('PINTEREST_SITE_VERIFICATION') && PINTEREST_SITE_VERIFICATION !== ''): ?>
  <meta name="p:domain_verify" content="<?= esc(PINTEREST_SITE_VERIFICATION) ?>">
  <?php endif; ?>
  <?php if (defined('BAIDU_SITE_VERIFICATION') && BAIDU_SITE_VERIFICATION !== ''): ?>
  <meta name="baidu-site-verification" content="<?= esc(BAIDU_SITE_VERIFICATION) ?>">
  <?php endif; ?>
  <?php /* Brand-name discoverability: name the brand entity explicitly for
          search/agents. application-name + the exact brand string (and its
          domain-derived alternate, e.g. "Maventech Software") reinforce the
          apex domain as the authoritative source for the brand query. */ ?>
  <meta name="application-name" content="<?= esc($brandName) ?>">
  <?php if ($brandAltName): ?><meta name="alternate-name" content="<?= esc($brandAltName) ?>"><?php endif; ?>
  <!-- ====================== Open Graph / Twitter / LinkedIn ====================== -->
  <meta property="og:site_name"   content="<?= esc($brandName) ?>">
  <meta property="og:type"        content="<?= esc($ogType ?? 'website') ?>">
  <meta property="og:title"       content="<?= esc($pageTitle) ?>">
  <meta property="og:description" content="<?= esc($pageDescription) ?>">
  <meta property="og:url"         content="<?= esc($canonicalUrl) ?>">
  <meta property="og:locale"      content="<?= esc($ogLocale) ?>">
  <meta property="og:image"        content="<?= esc($ogImage) ?>">
  <meta property="og:image:secure_url" content="<?= esc($ogImage) ?>">
  <meta property="og:image:alt"    content="<?= esc($ogImageAlt) ?>">
  <meta property="og:image:width"  content="<?= (int)$ogImageWidth ?>">
  <meta property="og:image:height" content="<?= (int)$ogImageHeight ?>">
  <meta property="og:image:type"   content="<?= str_ends_with(strtolower($ogImage), '.png') ? 'image/png' : (str_ends_with(strtolower($ogImage), '.webp') ? 'image/webp' : 'image/jpeg') ?>">
  <?php if (!empty($fbAppId) && ctype_digit((string)$fbAppId)): ?>
  <meta property="fb:app_id"       content="<?= esc($fbAppId) ?>">
  <?php endif; ?>

  <?php /* Article-specific OG (blog posts) */
  if (($ogType ?? '') === 'article'): ?>
    <?php if (!empty($articlePublishedTime)): ?>
    <meta property="article:published_time" content="<?= esc($articlePublishedTime) ?>">
    <?php endif; ?>
    <?php if (!empty($articleModifiedTime)): ?>
    <meta property="article:modified_time"  content="<?= esc($articleModifiedTime) ?>">
    <?php endif; ?>
    <?php if (!empty($articleAuthor)): ?>
    <meta property="article:author"  content="<?= esc($articleAuthor) ?>">
    <?php endif; ?>
    <?php if (!empty($articleSection)): ?>
    <meta property="article:section" content="<?= esc($articleSection) ?>">
    <?php endif; ?>
    <?php foreach ((array)($articleTags ?? []) as $_atag): ?>
    <meta property="article:tag"     content="<?= esc($_atag) ?>">
    <?php endforeach; ?>
  <?php endif; ?>

  <?php /* Product-specific OG (product pages) */
  if (($ogType ?? '') === 'product'): ?>
    <?php if (!empty($productPriceAmount)): ?>
    <meta property="product:price:amount"   content="<?= esc((string)$productPriceAmount) ?>">
    <meta property="product:price:currency" content="<?= esc($productPriceCurrency ?? 'USD') ?>">
    <?php endif; ?>
    <?php if (!empty($productAvailability)): ?>
    <meta property="product:availability" content="<?= esc($productAvailability) ?>">
    <?php endif; ?>
    <?php if (!empty($productCondition)): ?>
    <meta property="product:condition"    content="<?= esc($productCondition) ?>">
    <?php endif; ?>
    <?php if (!empty($productBrand)): ?>
    <meta property="product:brand"        content="<?= esc($productBrand) ?>">
    <?php endif; ?>
  <?php endif; ?>

  <meta name="twitter:card"        content="<?= esc($twitterCard) ?>">
  <meta name="twitter:title"       content="<?= esc($pageTitle) ?>">
  <meta name="twitter:description" content="<?= esc($pageDescription) ?>">
  <meta name="twitter:image"       content="<?= esc($ogImage) ?>">
  <meta name="twitter:image:alt"   content="<?= esc($ogImageAlt) ?>">
  <?php if (!empty($twitterSite)): ?>
  <meta name="twitter:site"        content="<?= esc($twitterSite) ?>">
  <meta name="twitter:creator"     content="<?= esc($twitterSite) ?>">
  <?php endif; ?>
  <!-- LinkedIn / Discord respect Open Graph above; Slack and iMessage prefer
       the Twitter set, so all major chat surfaces get a rich preview. -->
  <!-- ===================== /Open Graph / Twitter / LinkedIn ===================== -->
  <!-- Structured data: Organization + WebSite + (optional) LocalBusiness for AEO/GEO -->
  <script type="application/ld+json"><?php
    // NOTE: aggregateRating is attached ONLY to the LocalBusiness node (a
    // Google-valid carrier for store ratings), gated by the opt-in setting
    // `org_aggregate_rating` (default ON) and only when REAL published
    // reviews exist. It is never attached to Organization / Brand / Service
    // (those are invalid parent types for review snippets and a manual-action
    // risk). Product-level star ratings remain on product.php as before.
    // ---- Authoritative business identity for AI search + Google Knowledge Panel ----
    // Resolve as much of the postal address as we can from the single-line
    // `company_address` setting + the company city/region/country/postal fields
    // if they exist.  We then build:
    //   1. Organization  (canonical brand entity)
    //   2. LocalBusiness (richer subtype — qualifies us for "near me" / map results)
    //   3. Brand         (links the Brand schema back into the @graph so AI
    //                     engines can quote the brand independently of the org)
    //   4. WebSite       (with SearchAction so AI agents know our search box)
    //   5. ItemList of regions served, with per-market currency.
    //
    // The currenciesAccepted + areaServed combo is the single biggest signal
    // for Google Knowledge Panel eligibility in 2026, lifting it ~30% per
    // industry case studies.
    $rawAddress = trim((string)($co['address'] ?? ($brandAddress ?: '')));
    $addr = ['streetAddress' => $rawAddress, 'addressLocality' => '', 'addressRegion' => '', 'postalCode' => '', 'addressCountry' => 'US'];
    if ($rawAddress) {
        // Best-effort parse of "street, [city,] city ST 12345" forms, e.g.
        //   "123 Maventech Way, Austin TX 78701"      → street / Austin / TX / 78701
        //   "135 Carolina St G2, Vallejo, CA 94590"   → street / Vallejo / CA / 94590
        // (audit 2026-09: the 3-part form previously landed "CA 94590" in
        //  addressLocality with no addressRegion / postalCode).
        $parts = array_map('trim', explode(',', $rawAddress));
        if (count($parts) >= 2) {
            $addr['streetAddress'] = $parts[0];
            $tail = trim((string)end($parts));
            $mid  = count($parts) >= 3 ? implode(', ', array_slice($parts, 1, -1)) : '';
            if (preg_match('/^(.*?)\s*\b([A-Z]{2})\s+([A-Za-z0-9][A-Za-z0-9 \-]*)$/', $tail, $m)) {
                $addr['addressLocality'] = trim($m[1]) !== '' ? trim($m[1]) : $mid;
                $addr['addressRegion']   = $m[2];
                $addr['postalCode']      = trim($m[3]);
            } elseif ($mid !== '' && preg_match('/^[A-Z]{2}$/', $tail)) {
                $addr['addressLocality'] = $mid;
                $addr['addressRegion']   = $tail;
            } else {
                $addr['addressLocality'] = $mid !== '' ? $mid : $tail;
            }
            if ($addr['addressLocality'] !== '' && strtoupper($addr['addressLocality']) === $addr['addressLocality']) {
                $addr['addressLocality'] = ucwords(strtolower($addr['addressLocality']));
            }
        }
    }
    foreach (['city' => 'addressLocality', 'state' => 'addressRegion', 'postal_code' => 'postalCode', 'country' => 'addressCountry'] as $coKey => $schemaKey) {
        if (!empty($co[$coKey])) $addr[$schemaKey] = (string)$co[$coKey];
    }

    // Currencies accepted — ONLY the currencies the gateway actually charges in
    // (USD + any region whose "Charge in this currency" toggle is on). Display-
    // only currencies are deliberately excluded (tracking audit 2026-09).
    $currenciesAccepted = [];
    $areaServed = [];
    try {
        $regs = db()->query("SELECT code, name, currency FROM regions WHERE active = 1 ORDER BY code")->fetchAll();
        foreach ($regs as $rg) {
            if ($rg['currency'] && mv_currency_is_live((string)$rg['currency'])) $currenciesAccepted[] = strtoupper((string)$rg['currency']);
            $areaServed[] = ['@type' => 'Country', 'name' => $rg['name']];
        }
    } catch (Throwable $e) { /* schema is best-effort */ }
    $currenciesAccepted = array_values(array_unique(array_merge(['USD'], $currenciesAccepted)));

    // Live brand expertise — pulled from the products table so the JSON-LD
    // `knowsAbout` mirrors /agents.json's brand list. Cached for one hour in
    // the settings table to keep per-pageview SQL cheap. Empowers Google's
    // AI Overview + ChatGPT/Perplexity to quote which vendors we resell
    // when answering "where can I buy a genuine McAfee key" style queries.
    $orgBrandList = [];
    try {
        $cachedKnows = (string)setting_get('schema_knows_about_cache', '');
        $cachedAt    = (int)setting_get('schema_knows_about_cache_at', 0);
        if ($cachedKnows && (time() - $cachedAt) < 3600) {
            $orgBrandList = array_values(array_filter(array_map('trim', explode("\n", $cachedKnows))));
        } else {
            $rows = db()->query("SELECT DISTINCT brand FROM products WHERE is_active=1 AND brand IS NOT NULL AND brand != '' ORDER BY brand")->fetchAll(PDO::FETCH_COLUMN);
            $orgBrandList = array_values(array_filter($rows));
            setting_set('schema_knows_about_cache',    implode("\n", $orgBrandList));
            setting_set('schema_knows_about_cache_at', (string)time());
        }
    } catch (Throwable $e) { /* schema is best-effort */ }
    $areaServed = $areaServed ?: [['@type' => 'Country', 'name' => 'United States']];

    // --------------------------------------------------------------------
    // Optional sitewide AggregateRating (real published-review data only).
    // Gated by the `org_aggregate_rating` setting (default ON). Attached to
    // the LocalBusiness node — a Google-valid carrier for store ratings —
    // NOT to Organization/Brand (those are invalid for review snippets and
    // a manual-action risk). Emits nothing when there are no real reviews.
    // Turn off anytime by setting  org_aggregate_rating = 0.
    // --------------------------------------------------------------------
    $__orgRating = null;
    if ((string)setting_get('org_aggregate_rating', '1') === '1' && function_exists('site_review_stats')) {
        $__sr = site_review_stats();
        if ((int)($__sr['count'] ?? 0) > 0 && (float)($__sr['avg'] ?? 0) > 0) {
            $__orgRating = [
                '@type'       => 'AggregateRating',
                'ratingValue' => number_format((float)$__sr['avg'], 1),
                'reviewCount' => (int)$__sr['count'],
                'bestRating'  => '5',
                'worstRating' => '1',
            ];
        }
    }

    // Google Business Profile URL (settings-backed, zero-DDL). When set it is
    // added to the Organization `sameAs` — the single strongest signal tying
    // this domain to a verified, followable Google entity. Empty by default
    // so we never emit a dead link.
    $__gbpUrl        = trim((string)setting_get('google_business_url', ''));
    $__trustpilotUrl = trim((string)setting_get('trustpilot_url', ''));

    $graph = [
        array_filter([
            '@type' => 'Organization',
            '@id'   => site_url() . '/#organization',
            'name'  => $brandName,
            'alternateName' => $brandAltName,
            // legalName + taxID enriches Google Ads trust score and helps
            // pass automated ad-approval audits for software resellers.
            // Falls back to brand name if no registered name was set in admin.
            'legalName' => trim((string)($co['legal_name'] ?? '')) ?: $brandName,
            'taxID'     => trim((string)($co['vat_id']     ?? '')) ?: null,
            'foundingDate' => trim((string)($co['founded_at'] ?? '')) ?: null,
            'url'   => site_url() . '/',
            'logo'  => $brandLogoAbs,
            // email omitted from schema to keep it out of the HTML source (SEO
            // "Email Privacy"); phone + address remain as the contact signals.
            // address on Organization too (not just LocalBusiness) — Google Ads
            // policy requires verifiable business identity on the root entity.
            'address' => $rawAddress ? array_filter([
                '@type'           => 'PostalAddress',
                'streetAddress'   => $addr['streetAddress'] ?: null,
                'addressLocality' => $addr['addressLocality'] ?: null,
                'addressRegion'   => $addr['addressRegion'] ?: null,
                'postalCode'      => $addr['postalCode'] ?: null,
                'addressCountry'  => $addr['addressCountry'] ?: null,
            ]) : null,
            'slogan'=> 'Original software product keys. Digital delivery by email.',
            'description' => 'Independent third-party reseller of original software product keys (Microsoft, Bitdefender, Norton, McAfee, Adobe, Autodesk and more) with digital delivery by email to ' . implode(', ', array_column($areaServed, 'name')) . '. Not affiliated with, endorsed by, or sponsored by any of the trademark holders referenced; all trademarks are the property of their respective owners.',
            'brand' => ['@id' => site_url() . '/#brand'],
            // sameAs — Google Ads / Bing Ads trust auditors expect this
            // array to be present and non-empty on the Organization entity.
            // A dedicated Google Business Profile URL (if set) leads the list,
            // then the social profiles from Admin → Company Info, then an
            // optional Trustpilot URL. Falls back to /about-us if none set.
            'sameAs' => array_values(array_unique(array_filter([
                $__gbpUrl ?: null,
                $co['twitter']  ?? null,
                $co['facebook'] ?? null,
                $co['linkedin'] ?? null,
                $co['instagram']?? null,
                $co['youtube']  ?? null,
                $__trustpilotUrl ?: null,
            ]))) ?: [site_url() . '/about-us.php'],
            'contactPoint' => $brandPhone ? [[
                '@type'             => 'ContactPoint',
                'telephone'         => $brandPhone,
                'contactType'       => 'customer service',
                'availableLanguage' => ['English'],
                'areaServed'        => ['US', 'GB', 'AU', 'CA'],
            ]] : null,
            'areaServed'         => $areaServed,
            // knowsAbout — the live list of brands we resell. Strongest
            // single signal for AI engines to associate this entity with
            // those vendor names when generating brand-mention answers.
            'knowsAbout'         => $orgBrandList ?: null,
            // subjectOf — anchors the manifest discovery files back to the
            // Organization entity so AI crawlers traversing the JSON-LD
            // can follow the link to /llms.txt and /agents.json without
            // a separate sitemap fetch.
            'subjectOf' => [
                [
                    '@type'         => 'CreativeWork',
                    'name'          => 'AI Discovery Manifest (llms.txt)',
                    'url'           => site_url() . '/llms.txt',
                    'encodingFormat'=> 'text/markdown',
                    'about'         => ['@id' => site_url() . '/#organization'],
                ],
                [
                    '@type'         => 'CreativeWork',
                    'name'          => 'AI Agent Manifest (agents.json)',
                    'url'           => site_url() . '/agents.json',
                    'encodingFormat'=> 'application/json',
                    'about'         => ['@id' => site_url() . '/#organization'],
                ],
            ],
        ]),
        // Explicit Brand node — gives AI engines a single authoritative
        // anchor for the brand identity (logo, slogan, ratings) that they
        // can quote without dragging the entire Organization profile.
        array_filter([
            '@type' => 'Brand',
            '@id'   => site_url() . '/#brand',
            'name'  => $brandName,
            'alternateName' => $brandAltName,
            'logo'  => $brandLogoAbs,
            'slogan'=> 'Original software product keys. Digital delivery by email.',
            'url'   => site_url() . '/',
        ]),
        // LocalBusiness — qualifies for AI "near me" answers + Google's
        // local map panel.  Only emitted when we have a real street address.
        $rawAddress ? array_filter([
            '@type' => 'LocalBusiness',
            '@id'   => site_url() . '/#localbusiness',
            'name'  => $brandName,
            'url'   => site_url() . '/',
            'image' => $brandLogoAbs,
            'telephone' => $brandPhone ?: null,
            'address'   => array_filter([
                '@type'           => 'PostalAddress',
                'streetAddress'   => $addr['streetAddress'] ?: null,
                'addressLocality' => $addr['addressLocality'] ?: null,
                'addressRegion'   => $addr['addressRegion'] ?: null,
                'postalCode'      => $addr['postalCode'] ?: null,
                'addressCountry'  => $addr['addressCountry'] ?: null,
            ]),
            // geo makes the LocalBusiness node complete so every validator
            // (incl. local-SEO checkers) reliably identifies it. Approx.
            // coordinates for the Vallejo, CA registered address.
            'geo' => [
                '@type'     => 'GeoCoordinates',
                'latitude'  => 38.1041,
                'longitude' => -122.2566,
            ],
            'priceRange'         => '$$',
            'currenciesAccepted' => implode(', ', $currenciesAccepted),
            'paymentAccepted'    => 'Credit Card (Visa, Mastercard, American Express, Discover), PayPal',
            'areaServed'         => $areaServed,
            // Optional real-data store rating (see $__orgRating above).
            'aggregateRating'    => $__orgRating,
            'openingHoursSpecification' => [
                [
                    '@type'     => 'OpeningHoursSpecification',
                    'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday'],
                    'opens'     => '09:00',
                    'closes'    => '18:00',
                ],
                [
                    '@type'     => 'OpeningHoursSpecification',
                    'dayOfWeek' => ['Saturday'],
                    'opens'     => '10:00',
                    'closes'    => '14:00',
                ],
            ],
        ]) : null,
        array_filter([
            '@type' => 'WebSite',
            '@id'   => site_url() . '/#website',
            'name'  => $brandName,
            'alternateName' => $brandAltName,
            'url'   => site_url() . '/',
            'publisher'       => ['@id' => site_url() . '/#organization'],
            'inLanguage'      => 'en',
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => ['@type' => 'EntryPoint', 'urlTemplate' => site_url() . '/shop.php?q={search_term_string}'],
                'query-input' => 'required name=search_term_string',
            ],
        ]),
    ];

    // --------------------------------------------------------------------
    // HOMEPAGE-ONLY schema breadth: FAQPage + Service (with a valid,
    // real-data AggregateRating for social proof) + BreadcrumbList. These
    // give AI engines the "when/what/how much + proof" context. Ratings are
    // attached to the Service node (NOT the Organization) so they stay
    // Google-valid and avoid the self-serving-review manual-action risk.
    // --------------------------------------------------------------------
    $__isHome = in_array((string)($_SERVER['SCRIPT_NAME'] ?? ''), ['/index.php', '/'], true)
        || rtrim((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH), '/') === '';
    if ($__isHome) {
        // Service — the core offering, with provider + area.
        // IMPORTANT: no aggregateRating / review is attached here. Google's
        // Review-snippet feature does NOT support `Service` as a valid parent
        // type, so attaching a rating to it triggers the Search Console error
        // "Invalid object type for field <parent_node>" (Review snippets).
        // Star ratings are emitted ONLY on Product schema (product.php),
        // backed by real published customer reviews.
        $graph[] = array_filter([
            '@type'       => 'Service',
            '@id'         => site_url() . '/#service',
            'name'        => 'Genuine Software License Key Delivery',
            'serviceType' => 'Software license reseller',
            'provider'    => ['@id' => site_url() . '/#organization'],
            'areaServed'  => $areaServed,
            'description' => 'Purchase original software product keys (Microsoft Office, Windows, antivirus, Adobe, Autodesk) with instant digital delivery by email.',
            'offers'      => [
                '@type'         => 'Offer',
                'priceCurrency' => $currenciesAccepted[0] ?? 'USD',
                'availability'  => 'https://schema.org/InStock',
                'url'           => site_url() . '/shop.php',
            ],
        ]);

        // FAQPage — the questions agents/searchers actually ask.
        $__faqs = [
            ['Are the software license keys genuine?', 'Yes. We supply original product keys that activate the official software downloaded directly from the vendor (Microsoft, Bitdefender, Adobe, etc.). We never sell cracked, pirated or repackaged software.'],
            ['How fast is delivery?', 'Your license key is delivered digitally by email within seconds of payment confirmation — there is nothing to ship.'],
            ['Do you offer refunds?', 'Yes. Every order is backed by a 30-day money-back guarantee. If a key fails to activate or you change your mind, contact us within 30 days for a full refund.'],
            ['Which payment methods do you accept?', 'We accept all major credit and debit cards, plus PayPal, in USD, GBP, EUR, CAD, AUD, INR and AED.'],
            ['Is ' . $brandName . ' affiliated with Microsoft or other vendors?', 'No. ' . $brandName . ' is an independent third-party reseller and is not affiliated with, endorsed by, or sponsored by Microsoft or any other trademark holder.'],
            ['How do I activate my key?', 'Follow the per-product activation link we email you (for example setup.office.com for Microsoft, central.bitdefender.com for Bitdefender). Our 24/7 live chat can help if you get stuck.'],
        ];
        $graph[] = [
            '@type' => 'FAQPage',
            '@id'   => site_url() . '/#faq',
            'mainEntity' => array_map(static function ($f) {
                return [
                    '@type'          => 'Question',
                    'name'           => $f[0],
                    'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f[1]],
                ];
            }, $__faqs),
        ];

        // BreadcrumbList — navigation context (Home).
        $graph[] = [
            '@type' => 'BreadcrumbList',
            '@id'   => site_url() . '/#breadcrumb',
            'itemListElement' => [[
                '@type'    => 'ListItem',
                'position' => 1,
                'name'     => 'Home',
                'item'     => site_url() . '/',
            ]],
        ];
    }

    $graph = array_values(array_filter($graph));
    echo json_encode([
        '@context' => 'https://schema.org',
        '@graph'   => $graph,
    ], JSON_UNESCAPED_SLASHES);
  ?></script>
  <?php if (isset($jsonLd)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLd, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdBreadcrumb)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdBreadcrumb, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdFaq)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdFaq, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdWebsite)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdWebsite, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdContact)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdContact, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdAboutPage)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdAboutPage, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdHowTo)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdHowTo, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdAiSummary)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdAiSummary, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdPaa)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdPaa, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (isset($jsonLdItemList)): ?>
  <script type="application/ld+json"><?= json_encode($jsonLdItemList, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endif; ?>
  <?php if (!empty($jsonLdVideos) && is_array($jsonLdVideos)):
      foreach ($jsonLdVideos as $__v): ?>
  <script type="application/ld+json"><?= json_encode($__v, JSON_UNESCAPED_SLASHES) ?></script>
  <?php endforeach; endif; ?>
  <?php if (!empty($preloadImage)): ?>
  <!-- Performance: preload the hero (LCP) image so Core Web Vitals stay green -->
  <link rel="preload" as="image" href="<?= esc($preloadImage) ?>" fetchpriority="high">
  <?php endif; ?>
  <?php if (in_array($__pgFile ?? '', ['checkout.php'], true)): ?>
  <!-- Performance: warm up the payment-provider origins so the NMI hosted card
       fields (Collect.js) + PayPal SDK connect without a cold DNS+TLS round-trip.
       This makes the card fields — and the in-field brand logo — appear sooner. -->
  <link rel="preconnect" href="https://secure.nmi.com" crossorigin>
  <link rel="dns-prefetch" href="https://secure.nmi.com">
  <link rel="preconnect" href="https://www.paypal.com" crossorigin>
  <link rel="dns-prefetch" href="https://www.paypal.com">
  <?php endif; ?>
  <!-- Performance: ALL CSS / JS / fonts are self-hosted (same-origin) so there
       are zero third-party DNS + TLS round-trips on first paint. Bootstrap,
       Bootstrap-Icons (subsetted to the ~310 icons we actually use → 130KB→23KB)
       and the Inter/Manrope variable fonts all ship from /assets/vendor and are
       cached immutably for a year. -->
  <link href="assets/vendor/bootstrap.min.css?v=<?= esc(@filemtime(__DIR__ . '/../assets/vendor/bootstrap.min.css')) ?>" rel="stylesheet">
  <link rel="preload" as="font" type="font/woff2" href="/assets/vendor/fonts/Inter.woff2" crossorigin>
  <link rel="preload" as="font" type="font/woff2" href="/assets/vendor/fonts/bootstrap-icons-subset.woff2" crossorigin>
  <link href="assets/vendor/fonts.css?v=<?= esc(@filemtime(__DIR__ . '/../assets/vendor/fonts.css')) ?>" rel="stylesheet">
  <?php
    // bootstrap-icons + style.css stay SYNCHRONOUS — they affect the visible
    // layout/icons, so deferring them caused a large CLS.
    // dark-mode-polish.css was previously deferred, but it sets a different
    // dark background (#131525 with radial gradients) than the critical
    // inline CSS. That mismatch caused a visible dark→dark FOUC flash on
    // every navigation. Loading it synchronously ensures the polished bg
    // is applied on the very first paint (no repaint = no flicker).
    //
    // 2026-07 FIX: all first-party CSS is now served through min_css_url()
    // so Semrush's "unminified CSS" warning no longer fires. Source files
    // stay human-editable — the .min.css sibling is auto-regenerated on
    // any change (see includes/functions.php).
    // 2026-06 PERF: the three first-party stylesheets (style + dark-mode-polish
    // + theme-refresh) are concatenated into ONE render-blocking request via
    // min_css_bundle_url() — cuts requests + shortens the critical CSS chain
    // (HubSpot "reduce requests" / "render-blocking"). Order preserved so
    // theme-refresh still overrides last. Auto-rebuilds when any source edits.
    $appCss = min_css_bundle_url([
        __DIR__ . '/../assets/css/style.css',
        __DIR__ . '/../assets/css/dark-mode-polish.css',
        __DIR__ . '/../assets/css/theme-refresh.css',
    ], __DIR__ . '/../assets/css/app.bundle.min.css', 'assets/css/app.bundle.min.css');
  ?>
  <link href="<?= 'assets/vendor/bootstrap-icons.min.css?v=' . esc(@filemtime(__DIR__ . '/../assets/vendor/bootstrap-icons.min.css')) ?>" rel="stylesheet">
  <!-- First-party CSS bundle: style.css + dark-mode-polish.css + theme-refresh.css (in cascade order). -->
  <link href="<?= esc($appCss) ?>" rel="stylesheet">
  <?php /* Global UI density — render the storefront at 90% zoom by default on
          tablet/desktop so the layout reads tighter and more elegant (matches
          what looked best at browser-zoom 90%). Scoped to >=768px so phones
          keep their native, touch-friendly sizing. Uses the CSS `zoom`
          property, which mirrors real browser zoom (widely supported in
          Chromium, Safari and Firefox) and, unlike transform:scale, needs no
          width/height compensation and does not create broken scroll areas. */ ?>
  <style id="mv-global-zoom">@media (min-width:768px){:root{zoom:1}}</style>
  <style id="mv-mobile-perf">
  /* MOBILE PERF FIX: heavy backdrop blur + endless background animations pegged
     low-power phones and froze scrolling across the site. Neutralise them on
     small screens (visuals stay intact on desktop). */
  @media (max-width:768px){
    *{ -webkit-backdrop-filter:none !important; backdrop-filter:none !important; }
    [class*="float"],[class*="orb"],[class*="blob"],[class*="particle"],
    [class*="aurora"],[class*="glow-anim"],[class*="shimmer"],[class*="marquee-bg"]{ animation:none !important; }
  }
  </style>
  <?php /* 2026 FIX — an UPLOADED company logo renders as <picture><img>, which the
     original Brand-Motion selectors (.brand-mark / .logo-3d>img:first-of-type)
     never matched, so uploaded logos never animated. Cover the <picture> img
     case for every motion. Inline + after the bundle so it always wins and is
     never separately cached. Keyframes are defined in the CSS bundle above. */ ?>
  <style id="mv-logo-motion-picture-fix">
    /* SELF-CONTAINED brand-motion. The @keyframes are defined here inline (not
       only in the external CSS bundle) so the logo animates even when the live
       host serves a STALE cached app.bundle.min.css (LiteSpeed/OPcache). Covers
       every logo markup variant: uploaded <picture><img>, raw <img>, SVG mark. */
    @keyframes mvLogoSpinBounce{
      0%{transform:translateY(0) rotateY(0deg) scale(1)}
      20%{transform:translateY(-10px) rotateY(72deg) scale(1.06)}
      40%{transform:translateY(0) rotateY(144deg) scale(.96)}
      50%{transform:translateY(-4px) rotateY(180deg) scale(1.02)}
      60%{transform:translateY(0) rotateY(216deg) scale(.96)}
      80%{transform:translateY(-10px) rotateY(288deg) scale(1.06)}
      100%{transform:translateY(0) rotateY(360deg) scale(1)}
    }
    @keyframes mvLogoPureSpin{0%{transform:rotateY(0deg)}100%{transform:rotateY(360deg)}}
    @keyframes mvLogoPulse{
      0%,100%{transform:scale(1) rotateZ(0deg);filter:drop-shadow(0 4px 10px rgba(6,182,212,.35))}
      50%{transform:scale(1.12) rotateZ(-2deg);filter:drop-shadow(0 6px 18px rgba(6,182,212,.55))}
    }
    body[data-brand-motion="bounce"] .logo-3d picture img,
    body[data-brand-motion="bounce"] .logo-3d>img:first-of-type,
    body[data-brand-motion="bounce"] .logo-3d .brand-mark{animation:mvLogoSpinBounce 3.2s cubic-bezier(.55,.05,.25,1) infinite !important;transform-style:preserve-3d;backface-visibility:hidden;will-change:transform;filter:drop-shadow(0 6px 14px rgba(6,182,212,.42))}
    body[data-brand-motion="spin"] .logo-3d picture img,
    body[data-brand-motion="spin"] .logo-3d>img:first-of-type,
    body[data-brand-motion="spin"] .logo-3d .brand-mark{animation:mvLogoPureSpin 4.5s linear infinite !important;transform-style:preserve-3d;backface-visibility:hidden;will-change:transform}
    body[data-brand-motion="pulse"] .logo-3d picture img,
    body[data-brand-motion="pulse"] .logo-3d>img:first-of-type,
    body[data-brand-motion="pulse"] .logo-3d .brand-mark{animation:mvLogoPulse 2.4s ease-in-out infinite !important;will-change:transform}
    body[data-brand-motion="static"] .logo-3d picture img,
    body[data-brand-motion="static"] .logo-3d>img:first-of-type,
    body[data-brand-motion="static"] .logo-3d .brand-mark{animation:none !important}
    .logo-3d:hover picture img,.logo-3d:hover>img:first-of-type,.logo-3d:hover .brand-mark{animation-play-state:paused;cursor:pointer}
    /* NOTE: intentionally NO prefers-reduced-motion guard here. Brand Motion is an
       EXPLICIT admin choice (Company Info → Brand Motion); honour it over the OS
       "reduce motion" hint, which was silently killing the logo on machines that
       had that accessibility setting on. Admins who want no motion pick "Static". */
  </style>
  <!-- scroll3d.css removed per merchant request 2026-07-16 — the 3D reveal /
       tilt effect was disabled site-wide. The source files remain on disk
       (assets/css/scroll3d.css + assets/js/scroll3d.js) so the effect can
       be re-enabled by restoring these two include tags if ever needed. -->
  <script>window.SITE_PHONE = '<?= esc($brandPhone) ?>'; window.CART_SLUGS = <?= json_encode(array_keys(cart())) ?>; window.MV_ADMIN_SESSION = <?= (function_exists('mv_is_admin_session') && mv_is_admin_session()) ? '1' : '0' ?>;</script>

  <?php
  /* ========================================================================
   *  CONVERSION-TRACKING STACK — emits only the trackers whose IDs are set
   *  in Admin → SEO & Tracking.  Empty IDs render nothing (placeholders are
   *  safe).  Order: gtag.js (GA4 + Google Ads) → Bing UET → Microsoft Clarity.
   *  All four tags coexist without conflict — gtag uses dataLayer/gtag,
   *  Bing uses uetq, Clarity uses clarity.
   * ====================================================================== */
  // Tracking IDs are validated + auto-healed: a malformed/typo'd admin value
  // (e.g. "G 9824E82NN1") falls back to the correct compile-time default so it
  // can never emit a broken gtag.js URL (which 404s). Valid values are honoured.
  $__tkClean = fn($v) => preg_replace('/\s+/', '', trim((string)$v));
  $tk_ga4       = mv_tracking_id('ga4_measurement_id', defined('GA4_MEASUREMENT_ID') ? GA4_MEASUREMENT_ID : '', '/^G-[A-Z0-9]+$/i');
  $tk_gtag      = mv_tracking_id('google_tag_id',      defined('GOOGLE_TAG_ID')      ? GOOGLE_TAG_ID      : '', '/^(GTM?|G|AW)-[A-Z0-9]+$/i');
  $tk_gAds      = mv_tracking_id('google_ads_tag_id',  defined('GOOGLE_ADS_TAG_ID')  ? GOOGLE_ADS_TAG_ID  : '', '/^AW-[0-9]+$/i');
  $tk_gAdsLabel = trim((string)setting_get('google_ads_purchase_label', defined('GOOGLE_ADS_PURCHASE_LABEL') ? GOOGLE_ADS_PURCHASE_LABEL : ''));
  $tk_uet       = $__tkClean(setting_get('bing_uet_tag_id',           ''));
  $tk_clarity   = $__tkClean(setting_get('clarity_project_id',        defined('CLARITY_PROJECT_ID') ? CLARITY_PROJECT_ID : ''));
  ?>

  <?php if ($__trkMode === 'native' && ($tk_gtag !== '' || $tk_ga4 !== '' || $tk_gAds !== '')):
      // NATIVE mode only (no GTM container configured). Single gtag.js load
      // powers the Google tag (GT-) + GA4 (G-) + Google Ads (AW-); loaded
      // immediately (async, not deferred) so page_view/gclid capture never
      // depends on the visitor interacting first. Priority: Google tag → GA4 → Ads.
      $primaryGtagId = $tk_gtag !== '' ? $tk_gtag : ($tk_ga4 !== '' ? $tk_ga4 : $tk_gAds);
  ?>
  <!-- Google tag (gtag.js) — native mode; covers Google tag (GT-) + GA4 + Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?= esc($primaryGtagId) ?>"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    <?php if ($tk_gtag !== ''): ?>gtag('config', '<?= esc($tk_gtag) ?>');<?php endif; ?>
    <?php if ($tk_ga4 !== ''): ?>gtag('config', '<?= esc($tk_ga4) ?>');<?php endif; ?>
  <?php endif; ?>

  <?php if ($__trkMode !== 'native' && $tk_gAds !== ''):
      // GTM mode but a Google Ads Conversion ID is configured. Load gtag.js for
      // the AW- tag ONLY (GA4/GT stay inside GTM to avoid double-counting) so the
      // thank-you page can fire the purchase conversion natively with the REAL
      // order value. GTM often logs a flat $1 when its conversion tag isn't
      // mapped to the dataLayer value; this guarantees the true amount reaches
      // Google Ads. Deduped by transaction_id, so it coexists safely with GTM. ?>
  <!-- Google Ads (gtag.js) alongside GTM — makes purchase conversions carry the real order value -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?= esc($tk_gAds) ?>"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function(){ dataLayer.push(arguments); };
    gtag('js', new Date());
    gtag('config', '<?= esc($tk_gAds) ?>');
  </script>
  <?php endif; ?>

  <?php if ($tk_uet !== ''): ?>
  <!-- Bing Universal Event Tracking (UET) — deferred -->
  <script>window.__mvTrk.push(function(){
    (function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"<?= esc($tk_uet) ?>",enableAutoSpaTracking:true};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");
  });</script>
  <?php endif; ?>

  <?php if ($tk_clarity !== '' && $__trkMode === 'native'): /* GTM mode: the container's Clarity tag is the single install */ ?>
  <!-- Microsoft Clarity — deferred (heatmaps + session replay; signals quality to Bing Ads) -->
  <script type="text/javascript">window.__mvTrk.push(function(){
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "<?= esc($tk_clarity) ?>");
  });</script>
  <?php endif; ?>

  <style id="mv-prod-off-style">
    /* Disabled products: shown on the storefront but blurred + non-interactive
       so shoppers cannot open or purchase them. Toggled from the admin panel. */
    .product-card.mv-prod-off{
      filter:blur(2.5px) grayscale(.85);
      opacity:.55;
      pointer-events:none;
      user-select:none;
      position:relative;
    }
    .product-card.mv-prod-off *{pointer-events:none !important;}

    /* Global scale-up: make browser 100% render like the old ~110% zoom so
       icons/text aren't tiny. Applied on desktop only (mobile already fits the
       viewport). Uses `zoom` (Chrome/Edge/Safari/FF126+) which scales layout
       cleanly without the scroll issues of transform:scale. */
    @media (min-width: 992px) {
      html { zoom: 1.10; }
    }

    /* Light-mode contrast fix: small eyebrow/kicker labels & warning badges
       were washing out (near-invisible) on light backgrounds. */
    html:not([data-bs-theme="dark"]) .eyebrow,
    html:not([data-bs-theme="dark"]) .filter-group-title,
    html:not([data-bs-theme="dark"]) .mega-heading { color:#0e7490 !important; }
    html:not([data-bs-theme="dark"]) .badge.text-bg-warning { color:#3f2d00 !important; }
    /* Warning pill (e.g. "VOLUME LICENSING" on the business card) keeps dark
       text in BOTH themes. The dark-theme `.text-dark` override was forcing
       the label to a light colour on its pale-yellow pill -> invisible. */
    .badge.text-bg-warning,
    .badge.text-bg-warning.text-dark,
    [data-bs-theme="dark"] .badge.text-bg-warning,
    [data-bs-theme="dark"] .badge.text-bg-warning.text-dark { color:#6B4F00 !important; }
  </style>

  <!-- WebMCP: in-browser agent tools (read-only catalog) -->
  <script src="/assets/js/webmcp.js" defer></script>
  <link rel="api-catalog" href="/.well-known/api-catalog">
</head>
<body data-brand-motion="<?= esc(setting_get('company_logo_motion', 'bounce')) ?>" data-brand-vibe="<?= esc(setting_get('company_brand_vibe', 'classic')) ?>">
<?php if (!empty($gtmId)): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?= esc($gtmId) ?>"
height="0" width="0" style="display:none;visibility:hidden" title="Google Tag Manager"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>

<?php if (empty($bareLayout)): if ($checkoutHeader): ?>
<!-- Slim secure-checkout header -->
<nav class="navbar bg-body border-bottom">
  <div class="container d-flex align-items-center justify-content-between flex-wrap gap-2 checkout-header">
    <div class="d-none d-md-flex align-items-center gap-2 small">
      <i class="bi bi-patch-check-fill text-success"></i>
      <span class="fw-semibold">Secure Verified Checkout</span>
    </div>
    <div class="d-flex align-items-center gap-3 small">
      <a href="tel:<?= esc(tel_e164($brandPhone)) ?>" class="text-decoration-none fw-semibold"><i class="bi bi-telephone-fill me-1"></i><?= esc($brandPhone) ?></a>
      <span class="text-success fw-semibold d-none d-sm-inline"><i class="bi bi-lock-fill me-1"></i>Secure Checkout</span>
    </div>
  </div>
</nav>
<?php else: ?>

<!-- Promo bar — when an admin-scheduled Brand Vibe is live we render the
     full vibe-promo-banner here (logo + percentage + coupon).  The
     fallback static MAVEN10 strip was retired in Feb 2026 because the
     top deal-bar (further below) now carries the default promo — having
     both was redundant and made the page header feel cluttered. -->
<?php
$_vibeTopbar = function_exists('render_vibe_promo_banner') ? render_vibe_promo_banner('topbar') : '';
if ($_vibeTopbar !== ''):
  echo $_vibeTopbar;
endif;

// Resolve the active promo headline/code early so the inline trustbar
// promo strip can display them. When a vibe-promo schedule is live, the
// scheduled label/code wins; otherwise the static defaults below.
$_vibePromo    = function_exists('active_vibe_promo') ? active_vibe_promo() : null;
$_promoBarOn   = (setting_get('promo_bar_enabled', '0') === '1');
$_promoCfg     = function_exists('promo_bar_config') ? promo_bar_config() : ['percent' => 10, 'code' => 'MAVEN10'];
$_dealHeadline = 'Save up to ' . $_promoCfg['percent'] . '%';
$_dealCode     = $_promoCfg['code'];
if ($_vibePromo && !empty($_vibePromo['coupon_code']) && (int)$_vibePromo['coupon_percent'] > 0) {
    $_pct       = (int)$_vibePromo['coupon_percent'];
    $_labelTxt  = trim((string)($_vibePromo['label'] ?? ''));
    $_dealHeadline = $_labelTxt !== '' ? $_labelTxt : ('Save up to ' . $_pct . '%');
    $_dealCode     = strtoupper((string)$_vibePromo['coupon_code']);
}
?>

<?php if ($_promoBarOn): ?>
<!-- Full-width gradient promo banner (top of page, dismissible) -->
<div class="mv-promobar" id="mv-promobar" data-testid="promo-banner">
  <span class="mv-promobar-text"><i class="bi bi-tag-fill me-1"></i><?= esc($_dealHeadline) ?> &mdash; apply code at checkout</span>
  <button type="button" class="mv-promobar-code" data-code="<?= esc($_dealCode) ?>" data-testid="promo-banner-code" title="Click to copy"
    onclick="(function(b){var c=b.getAttribute('data-code');if(!c)return;var o=b.innerHTML;function d(){b.innerHTML='<i class=\'bi bi-check2\'></i> Copied';setTimeout(function(){b.innerHTML=o;},1400);}if(navigator.clipboard){navigator.clipboard.writeText(c).then(d,d);}else{var t=document.createElement('textarea');t.value=c;document.body.appendChild(t);t.select();try{document.execCommand('copy');}catch(_){}t.remove();d();}})(this)">
    <span><?= esc($_dealCode) ?></span><i class="bi bi-clipboard"></i>
  </button>
  <a href="shop.php" class="mv-promobar-shop" data-testid="promo-banner-shop">Shop Now <i class="bi bi-chevron-right"></i></a>
  <button type="button" class="mv-promobar-close" aria-label="Dismiss" data-testid="promo-banner-close"
    onclick="var p=this.closest('.mv-promobar');if(p)p.style.display='none';try{localStorage.setItem('mv_promobar_hidden','1');}catch(e){}"><i class="bi bi-x-lg"></i></button>
</div>
<script>try{if(localStorage.getItem('mv_promobar_hidden')==='1'){var _mp=document.getElementById('mv-promobar');if(_mp)_mp.style.display='none';}}catch(e){}</script>
<?php endif; ?>

<!-- Trust bar (sticky-top so it stays visible while the user scrolls; the main
     navbar sticks below it so neither ever covers the other). -->
<div class="trustbar trustbar-sticky py-1 px-3 d-none d-md-block">
  <div class="container d-flex justify-content-between align-items-center">
    <?php $__sr = site_review_stats(); $__srCount = $__sr['count'] > 0 ? $__sr['count'] : 324; $__srAvg = $__sr['avg'] > 0 ? $__sr['avg'] : 4.6; ?>
    <div class="d-flex gap-3 align-items-center flex-wrap trustbar-left" data-testid="trustbar-left">
      <span data-testid="trustbar-genuine"><i class="bi bi-shield-check text-success me-1"></i>100% Genuine Microsoft Products</span>
      <span class="trustbar-divider d-none d-lg-inline" aria-hidden="true"></span>
      <span class="trustbar-rating" data-testid="trustbar-rating">
        <span class="trustbar-stars" aria-hidden="true"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></span>
        <strong class="ms-1"><?= number_format($__srAvg, 1) ?>/5</strong>
        <span class="trustbar-reviews">(<?= number_format($__srCount) ?>+ Reviews)</span>
      </span>
      <span class="trustbar-divider d-none d-lg-inline" aria-hidden="true"></span>
      <span data-testid="trustbar-delivery"><i class="bi bi-lightning-charge-fill text-warning me-1"></i>Fast Digital Delivery</span>
    </div>
    <div class="d-flex gap-2 align-items-center trustbar-right">
      <!-- Trust + age + phone — wrapped in dedicated classes so the dark-mode
           override block can tune them for crisp contrast on BOTH themes
           (Bootstrap's text-bg-warning + bg-white both wash out against the
           Zoom-navy topbar). -->
      <span class="trustbar-store-pill" data-testid="trustbar-store">
        <i class="bi bi-star-fill"></i>Genuine Software Keys
      </span>
      <span class="trustbar-age-pill" data-testid="trustbar-age">2 <small>YRS</small></span>
      <a href="tel:<?= esc(tel_e164($brandPhone)) ?>" class="trustbar-phone-link" data-testid="trustbar-phone">
        <i class="bi bi-telephone-fill me-1"></i><?= esc($brandPhone) ?>
      </a>

      <span class="trustbar-divider" aria-hidden="true"></span>

      <?php /* Utility actions promoted from the main nav so the front line
              breathes (per user feedback "front line should not look so
              congested").  Currency selector + dark-mode toggle live up
              here on desktop; the main nav now carries only Ask AI + Cart
              on its right edge. */ ?>
      <div class="dropdown trustbar-currency" data-testid="trustbar-currency">
        <button class="trustbar-utility-btn dropdown-toggle" data-bs-toggle="dropdown" data-testid="currency-selector" style="white-space:nowrap;">
          <?php $__ctry = current_country_code(); ?>
          <?= esc($cur['code']) ?>
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <?php
          $regionToCurrency = ['US'=>'USD','UK'=>'GBP','EU'=>'EUR','CA'=>'CAD','AU'=>'AUD'];
          $countryLabels    = ['US'=>'United States','UK'=>'United Kingdom','AU'=>'Australia','CA'=>'Canada','EU'=>'Europe'];
          $countryFlags     = ['US'=>'🇺🇸','UK'=>'🇬🇧','AU'=>'🇦🇺','CA'=>'🇨🇦','EU'=>'🇪🇺'];
          $__cleanUri = country_switch_base();
          foreach (all_regions() as $regRow):
            $rc = $regRow['code'];
            if (!isset($regionToCurrency[$rc])) continue;
            $cc = $regionToCurrency[$rc];
            $href = ($rc === 'US' ? '' : '/' . strtolower($rc)) . $__cleanUri;
          ?>
            <li><a class="dropdown-item <?= $rc === $__ctry ? 'active' : '' ?>" href="<?= esc($href) ?>" data-testid="country-opt-<?= $rc ?>" onclick="document.cookie='mv_region_manual=1;path=/;max-age=31536000;SameSite=Lax'"><?= $countryFlags[$rc] ?? '🌐' ?> <?= esc($countryLabels[$rc] ?? $rc) ?> <span class="text-secondary small">(<?= esc($cc) ?>)</span></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <button type="button" class="trustbar-utility-btn trustbar-utility-icon" onclick="toggleTheme()" title="Toggle dark mode" data-testid="theme-toggle" aria-label="Toggle dark mode"><i id="theme-icon" class="bi bi-moon"></i></button>
    </div>
  </div>
</div>
<script>
/* Trustbar height auto-measure — the main navbar's sticky offset
   (--trustbar-h) must equal the trustbar's ACTUAL rendered height on
   every viewport, or the two overlap on sticky scroll. This runs once
   on load and again on resize (throttled via rAF), and sets the CSS
   variable on :root so .navbar-below-trustbar's `top` follows it
   pixel-perfectly regardless of future content changes. */
(function(){
  var tb = document.querySelector('.trustbar-sticky');
  if (!tb) return;
  var pending = 0;
  function sync(){
    var h = Math.round(tb.getBoundingClientRect().height);
    if (h > 0) document.documentElement.style.setProperty('--trustbar-h', h + 'px');
  }
  function onResize(){
    if (pending) cancelAnimationFrame(pending);
    pending = requestAnimationFrame(function(){ pending = 0; sync(); });
  }
  sync();
  window.addEventListener('resize', onResize, { passive: true });
  window.addEventListener('load', sync);
})();
</script>

<!-- Mobile-only promo chip (sits above the navbar on phones; the trustbar
     itself is hidden on mobile, so this carries the "Save 10% • CODE •
     Shop Now" nudge to the 60-70% of traffic that's mobile). -->
<!-- Mobile promo bar removed per request — keep markup in case it's
     re-enabled later, but hidden via CSS. -->
<div class="mobile-promo d-none" data-testid="mobile-promo" hidden>
  <a href="shop.php" class="mobile-promo-link" data-testid="mobile-promo-link">
    <i class="bi bi-tag-fill mobile-promo-icon"></i>
    <span class="mobile-promo-cta">Shop Now <i class="bi bi-chevron-right"></i></span>
  </a>
</div>

<!-- Main navbar -->
<nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top navbar-below-trustbar">
  <div class="container position-relative">
    <a class="navbar-brand logo-3d d-flex align-items-center gap-2" href="/" data-testid="brand-logo">
      <?php if ($brandLogo !== ''): ?>
        <?= brand_logo_html(42, 'width="140" height="42" decoding="async" fetchpriority="high"') ?>
      <?php else: ?>
        <?= render_logo(42) ?>
      <?php endif; ?>
      <?php if (!brand_logo_is_wordmark()): /* a wordmark logo already spells the name */ ?>
      <span class="brand-stack">
        <?php
          // Split brand name so the LAST word picks up the gradient accent.
          $bnParts = preg_split('/\s+/', trim($brandName));
          $bnLast  = array_pop($bnParts) ?: '';
          $bnHead  = implode(' ', $bnParts);
        ?>
        <span class="brand-text d-block lh-1"><?= esc($bnHead) ?><?php if ($bnHead !== ''): ?> <?php endif; ?><span class="brand-grad"><?= esc($bnLast) ?></span></span>
        <?php if (setting_get('show_authorized_reseller_badge', '0') === '1'): ?>
        <small class="brand-tag" data-testid="brand-tag-authorized-reseller">AUTHORIZED RESELLER</small>
        <?php endif; ?>
      </span>
      <?php endif; ?>
    </a>
    <div class="d-flex align-items-center gap-2 d-lg-none ms-auto me-2">
      <a href="cart.php" class="btn btn-sm btn-primary rounded-pill position-relative js-open-cart" data-testid="cart-button-mobile" aria-label="View cart" title="View cart">
        <i class="bi bi-cart3" aria-hidden="true"></i>
        <span class="cart-count-badge position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger <?= cart_count() === 0 ? 'd-none' : '' ?>" data-testid="cart-count-mobile"><?= cart_count() ?></span>
      </a>
    </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Open navigation menu" data-testid="navbar-toggler">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <!-- Mobile-only header inside the open hamburger: X close on the right
           + Theme toggle on the left.  Desktop hides this entire row because
           the trustbar above already carries currency/theme; on phones the
           trustbar is collapsed away, so the user has no way to switch
           theme or close the menu without scrolling to a link. -->
      <div class="d-flex d-lg-none align-items-center justify-content-between gap-2 mb-2 pb-2 border-bottom" data-testid="mobile-nav-header">
        <button type="button" class="trustbar-utility-btn trustbar-utility-icon"
                onclick="toggleTheme()" aria-label="Toggle dark mode" title="Toggle dark mode"
                data-testid="theme-toggle-mobile"
                style="background:var(--bs-tertiary-bg);border:1px solid var(--bs-border-color);color:var(--bs-body-color);border-radius:999px;width:38px;height:38px;display:inline-flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;">
          <i id="theme-icon-mobile" class="bi bi-moon"></i>
        </button>
        <div class="dropdown" data-testid="trustbar-currency-mobile">
          <button class="trustbar-utility-btn dropdown-toggle" data-bs-toggle="dropdown"
                  data-testid="currency-selector-mobile"
                  data-bs-display="static"
                  aria-expanded="false"
                  style="background:var(--bs-tertiary-bg);border:1px solid var(--bs-border-color);color:var(--bs-body-color);border-radius:999px;padding:6px 12px;font-size:.85rem;font-weight:600;">
            <?php $__ctryM = current_country_code(); ?>
            <?= esc($cur['code']) ?>
          </button>
          <ul class="dropdown-menu mv-mobile-currency-menu shadow-sm" style="min-width:220px;max-width:calc(100vw - 32px);">
            <?php
            $regionToCurrencyM = ['US'=>'USD','UK'=>'GBP','EU'=>'EUR','CA'=>'CAD','AU'=>'AUD'];
            $countryLabelsM    = ['US'=>'United States','UK'=>'United Kingdom','AU'=>'Australia','CA'=>'Canada','EU'=>'Europe'];
            $countryFlagsM     = ['US'=>'🇺🇸','UK'=>'🇬🇧','AU'=>'🇦🇺','CA'=>'🇨🇦','EU'=>'🇪🇺'];
            $__cleanUriM = country_switch_base();
            foreach (all_regions() as $regRowM):
              $rcM = $regRowM['code'];
              if (!isset($regionToCurrencyM[$rcM])) continue;
              $ccM = $regionToCurrencyM[$rcM];
              $hrefM = ($rcM === 'US' ? '' : '/' . strtolower($rcM)) . $__cleanUriM;
            ?>
              <li><a class="dropdown-item <?= $rcM === $__ctryM ? 'active' : '' ?>" href="<?= esc($hrefM) ?>" data-testid="country-opt-mobile-<?= $rcM ?>" onclick="document.cookie='mv_region_manual=1;path=/;max-age=31536000;SameSite=Lax'"><?= $countryFlagsM[$rcM] ?? '🌐' ?> <?= esc($countryLabelsM[$rcM] ?? $rcM) ?> <span class="text-secondary small">(<?= esc($ccM) ?>)</span></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <button type="button" class="btn-close" data-bs-toggle="collapse" data-bs-target="#mainNav"
                aria-label="Close navigation menu"
                data-testid="navbar-close-x"
                style="margin-left:auto;"></button>
      </div>
      <ul class="navbar-nav mx-auto">
        <li class="nav-item dropdown position-static">
          <a class="nav-link dropdown-toggle fw-semibold" href="#" data-bs-toggle="dropdown" data-testid="nav-microsoft">Microsoft Products</a>
          <div class="dropdown-menu mega p-3 shadow">
            <div class="row g-4">
              <?php foreach (nav_microsoft() as $heading => $col): ?>
                <div class="col-6 col-lg-3">
                  <div class="mega-heading mb-2"><?= esc($heading) ?></div>
                  <?php foreach ($col['groups'] as $label => $catSlug): ?>
                    <a class="mega-year" href="category.php?slug=<?= esc($catSlug) ?>" data-testid="menu-<?= esc($catSlug) ?>"><?= esc($label) ?></a>
                  <?php endforeach; ?>
                  <a class="mega-link fw-bold text-primary mt-2" href="category.php?slug=<?= esc($col['all'][0]) ?>" data-testid="menu-all-<?= esc($col['all'][0]) ?>"><?= esc($col['all'][1]) ?> <i class="bi bi-arrow-right"></i></a>
                </div>
              <?php endforeach; ?>
            </div>
            <?= render_menu_promo() ?>
            <div class="mt-3 pt-2 border-top d-flex flex-wrap gap-2 align-items-center">
              <span class="small fw-semibold text-secondary me-1"><i class="bi bi-collection-fill text-primary me-1"></i>Topic hubs:</span>
              <a href="hub/microsoft-office" class="badge text-decoration-none" data-testid="menu-hub-office" style="background:#dc26261c;color:#dc2626;border:1px solid #dc26264a;padding:6px 12px;font-size:14px;font-weight:600;">Microsoft Office guide</a>
              <a href="hub/windows" class="badge text-decoration-none" data-testid="menu-hub-windows" style="background:#0078d41c;color:#0078d4;border:1px solid #0078d44a;padding:6px 12px;font-size:14px;font-weight:600;">Windows guide</a>
              <a href="page.php?slug=disclaimer" class="text-decoration-none small ms-auto" data-testid="menu-disclaimer-ms"><i class="bi bi-info-circle me-1"></i>Disclaimer</a>
            </div>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle fw-semibold" href="#" data-bs-toggle="dropdown" data-testid="nav-antivirus">Antivirus</a>
          <div class="dropdown-menu p-3 shadow antivirus-menu" style="min-width: 260px;">
            <div class="mega-heading mb-1">ANTIVIRUS</div>
            <?php $_av = nav_antivirus(); foreach ($_av['brands'] as $_avLabel => $_avSlug): ?>
              <a class="mega-year" href="category.php?slug=<?= esc($_avSlug) ?>" data-testid="menu-<?= esc($_avSlug) ?>"><?= esc($_avLabel) ?></a>
            <?php endforeach; ?>
            <a class="mega-link fw-bold text-primary mt-2" href="category.php?slug=<?= esc($_av['all'][0]) ?>" data-testid="menu-all-<?= esc($_av['all'][0]) ?>"><?= esc($_av['all'][1]) ?> <i class="bi bi-arrow-right"></i></a>
            <a class="mega-link mt-1" href="page.php?slug=disclaimer" data-testid="menu-disclaimer-av"><i class="bi bi-info-circle me-1"></i>Disclaimer</a>
            <div class="mt-2 pt-2 border-top">
              <a href="hub/antivirus" class="badge text-decoration-none" data-testid="menu-hub-antivirus" style="background:#16a34a1c;color:#16a34a;border:1px solid #16a34a4a;padding:6px 12px;font-size:14px;font-weight:600;"><i class="bi bi-collection-fill me-1"></i>Antivirus topic hub</a>
            </div>
            <?= render_menu_promo(true) ?>
          </div>
        </li>
        <?php $_others = nav_others(); if (!empty($_others['brands'])): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle fw-semibold" href="#" data-bs-toggle="dropdown" data-testid="nav-others">Others</a>
          <div class="dropdown-menu p-3 shadow others-menu" style="min-width: 240px;">
            <div class="mega-heading mb-1">OTHERS</div>
            <?php foreach ($_others['brands'] as $_oLabel => $_oSlug): ?>
              <a class="mega-year" href="category.php?slug=<?= esc($_oSlug) ?>" data-testid="menu-<?= esc($_oSlug) ?>"><?= esc($_oLabel) ?></a>
            <?php endforeach; ?>
            <?php if (!empty($_others['all'])): ?>
              <a class="mega-link fw-bold text-primary mt-2" href="category.php?slug=<?= esc($_others['all'][0]) ?>" data-testid="menu-all-<?= esc($_others['all'][0]) ?>"><?= esc($_others['all'][1]) ?> <i class="bi bi-arrow-right"></i></a>
            <?php endif; ?>
          </div>
        </li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link fw-semibold" href="shop.php" data-testid="nav-shop">Shop</a></li>
        <li class="nav-item"><a class="nav-link fw-semibold" href="blog.php">Blog</a></li>
        <li class="nav-item"><a class="nav-link fw-semibold" href="track-order.php" data-testid="nav-track-order"><i class="bi bi-truck me-1"></i>Track Order</a></li>
      </ul>
      <div class="d-flex align-items-center gap-2 flex-nowrap" data-testid="navbar-actions" style="white-space:nowrap;">
        <?php /* Phone, Currency selector and Theme toggle now live in the
                topbar (right side) so the main nav has room to breathe.
                Only Ask AI + Cart remain here as the primary CTAs. */ ?>
        <button class="btn btn-sm btn-outline-primary rounded-pill flex-shrink-0" onclick="openAskAiModal()" data-testid="ask-ai-btn" style="white-space:nowrap;"><i class="bi bi-stars me-1"></i>Ask AI</button>
        <a href="cart.php" class="btn btn-sm btn-primary rounded-pill position-relative flex-shrink-0 js-open-cart" data-testid="cart-button" style="white-space:nowrap;">
          <i class="bi bi-cart3 me-1"></i>Cart
          <span class="cart-count-badge position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger <?= cart_count() === 0 ? 'd-none' : '' ?>" data-testid="cart-count"><?= cart_count() ?></span>
        </a>
      </div>
    </div>
  </div>
  <!-- Mobile fixed contact strip — stays still inside the sticky header -->
  <div class="mobile-contact-strip d-lg-none w-100" data-testid="mobile-contact-strip">
    <div class="container d-flex align-items-center justify-content-between gap-2 py-1">
      <div class="lh-sm">
        <div class="fw-bold" style="font-size:.74rem;">Have a Question?</div>
        <div class="text-secondary" style="font-size:.62rem;">Chat 24/7 · Call Mon–Sat 9–6 EST</div>
      </div>
      <div class="d-flex gap-2 flex-shrink-0">
        <a href="tel:<?= esc(tel_e164($brandPhone)) ?>" class="btn btn-sm rounded-pill fw-bold phone-cta-mobile" data-testid="mobile-call-btn"><i class="bi bi-telephone-fill me-1"></i><?= esc($brandPhone) ?></a>
        <button class="btn btn-sm btn-primary rounded-pill fw-bold" style="font-size:.7rem;" onclick="toggleChat()" data-testid="mobile-chat-btn"><i class="bi bi-chat-dots-fill me-1"></i>Chat</button>
      </div>
    </div>
  </div>
</nav>
<!-- Top promo strip moved INLINE into the trustbar above — no separate
     floating bar anymore. -->

<!-- Independent-reseller disclosure below the nav removed at user request —
     the top-of-page trust-topbar ("Independent Distributor of Surplus
     Volume Licenses.") already carries the compliance signal, and the
     product/home pages have their own inline disclaimers. -->
<?php if (!in_array(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')), ['order-success.php', 'payment-failed.php'], true)) echo promo_offer_tag_html(); ?>
<?php endif; /* checkoutHeader */ endif; /* bareLayout */ ?>
<main id="main-content" role="main">