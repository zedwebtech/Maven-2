<?php
/**
 * Global "Contact Sales" / Volume Licensing banner modal.
 * Included once from footer.php so every page can open it via
 * window.mvOpenVolumeModal(). Posts to /ajax/volume-lead.php.
 *
 * Anti-bot: mandatory name/email/phone + an on-screen slide-to-verify control
 * + a server-signed capture token (mv_cap). The server rejects any submission
 * without a valid completed capture, so blind bot posts never create a lead.
 */
?>
<div class="modal fade" id="mvVolumeModal" tabindex="-1" aria-hidden="true" aria-labelledby="mvVolumeModalTitle" data-testid="volume-modal">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content" style="border:0;border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(15,23,42,.25);">
      <div class="modal-header border-0 pb-0 px-4 pt-4">
        <div>
          <h5 class="modal-title fw-bold" id="mvVolumeModalTitle" data-testid="volume-modal-title">Contact Sales</h5>
          <p class="text-secondary small mb-0 mt-1" style="max-width:420px;">Get in touch with our team for bulk licensing, priority support, and volume discounts.</p>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" data-testid="volume-modal-close"></button>
      </div>
      <div class="modal-body px-4 pb-4 pt-3">
        <?php if (!mv_volume_enabled()): ?>
        <div class="text-center py-5" data-testid="volume-coming-soon">
          <i class="bi bi-cone-striped" style="font-size:2.6rem;color:#f59e0b;"></i>
          <h5 class="fw-bold mt-3 mb-2">Coming Soon</h5>
          <p class="text-secondary small mb-0" style="max-width:360px;margin:0 auto;">Volume &amp; business licensing is not available right now. Please check back shortly — thank you for your patience.</p>
          <button type="button" class="btn btn-outline-secondary rounded-pill px-4 mt-4" data-bs-dismiss="modal" data-testid="volume-comingsoon-close">Close</button>
        </div>
        <?php else: ?>
        <form id="mvVolumeForm" novalidate data-testid="volume-form">
          <!-- Honeypot: hidden from humans; bots fill it and are silently dropped -->
          <div aria-hidden="true" style="position:absolute!important;left:-9999px!important;top:-9999px!important;width:1px;height:1px;overflow:hidden;">
            <label>Leave this field empty <input type="text" name="mv_hp" tabindex="-1" autocomplete="off"></label>
          </div>
          <!-- Server-signed capture token (only present on a real page load) -->
          <input type="hidden" name="mv_cap" value="<?= htmlspecialchars(mv_captcha_token(), ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="mv_human" id="mvVolHuman" value="0">
          <input type="hidden" name="mv_bh" id="mvVolBehavior" value="">

          <div class="mb-3">
            <label class="form-label small fw-semibold">Name <span class="text-danger">*</span></label>
            <input name="name" class="form-control" placeholder="Your name" required data-testid="volume-name">
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Email <span class="text-danger">*</span></label>
            <input name="email" type="email" class="form-control" placeholder="your@email.com" required data-testid="volume-email">
          </div>
          <div class="row g-3 mb-3">
            <div class="col-sm-6">
              <label class="form-label small fw-semibold">Phone <span class="text-danger">*</span></label>
              <input name="phone" class="form-control" placeholder="Phone number" required data-testid="volume-phone">
            </div>
            <div class="col-sm-6">
              <label class="form-label small fw-semibold">Number of Licenses</label>
              <input name="licenses" class="form-control" placeholder="e.g. 10, 50, 100+" data-testid="volume-licenses">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Company</label>
            <input name="company" class="form-control" placeholder="Company name" data-testid="volume-company">
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Message</label>
            <textarea name="message" class="form-control" rows="3" placeholder="Tell us about your requirements..." data-testid="volume-message"></textarea>
          </div>

          <!-- Slide-to-verify -->
          <div class="mv-slide" id="mvVolSlide" data-testid="volume-slider" role="button" aria-label="Slide to verify">
            <div class="mv-slide-fill" id="mvVolSlideFill"></div>
            <div class="mv-slide-handle" id="mvVolSlideHandle"><i class="bi bi-chevron-double-right"></i></div>
            <span class="mv-slide-label" id="mvVolSlideLabel">Slide to verify &nbsp;&raquo;</span>
          </div>

          <div class="rounded-3 px-3 py-2 mb-3" style="background:#f1f5f9;font-size:.8rem;color:#475569;">
            <strong class="text-dark">Benefits:</strong> Team Licensing &bull; Priority Support &bull; Bulk Discounts
          </div>

          <div id="mvVolumeAlert" class="alert d-none mb-3" role="alert" data-testid="volume-alert"></div>

          <div class="d-flex gap-2 justify-content-end">
            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal" data-testid="volume-cancel">Cancel</button>
            <button type="submit" class="btn btn-primary rounded-pill px-4" id="mvVolumeSubmit" data-testid="volume-submit" disabled>Send Inquiry</button>
          </div>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<style>
#mvVolSlide{position:relative;height:46px;border-radius:10px;background:#eef2f7;border:1px solid #d7dee8;overflow:hidden;margin-bottom:14px;user-select:none;touch-action:none;}
#mvVolSlideFill{position:absolute;left:0;top:0;bottom:0;width:23px;background:#dbeafe;}
#mvVolSlideLabel{position:absolute;left:0;right:0;top:0;bottom:0;display:flex;align-items:center;justify-content:center;font-size:.82rem;color:#64748b;font-weight:600;pointer-events:none;}
#mvVolSlideHandle{position:absolute;left:2px;top:2px;bottom:2px;width:42px;border-radius:8px;background:#2563eb;color:#fff;display:flex;align-items:center;justify-content:center;cursor:grab;box-shadow:0 2px 6px rgba(37,99,235,.4);transition:background .2s;}
#mvVolSlide.done #mvVolSlideHandle{background:#16a34a;cursor:default;}
#mvVolSlide.done #mvVolSlideFill{background:#dcfce7;}
#mvVolSlide.done #mvVolSlideLabel{color:#16a34a;}
</style>
<script>
(function () {
  var modalEl = document.getElementById('mvVolumeModal');
  if (!modalEl) return;
  var modal = null;
  window.mvOpenVolumeModal = function () {
    try {
      if (!modal && window.bootstrap && window.bootstrap.Modal) modal = new window.bootstrap.Modal(modalEl);
      if (modal) modal.show();
    } catch (e) { window.location.href = 'contact.php'; }
  };

  var form   = document.getElementById('mvVolumeForm');
  var alertB = document.getElementById('mvVolumeAlert');
  var btn    = document.getElementById('mvVolumeSubmit');
  var humanF = document.getElementById('mvVolHuman');
  if (!form) return;

  // ── Smart behaviour tracker ── records genuine human interaction into mv_bh.
  var bh = {kd:0, pm:0, tc:0, fl:0, ps:0};
  function binc(k){ if(bh[k] < 100000) bh[k]++; }
  document.addEventListener('mousemove',  function(){ binc('pm'); }, {passive:true});
  document.addEventListener('pointermove',function(){ binc('pm'); }, {passive:true});
  document.addEventListener('touchmove',  function(){ binc('tc'); }, {passive:true});
  document.addEventListener('touchstart', function(){ binc('tc'); }, {passive:true});
  document.addEventListener('pointerdown',function(){ binc('tc'); }, {passive:true});
  form.addEventListener('keydown', function(){ binc('kd'); }, true);
  form.addEventListener('focusin', function(){ binc('fl'); }, true);
  form.addEventListener('paste',   function(){ binc('ps'); }, true);

  // --- Slide to verify ---
  var slide = document.getElementById('mvVolSlide'),
      handle = document.getElementById('mvVolSlideHandle'),
      fill = document.getElementById('mvVolSlideFill'),
      label = document.getElementById('mvVolSlideLabel'),
      solved = false, dragging = false, startX = 0, maxX = 0;

  function setX(x){
    var hw = handle.offsetWidth;
    maxX = slide.clientWidth - hw - 4;
    x = Math.max(0, Math.min(x, maxX));
    handle.style.left = (2 + x) + 'px';
    fill.style.width = (x + hw) + 'px';
    if (x >= maxX - 2 && !solved){ solved = true; finishSolve(); }
  }
  function finishSolve(){
    slide.classList.add('done');
    handle.innerHTML = '<i class="bi bi-check-lg"></i>';
    label.innerHTML = 'Verified &#10003;';
    humanF.value = '1';
    btn.disabled = false;
  }
  function onDown(e){ if (solved) return; dragging = true; startX = (e.touches?e.touches[0].clientX:e.clientX) - (parseFloat(handle.style.left)||2); handle.style.cursor='grabbing'; }
  function onMove(e){ if (!dragging || solved) return; var cx = (e.touches?e.touches[0].clientX:e.clientX); setX(cx - startX - 2); if(e.cancelable)e.preventDefault(); }
  function onUp(){ if (!dragging) return; dragging = false; handle.style.cursor='grab'; if (!solved) setX(0); }
  if (handle){
    handle.addEventListener('mousedown', onDown);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    handle.addEventListener('touchstart', onDown, {passive:true});
    document.addEventListener('touchmove', onMove, {passive:false});
    document.addEventListener('touchend', onUp);
  }

  function showAlert(type, msg) {
    alertB.className = 'alert mb-3 alert-' + (type === 'ok' ? 'success' : 'danger');
    alertB.textContent = msg;
    alertB.classList.remove('d-none');
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    alertB.classList.add('d-none');
    var name  = (form.name.value || '').trim();
    var email = (form.email.value || '').trim();
    var phone = (form.phone.value || '').trim();
    if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || phone.length < 6) {
      showAlert('err', 'Please enter your name, a valid email, and your phone number.');
      return;
    }
    if (!solved) { showAlert('err', 'Please slide to verify before sending.'); return; }
    btn.disabled = true;
    var original = btn.textContent;
    btn.textContent = 'Sending…';
    var bhEl = document.getElementById('mvVolBehavior');
    if (bhEl) bhEl.value = JSON.stringify(bh);
    fetch('ajax/volume-lead.php', { method: 'POST', body: new FormData(form) })
      .then(function (r) { return r.json().catch(function(){ return { ok:false, error:'Something went wrong. Please try again.' }; }); })
      .then(function (d) {
        if (d && d.ok) {
          form.reset();
          showAlert('ok', 'Thanks! Our team has received your request and will reply shortly. A confirmation has been emailed to you.');
          btn.textContent = 'Sent ✓';
        } else {
          showAlert('err', (d && d.error) || 'Something went wrong. Please try again.');
          btn.disabled = false; btn.textContent = original;
        }
      })
      .catch(function () { showAlert('err', 'Network error — please try again.'); btn.disabled = false; btn.textContent = original; });
  });
})();
</script>
