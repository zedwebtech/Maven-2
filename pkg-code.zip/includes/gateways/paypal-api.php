<?php
/**
 * includes/gateways/paypal-api.php
 *
 * Real PayPal Checkout (Orders API v2) integration using the merchant's own
 * REST app Client ID + Secret stored in settings (gw_paypal_client_id_{mode} /
 * gw_paypal_secret_{mode}). Mode follows gw_mode: test => sandbox, live => prod.
 *
 * Flow: OAuth token -> create order (intent CAPTURE) -> redirect buyer to the
 * approve link -> on return, capture the order -> mark paid ONLY when the
 * capture status is COMPLETED. Plain PHP cURL, no SDK.
 */
require_once __DIR__ . '/../settings.php';

function paypal_api_base(string $mode): string {
    return $mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
}

/** OAuth2 client-credentials access token. Returns '' on failure. */
function paypal_access_token(string $mode): string {
    $cid = trim((string)setting_get('gw_paypal_client_id_' . $mode, ''));
    $sec = trim((string)setting_get('gw_paypal_secret_' . $mode, ''));
    if ($cid === '' || $sec === '') return '';
    $ch = curl_init(paypal_api_base($mode) . '/v1/oauth2/token');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD        => $cid . ':' . $sec,
        CURLOPT_POSTFIELDS     => 'grant_type=client_credentials',
        CURLOPT_HTTPHEADER     => ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) { @error_log('[paypal token] HTTP ' . $code . ' ' . $body); return ''; }
    $j = json_decode($body, true);
    return (string)($j['access_token'] ?? '');
}

/**
 * Generate a short-lived PayPal *client token* (required by the v5
 * paypal.CardFields SDK for Advanced/Inline Card Fields to be eligible in
 * LIVE). Returns '' on failure so the checkout can fall back gracefully.
 * Sequence: OAuth access token -> POST /v1/identity/generate-token.
 */
function paypal_client_token(string $mode): string {
    $access = paypal_access_token($mode);
    if ($access === '') return '';
    $ch = curl_init(paypal_api_base($mode) . '/v1/identity/generate-token');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS     => '',
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $access,
            'Content-Type: application/json',
            'Accept: application/json',
            'Accept-Language: en_US',
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) { @error_log('[paypal client-token] HTTP ' . $code . ' ' . $body); return ''; }
    $j = json_decode($body, true);
    return (string)($j['client_token'] ?? '');
}

/**
 * Is this PayPal account enabled for Advanced (inline, unbranded) Card Fields?
 * The JS SDK embeds the merchant's funding eligibility; `card.branded:true`
 * means ONLY the branded PayPal card button is allowed → paypal.CardFields
 * .isEligible() is false in the browser. Returns true/false, or null if the
 * SDK could not be fetched.
 */
/**
 * The exact JS SDK <script src> the checkout loads. PayPal's CDN caches this
 * bundle PER URL for up to 3 h (s-maxage=10800) and the bundle EMBEDS the
 * merchant's card eligibility. enable-funding=card is a documented, harmless
 * param that gave the URL its own fresh cache key after ACDC was approved on
 * the live account (verified: eligible:true, branded:false). Keep the URL
 * STABLE — a fixed, documented parameter set can never be rejected by the
 * SDK endpoint, and buyers get a warm CDN cache.
 */
function paypal_sdk_src(string $mode, string $currency = 'USD'): string {
    $cid = trim((string)setting_get('gw_paypal_client_id_' . $mode, ''));
    return 'https://www.paypal.com/sdk/js?client-id=' . rawurlencode($cid)
        . '&currency=' . rawurlencode($currency) . '&intent=capture&components=buttons,card-fields&enable-funding=card';
}

function paypal_acdc_eligible(string $mode, string $currency = 'USD'): ?bool {
    $cid = trim((string)setting_get('gw_paypal_client_id_' . $mode, ''));
    if ($cid === '') return null;
    $ch = curl_init(paypal_sdk_src($mode, $currency));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => '',
        CURLOPT_TIMEOUT => 20, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $js = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200 || !preg_match('/"card":\{"eligible":(true|false),"branded":(true|false)/', $js, $m)) return null;
    return $m[1] === 'true' && $m[2] === 'false';
}

/**
 * Trim a string safely for PayPal (values are UTF-8 and length-limited).
 * PayPal Orders API v2 limits: item.name = 127, item.description = 127,
 * item.sku = 127, purchase_unit.description = 127.
 */
function pp_str(string $v, int $max): string {
    $v = trim(preg_replace('/\s+/', ' ', (string)$v) ?? '');
    if ($max > 0 && mb_strlen($v) > $max) $v = mb_substr($v, 0, $max);
    return $v;
}

/**
 * Build PayPal purchase_units.items[] + description + amount.breakdown from
 * our internal cart items so PayPal shows the real item name/description on
 * the review screen and the customer's receipt (fixes the "-" placeholder).
 *
 * @param array $items    Each item: ['slug','name','price','qty', optional 'description'/'sku']
 * @param float $subtotal Sum of qty × price (BEFORE discount).
 * @param float $discount Discount amount (>=0). If >0 it is shown as a
 *                        separate line in PayPal's amount breakdown so the
 *                        buyer sees exactly what was applied.
 * @param float $total    Final amount to charge = subtotal - discount.
 * @param string $currency ISO code (e.g. USD).
 * @param string $description Optional order-level description (max 127 chars).
 */
function pp_build_units_from_items(array $items, float $subtotal, float $discount, float $total, string $currency, string $refId, string $description = ''): array {
    $currency = strtoupper($currency);
    $ppItems  = [];
    $sum      = 0.0;
    foreach ($items as $it) {
        $qty  = max(1, (int)($it['qty'] ?? 1));
        $unit = round((float)($it['price'] ?? 0), 2);
        $name = pp_str((string)($it['name'] ?? 'Item'), 127);
        if ($name === '') $name = 'Item';
        $desc = pp_str((string)($it['description'] ?? ''), 127);
        $sku  = pp_str((string)($it['sku'] ?? ($it['slug'] ?? '')), 127);
        $one  = [
            'name'        => $name,
            'quantity'    => (string)$qty,
            'unit_amount' => ['currency_code' => $currency, 'value' => number_format($unit, 2, '.', '')],
            'category'    => 'DIGITAL_GOODS',
        ];
        if ($desc !== '') $one['description'] = $desc;
        if ($sku  !== '') $one['sku']         = $sku;
        $ppItems[] = $one;
        $sum      += $unit * $qty;
    }
    $sum = round($sum, 2);
    // Reconcile: PayPal rejects the order unless item_total - discount (+ handling)
    // == total, so if rounding drifts we adjust the discount (total below the
    // item sum) or add a handling line (total above it) to compensate.
    $itemTotal = $sum;
    $disc      = max(0.0, round((float)$discount, 2));
    $totalR    = round((float)$total, 2);
    $handling  = 0.0;
    $expected  = round($itemTotal - $disc, 2);
    if (abs($expected - $totalR) > 0.001) {
        // Rebase discount so the math matches whatever total we already
        // saved on the order.
        $disc = round($itemTotal - $totalR, 2);
        if ($disc < 0) { $handling = -$disc; $disc = 0.0; }
    }
    $breakdown = [
        'item_total' => ['currency_code' => $currency, 'value' => number_format($itemTotal, 2, '.', '')],
    ];
    if ($disc > 0.0) {
        $breakdown['discount'] = ['currency_code' => $currency, 'value' => number_format($disc, 2, '.', '')];
    }
    if ($handling > 0.0) {
        $breakdown['handling'] = ['currency_code' => $currency, 'value' => number_format($handling, 2, '.', '')];
    }
    $unit = [
        'reference_id' => $refId,
        'custom_id'    => $refId,
        'invoice_id'   => $refId,
        'amount'       => [
            'currency_code' => $currency,
            'value'         => number_format($totalR, 2, '.', ''),
            'breakdown'     => $breakdown,
        ],
        'items'        => $ppItems,
    ];
    if ($description !== '') $unit['description'] = pp_str($description, 127);
    return $unit;
}

/**
 * Create a PayPal order. Returns ['ok'=>bool,'id'=>string,'approve'=>url,'error'=>str].
 *
 * Extra params (all optional, defaults preserve old single-line behaviour):
 *   $items       — cart items so PayPal shows real product name/desc
 *   $subtotal    — sum before discount (used for amount.breakdown.item_total)
 *   $discount    — coupon discount (shown as amount.breakdown.discount)
 *   $description — order-level description shown as the transaction memo
 */
function paypal_create_order(float $amount, string $currency, string $refId, string $returnUrl, string $cancelUrl, string $mode, array $items = [], float $subtotal = 0.0, float $discount = 0.0, string $description = '', array $opts = []): array {
    $token = paypal_access_token($mode);
    if ($token === '') return ['ok'=>false, 'error'=>'Could not authenticate with PayPal. Check the PayPal Client ID / Secret.'];
    // Build the purchase unit — prefer itemised breakdown when items are
    // supplied so the buyer sees real product names/descriptions on the
    // PayPal review screen and receipt (not the dash "-" placeholder).
    if (!empty($items)) {
        if ($subtotal <= 0) {
            $s = 0.0;
            foreach ($items as $it) { $s += (float)($it['price'] ?? 0) * max(1, (int)($it['qty'] ?? 1)); }
            $subtotal = round($s, 2);
        }
        if ($description === '') {
            $first = (string)($items[0]['name'] ?? '');
            $rest  = count($items) - 1;
            $description = 'Order ' . $refId . ' — ' . $first . ($rest > 0 ? ' + ' . $rest . ' more item' . ($rest > 1 ? 's' : '') : '');
        }
        $unit = pp_build_units_from_items($items, (float)$subtotal, (float)$discount, (float)$amount, $currency, $refId, $description);
    } else {
        $unit = [
            'reference_id' => $refId,
            'custom_id'    => $refId,
            'invoice_id'   => $refId,
            'amount'       => ['currency_code' => strtoupper($currency), 'value' => number_format($amount, 2, '.', '')],
        ];
        if ($description !== '') $unit['description'] = pp_str($description, 127);
    }
    $payload = [
        'intent' => 'CAPTURE',
        'purchase_units' => [$unit],
        'application_context' => [
            'brand_name'          => brand_name(),
            'user_action'         => 'PAY_NOW',
            'shipping_preference' => 'NO_SHIPPING',
            'return_url'          => $returnUrl,
            'cancel_url'          => $cancelUrl,
        ],
    ];
    // Inline Card Fields: NO verification.method is sent — we never request
    // 3-D Secure from our side (store policy: simple 2D checkout). If the
    // issuer or regulation mandates SCA, PayPal/the bank handle it themselves.
    // For the inline "pay by card" (guest CardFields) flow, PayPal shows a blank
    // name ("--") in the merchant account unless we tell it who is paying: the
    // CardFields box has no cardholder-name input, so set the buyer's name (and
    // email) on the order's payer object. PayPal then records the real name on
    // the transaction, exactly like a PayPal-account payment. Only applied to the
    // card flow — the standard PayPal button flow already carries the payer name.
    if (!empty($opts['card_fields']) && !empty($opts['buyer']) && is_array($opts['buyer'])) {
        $bFirst = pp_str((string)($opts['buyer']['first'] ?? ''), 140);
        $bLast  = pp_str((string)($opts['buyer']['last'] ?? ''), 140);
        $bEmail = trim((string)($opts['buyer']['email'] ?? ''));
        $payer  = [];
        if ($bFirst !== '' || $bLast !== '') {
            $payer['name'] = array_filter(['given_name' => $bFirst, 'surname' => $bLast], fn($v) => $v !== '');
        }
        if ($bEmail !== '' && filter_var($bEmail, FILTER_VALIDATE_EMAIL)) {
            $payer['email_address'] = $bEmail;
        }
        if ($payer) $payload['payer'] = $payer;
    }
    $ch = curl_init(paypal_api_base($mode) . '/v2/checkout/orders');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token, 'PayPal-Request-Id: ' . $refId . '-' . substr(md5($refId . microtime(true)), 0, 10)],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $j = json_decode($body, true);
    if ($code < 200 || $code >= 300 || empty($j['id'])) {
        @error_log('[paypal create] HTTP ' . $code . ' ' . $body);
        $issue = (string)($j['details'][0]['issue'] ?? '');
        $why   = $issue !== '' ? paypal_issue_text($issue, (string)($j['details'][0]['description'] ?? '')) : '';
        return ['ok'=>false, 'error'=>'PayPal could not create the order' . ($why !== '' ? ': ' . $why : '. Please try again.'), 'code'=>$issue];
    }
    $approve = '';
    foreach (($j['links'] ?? []) as $l) {
        if (($l['rel'] ?? '') === 'approve') { $approve = (string)$l['href']; break; }
    }
    if ($approve === '' && empty($opts['card_fields'])) return ['ok'=>false, 'error'=>'PayPal did not return an approval link.'];
    return ['ok'=>true, 'id'=>(string)$j['id'], 'approve'=>$approve];
}

/**
 * PayPal processor_response.response_code → [enum label, buyer-safe message].
 * Full enum per developer.paypal.com/api/orders/v2 (processor_response).
 * Unknown codes still surface the raw code so the reason is never hidden.
 */
function paypal_processor_decline_text(string $code): array {
    static $labels = [
        '0000'=>'APPROVED','00N7'=>'CVV2_FAILURE_POSSIBLE_RETRY_WITH_CVV','0100'=>'REFERRAL','0390'=>'ACCOUNT_NOT_FOUND','0500'=>'DO_NOT_HONOR',
        '0580'=>'UNAUTHORIZED_TRANSACTION','0800'=>'BAD_RESPONSE_REVERSAL_REQUIRED','0880'=>'CRYPTOGRAPHIC_FAILURE','0890'=>'UNACCEPTABLE_PIN',
        '0960'=>'SYSTEM_MALFUNCTION','0R00'=>'CANCELLED_PAYMENT','1000'=>'PARTIAL_AUTHORIZATION','10BR'=>'ISSUER_REJECTED','1300'=>'INVALID_DATA_FORMAT',
        '1310'=>'INVALID_AMOUNT','1312'=>'INVALID_TRANSACTION_CARD_ISSUER_ACQUIRER','1317'=>'INVALID_CAPTURE_DATE','1320'=>'INVALID_CURRENCY_CODE',
        '1330'=>'INVALID_ACCOUNT','1335'=>'INVALID_ACCOUNT_RECURRING','1340'=>'INVALID_TERMINAL','1350'=>'INVALID_MERCHANT','1352'=>'RESTRICTED_OR_INACTIVE_ACCOUNT',
        '1360'=>'BAD_PROCESSING_CODE','1370'=>'INVALID_MCC','1380'=>'INVALID_EXPIRATION','1382'=>'INVALID_CARD_VERIFICATION_VALUE','1384'=>'INVALID_LIFE_CYCLE_OF_TRANSACTION',
        '1390'=>'INVALID_ORDER','1393'=>'TRANSACTION_CANNOT_BE_COMPLETED','5100'=>'GENERIC_DECLINE','5110'=>'CVV2_FAILURE','5120'=>'INSUFFICIENT_FUNDS',
        '5130'=>'INVALID_PIN','5135'=>'DECLINED_PIN_TRY_EXCEEDED','5140'=>'CARD_CLOSED','5150'=>'PICKUP_CARD_SPECIAL_CONDITIONS','5160'=>'UNAUTHORIZED_USER',
        '5170'=>'AVS_FAILURE','5180'=>'INVALID_OR_RESTRICTED_CARD','5190'=>'SOFT_AVS','5200'=>'DUPLICATE_TRANSACTION','5210'=>'INVALID_TRANSACTION',
        '5400'=>'EXPIRED_CARD','5500'=>'INCORRECT_PIN_REENTER','5650'=>'DECLINED_SCA_REQUIRED','5700'=>'TRANSACTION_NOT_PERMITTED','5710'=>'TX_ATTEMPTS_EXCEED_LIMIT',
        '5800'=>'REVERSAL_REJECTED','5900'=>'INVALID_ISSUE','5910'=>'ISSUER_NOT_AVAILABLE_NOT_RETRIABLE','5920'=>'ISSUER_NOT_AVAILABLE_RETRIABLE','5930'=>'CARD_NOT_ACTIVATED',
        '5950'=>'DECLINED_DUE_TO_UPDATED_ACCOUNT','6300'=>'ACCOUNT_NOT_ON_FILE','7600'=>'APPROVED_NON_CAPTURE','7700'=>'ERROR_3DS','7710'=>'AUTHENTICATION_FAILED',
        '7800'=>'BIN_ERROR','7900'=>'PIN_ERROR','8000'=>'PROCESSOR_SYSTEM_ERROR','8010'=>'HOST_KEY_ERROR','8020'=>'CONFIGURATION_ERROR','8030'=>'UNSUPPORTED_OPERATION',
        '8100'=>'FATAL_COMMUNICATION_ERROR','8110'=>'RETRY_SPECIAL_CONDITIONS','8220'=>'STOP_ALL_RECURRING_PAYMENTS','9100'=>'DECLINED_PLEASE_RETRY','9500'=>'SUSPECTED_FRAUD',
        '9510'=>'SECURITY_VIOLATION','9520'=>'LOST_OR_STOLEN','9530'=>'HOLD_CALL_CENTER','9540'=>'REFUSED_CARD','9600'=>'UNRECOGNIZED_RESPONSE_CODE',
        'PCNR'=>'CONTINGENCIES_NOT_RESOLVED','PCVV'=>'CVV_FAILURE','PP06'=>'ACCOUNT_CLOSED','PPRN'=>'RE_ENTER_TRANSACTION','PPAD'=>'BILLING_ADDRESS','PPAB'=>'ACCOUNT_BLOCKED_BY_ISSUER',
        'PPAE'=>'AMEX_DISABLED','PPAG'=>'ADULT_GAMING_UNSUPPORTED','PPAI'=>'AMOUNT_INCOMPATIBLE','PPAR'=>'AUTH_RESULT','PPAU'=>'MCC_CODE','PPAV'=>'ARC_AVS','PPAX'=>'AMOUNT_EXCEEDED',
        'PPBG'=>'BAD_GAMING','PPC2'=>'ARC_CVV','PPCE'=>'CE_REGISTRATION_INCOMPLETE','PPCO'=>'COUNTRY','PPCR'=>'CREDIT_ERROR','PPCT'=>'CARD_TYPE_UNSUPPORTED','PPCU'=>'CURRENCY_USED_INVALID',
        'PPD3'=>'SECURE_ERROR_3DS','PPDC'=>'DCC_UNSUPPORTED','PPDI'=>'DINERS_REJECT','PPDV'=>'AUTH_MESSAGE','PPDT'=>'DECLINE_THRESHOLD_BREACH','PPEF'=>'EXPIRED_FUNDING_INSTRUMENT',
        'PPEL'=>'EXCEEDS_FREQUENCY_LIMIT','PPER'=>'INTERNAL_SYSTEM_ERROR','PPEX'=>'EXPIRY_DATE','PPFE'=>'FUNDING_SOURCE_ALREADY_EXISTS','PPFI'=>'INVALID_FUNDING_INSTRUMENT',
        'PPFR'=>'RESTRICTED_FUNDING_INSTRUMENT','PPFV'=>'FIELD_VALIDATION_FAILED','PPGR'=>'GAMING_REFUND_ERROR','PPH1'=>'H1_ERROR','PPIF'=>'IDEMPOTENCY_FAILURE','PPII'=>'INVALID_INPUT_FAILURE',
        'PPIM'=>'ID_MISMATCH','PPIT'=>'INVALID_TRACE_ID','PPLR'=>'LATE_REVERSAL','PPLS'=>'LARGE_STATUS_CODE','PPMB'=>'MISSING_BUSINESS_RULE_OR_DATA','PPMC'=>'BLOCKED_MASTERCARD','PPMD'=>'PPMD',
        'PPNC'=>'NOT_SUPPORTED_NRC','PPNL'=>'EXCEEDS_NETWORK_FREQUENCY_LIMITS','PPNM'=>'NO_MID_FOUND','PPNT'=>'NETWORK_ERROR','PPPH'=>'NO_PHONE_FOR_DCC_TRANSACTION','PPPI'=>'INVALID_PRODUCT',
        'PPPM'=>'INVALID_PAYMENT_METHOD','PPQC'=>'QUASI_CASH_UNSUPPORTED','PPRE'=>'UNSUPPORT_REFUND_ON_PENDING_BC','PPRF'=>'INVALID_PARENT_TRANSACTION_STATUS','PPRR'=>'MERCHANT_NOT_REGISTERED',
        'PPS0'=>'BANKAUTH_ROW_MISMATCH','PPS1'=>'BANKAUTH_ROW_SETTLED','PPS2'=>'BANKAUTH_ROW_VOIDED','PPS3'=>'BANKAUTH_EXPIRED','PPS4'=>'CURRENCY_MISMATCH','PPS5'=>'CREDITCARD_MISMATCH',
        'PPS6'=>'AMOUNT_MISMATCH','PPSC'=>'ARC_SCORE','PPSD'=>'STATUS_DESCRIPTION','PPSE'=>'AMEX_DENIED','PPTE'=>'VERIFICATION_TOKEN_EXPIRED','PPTF'=>'INVALID_TRACE_REFERENCE',
        'PPTI'=>'INVALID_TRANSACTION_ID','PPTR'=>'VERIFICATION_TOKEN_REVOKED','PPTT'=>'TRANSACTION_TYPE_UNSUPPORTED','PPTV'=>'INVALID_VERIFICATION_TOKEN','PPUA'=>'USER_NOT_AUTHORIZED',
        'PPUC'=>'CURRENCY_CODE_UNSUPPORTED','PPUE'=>'UNSUPPORT_ENTITY','PPUI'=>'UNSUPPORT_INSTALLMENT','PPUP'=>'UNSUPPORT_POS_FLAG','PPUR'=>'UNSUPPORTED_REVERSAL','PPVC'=>'VALIDATE_CURRENCY',
        'PPVE'=>'VALIDATION_ERROR','PPVT'=>'VIRTUAL_TERMINAL_UNSUPPORTED',
    ];
    static $msgs = [
        '00N7'=>'The security code (CVV) did not match your card. Please check the 3-digit code (4 digits for Amex) and try again.',
        '5110'=>'The security code (CVV) did not match your card. Please check it and try again.',
        'PCVV'=>'The security code (CVV) did not match your card. Please check it and try again.',
        'PPC2'=>'The security code (CVV) did not match your card. Please check it and try again.',
        '1382'=>'The security code (CVV) is invalid. Please check it and try again.',
        '0100'=>'Your bank needs to authorise this payment by phone. No charge was made — approve it with your bank, then retry.',
        '0390'=>'Card account not found. Please check the card number and try again.',
        '0500'=>'Your bank declined the payment (Do Not Honor). No charge was made — approve the payment with your bank, then retry.',
        '0580'=>'Your bank did not authorise this transaction. No charge was made — approve the payment with your bank, then retry.',
        '0800'=>'Your bank returned an error and the payment was reversed — nothing was charged. Please try again.',
        '0880'=>'A card security check failed. Please try again.',
        '0960'=>'The card network is temporarily unavailable. Nothing was charged — please try again in a moment.',
        '0R00'=>'The payment was cancelled before it completed. Nothing was charged.',
        '1000'=>'Your bank only approved part of the amount, so the payment was not completed.',
        '10BR'=>'Your card issuer rejected the payment. No charge was made — approve the payment with your bank, then retry.',
        '1320'=>'This card cannot be charged in this currency.',
        '1330'=>'This card number is not valid. Please check it and try again.',
        '1352'=>'This card account is restricted or inactive. No charge was made — approve the payment with your bank, then retry.',
        '1380'=>'The expiry date is invalid. Please check it and try again.',
        '5100'=>'Your card was declined by your bank. No charge was made — approve the payment with your bank, then retry.',
        '5120'=>'Insufficient funds — your bank declined the payment. No charge was made — top up or approve it with your bank, then retry.',
        '5140'=>'This card account has been closed.',
        'PP06'=>'This card account has been closed.',
        '5150'=>'Your bank declined this card and asked for it to be retained.',
        '5160'=>'The cardholder is not authorised for this transaction.',
        '5170'=>'The billing address does not match the address your bank has on file. Please check the address and postcode.',
        'PPAD'=>'The billing address was rejected. Please check the address and postcode and try again.',
        'PPAV'=>'The billing address could not be verified by your bank. Please check it and try again.',
        '5180'=>'This card is invalid or restricted and cannot be used.',
        '5190'=>'The billing address could not be verified. Please check the address and postcode.',
        '5200'=>'This looks like a duplicate of a payment already made. Please check your email for a receipt before retrying.',
        '5400'=>'This card has expired.',
        'PPEF'=>'This card has expired.',
        'PPEX'=>'The expiry date is invalid. Please check it and try again.',
        '5650'=>'Your bank requires extra verification (3-D Secure) for this payment. Please retry and complete the bank verification window.',
        '5700'=>'This type of purchase is not permitted on this card (online payments may be disabled). No charge was made — approve the payment with your bank, then retry.',
        '5710'=>'Too many payment attempts on this card. Please wait a few minutes, then retry.',
        '5910'=>'Your card issuer is not responding.',
        '5920'=>'Your card issuer is temporarily unavailable. Nothing was charged — please try again in a moment.',
        '5930'=>'This card has not been activated yet. Please activate it with your bank, then retry.',
        '5950'=>'Your bank has issued you a new card; the old details were declined. Please use your updated card.',
        '7700'=>'The 3-D Secure bank verification could not be completed. Please try again.',
        'PPD3'=>'The 3-D Secure bank verification could not be completed. Please try again.',
        '7710'=>'The 3-D Secure bank verification failed. Please try again.',
        'PCNR'=>'The bank verification (3-D Secure) was not completed. Please try again and finish the verification.',
        '8000'=>'The payment processor had a system error. Nothing was charged — please try again.',
        '8100'=>'The payment processor could not be reached. Nothing was charged — please try again.',
        'PPER'=>'PayPal had an internal error. Nothing was charged — please try again.',
        'PPNT'=>'A card network error occurred. Nothing was charged — please try again.',
        '9100'=>'Your bank declined the payment and asked for a retry. Please try again.',
        '9500'=>'Your bank flagged this payment as suspected fraud and declined it. No charge was made — approve the payment with your bank, then retry.',
        '9510'=>'Your bank declined the payment for security reasons. No charge was made — approve the payment with your bank, then retry.',
        '9520'=>'This card has been reported lost or stolen and cannot be used.',
        '9530'=>'Your bank has asked you to call them before this payment can be approved.',
        '9540'=>'Your bank refused this card.',
        'PPRN'=>'Please re-enter your card details and try again.',
        'PPAB'=>'This card has been blocked by the issuing bank. No charge was made — approve the payment with your bank, then retry.',
        'PPAE'=>'American Express cards cannot be accepted here.',
        'PPSE'=>'American Express declined this payment.',
        'PPAX'=>'The amount exceeds the limit on this card.',
        'PPCO'=>'Cards issued in this country cannot be accepted. You can also pay with PayPal.',
        'PPCT'=>'This card type is not supported. Please use a Visa, Mastercard, Amex or Discover card.',
        'PPDT'=>'Too many declined attempts. Please try again later.',
        'PPFI'=>'This card cannot be used for this payment.',
        'PPFR'=>'This card is restricted and cannot be used.',
        'PPFV'=>'Some of the card details failed validation. Please check them and try again.',
        'PPMC'=>'Mastercard payments cannot be accepted here.',
        'PPSC'=>'The payment was declined by risk checks. You can also pay with PayPal.',
        'PPUC'=>'This currency is not supported for this card.',
    ];
    $code  = strtoupper(trim($code));
    $label = $labels[$code] ?? '';
    if (isset($msgs[$code])) return ['label'=>$label, 'message'=>$msgs[$code]];
    $nice  = $label !== '' ? ' (' . ucfirst(strtolower(str_replace('_', ' ', $label))) . ', code ' . $code . ')' : ($code !== '' ? ' (code ' . $code . ')' : '');
    return ['label'=>$label, 'message'=>'Your card was declined by the bank' . $nice . '. No charge was made — approve the payment with your bank, then retry.'];
}

/** PayPal 4xx `details[0].issue` → buyer-safe message (description shown when unknown). */
function paypal_issue_text(string $issue, string $description = ''): string {
    static $m = [
        'INSTRUMENT_DECLINED'                     => 'Your card / funding source was declined by your bank. No charge was made — approve it with your bank, then retry.',
        'PAYER_ACTION_REQUIRED'                   => 'Your bank requires additional verification (3-D Secure) for this payment. Please try again and complete the verification.',
        'ORDER_NOT_APPROVED'                      => 'The payment was not approved, so nothing was charged. Please try again.',
        'ORDER_EXPIRED'                           => 'The payment session expired. Please try again.',
        'ORDER_COMPLETED_OR_VOIDED'               => 'This payment has already been processed or voided. Please check your email for a receipt before retrying.',
        'PAYER_CANNOT_PAY'                        => 'PayPal could not process a payment from this account. Please retry, or pay by card instead.',
        'PAYER_ACCOUNT_RESTRICTED'                => 'Your PayPal account is restricted. Please retry, or pay by card instead.',
        'PAYER_ACCOUNT_LOCKED_OR_CLOSED'          => 'Your PayPal account is locked or closed. Please retry, or pay by card instead.',
        'PAYEE_ACCOUNT_RESTRICTED'                => 'Our PayPal account cannot accept this payment right now. Nothing was charged — please contact us.',
        'PAYEE_ACCOUNT_LOCKED_OR_CLOSED'          => 'Our PayPal account cannot accept this payment right now. Nothing was charged — please contact us.',
        'PAYEE_BLOCKED_TRANSACTION'               => 'This payment was blocked by our PayPal account settings. Nothing was charged — please contact us.',
        'TRANSACTION_BLOCKED_BY_PAYEE'            => 'This payment was blocked by our PayPal account settings. Nothing was charged — please contact us.',
        'TRANSACTION_REFUSED'                     => 'PayPal refused this transaction. Nothing was charged — please retry, or pay by card instead.',
        'TRANSACTION_LIMIT_EXCEEDED'              => 'The amount exceeds the PayPal transaction limit. Please retry, or pay by card instead.',
        'TRANSACTION_RECEIVING_LIMIT_EXCEEDED'    => 'PayPal could not accept this payment (receiving limit). Nothing was charged — please contact us.',
        'COMPLIANCE_VIOLATION'                    => 'PayPal blocked this payment for compliance reasons. Please retry, or pay by card instead.',
        'MAX_NUMBER_OF_PAYMENT_ATTEMPTS_EXCEEDED' => 'Too many payment attempts. Please try again later.',
        'CARD_EXPIRED'                            => 'This card has expired.',
        'CARD_CLOSED'                             => 'This card account has been closed.',
        'CARD_BRAND_NOT_SUPPORTED'                => 'This card brand is not supported. Please use a Visa, Mastercard, Amex or Discover card.',
        'CARD_TYPE_NOT_SUPPORTED'                 => 'This card type is not supported.',
        'CURRENCY_NOT_SUPPORTED_FOR_CARD_TYPE'    => 'This card cannot be charged in this currency.',
        'DOMESTIC_TRANSACTION_REQUIRED'           => 'This card can only be used for domestic payments.',
        'REDIRECT_PAYER_FOR_ALTERNATE_FUNDING'    => 'PayPal asks you to choose a different funding source. Please try again.',
        'DUPLICATE_INVOICE_ID'                    => 'A payment for this order reference already exists. Please check your email for a receipt before retrying.',
        'INVALID_RESOURCE_ID'                     => 'The payment reference was not found. Please try again.',
        'NOT_AUTHORIZED'                          => 'The payment could not be authorised on our merchant account. Nothing was charged — please contact us.',
        'PERMISSION_DENIED'                       => 'The payment could not be authorised on our merchant account. Nothing was charged — please contact us.',
        'AUTHENTICATION_FAILURE'                  => 'PayPal could not authenticate our merchant account. Nothing was charged — please contact us.',
        'INTERNAL_SERVER_ERROR'                   => 'PayPal had an internal error. Nothing was charged — please try again.',
    ];
    $issue = strtoupper(trim($issue));
    if (isset($m[$issue])) return $m[$issue];
    $d = trim($description);
    if ($d !== '') return rtrim($d, '.') . '.' . ($issue !== '' ? ' (' . $issue . ')' : '');
    return $issue !== '' ? 'PayPal could not complete the payment (' . $issue . ').' : 'PayPal could not complete the payment.';
}

/** Capture status_details.reason (PENDING / DENIED) → buyer-safe message. */
function paypal_pending_reason_text(string $reason): string {
    static $m = [
        'PENDING_REVIEW'      => 'PayPal is reviewing this payment. Nothing further is needed from you — we will email you as soon as it is confirmed (usually within a few hours).',
        'ECHECK'              => 'Your payment is being processed as a bank transfer (eCheck), which PayPal usually clears in 3–5 business days. We will email you as soon as the funds clear.',
        'UNILATERAL'          => 'PayPal is holding the payment until it is accepted. We will email you as soon as it is confirmed.',
        'VERIFICATION_REQUIRED' => 'PayPal needs to verify this payment before it clears. We will email you as soon as it is confirmed.',
        'INTERNATIONAL_WITHDRAWAL' => 'PayPal is processing this international payment. We will email you as soon as it is confirmed.',
        'RECEIVING_PREFERENCE_MANDATES_MANUAL_ACTION' => 'PayPal is holding the payment for manual acceptance. We will email you as soon as it is confirmed.',
        'TRANSACTION_APPROVED_AWAITING_FUNDING' => 'The payment was approved and is awaiting funding. We will email you as soon as the funds arrive.',
        'DECLINED_BY_RISK_FRAUD_FILTERS' => 'PayPal declined this payment through its risk / fraud filters. Nothing was charged — please use another payment method.',
        'BUYER_COMPLAINT'     => 'PayPal is holding this payment due to a buyer complaint.',
        'CHARGEBACK'          => 'This payment is subject to a chargeback.',
        'REFUNDED'            => 'This payment was refunded.',
        'OTHER'               => 'PayPal has placed this payment on hold. We will email you as soon as it is confirmed.',
    ];
    $reason = strtoupper(trim($reason));
    return $m[$reason] ?? ('PayPal has not confirmed this payment yet' . ($reason !== '' ? ' (' . $reason . ')' : '') . '. We will email you as soon as it is confirmed.');
}

/**
 * Normalise a PayPal order representation (capture or GET response) into the
 * facts we act on. `paid` is TRUE only when a capture exists whose OWN status
 * is COMPLETED — PayPal returns order.status=COMPLETED even for a DECLINED
 * card capture, so the order status alone is never trusted.
 */
function paypal_parse_order_json(array $j): array {
    $caps = [];
    foreach (($j['purchase_units'] ?? []) as $pu) {
        foreach (($pu['payments']['captures'] ?? []) as $c) $caps[] = $c;
    }
    $completed = null;
    foreach ($caps as $c) { if (($c['status'] ?? '') === 'COMPLETED') { $completed = $c; break; } }
    $last = $completed ?: ($caps ? end($caps) : []);
    $card = $j['payment_source']['card'] ?? [];
    $pp   = $j['payment_source']['paypal'] ?? [];
    $brandRaw = strtoupper((string)($card['brand'] ?? ''));
    $brandMap = ['VISA'=>'Visa','MASTERCARD'=>'Mastercard','MASTER_CARD'=>'Mastercard','AMEX'=>'Amex','DISCOVER'=>'Discover','DINERS'=>'Diners','JCB'=>'JCB','MAESTRO'=>'Maestro','CUP'=>'UnionPay','ELO'=>'Elo','HIPER'=>'Hiper'];
    $funding = strtolower((string)($card['type'] ?? ''));
    $auth = $card['authentication_result'] ?? [];
    // Expiry arrives as "YYYY-MM" → store/display as MM/YY (same shape as NMI).
    $expRaw = (string)($card['expiry'] ?? '');
    $expMmYy = preg_match('/^(\d{4})-(\d{2})$/', $expRaw, $em) ? ($em[2] . '/' . substr($em[1], 2)) : '';
    $bin = preg_replace('/\D/', '', (string)($card['bin_details']['bin'] ?? ''));
    return [
        'order_status'   => (string)($j['status'] ?? ''),
        'capture_id'     => (string)($last['id'] ?? ''),
        'capture_status' => (string)($last['status'] ?? ''),
        'reason'         => (string)($last['status_details']['reason'] ?? ''),
        'amount'         => isset($last['amount']['value']) ? (float)$last['amount']['value'] : null,
        'currency'       => strtoupper((string)($last['amount']['currency_code'] ?? '')),
        'processor'      => [
            'response_code' => (string)($last['processor_response']['response_code'] ?? ''),
            'avs_code'      => (string)($last['processor_response']['avs_code'] ?? ''),
            'cvv_code'      => (string)($last['processor_response']['cvv_code'] ?? ''),
        ],
        'paid'           => $completed !== null,
        'card'           => $card ? [
            'brand'   => $brandRaw !== '' ? ($brandMap[$brandRaw] ?? ucfirst(strtolower($brandRaw))) : '',
            'last4'   => (string)($card['last_digits'] ?? ''),
            'funding' => in_array($funding, ['credit','debit','prepaid'], true) ? $funding : '',
            'country' => strtoupper((string)($card['bin_details']['bin_country_code'] ?? '')),
            'bank'    => (string)($card['bin_details']['issuing_bank'] ?? ''),
            'bin'     => strlen($bin) >= 6 ? substr($bin, 0, 6) : '',
            'exp'     => $expMmYy,
            'cvv'     => (string)($last['processor_response']['cvv_code'] ?? ''),
            'avs'     => (string)($last['processor_response']['avs_code'] ?? ''),
            'name'    => (string)($card['name'] ?? ''),
            'liability_shift' => (string)($auth['liability_shift'] ?? ''),
            'three_ds'        => (string)($auth['three_d_secure']['authentication_status'] ?? ''),
            'enrollment'      => (string)($auth['three_d_secure']['enrollment_status'] ?? ''),
        ] : [],
        'payer'          => $pp ? [
            'email' => (string)($pp['email_address'] ?? ''),
            'id'    => (string)($pp['account_id'] ?? ''),
        ] : [],
    ];
}

/** Build the not-paid result (decline / pending / error) from parsed facts. */
function paypal_failure_result(array $p, string $fallbackStatus = 'FAILED'): array {
    $st = $p['capture_status'] ?: $fallbackStatus;
    if ($st === 'PENDING') {
        return ['ok'=>false, 'pending'=>true, 'status'=>'PENDING', 'capture_id'=>$p['capture_id'], 'code'=>'PENDING' . ($p['reason'] !== '' ? ':' . $p['reason'] : ''),
                'label'=>$p['reason'], 'error'=>paypal_pending_reason_text($p['reason']), 'card'=>$p['card'], 'payer'=>$p['payer'], 'amount'=>$p['amount'], 'currency'=>$p['currency']];
    }
    $rc = $p['processor']['response_code'];
    if ($rc !== '' && $rc !== '0000') {
        $t = paypal_processor_decline_text($rc);
        return ['ok'=>false, 'pending'=>false, 'status'=>$st ?: 'DECLINED', 'capture_id'=>$p['capture_id'], 'code'=>$rc, 'label'=>$t['label'],
                'error'=>$t['message'], 'processor'=>$p['processor'], 'card'=>$p['card'], 'payer'=>$p['payer'], 'amount'=>$p['amount'], 'currency'=>$p['currency']];
    }
    if ($p['reason'] !== '') {
        return ['ok'=>false, 'pending'=>false, 'status'=>$st, 'capture_id'=>$p['capture_id'], 'code'=>$p['reason'], 'label'=>$p['reason'],
                'error'=>paypal_pending_reason_text($p['reason']), 'card'=>$p['card'], 'payer'=>$p['payer'], 'amount'=>$p['amount'], 'currency'=>$p['currency']];
    }
    return ['ok'=>false, 'pending'=>false, 'status'=>$st, 'capture_id'=>$p['capture_id'], 'code'=>$st, 'label'=>$st,
            'error'=>'PayPal did not complete the payment (status: ' . $st . '). Nothing was charged — please retry the payment.',
            'card'=>$p['card'], 'payer'=>$p['payer'], 'amount'=>$p['amount'], 'currency'=>$p['currency']];
}

/**
 * Fetch an existing PayPal order (GET). Used to reconcile the
 * ORDER_ALREADY_CAPTURED race so a refresh/retry never marks a PAID order as
 * failed — and never marks a DECLINED one as paid. `paid` is true only when a
 * capture with status COMPLETED exists.
 */
function paypal_get_order(string $paypalOrderId, string $mode): array {
    $token = paypal_access_token($mode);
    if ($token === '') return ['ok'=>false, 'status'=>'', 'capture_id'=>'', 'paid'=>false, 'capture_status'=>''];
    $ch = curl_init(paypal_api_base($mode) . '/v2/checkout/orders/' . rawurlencode($paypalOrderId));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $j = json_decode($body, true) ?: [];
    $p = paypal_parse_order_json($j);
    return ['ok'=>($code >= 200 && $code < 300), 'status'=>$p['order_status'], 'capture_id'=>$p['capture_id'], 'paid'=>$p['paid'],
            'capture_status'=>$p['capture_status'], 'parsed'=>$p];
}

/**
 * Capture an approved PayPal order. Returns
 * ['ok'=>bool,'status'=>str,'capture_id'=>str,'error'=>str,'code'=>str,'label'=>str,
 *  'pending'=>bool,'amount'=>float|null,'currency'=>str,'card'=>[],'payer'=>[]].
 *
 * MONEY-SAFE: ok=true ONLY when a capture's own status is COMPLETED. PayPal
 * answers HTTP 201 + order.status=COMPLETED for a DECLINED card (the decline
 * lives in purchase_units[].payments.captures[].status + processor_response),
 * so we never trust the order status. PENDING captures (review / eCheck) are
 * reported with pending=true so callers hold the order instead of fulfilling.
 *
 * IDEMPOTENT: on 422 ORDER_ALREADY_CAPTURED (refresh / double submit) we
 * re-fetch the order and report success only if a COMPLETED capture exists —
 * otherwise the real decline reason from that capture is returned.
 */
/**
 * Ask PayPal what actually happened to an order (GET) and turn it into the
 * same result shape as paypal_capture_order(). Used whenever the capture
 * outcome is ambiguous (already captured, timeout, PayPal 5xx) so a buyer
 * whose card WAS charged is never told "failed" and never charged twice.
 * Returns null when PayPal has no capture on record for the order.
 */
function paypal_reconcile_order(string $paypalOrderId, string $mode, ?bool &$answered = null): ?array {
    $chk = paypal_get_order($paypalOrderId, $mode);
    $answered = !empty($chk['ok']);
    $p   = $chk['parsed'] ?? null;
    if (!$p) return null;
    if ($p['paid']) {
        return ['ok'=>true, 'pending'=>false, 'status'=>'COMPLETED', 'capture_id'=>($p['capture_id'] ?: $paypalOrderId), 'reconciled'=>true,
                'amount'=>$p['amount'], 'currency'=>$p['currency'], 'card'=>$p['card'], 'payer'=>$p['payer'], 'processor'=>$p['processor']];
    }
    if ($p['capture_status'] !== '') { $r = paypal_failure_result($p, 'FAILED'); $r['reconciled'] = true; return $r; }
    return null;
}

function paypal_capture_order(string $paypalOrderId, string $mode): array {
    @set_time_limit(120);
    $token = paypal_access_token($mode);
    if ($token === '') return ['ok'=>false, 'pending'=>false, 'status'=>'', 'capture_id'=>'', 'code'=>'AUTH', 'error'=>'PayPal authentication failed. Nothing was charged — please contact us.'];
    $ch = curl_init(paypal_api_base($mode) . '/v2/checkout/orders/' . rawurlencode($paypalOrderId) . '/capture');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS     => '{}',
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token, 'Prefer: return=representation'],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    $j = json_decode($body, true) ?: [];

    if ($code >= 200 && $code < 300) {
        $p = paypal_parse_order_json($j);
        if ($p['paid']) {
            $done = null;
            foreach (($j['purchase_units'][0]['payments']['captures'] ?? []) as $c) { if (($c['status'] ?? '') === 'COMPLETED') { $done = $c; break; } }
            return ['ok'=>true, 'pending'=>false, 'status'=>'COMPLETED', 'capture_id'=>(string)($done['id'] ?? $p['capture_id'] ?: $paypalOrderId),
                    'amount'=>isset($done['amount']['value']) ? (float)$done['amount']['value'] : $p['amount'],
                    'currency'=>strtoupper((string)($done['amount']['currency_code'] ?? $p['currency'])),
                    'card'=>$p['card'], 'payer'=>$p['payer'], 'processor'=>$p['processor']];
        }
        @error_log('[paypal capture] not completed HTTP ' . $code . ' capture=' . $p['capture_status'] . ' rc=' . $p['processor']['response_code'] . ' reason=' . $p['reason'] . ' id=' . $paypalOrderId);
        return paypal_failure_result($p, 'FAILED');
    }

    $issue = (string)($j['details'][0]['issue'] ?? '');
    $desc  = (string)($j['details'][0]['description'] ?? ($j['message'] ?? ''));
    if ($code === 422 && ($issue === 'ORDER_ALREADY_CAPTURED' || stripos($body, 'ORDER_ALREADY_CAPTURED') !== false
                          || $issue === 'ORDER_COMPLETED_OR_VOIDED')) {
        $r = paypal_reconcile_order($paypalOrderId, $mode);
        if ($r !== null) return $r;
    }

    @error_log('[paypal capture] HTTP ' . $code . ' ' . ($cerr !== '' ? 'curl: ' . $cerr . ' ' : '') . $body);
    // Ambiguous outcome (timeout / PayPal 5xx): the capture MAY have gone
    // through. Ask PayPal before saying anything to the buyer.
    if ($code === 0 || $code >= 500) {
        $answered = false;
        $r = paypal_reconcile_order($paypalOrderId, $mode, $answered);
        if ($r !== null) return $r;
        return ['ok'=>false, 'pending'=>false, 'status'=>'ERROR', 'capture_id'=>'', 'code'=>'NETWORK', 'label'=>'NETWORK',
                'error'=>$answered
                    ? 'PayPal did not complete the payment (temporary PayPal error). Nothing was charged — please wait a moment and try again.'
                    : 'We could not reach PayPal to confirm the payment. Please wait a moment and try again — do not re-enter your card until you have checked your email for a receipt.'];
    }
    return ['ok'=>false, 'pending'=>false, 'status'=>$issue ?: 'FAILED', 'capture_id'=>'', 'code'=>($issue ?: 'HTTP_' . $code), 'label'=>$issue,
            'error'=>paypal_issue_text($issue, $desc)];
}

/**
 * Finalise a COMPLETED capture on OUR order — the single place that marks a
 * PayPal order paid. Verifies the captured amount + currency equal the order
 * total before anything else; on mismatch the order is NOT marked paid (the
 * anomaly is logged + flagged for the admin). Returns ['ok'=>bool,'error'=>str].
 */
function paypal_settle_order(array $order, array $cap, string $via): array {
    $pdo      = db();
    $orderId  = (int)$order['id'];
    $total    = round((float)($order['total'] ?? 0), 2);
    $currency = strtoupper((string)($order['currency'] ?? '') ?: (function_exists('current_currency') ? (current_currency()['code'] ?? 'USD') : 'USD'));
    $capId    = (string)($cap['capture_id'] ?? '');
    $capAmt   = isset($cap['amount']) && $cap['amount'] !== null ? round((float)$cap['amount'], 2) : null;
    $capCur   = strtoupper((string)($cap['currency'] ?? ''));

    if ($capAmt === null || abs($capAmt - $total) > 0.005 || ($capCur !== '' && $capCur !== $currency)) {
        $msg = 'PayPal captured ' . ($capAmt === null ? 'an unknown amount' : $capCur . ' ' . number_format($capAmt, 2))
             . ' but the order total is ' . $currency . ' ' . number_format($total, 2) . '. The order has NOT been marked paid — please contact support quoting order ' . ($order['order_number'] ?? '') . ' (do not pay again).';
        @error_log('[paypal settle] AMOUNT MISMATCH order ' . $orderId . ' capture ' . $capId . ': ' . $msg);
        try {
            $pdo->prepare('UPDATE orders SET payment_status = "review", payment_error_code = ?, payment_error_message = ?, transaction_id = ?, last_activity_at = NOW() WHERE id = ?')
                ->execute(['paypal_amount_mismatch', substr($msg, 0, 500), $capId !== '' ? $capId : ($order['transaction_id'] ?? ''), $orderId]);
            $pdo->prepare('INSERT INTO transaction_logs (order_id, gateway, transaction_id, amount, currency, status, raw_response) VALUES (?,?,?,?,?,?,?)')
                ->execute([$orderId, 'paypal', $capId, $capAmt ?? 0, $capCur ?: $currency, 'review',
                           json_encode(['status'=>'AMOUNT_MISMATCH', 'expected'=>$total, 'captured'=>$capAmt, 'expected_currency'=>$currency, 'captured_currency'=>$capCur, 'via'=>$via], JSON_UNESCAPED_SLASHES)]);
        } catch (Throwable $e) { @error_log('[paypal settle] ' . $e->getMessage()); }
        return ['ok'=>false, 'error'=>$msg, 'code'=>'AMOUNT_MISMATCH'];
    }

    $card  = $cap['card']  ?? [];
    $payer = $cap['payer'] ?? [];
    $pdo->prepare('UPDATE orders SET status = "paid", payment_status = "succeeded", transaction_id = ?, payment_error_code = NULL, payment_error_message = NULL, last_activity_at = NOW() WHERE id = ?')
        ->execute([$capId !== '' ? $capId : (string)($order['transaction_id'] ?? ''), $orderId]);
    try {
        if ($card) {
            // Same PCI-allowed subset the NMI card flow stores (brand, BIN, last 4,
            // expiry, CVV match status, funding, country) so the admin sees the
            // identical "Card Details" block for a card paid through PayPal.
            $pdo->prepare('UPDATE orders SET
                    card_brand = COALESCE(NULLIF(?, ""), card_brand), card_last4 = COALESCE(NULLIF(?, ""), card_last4),
                    card_funding = COALESCE(NULLIF(?, ""), card_funding), card_country = COALESCE(NULLIF(?, ""), card_country),
                    paypal_funding_source = "card_direct", paypal_funding_card_brand = COALESCE(NULLIF(?, ""), paypal_funding_card_brand),
                    paypal_funding_card_last4 = COALESCE(NULLIF(?, ""), paypal_funding_card_last4)
                 WHERE id = ?')
                ->execute([$card['brand'] ?? '', $card['last4'] ?? '', $card['funding'] ?? '', $card['country'] ?? '', $card['brand'] ?? '', $card['last4'] ?? '', $orderId]);
            $cvvLabel = function_exists('mv_cvv_status_label') ? mv_cvv_status_label((string)($card['cvv'] ?? '')) : '';
            $cardType = ($card['funding'] ?? '') !== '' ? ucfirst((string)$card['funding']) : '';
            foreach ([
                'card_bin'                 => (string)($card['bin'] ?? ''),
                'card_exp'                 => (string)($card['exp'] ?? ''),
                'card_cvv_status'          => $cvvLabel,
                'card_type'                => $cardType,
                'paypal_funding_bank_name' => (string)($card['bank'] ?? ''),
            ] as $col => $val) {
                if ($val === '') continue;
                try { $pdo->prepare("UPDATE orders SET `$col` = COALESCE(NULLIF(?, ''), `$col`) WHERE id = ?")->execute([$val, $orderId]); }
                catch (Throwable $e) { /* column absent on this install — zero-DDL, skip */ }
            }
        } elseif ($payer) {
            $pdo->prepare('UPDATE orders SET paypal_payer_email = COALESCE(NULLIF(?, ""), paypal_payer_email), paypal_payer_id = COALESCE(NULLIF(?, ""), paypal_payer_id) WHERE id = ?')
                ->execute([$payer['email'] ?? '', $payer['id'] ?? '', $orderId]);
        }
    } catch (Throwable $e) { @error_log('[paypal settle meta] ' . $e->getMessage()); }
    try {
        $raw = ['status'=>'COMPLETED', 'via'=>$via, 'captured'=>$capAmt, 'currency'=>$capCur];
        if ($card)  $raw['card']  = ['brand'=>$card['brand'] ?? '', 'last4'=>$card['last4'] ?? '', 'bin'=>$card['bin'] ?? '', 'exp'=>$card['exp'] ?? '', 'funding'=>$card['funding'] ?? '', 'country'=>$card['country'] ?? '', 'bank'=>$card['bank'] ?? '', 'liability_shift'=>$card['liability_shift'] ?? '', '3ds'=>$card['three_ds'] ?? ''];
        if ($card)  { $raw['card_brand'] = $card['brand'] ?? ''; $raw['card_last4'] = $card['last4'] ?? ''; } // card-trail keys (order-view)
        if (!empty($cap['processor']['response_code'])) $raw['processor_response'] = $cap['processor'];
        if (!empty($cap['reconciled'])) $raw['reconciled'] = true;
        $pdo->prepare('INSERT INTO transaction_logs (order_id, gateway, transaction_id, amount, currency, status, raw_response) VALUES (?,?,?,?,?,?,?)')
            ->execute([$orderId, 'paypal', $capId, $total, $currency, 'succeeded', json_encode($raw, JSON_UNESCAPED_SLASHES)]);
    } catch (Throwable $e) { /* best-effort */ }
    unset($_SESSION['mv_resume_order_id']);
    $_SESSION['mv_last_paid_order'] = (string)($order['order_number'] ?? '');
    if (function_exists('fulfill_order')) {
        try { fulfill_order($orderId); }
        catch (Throwable $e) { @error_log('[paypal settle fulfill] order ' . $orderId . ': ' . $e->getMessage()); }
    }
    foreach (['cart', 'coupon', 'proassist', 'sub_plan'] as $k) { unset($_SESSION[$k]); }
    return ['ok'=>true, 'capture_id'=>$capId];
}

/**
 * Record a NOT-completed capture on our order. PENDING → payment_status
 * "pending" (held, webhook PAYMENT.CAPTURE.COMPLETED finalises it later);
 * everything else → the single failure funnel (mv_mark_payment_failed) with
 * the exact PayPal decline code + buyer message so the admin sees the reason.
 */
function paypal_record_not_paid(array $order, array $cap, string $paypalOrderId, string $via): void {
    $pdo     = db();
    $orderId = (int)$order['id'];
    $card    = $cap['card'] ?? [];
    $code    = (string)($cap['code'] ?? 'paypal_capture_failed');
    $label   = (string)($cap['label'] ?? '');
    $msg     = (string)($cap['error'] ?? 'PayPal capture failed.');
    $raw     = ['status'=>$cap['status'] ?? 'FAILED', 'code'=>$code, 'label'=>$label, 'error'=>$msg, 'via'=>$via, 'paypal_order_id'=>$paypalOrderId];
    if (!empty($cap['processor'])) $raw['processor_response'] = $cap['processor'];
    if (!empty($cap['capture_id'])) $raw['capture_id'] = $cap['capture_id'];
    if ($card) $raw['card'] = ['brand'=>$card['brand'] ?? '', 'last4'=>$card['last4'] ?? '', 'funding'=>$card['funding'] ?? '', 'country'=>$card['country'] ?? '', 'liability_shift'=>$card['liability_shift'] ?? '', '3ds'=>$card['three_ds'] ?? ''];

    if (!empty($cap['pending'])) {
        try {
            $pdo->prepare('UPDATE orders SET payment_status = "pending", payment_error_code = ?, payment_error_message = ?, transaction_id = ?, last_activity_at = NOW() WHERE id = ?')
                ->execute([substr($code, 0, 80), substr($msg, 0, 500), 'PP:' . $paypalOrderId, $orderId]);
            $pdo->prepare('INSERT INTO transaction_logs (order_id, gateway, transaction_id, amount, currency, status, raw_response) VALUES (?,?,?,?,?,?,?)')
                ->execute([$orderId, 'paypal', (string)($cap['capture_id'] ?? $paypalOrderId), (float)($order['total'] ?? 0), (string)($order['currency'] ?? 'USD'), 'pending', json_encode($raw, JSON_UNESCAPED_SLASHES)]);
        } catch (Throwable $e) { @error_log('[paypal pending] ' . $e->getMessage()); }
        return;
    }
    if (function_exists('mv_mark_payment_failed')) {
        mv_mark_payment_failed($order, [
            'code'           => $label !== '' && $label !== $code ? $label . ' (' . $code . ')' : $code,
            'message'        => $msg,
            'transaction_id' => $paypalOrderId,
            'gateway'        => 'paypal',
            'card_brand'     => (string)($card['brand'] ?? ''),
            'card_last4'     => (string)($card['last4'] ?? ''),
            'raw_response'   => json_encode($raw, JSON_UNESCAPED_SLASHES),
        ]);
    }
}
