<?php
/**
 * includes/gateways/charge.php
 *
 * Server-side, direct-charge implementations for the non-Stripe card
 * gateways (NMI, Authorize.Net, and a generic "Custom" direct-post).
 *
 * These gateways collect the raw card number / expiry / CVV on OUR checkout
 * form and POST it straight to the processor's transaction API (Direct Post
 * for NMI, the XML API for Authorize.Net).  Stripe keeps using its hosted
 * redirect flow (see includes/stripe.php) so this file is ONLY used when the
 * admin has selected NMI / Authorize.Net / Custom as the active card gateway.
 *
 * SECURITY:
 *   · We never persist the PAN or CVV anywhere — only last4 + brand.
 *   · Goods are released upstream (fulfill_order) ONLY after mv_card_charge()
 *     returns status='succeeded'.
 *   · TLS peer verification is always ON.
 *
 * Every charge function returns a normalised array:
 *   [
 *     'status'         => 'succeeded' | 'failed',
 *     'error_code'     => string,   // machine code when failed
 *     'error_message'  => string,   // human-readable reason (safe to show)
 *     'transaction_id' => string,   // processor transaction id
 *     'auth_code'      => string,   // processor auth code (when present)
 *     'raw'            => array,    // sanitised processor payload for logging
 *   ]
 */

require_once __DIR__ . '/../settings.php';

/**
 * Minimal cURL POST helper.  Returns [http_code, body, curl_errno, curl_error].
 */
function mv_gw_http_post(string $url, string $body, array $headers): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $resp  = curl_exec($ch);
    $errNo = curl_errno($ch);
    $err   = curl_error($ch);
    $code  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $resp === false ? '' : (string)$resp, $errNo, $err];
}

/** Best-effort card brand from the PAN (display only — never stores full PAN). */
function mv_detect_card_brand(string $pan): string
{
    $d = preg_replace('/\D/', '', $pan);
    if ($d === '') return '';
    if (preg_match('/^4\d{12,18}$/', $d)) return 'Visa';
    if (preg_match('/^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7[01]\d{12}|720\d{12}))$/', $d)) return 'Mastercard';
    if (preg_match('/^3[47]\d{13}$/', $d)) return 'Amex';
    if (preg_match('/^(6011\d{12}|65\d{14}|64[4-9]\d{13}|622\d{13})$/', $d)) return 'Discover';
    return 'Card';
}

/** ISO 3166-1 alpha-2 country for gateway requests. Our storefront region
 *  code "UK" is NOT an ISO code (the United Kingdom is "GB") and "EU" is not a
 *  country at all — NMI / AVS only understand ISO codes, so a wrong code can
 *  spoil the address check for a perfectly good card. Returns '' when there is
 *  no usable country (callers then omit the field). */
function mv_gateway_country_code(string $cc): string
{
    $cc = substr(strtoupper(trim($cc)), 0, 2);
    if ($cc === 'UK') return 'GB';
    if ($cc === 'EU' || !preg_match('/^[A-Z]{2}$/', $cc)) return '';
    return $cc;
}

/** Map a raw processor decline/reject text into a friendly, customer-safe
 *  message. The RAW text is still logged (rawSafe.responsetext) so the admin
 *  decline trail shows the true gateway reason (e.g. "REJECTED CONTACT CUST
 *  SERV"), while the shopper never sees a scary all-caps gateway string. */
function mv_card_decline_message(string $respCode, string $rawText): string
{
    // NMI / processor response_code → the EXACT reason (per NMI's Payment API
    // response-code table). Code first (authoritative), then the text heuristics.
    static $byCode = [
        '200' => 'Your bank declined the payment. No charge was made — approve the payment with your bank, then retry.',
        '201' => 'Your bank declined the payment (Do Not Honor). No charge was made — approve the payment with your bank, then retry.',
        '202' => 'Insufficient funds — your bank declined the payment. No charge was made — top up or approve it with your bank, then retry.',
        '203' => 'This card is over its limit — your bank declined the payment. No charge was made.',
        '204' => 'Your bank does not allow this type of transaction on this card (online payments may be disabled). No charge was made — approve it with your bank, then retry.',
        '220' => 'The card details were not accepted by your bank (incorrect payment information). Please re-check the card number, expiry and CVV.',
        '221' => 'No such card issuer — please check the card number.',
        '222' => 'Your bank has no card with this number on file — please check the card number.',
        '223' => 'Your bank reports this card as expired. No charge was made.',
        '224' => 'The expiry date is invalid. Please re-check it and try again.',
        '225' => 'The card security code (CVV) is invalid. Please re-check it and try again.',
        '226' => 'Invalid PIN.',
        '240' => 'Your bank asks you to call them to approve this payment. No charge was made — call your bank, then retry.',
        '250' => 'Your bank declined this card (pick-up card). No charge was made.',
        '251' => 'This card has been reported lost. No charge was made.',
        '252' => 'This card has been reported stolen. No charge was made.',
        '253' => 'Your bank flagged this card as fraudulent and declined the payment. No charge was made.',
        '260' => 'Your bank declined the payment. No charge was made — approve the payment with your bank, then retry.',
        '261' => 'Your bank declined the payment and asked to stop all recurring payments on this card.',
        '262' => 'Your bank declined the payment and asked to stop this recurring program.',
        '263' => 'Your bank declined the payment — updated card details are available from your bank. Please use your new card.',
        '264' => 'Your bank declined the payment and asks you to retry in a few days.',
        '300' => 'The payment was rejected by the payment gateway (not by your bank). No charge was made — please try again or contact us.',
        '400' => 'The card processor returned an error. No charge was made — please try again.',
        '410' => 'Payment gateway configuration error on our side. No charge was made — please contact us.',
        '411' => 'Our merchant account is inactive. No charge was made — please contact us.',
        '420' => 'Communication error with the card processor. No charge was made — please try again.',
        '421' => 'Communication error with your card issuer. No charge was made — please try again.',
        '430' => 'This looks like a duplicate of a payment already made. Please check your email for a receipt before retrying.',
        '440' => 'The card processor rejected the request format. No charge was made — please try again.',
        '441' => 'Invalid transaction information. No charge was made — please re-check your details and try again.',
        '460' => 'This payment feature is not available on our processor. No charge was made — please contact us.',
        '461' => 'This card type is not supported. Please use a Visa, Mastercard, Amex or Discover card.',
    ];
    $respCode = trim($respCode);
    $t = strtoupper(trim($rawText));
    if (isset($byCode[$respCode])) {
        $m = $byCode[$respCode];
        // Codes 200/260/300/400 are generic — append the processor's own words so the exact reason is never hidden.
        if (in_array($respCode, ['200', '260', '300', '400'], true) && $t !== '' && !preg_match('/^(DECLINE|DECLINED|SUCCESS)$/', $t)) {
            $m .= ' Bank message: "' . ucfirst(strtolower(preg_replace('/\s+/', ' ', $rawText))) . '".';
        }
        return $m;
    }
    if ($t === '') return 'Your card was declined by your bank. No charge was made — approve the payment with your bank if asked, then retry.';
    // Gateway / fraud-filter rejection (NMI "Deny Transaction", pickup, fraud).
    if (preg_match('/REJECT|FRAUD|CONTACT (CARD ISSUER|CUST|YOUR)|PICK ?UP|SECURITY VIOLATION|SERV|DO NOT HONOR|DO NOT HONOUR/', $t)) {
        return 'Your bank did not authorise this payment (Do Not Honor). No charge was made — please approve the payment with your bank, then retry.';
    }
    if (strpos($t, 'INSUFFICIENT') !== false)         return 'Insufficient funds — your bank declined the payment. No charge was made.';
    if (strpos($t, 'EXPIRED') !== false)              return 'Your bank reports this card as expired. No charge was made.';
    if (strpos($t, 'CVV') !== false || strpos($t, 'CVC') !== false || strpos($t, 'CVV2') !== false)
                                                       return 'The card security code (CVV) didn\'t match. Please re-check it and try again.';
    if (strpos($t, 'AVS') !== false || strpos($t, 'ADDRESS') !== false)
                                                       return 'The billing address didn\'t match your card. Please re-check it and try again.';
    if (strpos($t, 'INVALID') !== false && (strpos($t, 'CARD') !== false || strpos($t, 'ACCOUNT') !== false || strpos($t, 'NUMBER') !== false))
                                                       return 'That card number looks invalid. Please re-check the number and try again.';
    // Plain bank decline — keep it simple and non-technical.
    return 'Your card was declined by your bank. No charge was made — approve the payment with your bank if asked, then retry.' . ($t !== '' && !preg_match('/^(DECLINE|DECLINED)$/', $t) ? ' Bank message: "' . ucfirst(strtolower(preg_replace('/\s+/', ' ', trim($rawText)))) . '".' : '');
}


function mv_parse_exp(string $exp): array
{
    $exp = trim($exp);
    $mm = ''; $yy = '';
    // Explicit separator: "M/YY", "MM/YY", "M/YYYY", "MM/YYYY" (/, -, ., space).
    if (preg_match('~^(\d{1,2})\s*[/\-. ]\s*(\d{2}|\d{4})$~', $exp, $m)) {
        $mm = $m[1]; $yy = $m[2];
    } else {
        $d = preg_replace('/\D/', '', $exp);
        switch (strlen($d)) {
            case 4: $mm = substr($d, 0, 2); $yy = substr($d, 2, 2); break; // MMYY
            case 3: $mm = substr($d, 0, 1); $yy = substr($d, 1, 2); break; // MYY
            case 6: $mm = substr($d, 0, 2); $yy = substr($d, 4, 2); break; // MMYYYY
            case 5: $mm = substr($d, 0, 1); $yy = substr($d, 3, 2); break; // MYYYY
            default: return ['', ''];
        }
    }
    $mi = (int)$mm;
    if ($mi < 1 || $mi > 12) return ['', '']; // never emit a bogus month like "32"
    $mm = str_pad((string)$mi, 2, '0', STR_PAD_LEFT); // ALWAYS zero-padded MM
    if (strlen($yy) === 4) $yy = substr($yy, -2);
    if (strlen($yy) !== 2 || !ctype_digit($yy)) return ['', ''];
    return [$mm, $yy]; // MM, YY (both 2 digits) or ['',''] if unparseable
}

/** Luhn (mod-10) check for a raw PAN. */
function mv_luhn_ok(string $digits): bool
{
    if (!preg_match('/^\d{13,19}$/', $digits)) return false;
    $sum = 0; $alt = false;
    for ($i = strlen($digits) - 1; $i >= 0; $i--) {
        $n = (int)$digits[$i];
        if ($alt) { $n *= 2; if ($n > 9) $n -= 9; }
        $sum += $n; $alt = !$alt;
    }
    return $sum % 10 === 0;
}

/**
 * Universal card-field validation for the DIRECT-CHARGE gateways that post the
 * raw PAN to us — NMI (classic, no Collect.js), Authorize.Net, and custom
 * (e.g. Razorpay). Returns '' when valid, otherwise a shopper-friendly error.
 * Hosted flows (NMI Collect.js token, Stripe redirect) validate on the
 * provider side and never pass raw fields through here, so they skip this.
 * Rules are the universal card rules every processor enforces: Luhn-valid
 * number, a real non-expired MM/YY that isn't implausibly far out, and a
 * brand-correct security code (Amex = 4 digits, everything else = 3).
 */
function mv_validate_card_fields(string $pan, string $exp, string $cvv): string
{
    $pan = preg_replace('/\D/', '', $pan);
    if ($pan === '' || !mv_luhn_ok($pan)) {
        return 'Please enter a valid card number.';
    }
    [$mm, $yy] = mv_parse_exp($exp);
    if ($mm === '' || $yy === '') {
        return 'Please enter a valid card expiry date (MM / YY).';
    }
    $expY = 2000 + (int)$yy; $expM = (int)$mm;
    $nowY = (int)date('Y'); $nowM = (int)date('n');
    if ($expY < $nowY || ($expY === $nowY && $expM < $nowM)) {
        return 'This card has expired — please check the expiry date.';
    }
    $cvvD  = preg_replace('/\D/', '', $cvv);
    $brand = mv_detect_card_brand($pan);
    $isAmex = (stripos($brand, 'amex') !== false || stripos($brand, 'american') !== false);
    $need  = $isAmex ? 4 : 3;
    if (strlen($cvvD) !== $need) {
        return $isAmex
            ? 'American Express security codes are 4 digits.'
            : 'Please enter a valid 3-digit security code.';
    }
    return '';
}

/**
 * Persist PCI-safe card metadata (brand + BIN + last4 + MM/YY) for an order from
 * the posted card fields. NEVER stores the full PAN or the CVV code. Used on the
 * test-mode success + decline paths so the admin card panel shows WHICH card was
 * used (Visa/Mastercard/Amex/Discover) even on declined/retried attempts.
 */
function mv_capture_card_meta(PDO $pdo, int $orderId, ?string $panRaw = null, ?string $expRaw = null): void
{
    try {
        if ($orderId <= 0) return;
        $pan = preg_replace('/\D/', '', (string)($panRaw ?? ($_POST['card_number'] ?? '')));
        if ($pan !== '') {
            [$mm, $yy] = mv_parse_exp((string)($expRaw ?? ($_POST['card_exp'] ?? '')));
            $meta = ['brand' => mv_detect_card_brand($pan), 'last4' => substr($pan, -4), 'bin' => substr($pan, 0, 6),
                     'exp' => ($mm !== '' && $yy !== '') ? $mm . '/' . $yy : ''];
        } else {
            $meta = mv_token_card_meta(); // Collect.js tokenised attempt — PAN never reaches us
            if ($meta['last4'] === '') return;
        }
        $pdo->prepare('UPDATE orders SET card_brand = ?, card_last4 = ?, card_bin = ?, card_exp = COALESCE(NULLIF(?, ""), card_exp) WHERE id = ?')
            ->execute([$meta['brand'], $meta['last4'], $meta['bin'], $meta['exp'], $orderId]);
        // Direct-charge gateways (NMI / Authorize.Net / Custom) don't return card
        // funding type or issuing country the way Stripe does, so derive them from
        // the stored BIN (cached, best-effort). Only fills blanks — never clobbers
        // richer data already captured by Stripe.
        if (!empty($meta['bin'])) {
            require_once __DIR__ . '/../bin_lookup.php';
            $bl = mv_bin_lookup($meta['bin']);
            if (($bl['funding'] ?? '') !== '' || ($bl['country'] ?? '') !== '') {
                $pdo->prepare("UPDATE orders SET
                        card_funding = CASE WHEN (card_funding IS NULL OR card_funding='' OR card_funding='unknown') THEN NULLIF(?, '') ELSE card_funding END,
                        card_country = CASE WHEN (card_country IS NULL OR card_country='') THEN NULLIF(?, '') ELSE card_country END
                     WHERE id = ?")
                    ->execute([$bl['funding'], $bl['country'], $orderId]);
            }
        }
    } catch (Throwable $e) {
        @error_log('[mv_capture_card_meta] ' . $e->getMessage());
    }
}

/** PCI-safe [card_brand, card_last4] for the current POSTed attempt — embedded
 *  into transaction_logs.raw_response so the per-order decline trail can show
 *  which card each attempt used. Returns [] when no card data is present. */
function mv_attempt_card_meta_arr(?string $panRaw = null): array
{
    $pan = preg_replace('/\D/', '', (string)($panRaw ?? ($_POST['card_number'] ?? '')));
    if ($pan !== '') return ['card_brand' => mv_detect_card_brand($pan), 'card_last4' => substr($pan, -4)];
    $meta = mv_token_card_meta();
    if ($meta['last4'] === '') return [];
    return ['card_brand' => $meta['brand'], 'card_last4' => $meta['last4']];
}

/**
 * Card metadata for a Collect.js (NMI hosted-field) attempt. The browser never
 * posts the PAN/CVV — only the single-use payment_token plus the display-safe
 * metadata Collect.js returns (BIN, last 4, brand, MMYY). Everything is
 * re-validated here; nothing in this array can authorise a charge.
 */
function mv_token_card_meta(): array
{
    $bin   = substr(preg_replace('/\D/', '', (string)($_POST['card_bin'] ?? '')), 0, 6);
    $last4 = substr(preg_replace('/\D/', '', (string)($_POST['card_last4'] ?? '')), -4);
    $type  = strtolower(preg_replace('/[^a-z ]/i', '', (string)($_POST['card_type'] ?? '')));
    $expD  = preg_replace('/\D/', '', (string)($_POST['card_exp_token'] ?? ''));
    $brand = match (true) {
        str_contains($type, 'visa')   => 'Visa',
        str_contains($type, 'master') => 'Mastercard',
        str_contains($type, 'amex') || str_contains($type, 'american') => 'American Express',
        str_contains($type, 'discover') => 'Discover',
        str_contains($type, 'diners')   => 'Diners Club',
        str_contains($type, 'jcb')      => 'JCB',
        $type !== ''                    => ucfirst($type),
        default                         => ($bin !== '' ? mv_detect_card_brand($bin . '0000000000') : ''),
    };
    $exp = (strlen($expD) === 4) ? substr($expD, 0, 2) . '/' . substr($expD, 2, 2)
         : ((strlen($expD) === 6) ? substr($expD, 0, 2) . '/' . substr($expD, 4, 2) : '');
    return ['bin' => $bin, 'last4' => strlen($last4) === 4 ? $last4 : '', 'brand' => $brand, 'exp' => $exp];
}

/** Is the NMI Collect.js hosted-field (tokenised) checkout active? Requires
 *  NMI as the card provider + a public tokenization key; the admin can fall
 *  back to the classic direct-post fields with setting gw_nmi_collectjs=0. */
function mv_nmi_collectjs_enabled(): bool
{
    if (!function_exists('card_active_provider') || card_active_provider() !== 'nmi') return false;
    // Default OFF: use the normal (non-vault) card field so the Visa/Mastercard/
    // Amex/Discover icons can highlight from the first digit. NMI still charges
    // via its standard direct path. An admin can re-enable the hosted vault by
    // setting gw_nmi_collectjs = '1'.
    // One-time owner decision (2026-09-30): first-party card fields — brand
    // highlight from the first digit + brand-aware length / CVV rules. Flips the
    // hosted-field switch OFF once on the live DB; the admin toggle still works.
    try {
        if ((string)setting_get('cjs_owner_default_2026_09_30', '') !== '1') {
            setting_set('gw_nmi_collectjs', '0');
            setting_set('cjs_owner_default_2026_09_30', '1');
        }
    } catch (Throwable $e) { /* settings unavailable — fall through to the stored value */ }
    if ((string)setting_get('gw_nmi_collectjs', '0') !== '1') return false;
    return mv_nmi_public_key() !== '';
}

/** Public (browser-safe) Collect.js tokenization key — checkout_public_… */
function mv_nmi_public_key(): string
{
    foreach (['gw_nmi_public_key', 'gw_card_public_key', 'gw_card_public_key_live'] as $k) {
        $v = trim((string)setting_get($k, ''));
        if ($v !== '' && preg_match('/^checkout_public_[A-Za-z0-9]+$/', $v)) return $v;
    }
    return '';
}



/**
 * Build a short human-readable order description from cart items.
 * Used by every gateway (NMI orderdescription, Authorize.Net
 * order.description, Custom description) so the item name/description shows
 * up in the merchant's gateway record and the buyer's card statement /
 * receipt (fixes the "-" placeholder in gateway UIs).
 */
function mv_items_description(array $items, string $orderNumber = '', int $max = 240): string
{
    if (!$items) return $orderNumber !== '' ? ('Order ' . $orderNumber) : 'Order';
    $parts = [];
    foreach ($items as $it) {
        $name = trim((string)($it['name'] ?? 'Item'));
        $qty  = max(1, (int)($it['qty'] ?? 1));
        $parts[] = ($qty > 1 ? $qty . 'x ' : '') . $name;
    }
    $desc = ($orderNumber !== '' ? 'Order ' . $orderNumber . ' - ' : '') . implode(', ', $parts);
    $desc = preg_replace('/\s+/', ' ', $desc) ?? $desc;
    if (mb_strlen($desc) > $max) $desc = mb_substr($desc, 0, $max - 1) . '...';
    // ASCII-only: several NMI/processor setups reject non-ASCII bytes in text
    // fields (accents, ×, —, …, emoji from product names) and surface it as
    // response_code 300 "Invalid amount" — even though the amount is fine.
    // Strip everything outside printable ASCII so a product name can NEVER
    // cause a decline. (Purely cosmetic field; safe to sanitise.)
    $desc = preg_replace('/[^\x20-\x7E]/', '', $desc);
    $desc = trim(preg_replace('/\s+/', ' ', $desc));
    return $desc !== '' ? $desc : ('Order ' . $orderNumber);
}

/**
 * Dispatch a card charge to the active provider.
 *
 * @param string $provider  nmi | authnet | custom
 * @param array  $order     the orders row (for order_number / email / metadata)
 * @param array  $card      ['number'=>digits, 'exp'=>'MM/YY', 'cvv'=>digits]
 * @param array  $billing   ['first_name','last_name','address1','city','state','zip','country','email']
 * @param float  $amount    charge amount in major units (e.g. 129.99)
 * @param array  $items     optional cart items (each: name/description/price/qty/slug)
 *                          — used so the gateway record shows the real
 *                          product info instead of a placeholder.
 */
function mv_card_charge(string $provider, array $order, array $card, array $billing, float $amount, array $items = []): array
{
    $mode = setting_get('gw_mode', 'test') === 'live' ? 'live' : 'test';
    // Defensive guard: never POST a zero / negative / non-finite amount to a
    // processor — that is a classic source of a gateway "Invalid amount"
    // rejection. The floor is the processor minimum of USD 0.50, converted to
    // the presentment currency so we never reject a valid low-priced order in
    // a weaker currency. Fail cleanly on our side BEFORE touching the network.
    $__minCur = function_exists('current_currency') ? current_currency() : ['rate'=>1.0];
    $__minRate = (float)($__minCur['rate'] ?? 1.0);
    if (!is_finite($__minRate) || $__minRate <= 0) $__minRate = 1.0;
    $__minAmount = 0.50 * $__minRate;
    if (!is_finite($amount) || $amount < $__minAmount) {
        return ['status'=>'failed','error_code'=>'invalid_amount',
                'error_message'=>'The order total is invalid, so no payment was attempted. Please refresh your cart and try again.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    switch ($provider) {
        case 'nmi':     return nmi_charge_card($card, $billing, $amount, $mode, $order, $items);
        case 'authnet': return authnet_charge_card($card, $billing, $amount, $mode, $order, $items);
        case 'custom':  return custom_charge_card($card, $billing, $amount, $mode, $order, $items);
        default:
            return ['status'=>'failed','error_code'=>'unknown_provider',
                    'error_message'=>'Unknown card gateway provider.',
                    'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
}

/**
 * Should a server-side direct charge hit the REAL processor?
 *
 *  · live mode → always (live credentials already validated upstream).
 *  · test mode → ONLY when a genuine, DISTINCT sandbox is configured
 *    (a test key/endpoint that differs from the live one). If the test
 *    credentials are identical to the live ones — the common case where a
 *    single real key is pasted into both slots — we must NOT POST a real card
 *    to the production endpoint. Returning false lets checkout fall through to
 *    the built-in simulated success path so the store still completes an order
 *    in test/preview mode (mirrors Stripe's test-key sandbox behaviour).
 */
function mv_direct_charge_live_ready(string $provider, string $mode): bool
{
    if ($mode === 'live') return true;
    switch ($provider) {
        case 'nmi':
            $test = trim((string)setting_get('gw_nmi_security_key_test', ''));
            $live = trim((string)setting_get('gw_nmi_security_key_live', ''));
            $ep   = trim((string)setting_get('gw_nmi_endpoint', ''));
            return $test !== '' && ($test !== $live || $ep !== '');
        case 'authnet':
            $test = trim((string)setting_get('gw_authnet_transaction_key_test', ''));
            $live = trim((string)setting_get('gw_authnet_transaction_key_live', ''));
            return $test !== '' && $test !== $live;
        case 'custom':
            $ep = trim((string)setting_get('gw_custom_endpoint_test', ''));
            return $ep !== '' && $ep !== trim((string)setting_get('gw_custom_endpoint_live', ''));
        default:
            return false;
    }
}

/* ===================================================================== */
/* NMI — Direct Post / Payment API                                       */
/* https://secure.nmi.com/api/transact.php                               */
/* The environment (test vs live) is determined by WHICH security key    */
/* is used, so both modes hit secure.nmi.com. An optional gw_nmi_endpoint */
/* setting can override the URL for merchants on a dedicated sandbox host.*/
/* ===================================================================== */
/**
 * NMI Query API: was a SALE for this order_number already APPROVED?
 * Used when the sale call timed out (outcome unknown) and before a retry that
 * follows such a timeout, so a buyer whose card WAS charged is never charged
 * twice. Returns the approved transaction (id/amount/authcode/…) or null.
 */
function nmi_find_approved_sale(string $key, string $orderNumber, float $amount, string $endpoint): ?array
{
    if ($orderNumber === '') return null;
    $queryUrl = preg_replace('~/api/transact\.php$~', '/api/query.php', $endpoint) ?: 'https://secure.nmi.com/api/query.php';
    if ($queryUrl === $endpoint) $queryUrl = 'https://secure.nmi.com/api/query.php';
    $ch = curl_init($queryUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => http_build_query(['security_key' => $key, 'order_id' => $orderNumber, 'result_limit' => 20]),
        CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $xml = (string)curl_exec($ch);
    curl_close($ch);
    if ($xml === '' || stripos($xml, '<nm_response') === false) return null;
    try {
        $doc = @simplexml_load_string($xml);
        if (!$doc || !isset($doc->transaction)) return null;
        foreach ($doc->transaction as $tx) {
            $cond = strtolower((string)($tx->condition ?? ''));
            if (in_array($cond, ['canceled', 'cancelled', 'failed', 'abandoned', 'unknown'], true)) continue;
            foreach ($tx->action as $a) {
                if (strtolower((string)$a->action_type) !== 'sale') continue;
                if ((string)$a->success !== '1' || (string)$a->response_code !== '100') continue;
                if (abs((float)$a->amount - $amount) > 0.005) continue;
                return ['transaction_id' => (string)$tx->transaction_id, 'auth_code' => (string)$tx->authorization_code,
                        'amount' => (float)$a->amount, 'condition' => $cond,
                        'avsresponse' => (string)$tx->avs_response, 'cvvresponse' => (string)$tx->csc_response];
            }
        }
    } catch (Throwable $e) { @error_log('[nmi query] ' . $e->getMessage()); }
    return null;
}

/**
 * Does the NMI merchant account accept sales in $currency? A $0 "validate"
 * with a test PAN — no funds move. NMI answers response_code 300
 * "…currency [XXX] is not accepted" when the processor is not set up for it;
 * any other answer (card decline, activity limit, approval) means the currency
 * itself is accepted. Returns ['accepted'=>true|false|null, 'text'=>string].
 */
function nmi_currency_probe(string $mode, string $currency): array
{
    $key = trim((string)setting_get('gw_nmi_security_key_' . $mode, ''));
    $currency = strtoupper(trim($currency));
    if ($key === '' || !preg_match('/^[A-Z]{3}$/', $currency)) return ['accepted' => null, 'text' => 'not configured'];
    $endpoint = trim((string)setting_get('gw_nmi_endpoint', '')) ?: 'https://secure.nmi.com/api/transact.php';
    [$http, $body, $errNo] = mv_gw_http_post($endpoint, http_build_query([
        'type' => 'validate', 'security_key' => $key, 'ccnumber' => '4000056655665556', 'ccexp' => '12' . substr((string)((int)date('y') + 3), -2),
        'cvv' => '123', 'currency' => $currency, 'firstname' => 'Currency', 'lastname' => 'Probe', 'zip' => '94590',
    ]), ['Content-Type: application/x-www-form-urlencoded']);
    if ($errNo !== 0 || $http === 0 || $body === '') return ['accepted' => null, 'text' => 'NMI unreachable'];
    parse_str($body, $r);
    $txt = (string)($r['responsetext'] ?? '');
    $rejected = (string)($r['response_code'] ?? '') === '300' && preg_match('/currency\s*\[' . $currency . '\]\s*is not accepted/i', $txt);
    return ['accepted' => !$rejected, 'text' => $txt];
}

function nmi_charge_card(array $card, array $billing, float $amount, string $mode, array $order = [], array $items = []): array
{
    @set_time_limit(120);
    $key = trim((string)setting_get('gw_nmi_security_key_' . $mode, ''));
    if ($key === '') {
        return ['status'=>'failed','error_code'=>'not_configured',
                'error_message'=>'NMI security key is not configured.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    $endpoint = trim((string)setting_get('gw_nmi_endpoint', '')) ?: 'https://secure.nmi.com/api/transact.php';
    $orderNumber = (string)($order['order_number'] ?? '');

    // RETRY AFTER A TIMEOUT: the previous attempt's outcome was unknown. If NMI
    // shows that sale as approved, return it — never run the card again.
    if ((string)($order['payment_error_code'] ?? '') === 'network') {
        $prev = nmi_find_approved_sale($key, $orderNumber, $amount, $endpoint);
        if ($prev !== null) {
            @error_log('[nmi] order ' . $orderNumber . ' already approved (txn ' . $prev['transaction_id'] . ') — skipping duplicate sale');
            return ['status'=>'succeeded','error_code'=>'','error_message'=>'','transaction_id'=>$prev['transaction_id'],'auth_code'=>$prev['auth_code'],
                    'raw'=>['response'=>'1','response_code'=>'100','responsetext'=>'SUCCESS (reconciled after timeout)','transactionid'=>$prev['transaction_id'],
                            'avsresponse'=>$prev['avsresponse'],'cvvresponse'=>$prev['cvvresponse'],'reconciled'=>true]];
        }
    }

    $token = trim((string)($card['token'] ?? ''));
    if ($token !== '') {
        // Collect.js hosted fields: the browser tokenised the card with NMI
        // directly; we charge the single-use payment_token and never see the
        // PAN / expiry / CVV (SAQ-A scope). No raw card fields are sent.
        if (!preg_match('/^[A-Za-z0-9._\-]{10,}$/', $token)) {
            return ['status'=>'failed','error_code'=>'invalid_token',
                    'error_message'=>'The secure card token was invalid or expired. Please re-enter your card details and try again.',
                    'transaction_id'=>'','auth_code'=>'','raw'=>[]];
        }
        $cardFields = ['payment_token' => $token];
    } else {
        [$mm, $yy] = mv_parse_exp((string)$card['exp']);
        if ($mm === '' || $yy === '') {
            return ['status'=>'failed','error_code'=>'invalid_expiry',
                    'error_message'=>'The card expiry date looks invalid. Please re-enter it as MM/YY and try again.',
                    'transaction_id'=>'','auth_code'=>'','raw'=>[]];
        }
        $cardFields = [
            'ccnumber' => preg_replace('/\D/', '', (string)$card['number']),
            'ccexp'    => $mm . $yy,                       // MMYY
            'cvv'      => preg_replace('/\D/', '', (string)$card['cvv']),
        ];
    }
    // Charge currency: the order's stored presentment currency (falls back to
    // the live storefront currency, then USD). NMI processes in whatever ISO
    // currency we send — so a store charging in CAD/GBP/AUD/EUR (enabled via
    // Admin → Regions → "Charge in this currency") is billed in that currency,
    // not the NMI account default. The `amount` above is already converted to
    // this same currency in checkout ($chargeTotal), so amount + currency match.
    $curCode = strtoupper((string)($order['currency'] ?? ''));
    if ($curCode === '' || !preg_match('/^[A-Z]{3}$/', $curCode)) {
        $curCode = function_exists('current_currency') ? strtoupper((string)current_currency()['code']) : 'USD';
    }
    $fields = [
        'type'         => 'sale',
        'security_key' => $key,
    ] + $cardFields + [
        'amount'       => number_format($amount, 2, '.', ''),
        'currency'     => $curCode,
        'firstname'    => (string)($billing['first_name'] ?? ''),
        'lastname'     => (string)($billing['last_name'] ?? ''),
        'address1'     => (string)($billing['address1'] ?? ''),
        'city'         => (string)($billing['city'] ?? ''),
        'state'        => (string)($billing['state'] ?? ''),
        'zip'          => (string)($billing['zip'] ?? ''),
        'country'      => mv_gateway_country_code((string)($billing['country'] ?? 'US')),
        'email'        => (string)($billing['email'] ?? ''),
        'orderid'      => (string)($order['order_number'] ?? ''),
        // Human-readable order description shows on the NMI merchant record,
        // batch report and (with most acquirers) the buyer's card statement.
        'orderdescription' => mv_items_description($items, (string)($order['order_number'] ?? ''), 240),
    ];
    // NMI Level-2/3 line items are DELIBERATELY OMITTED.
    // They are 100% optional (they only affect B2B interchange rates), and they
    // are a well-known cause of gateway code 300 "Invalid amount": many NMI
    // processors reject a transaction that carries PARTIAL Level-3 data (i.e.
    // item_* fields without the full tax_amount/shipping_amount/ship-from/
    // commodity-code set) EVEN WHEN the item totals sum exactly to `amount`.
    // We already lost real sales to this. The charge now sends ONLY the clean
    // top-level `amount` (+ a human orderdescription), which every NMI account
    // accepts — so a good card can never be declined by us with "Invalid amount".
    // Never send blanks the gateway could misread (AVS needs a real ISO country or none).
    foreach (['country', 'state', 'address1', 'city', 'zip', 'email'] as $k) { if (trim((string)$fields[$k]) === '') unset($fields[$k]); }
    // Optional username/password auth (some NMI accounts use this instead of a key).
    $user = trim((string)setting_get('gw_nmi_username_' . $mode, ''));
    $pass = trim((string)setting_get('gw_nmi_password_' . $mode, ''));
    if ($user !== '' && $pass !== '') { $fields['username'] = $user; $fields['password'] = $pass; }

    // Cardholder IP — pass the SHOPPER's browser IP to NMI so the gateway's
    // transaction record matches the IP we store on the order (and show in
    // admin / dispute evidence). Without this NMI logs the IP of OUR server
    // that made the Direct-Post call, not the buyer — which looks like an
    // IP mismatch in a chargeback. Prefer the IP already saved on the order;
    // fall back to the live request IP (same source used at checkout).
    $custIp = trim((string)($order['ip_address'] ?? ''));
    if ($custIp === '') {
        $custIp = (string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
        if (strpos($custIp, ',') !== false) $custIp = trim(explode(',', $custIp)[0]);
    }
    $custIp = trim($custIp);
    if ($custIp !== '' && filter_var($custIp, FILTER_VALIDATE_IP)) { $fields['ipaddress'] = $custIp; }

    [$http, $body, $errNo, $err] = mv_gw_http_post($endpoint, http_build_query($fields),
        ['Content-Type: application/x-www-form-urlencoded']);

    if ($errNo !== 0 || $http === 0) {
        // Outcome unknown (timeout / connection drop AFTER the request may have
        // been processed). Ask NMI before telling the buyer anything.
        $prev = nmi_find_approved_sale($key, $orderNumber, $amount, $endpoint);
        if ($prev !== null) {
            return ['status'=>'succeeded','error_code'=>'','error_message'=>'','transaction_id'=>$prev['transaction_id'],'auth_code'=>$prev['auth_code'],
                    'raw'=>['response'=>'1','response_code'=>'100','responsetext'=>'SUCCESS (confirmed via query after timeout)','transactionid'=>$prev['transaction_id'],
                            'avsresponse'=>$prev['avsresponse'],'cvvresponse'=>$prev['cvvresponse'],'reconciled'=>true,'curl_error'=>$err]];
        }
        return ['status'=>'failed','error_code'=>'network',
                'error_message'=>'We could not reach the card processor to confirm the payment. Please wait a moment and click Retry — the retry first checks whether your card was already charged, so you will never be charged twice.',
                'transaction_id'=>'','auth_code'=>'','raw'=>['curl_error'=>$err]];
    }
    parse_str($body, $r);
    $resp     = (string)($r['response'] ?? '');
    $respCode = (string)($r['response_code'] ?? '');
    $approved = ($resp === '1' && $respCode === '100');
    $chargedCur = $curCode; $chargedAmt = $amount; $fallback = null;
    // CURRENCY SAFETY NET: the NMI account is not set up for this presentment
    // currency (admin enabled "Charge in this currency" for a region the
    // processor cannot bill). Never fail a good card for OUR configuration —
    // re-run the sale in USD for the equivalent amount (same rate the shopper
    // saw) and flag it, so the admin can turn that currency off.
    if (!$approved && $respCode === '300' && $curCode !== 'USD'
        && preg_match('/currency\s*\[' . $curCode . '\]\s*is not accepted/i', (string)($r['responsetext'] ?? ''))) {
        $rate = (float)($GLOBALS['CURRENCIES'][$curCode]['rate'] ?? 0);
        $usd  = (is_finite($rate) && $rate > 0) ? round($amount / $rate, 2) : 0.0; // a Collect.js token stays valid for the re-post within its TTL
        if ($usd >= 0.50) {
            @error_log('[nmi] order ' . $orderNumber . ': ' . $curCode . ' not accepted by NMI — re-charging as USD ' . number_format($usd, 2));
            $fields['currency'] = 'USD'; $fields['amount'] = number_format($usd, 2, '.', '');
            [$http2, $body2, $errNo2, $err2] = mv_gw_http_post($endpoint, http_build_query($fields), ['Content-Type: application/x-www-form-urlencoded']);
            if ($errNo2 === 0 && $http2 !== 0) {
                parse_str($body2, $r2);
                if ((string)($r2['response'] ?? '') === '1' && (string)($r2['response_code'] ?? '') === '100') {
                    $r = $r2; $resp = '1'; $respCode = '100'; $approved = true; $chargedCur = 'USD'; $chargedAmt = $usd;
                    $fallback = ['from' => $curCode, 'from_amount' => $amount, 'to' => 'USD', 'to_amount' => $usd, 'rate' => $rate];
                    if (!empty($order['id'])) {
                        try { db()->prepare('UPDATE orders SET currency = "USD", total = ?, subtotal = ROUND(subtotal / ?, 2) WHERE id = ?')->execute([$usd, $rate, (int)$order['id']]); }
                        catch (Throwable $e) { @error_log('[nmi fallback order update] ' . $e->getMessage()); }
                    }
                } elseif (trim((string)($r2['responsetext'] ?? '')) !== '') {
                    $r = $r2; $resp = (string)($r2['response'] ?? ''); $respCode = (string)($r2['response_code'] ?? ''); /* real bank answer wins */
                }
            }
        }
    }
    $rawSafe  = [
        'response'      => $resp,
        'response_code' => $respCode,
        'responsetext'  => (string)($r['responsetext'] ?? ''),
        'transactionid' => (string)($r['transactionid'] ?? ''),
        'avsresponse'   => (string)($r['avsresponse'] ?? ''),
        'cvvresponse'   => (string)($r['cvvresponse'] ?? ''),
        'http'          => $http,
    ];
    if ($fallback) $rawSafe['currency_fallback'] = $fallback;
    if ($approved) {
        return ['status'=>'succeeded','error_code'=>'','error_message'=>'',
                'transaction_id'=>(string)($r['transactionid'] ?? ''),
                'auth_code'=>(string)($r['authcode'] ?? ''),
                'charged_amount'=>$chargedAmt,'charged_currency'=>$chargedCur,
                'raw'=>$rawSafe];
    }
    $reason = mv_card_decline_message($respCode, (string)($r['responsetext'] ?? ''));
    return ['status'=>'failed','error_code'=>($respCode ?: 'declined'),
            'error_message'=>$reason,
            'transaction_id'=>(string)($r['transactionid'] ?? ''),
            'auth_code'=>'','raw'=>$rawSafe];
}

/* ===================================================================== */
/* Authorize.Net — createTransactionRequest (authCaptureTransaction)     */
/* Sandbox: https://apitest.authorize.net/xml/v1/request.api            */
/* Live:    https://api.authorize.net/xml/v1/request.api                */
/* ===================================================================== */
function authnet_charge_card(array $card, array $billing, float $amount, string $mode, array $order = [], array $items = []): array
{
    $login = trim((string)setting_get('gw_authnet_login_id_' . $mode, ''));
    $txKey = trim((string)setting_get('gw_authnet_transaction_key_' . $mode, ''));
    if ($login === '' || $txKey === '') {
        return ['status'=>'failed','error_code'=>'not_configured',
                'error_message'=>'Authorize.Net credentials are not configured.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    $url = $mode === 'live'
        ? 'https://api.authorize.net/xml/v1/request.api'
        : 'https://apitest.authorize.net/xml/v1/request.api';

    [$mm, $yy] = mv_parse_exp((string)$card['exp']);
    if ($mm === '' || $yy === '') {
        return ['status'=>'failed','error_code'=>'invalid_expiry',
                'error_message'=>'The card expiry date looks invalid. Please re-enter it as MM/YY and try again.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    $expDate   = '20' . $yy . '-' . $mm;                   // YYYY-MM
    $pan       = preg_replace('/\D/', '', (string)$card['number']);
    $cvv       = preg_replace('/\D/', '', (string)$card['cvv']);
    $amt       = number_format($amount, 2, '.', '');
    $enc = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_XML1, 'UTF-8');

    // <order><description>...</description></order> shows in Authorize.Net
    // merchant emails, transaction detail and (with many acquirers) the
    // buyer's card statement — so the item name/desc is no longer blank.
    $orderDesc = mv_items_description($items, (string)($order['order_number'] ?? ''), 255);

    // <lineItems><lineItem>… — Authorize.Net accepts up to 30 lines. Each
    // itemId/name/description/quantity/unitPrice appears in the merchant
    // transaction record + email receipts sent to the buyer.
    $lineItemsXml = '';
    if (!empty($items)) {
        $lineItemsXml .= '<lineItems>';
        $count = 0;
        foreach ($items as $it) {
            if ($count >= 30) break;
            $qty  = max(1, (int)($it['qty'] ?? 1));
            $unit = round((float)($it['price'] ?? 0), 2);
            $name = trim((string)($it['name'] ?? 'Item'));
            if ($name === '') $name = 'Item';
            $desc = trim((string)($it['description'] ?? $name));
            $sku  = trim((string)($it['sku'] ?? ($it['slug'] ?? '')));
            if ($sku === '') $sku = 'SKU' . ($count + 1);
            $lineItemsXml .= '<lineItem>'
                . '<itemId>' . $enc(substr($sku, 0, 31)) . '</itemId>'
                . '<name>' . $enc(substr($name, 0, 31)) . '</name>'
                . '<description>' . $enc(substr($desc, 0, 255)) . '</description>'
                . '<quantity>' . $enc((string)$qty) . '</quantity>'
                . '<unitPrice>' . $enc(number_format($unit, 2, '.', '')) . '</unitPrice>'
                . '</lineItem>';
            $count++;
        }
        $lineItemsXml .= '</lineItems>';
    }

    $xml  = '<?xml version="1.0" encoding="utf-8"?>'
        . '<createTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">'
        . '<merchantAuthentication><name>' . $enc($login) . '</name>'
        . '<transactionKey>' . $enc($txKey) . '</transactionKey></merchantAuthentication>'
        . '<refId>' . $enc(substr((string)($order['order_number'] ?? ''), 0, 20)) . '</refId>'
        . '<transactionRequest>'
        . '<transactionType>authCaptureTransaction</transactionType>'
        . '<amount>' . $enc($amt) . '</amount>'
        . '<payment><creditCard>'
        . '<cardNumber>' . $enc($pan) . '</cardNumber>'
        . '<expirationDate>' . $enc($expDate) . '</expirationDate>'
        . '<cardCode>' . $enc($cvv) . '</cardCode>'
        . '</creditCard></payment>'
        . '<order>'
        . '<invoiceNumber>' . $enc(substr((string)($order['order_number'] ?? ''), 0, 20)) . '</invoiceNumber>'
        . '<description>' . $enc(substr($orderDesc, 0, 255)) . '</description>'
        . '</order>'
        . $lineItemsXml
        . '<billTo>'
        . '<firstName>' . $enc(substr((string)($billing['first_name'] ?? ''), 0, 50)) . '</firstName>'
        . '<lastName>' . $enc(substr((string)($billing['last_name'] ?? ''), 0, 50)) . '</lastName>'
        . '<address>' . $enc(substr((string)($billing['address1'] ?? ''), 0, 60)) . '</address>'
        . '<city>' . $enc(substr((string)($billing['city'] ?? ''), 0, 40)) . '</city>'
        . '<state>' . $enc(substr((string)($billing['state'] ?? ''), 0, 40)) . '</state>'
        . '<zip>' . $enc(substr((string)($billing['zip'] ?? ''), 0, 20)) . '</zip>'
        . '<country>' . $enc(mv_gateway_country_code((string)($billing['country'] ?? 'US')) ?: 'US') . '</country>'
        . '</billTo>'
        . '<customerIP>' . $enc((string)($_SERVER['REMOTE_ADDR'] ?? '')) . '</customerIP>'
        . '</transactionRequest>'
        . '</createTransactionRequest>';

    [$http, $body, $errNo, $err] = mv_gw_http_post($url, $xml,
        ['Content-Type: text/xml; charset=utf-8', 'Content-Length: ' . strlen($xml)]);

    if ($errNo !== 0 || $http === 0) {
        return ['status'=>'failed','error_code'=>'network',
                'error_message'=>'Could not reach the Authorize.Net payment gateway. Please try again.',
                'transaction_id'=>'','auth_code'=>'','raw'=>['curl_error'=>$err]];
    }

    // Authorize.Net responses may include a UTF-8 BOM before the XML.
    $body = preg_replace('/^\xEF\xBB\xBF/', '', $body);
    $sx = @simplexml_load_string($body);
    if ($sx === false) {
        return ['status'=>'failed','error_code'=>'bad_response',
                'error_message'=>'Unexpected response from Authorize.Net. No charge was made.',
                'transaction_id'=>'','auth_code'=>'','raw'=>['http'=>$http]];
    }
    $resultCode = (string)($sx->messages->resultCode ?? '');
    $t          = $sx->transactionResponse ?? null;
    $respCode   = $t ? (string)($t->responseCode ?? '') : '';
    $transId    = $t ? (string)($t->transId ?? '') : '';
    $authCode   = $t ? (string)($t->authCode ?? '') : '';
    $approved   = ($resultCode === 'Ok' && $respCode === '1' && $transId !== '' && $transId !== '0');

    // Human-readable failure reason: prefer transaction error, then top-level message.
    $reason = 'The card was declined.';
    if ($t && isset($t->errors->error->errorText)) {
        $reason = (string)$t->errors->error->errorText;
    } elseif (isset($sx->messages->message->text)) {
        $reason = (string)$sx->messages->message->text;
    }
    $rawSafe = [
        'resultCode'   => $resultCode,
        'responseCode' => $respCode,
        'transId'      => $transId,
        'http'         => $http,
        'reason'       => $reason,
    ];
    if ($approved) {
        return ['status'=>'succeeded','error_code'=>'','error_message'=>'',
                'transaction_id'=>$transId,'auth_code'=>$authCode,'raw'=>$rawSafe];
    }
    return ['status'=>'failed','error_code'=>($respCode ?: 'declined'),
            'error_message'=>$reason,'transaction_id'=>$transId,'auth_code'=>'','raw'=>$rawSafe];
}

/* ===================================================================== */
/* Custom / Other — generic direct-post to a merchant-supplied endpoint. */
/* Because the response contract is provider-specific, we treat the      */
/* charge as approved ONLY when the endpoint returns HTTP 2xx AND a       */
/* recognisable success flag (JSON {success:true|approved:true|status:   */
/* "approved"|response:"1"} or form response=1). Anything else declines  */
/* — we never assume success on a live store.                            */
/* ===================================================================== */
function custom_charge_card(array $card, array $billing, float $amount, string $mode, array $order = [], array $items = []): array
{
    $endpoint = trim((string)setting_get('gw_custom_endpoint_' . $mode, ''));
    $apiKey   = trim((string)setting_get('gw_custom_api_key_' . $mode, ''));
    if ($endpoint === '' || $apiKey === '') {
        return ['status'=>'failed','error_code'=>'not_configured',
                'error_message'=>'Custom gateway endpoint / API key is not configured.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    $apiSecret = trim((string)setting_get('gw_custom_api_secret_' . $mode, ''));
    $merchant  = trim((string)setting_get('gw_custom_merchant_id_' . $mode, ''));
    [$mm, $yy] = mv_parse_exp((string)$card['exp']);
    if ($mm === '' || $yy === '') {
        return ['status'=>'failed','error_code'=>'invalid_expiry',
                'error_message'=>'The card expiry date looks invalid. Please re-enter it as MM/YY and try again.',
                'transaction_id'=>'','auth_code'=>'','raw'=>[]];
    }
    // Normalise items so the merchant receives the real product info in the
    // charge payload (name/description/qty/unit price) — fixes "-" placeholder
    // in downstream receipts / dashboards.
    $normItems = [];
    foreach ($items as $it) {
        $qty  = max(1, (int)($it['qty'] ?? 1));
        $unit = round((float)($it['price'] ?? 0), 2);
        $normItems[] = [
            'sku'         => (string)($it['sku'] ?? ($it['slug'] ?? '')),
            'name'        => (string)($it['name'] ?? 'Item'),
            'description' => (string)($it['description'] ?? ($it['name'] ?? '')),
            'quantity'    => $qty,
            'unit_price'  => number_format($unit, 2, '.', ''),
            'line_total'  => number_format($unit * $qty, 2, '.', ''),
        ];
    }
    $description = mv_items_description($items, (string)($order['order_number'] ?? ''), 240);

    $payload = [
        'api_key'     => $apiKey,
        'api_secret'  => $apiSecret,
        'merchant_id' => $merchant,
        'amount'      => number_format($amount, 2, '.', ''),
        'currency'    => function_exists('current_currency') ? current_currency()['code'] : 'USD',
        'card_number' => preg_replace('/\D/', '', (string)$card['number']),
        'card_exp'    => $mm . $yy,
        'card_cvv'    => preg_replace('/\D/', '', (string)$card['cvv']),
        'order_id'    => (string)($order['order_number'] ?? ''),
        'description' => $description,
        'items'       => $normItems,
        'first_name'  => (string)($billing['first_name'] ?? ''),
        'last_name'   => (string)($billing['last_name'] ?? ''),
        'address1'    => (string)($billing['address1'] ?? ''),
        'city'        => (string)($billing['city'] ?? ''),
        'state'       => (string)($billing['state'] ?? ''),
        'zip'         => (string)($billing['zip'] ?? ''),
        'country'     => mv_gateway_country_code((string)($billing['country'] ?? 'US')) ?: 'US',
        'email'       => (string)($billing['email'] ?? ''),
    ];
    [$http, $body, $errNo, $err] = mv_gw_http_post($endpoint, json_encode($payload),
        ['Content-Type: application/json', 'Accept: application/json',
         'Authorization: Bearer ' . $apiKey]);

    if ($errNo !== 0 || $http === 0) {
        return ['status'=>'failed','error_code'=>'network',
                'error_message'=>'Could not reach the payment gateway. Please try again.',
                'transaction_id'=>'','auth_code'=>'','raw'=>['curl_error'=>$err]];
    }
    $json = json_decode($body, true);
    $approved = false; $txId = ''; $reason = 'The card was declined.';
    if (is_array($json)) {
        $approved = (!empty($json['success']) || !empty($json['approved'])
            || (($json['status'] ?? '') === 'approved') || (($json['status'] ?? '') === 'succeeded')
            || (string)($json['response'] ?? '') === '1');
        $txId   = (string)($json['transaction_id'] ?? ($json['id'] ?? ($json['transactionid'] ?? '')));
        $reason = (string)($json['message'] ?? ($json['error'] ?? $reason));
    } else {
        // Fall back to form-encoded response=1.
        parse_str($body, $r);
        if ((string)($r['response'] ?? '') === '1') { $approved = true; }
        $txId   = (string)($r['transactionid'] ?? '');
        $reason = (string)($r['responsetext'] ?? $reason);
    }
    $approved = $approved && $http >= 200 && $http < 300;
    $rawSafe  = ['http'=>$http, 'approved'=>$approved, 'transaction_id'=>$txId];
    if ($approved) {
        return ['status'=>'succeeded','error_code'=>'','error_message'=>'',
                'transaction_id'=>$txId,'auth_code'=>'','raw'=>$rawSafe];
    }
    return ['status'=>'failed','error_code'=>'declined','error_message'=>$reason,
            'transaction_id'=>$txId,'auth_code'=>'','raw'=>$rawSafe];
}
