<?php
/**
 * includes/gateways/credentials.php
 * ---------------------------------------------------------------------------
 * SINGLE SOURCE OF TRUTH for the merchant payment-gateway credentials
 * (PayPal Business "ZED WEB TECH" + NMI "FIVECODE LAB").
 *
 * These are seeded into the `settings` table so they survive ANY deploy
 * (Emergent preview, Emergent deploy, or a plain cPanel/shared-host upload)
 * WITHOUT the admin re-entering anything — the whole point of baking them
 * here. Runtime readers (paypal-api.php / charge.php / paypal-webhook.php)
 * only read from `settings`, so once seeded the live store just works.
 *
 *   • mv_seed_gateways(false) — seed-if-empty (safe on every boot / request;
 *     preserves any value the admin later changes in the panel).
 *   • mv_seed_gateways(true)  — force overwrite (used once from the CLI to
 *     (re)install the exact merchant-supplied values).
 *
 * Guarded by settings.gateways_seeded_v1 so the seed-if-empty path is a cheap
 * one-row no-op after the first successful install.
 */
require_once __DIR__ . '/../settings.php';

/** The canonical credential map: setting-key => value. */
function mv_gateway_seed_values(): array {
    return [
        /* ===== PayPal (Business: ZED WEB TECH) ===== */
        'gw_paypal_status'          => 'active',
        'gw_paypal_account_name'    => 'Zedweb Tech',
        'gw_paypal_provider'        => 'PayPal',
        // LIVE
        'gw_paypal_client_id_live'  => 'ATWxNFTFCqu_CtrYUBaZrVWUZkt3NSqKfxihElJ4rC3f1W9NuIL-y4wz8FiLC6lkcwm2lS0VFgL538Cd',
        'gw_paypal_secret_live'     => 'EH64yz-CAVlAoEhd3uYa1M8mruKR67099fK5mD-mY8-yMa1ZHBBYdAKFtpzctXPUp5nJ-Kmulu83yBbZ',
        'gw_paypal_webhook_id_live' => '35J58848HM622782F',
        // TEST / sandbox
        'gw_paypal_client_id_test'  => 'Add8gYb5pQ_xCuVaiSpxFpxDUa8TlSTbw8CH7D9AIj-4oKsgn9-9kIMQD0RLeIZ-QL823r3fcc-b1Kbj',
        'gw_paypal_secret_test'     => 'EGGTJpGQUZtZaSm6z8B4UrjJ3a9_t9RKiVqJq-rhOAFROXg5RWlY8LzkxOfJh4eqrRzUdVBpskweXd-l',
        'gw_paypal_webhook_id_test' => '56C18964R7715651V',
        'gw_paypal_webhook_url'     => 'https://maventechsoftware.com/paypal-webhook.php',
        'paypal_enabled'            => '1',

        /* ===== NMI (Gateway: FIVECODE LAB) ===== */
        'gw_card_status'           => 'active',
        'gw_card_provider_type'    => 'nmi',
        'gw_card_provider'         => 'NMI',
        'gw_card_merchant_name'    => 'Five Code Lab',
        // Private Security Key — Direct Post (server-side, per-mode).
        'gw_nmi_security_key_live' => 'mRpB7Ydz4uyEG6ev7v9HdRwNVYrqs895',
        'gw_nmi_security_key_test' => 'mRpB7Ydz4uyEG6ev7v9HdRwNVYrqs895',
        // Public (Collect.js) key on every slot the frontend/webhook read.
        'gw_card_public_key_live'  => 'checkout_public_7n66b4U3QwffQ26mcsg4jaz4uSbNvWE6',
        'gw_card_public_key'       => 'checkout_public_7n66b4U3QwffQ26mcsg4jaz4uSbNvWE6',
        'gw_nmi_public_key'        => 'checkout_public_7n66b4U3QwffQ26mcsg4jaz4uSbNvWE6',
        // Webhook signing key.
        'gw_card_webhook_secret'   => 'D1F2EADBD231C71AB96FAA962A0A7304',
        'gw_nmi_signing_key'       => 'D1F2EADBD231C71AB96FAA962A0A7304',
        'card_enabled'             => '1',
    ];
}

/**
 * Seed the gateway credentials into settings.
 * @param bool $force  true = overwrite existing values; false = seed-if-empty.
 * @return array       log lines (SET / KEEP / FORCE …)
 */
function mv_seed_gateways(bool $force = false): array {
    $log = [];
    // One-shot guard so the seed-if-empty path is a cheap no-op after install.
    if (!$force && (string)setting_get('gateways_seeded_v1', '') === '1') {
        return ['skipped: already seeded'];
    }
    foreach (mv_gateway_seed_values() as $k => $v) {
        $cur = trim((string)setting_get($k, ''));
        if ($force || $cur === '') {
            setting_set($k, $v);
            $log[] = ($force && $cur !== '' ? 'FORCE ' : 'SET   ') . $k;
        } else {
            $log[] = 'KEEP  ' . $k;
        }
    }
    // Active PayPal webhook id mirrors the current mode's id (live by default).
    $mode = setting_get('gw_mode', 'live') === 'live' ? 'live' : 'test';
    $wid  = $mode === 'live' ? '35J58848HM622782F' : '56C18964R7715651V';
    if ($force || trim((string)setting_get('gw_paypal_webhook_id', '')) === '') {
        setting_set('gw_paypal_webhook_id', $wid);
        $log[] = 'SET   gw_paypal_webhook_id (' . $mode . ')';
    }
    setting_set('gateways_seeded_v1', '1');
    return $log;
}

/**
 * Silent, guarded auto-heal for the WEB bootstrap. Runs once per install
 * (seed-if-empty) so a fresh cPanel/shared-host deploy configures itself on
 * the first page load. Never throws — payments must never crash the site.
 */
function mv_autoheal_gateways(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        // One-time correction of the customer-facing gateway display names to
        // the canonical merchant-supplied values. Runs INDEPENDENTLY of the
        // seed-if-empty guard so deploys that imported a stale/garbage value
        // (e.g. an old dump with a placeholder merchant name) are fixed exactly
        // once. Admin edits made afterwards are preserved (guard flag set).
        if ((string)setting_get('gw_display_names_v2', '') !== '1') {
            setting_set('gw_card_merchant_name', 'Five Code Lab');
            setting_set('gw_paypal_account_name', 'Zedweb Tech');
            setting_set('gw_display_names_v2', '1');
        }
        if ((string)setting_get('gateways_seeded_v1', '') !== '1') {
            mv_seed_gateways(false);
        }
        // Collect.js public tokenization key — installs seeded before this key
        // existed get it filled in (seed-if-empty, data-only, no DDL).
        if (trim((string)setting_get('gw_nmi_public_key', '')) === '') {
            $seed = mv_gateway_seed_values();
            if (!empty($seed['gw_nmi_public_key'])) setting_set('gw_nmi_public_key', $seed['gw_nmi_public_key']);
        }
    } catch (Throwable $e) {
        // settings table not ready yet / DB hiccup — ignore, retry next request.
    }
}
