<?php
/* ===========================================================================
 *  BRAND ICON — one square mark for favicon, PWA icons, admin tab, share
 *  card and PDF/email fallbacks. Source of truth: the logo uploaded in
 *  Admin → Company Info. When no logo is uploaded the mark is an automatic
 *  monogram of the company name (same look as the header's SVG fallback), so
 *  the same zip dropped on any other domain brands itself after Company Info
 *  is filled in. Rendered PNGs are cached under /uploads/cache/app-icons and
 *  keyed by app_icon_version() (logo mtime + company name + vibe).
 *  =========================================================================== */

function brand_icon_font(): string {
    foreach ([
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        dirname(__DIR__) . '/vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
    ] as $f) { if (is_file($f)) return $f; }
    return '';
}

function brand_icon_letter(): string {
    $name = function_exists('company_info') ? (string)(company_info()['name'] ?? '') : '';
    if ($name === '') $name = brand_name();
    $name = preg_replace('/^[^\p{L}\p{N}]+/u', '', trim($name));
    return $name !== '' ? mb_strtoupper(mb_substr($name, 0, 1)) : 'M';
}

function brand_icon_rgb(string $hex): array {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
}

function brand_icon_transparent_canvas(int $w, int $h): GdImage {
    $im = imagecreatetruecolor($w, $h);
    imagealphablending($im, false);
    imagesavealpha($im, true);
    imagefilledrectangle($im, 0, 0, $w, $h, imagecolorallocatealpha($im, 0, 0, 0, 127));
    imagealphablending($im, true);
    return $im;
}

/* Gradient rounded-square tile with the brand letter — mirrors render_logo(). */
function brand_icon_monogram(int $size): GdImage {
    $im = brand_icon_transparent_canvas($size, $size);
    $vibe = function_exists('current_vibe') ? current_vibe() : [];
    $classic = empty($vibe['key']) || $vibe['key'] === 'classic';
    [$c0, $c1] = $classic ? ['#0B5CFF', '#0848CC'] : [$vibe['gradient'][0], $vibe['gradient'][2]];
    $a = brand_icon_rgb($c0); $b = brand_icon_rgb($c1);
    $r = (int)round($size * 0.22);
    $min = $r; $max = $size - 1 - $r;
    imagealphablending($im, false);
    for ($y = 0; $y < $size; $y++) {
        for ($x = 0; $x < $size; $x++) {
            if (!($x >= $min && $x <= $max) && !($y >= $min && $y <= $max)) {
                $cx = $x < $min ? $min : $max; $cy = $y < $min ? $min : $max;
                if (($x - $cx) ** 2 + ($y - $cy) ** 2 > $r * $r) continue;
            }
            $t = ($x + $y) / (2 * ($size - 1));
            imagesetpixel($im, $x, $y, imagecolorallocate($im,
                (int)round($a[0] + ($b[0] - $a[0]) * $t),
                (int)round($a[1] + ($b[1] - $a[1]) * $t),
                (int)round($a[2] + ($b[2] - $a[2]) * $t)));
        }
    }
    imagealphablending($im, true);
    $font = brand_icon_font();
    $letter = brand_icon_letter();
    $white = imagecolorallocate($im, 255, 255, 255);
    if ($font !== '') {
        $fs = $size * 0.58;
        $bb = imagettfbbox($fs, 0, $font, $letter);
        $tw = $bb[2] - $bb[0]; $th = $bb[1] - $bb[7];
        $tx = (int)round(($size - $tw) / 2 - $bb[0]);
        $ty = (int)round(($size - $th) / 2 - $bb[7]);
        imagettftext($im, $fs, 0, $tx, $ty, $white, $font, $letter);
    } else {
        imagestring($im, 5, (int)($size / 2 - 4), (int)($size / 2 - 8), $letter, $white);
    }
    return $im;
}

/* Uploaded logo as a GD image (first frame for GIFs), or null when none usable. */
function brand_icon_logo_image(): ?GdImage {
    $src = function_exists('app_icon_src_path') ? app_icon_src_path() : '';
    if ($src === '' || !is_file($src)) return null;
    $mime = (string)(@getimagesize($src)['mime'] ?? '');
    $im = match ($mime) {
        'image/png'  => @imagecreatefrompng($src),
        'image/jpeg' => @imagecreatefromjpeg($src),
        'image/gif'  => @imagecreatefromgif($src),
        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($src) : false,
        default      => false,
    };
    if (!$im) return null;
    if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    imagesavealpha($im, true);
    return $im;
}

/* Square icon: the uploaded logo "contained" (never cropped), else the monogram. */
function brand_icon_image(int $size): GdImage {
    $logo = brand_icon_logo_image();
    if (!$logo) return brand_icon_monogram($size);
    $sw = imagesx($logo); $sh = imagesy($logo);
    $dst = brand_icon_transparent_canvas($size, $size);
    $scale = min($size / $sw, $size / $sh);
    $dw = max(1, (int)round($sw * $scale)); $dh = max(1, (int)round($sh * $scale));
    imagecopyresampled($dst, $logo, (int)round(($size - $dw) / 2), (int)round(($size - $dh) / 2), 0, 0, $dw, $dh, $sw, $sh);
    imagedestroy($logo);
    return $dst;
}

/* Share of the canvas that is opaque (16×16 sample). ~1.0 = full-bleed tile. */
function brand_icon_coverage(GdImage $im): float {
    $w = imagesx($im); $h = imagesy($im); $hit = 0;
    for ($i = 0; $i < 16; $i++) for ($j = 0; $j < 16; $j++) {
        $a = (imagecolorat($im, (int)(($i + .5) * $w / 16), (int)(($j + .5) * $h / 16)) >> 24) & 0x7F;
        if ($a < 64) $hit++;
    }
    return $hit / 256;
}

/* Cached PNG path for $size — regenerated whenever app_icon_version() changes. */
function brand_icon_png_path(int $size): string {
    $dir = dirname(__DIR__) . '/uploads/cache/app-icons';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $file = $dir . '/icon-' . $size . '-' . app_icon_version() . '.png';
    if (is_file($file) && filesize($file) > 0) return $file;
    $im = brand_icon_image($size);
    @imagepng($im, $file, 6);
    imagedestroy($im);
    return $file;
}
