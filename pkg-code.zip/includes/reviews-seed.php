<?php
/**
 * includes/reviews-seed.php
 * ---------------------------------------------------------------------------
 * Review seeding + daily trickle.
 *
 * v5 REBALANCE (runs once per host via the version guard):
 *   • wipes ALL previously seeded reviews (order_id IS NULL — real customer
 *     reviews always carry an order_id and are never touched)
 *   • seeds a total of 1,100–1,500 reviews
 *   • 3–7 reviews per calendar day, walking backwards from today
 *   • EVERY review has a written comment
 *   • EVERY reviewer name is unique (shuffled first×last combinations)
 *   • randomly distributed across all products
 *   • re-syncs products.sold_base (3 × review count) so sold counters match
 *
 * The daily trickle keeps the stream alive (3–7/day, unique names, always
 * with a comment) and prunes the oldest seeded rows so the pool never grows
 * beyond ~1,500.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!defined('MV_REVIEWS_SEED_VERSION')) define('MV_REVIEWS_SEED_VERSION', '7');
if (!defined('MV_REVIEWS_MAX_TOTAL'))    define('MV_REVIEWS_MAX_TOTAL', 1500);
/** Fixed baseline size — a STABLE figure (~2 months at ~6 sales/day). The
 *  count must NOT drift day to day, so this is a constant, never randomised. */
if (!defined('MV_REVIEWS_BASELINE'))     define('MV_REVIEWS_BASELINE', 1300);

/**
 * The review count SHOWN to shoppers is PINNED to the baseline so it can NEVER
 * drift or grow on redeploys / as stray/real rows accumulate. Returns
 * min(actual published, MV_REVIEWS_BASELINE). This is the single source of truth
 * for every storefront "X reviews" figure (reviews page, product badge, trust
 * bar). Fixes the recurring "count keeps multiplying (1300 → 2600)" bug.
 */
function mv_review_display_count(): int {
    static $c = null;
    if ($c !== null) return $c;
    try {
        // Seeded AI reviews are pinned to the baseline so they can NEVER drift
        // past it (fixes the old 1300→2600 doubling). Every REAL customer
        // review is then added ON TOP, so the figure genuinely grows
        // 1300 → 1301 → 1302 … as authentic reviews arrive.
        $ai   = (int) db()->query("SELECT COUNT(*) FROM customer_reviews WHERE status='published' AND rating IS NOT NULL AND ai_generated=1")->fetchColumn();
        $real = (int) db()->query("SELECT COUNT(*) FROM customer_reviews WHERE status='published' AND rating IS NOT NULL AND (ai_generated=0 OR ai_generated IS NULL)")->fetchColumn();
    } catch (Throwable $e) { $ai = 0; $real = 0; }
    $base = ($ai > MV_REVIEWS_BASELINE ? MV_REVIEWS_BASELINE : $ai);
    return $c = $base + $real;
}

/** Shared content pools. 80 × 50 = 4,000 unique name combinations. */
function mv_review_pools(): array {
    return [
        'first' => ['James','Mary','Robert','Patricia','John','Jennifer','Michael','Linda','David','Elizabeth',
                    'William','Barbara','Richard','Susan','Joseph','Jessica','Thomas','Sarah','Charles','Karen',
                    'Christopher','Nancy','Daniel','Lisa','Matthew','Betty','Anthony','Margaret','Mark','Sandra',
                    'Donald','Ashley','Steven','Kimberly','Paul','Emily','Andrew','Donna','Joshua','Michelle',
                    'Gary','Amy','Eric','Angela','Stephen','Anna','Larry','Pamela','Justin','Nicole',
                    'Kenneth','Amanda','Kevin','Melissa','Brian','Deborah','George','Stephanie','Timothy','Rebecca',
                    'Ronald','Laura','Jason','Sharon','Edward','Cynthia','Jeffrey','Kathleen','Ryan','Samantha',
                    'Raj','Priya','Ahmed','Wei','Carlos','Maria','Juan','Sofia','Hiroshi','Olga'],
        'last'  => ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Rodriguez','Martinez',
                    'Hernandez','Lopez','Gonzalez','Wilson','Anderson','Thomas','Taylor','Moore','Jackson','Martin',
                    'Lee','Perez','Thompson','White','Harris','Sanchez','Clark','Ramirez','Lewis','Robinson',
                    'Walker','Young','Allen','King','Wright','Scott','Torres','Nguyen','Hill','Flores',
                    'Green','Adams','Nelson','Baker','Hall','Rivera','Campbell','Mitchell','Carter','Patel'],
        'region'=> ['US','US','US','US','US','CA','CA','GB','GB','AU','EU'],
        'domain'=> ['gmail.com','yahoo.com','outlook.com','icloud.com','hotmail.com'],
        'text'  => [
            "Key worked instantly and activated on the first try. Great price too.",
            "Received my product key by email within minutes. Smooth, quick and legit.",
            "Much cheaper than the official store and it activated without any issues.",
            "Excellent service. The activation guide made setup really easy.",
            "Fast digital delivery and the license activated perfectly. Highly recommend.",
            "Was skeptical at first but everything worked exactly as described. Very happy.",
            "Great experience — instant delivery, easy activation, and support answered fast.",
            "Bought it, got the key in about 15 minutes, activated no problem. A+",
            "Genuine key, best price I found online. Will buy from here again.",
            "Simple checkout and the key activated right away. Saved me a lot of money.",
            "Delivery was quick and the product works flawlessly. Thank you!",
            "The whole process took less than 20 minutes. Very impressed with the service.",
            "Activated on my laptop with zero problems. Exactly what I needed.",
            "Support helped me through activation step by step. Really appreciated it.",
            "Legit key, fast email delivery, and a fair price. Couldn't ask for more.",
            "Perfect. Ordered late at night and had my key before I went to bed.",
            "Everything went smoothly from purchase to activation. Recommended.",
            "Saved over half the retail price and the license is completely genuine.",
            "Quick, easy, and it just works. No complaints at all.",
            "Great value. The download links they sent were official and safe.",
            "I've bought twice now — same fast, reliable service each time.",
            "Activation was painless and the key was valid immediately.",
            "Honestly better than I expected. Delivery was almost instant.",
            "No issues whatsoever. Key came fast and activated first time.",
            "Really good price and prompt delivery. Working great so far.",
            "Customer service was responsive and the product key was genuine.",
            "Set everything up in minutes. Very straightforward and trustworthy.",
            "Product key arrived quickly and worked on my new PC right away.",
            "Smooth transaction, clear instructions, and a working license. Thanks!",
            "Would recommend to anyone looking for a legit key at a good price.",
            "Fast, reliable and affordable. Exactly as advertised.",
            "The email with my key and instructions came through in minutes.",
            "Activated without a hitch. Great communication throughout.",
            "Best deal I could find and the key is 100% valid. Very pleased.",
            "Delivered on time and it works perfectly. Five stars.",
            "Good product for the money. Everything was quick and easy.",
            "Took a chance and it paid off — genuine key, instant delivery.",
            "The activation guide was clear and I was up and running fast.",
            "Solid experience overall. The key worked and support was helpful.",
            "Quick delivery and a legit license. Happy customer here.",
            "Worked exactly as described. No subscription, one-time payment. Love it.",
            "Easy checkout, instant email delivery, key activated with no problems.",
            "The step-by-step activation instructions were really helpful.",
            "Bought this for my new laptop. Installed and activated in minutes.",
            "Second time ordering from this store. Reliable every time.",
            "Instant delivery as promised. The license is genuine and validated online.",
            "Very straightforward process. Key came fast and worked immediately.",
            "Ordered late at night and still got the key within minutes.",
            "Legit key at a fraction of the retail price. Great experience.",
            "Works great on my PC. No issues after several weeks of use.",
            "Superb service. The whole process took less than five minutes.",
            "Was up and running the same hour I ordered. Very impressed.",
        ],
    ];
}

function mv_review_pick_rating(): int {
    $r = mt_rand(1, 100);
    if ($r <= 66) return 5;
    if ($r <= 92) return 4;
    if ($r <= 98) return 3;
    return 2;
}

/** Seed the review baseline (v5 rebalance). Returns number of reviews inserted. */
function mv_seed_reviews(bool $force = false): int {
    $pdo = db();

    if (!$force && (string)setting_get('reviews_seed_v', '') === MV_REVIEWS_SEED_VERSION) {
        return 0; // already seeded this version
    }

    $slugs = $pdo->query("SELECT slug FROM products WHERE slug IS NOT NULL AND slug<>''")
                 ->fetchAll(PDO::FETCH_COLUMN);
    if (!$slugs) return 0;

    $p = mv_review_pools();

    // Wipe EVERY seeded/generated row. We key off ai_generated=1 (the reliable
    // "this is a fabricated review" marker) INSTEAD of "order_id IS NULL",
    // because a pre-v5 seeder inserted rows with order_id = 0 which a NULL-only
    // wipe missed — leaving the old 1,300 in place while a fresh 1,300 was added
    // on top (the recurring 1300 → 2600 doubling). ai_generated=1 catches them
    // all. Real customer reviews (ai_generated=0/NULL) are always preserved.
    $pdo->exec("DELETE FROM customer_reviews WHERE ai_generated = 1 OR (order_id IS NULL AND (ai_generated IS NULL OR ai_generated = 0))");

    // Unique names: shuffle all first×last combinations, consume sequentially.
    $combos = [];
    foreach ($p['first'] as $f) foreach ($p['last'] as $l) $combos[] = $f . ' ' . $l;
    shuffle($combos);
    // Never reuse a real customer's name either.
    $taken = $pdo->query("SELECT DISTINCT customer_name FROM customer_reviews WHERE customer_name IS NOT NULL")
                 ->fetchAll(PDO::FETCH_COLUMN);
    $takenMap = array_fill_keys(array_map('strval', $taken), true);

    $target = MV_REVIEWS_BASELINE; // fixed, stable baseline — never randomised

    $insert = $pdo->prepare(
      "INSERT INTO customer_reviews
         (order_id, product_slug, customer_email, customer_name, rating, comment,
          ai_generated, status, request_token, request_sent_at, submitted_at, region)
       VALUES (NULL, ?, ?, ?, ?, ?, 1, 'published', ?, ?, ?, ?)"
    );

    $total = 0;
    $ci = 0;
    $todayMidnight = strtotime('today');
    $now = time();
    $pdo->beginTransaction();
    for ($d = 0; $total < $target; $d++) {
        $dayStart = $todayMidnight - ($d * 86400);
        $perDay = min(mt_rand(3, 7), $target - $total);
        for ($i = 0; $i < $perDay; $i++) {
            do { $name = $combos[$ci++] ?? null; } while ($name !== null && isset($takenMap[$name]));
            if ($name === null) break 2; // combo pool exhausted (can't happen below 4k)
            [$fn, $ln] = explode(' ', $name, 2);
            $slug    = $slugs[array_rand($slugs)];
            $region  = $p['region'][array_rand($p['region'])];
            $email   = strtolower(str_replace(' ', '.', $name)) . mt_rand(10, 99) . '@' . $p['domain'][array_rand($p['domain'])];
            $rating  = mv_review_pick_rating();
            $comment = $p['text'][array_rand($p['text'])];        // ALWAYS has text
            $tok     = bin2hex(random_bytes(16));
            $ts      = $dayStart + mt_rand(28800, 79199);          // 8am–10pm
            if ($ts > $now) { $ts = $now - mt_rand(60, 3600); }
            $submitted = date('Y-m-d H:i:s', $ts);
            $insert->execute([$slug, $email, $name, $rating, $comment, $tok, $submitted, $submitted, $region]);
            $total++;
        }
    }
    $pdo->commit();

    // Keep the "sold" counters consistent with the new review volume.
    try { $pdo->query('SELECT sold_base FROM products LIMIT 1'); }
    catch (Throwable $e) { try { $pdo->exec('ALTER TABLE products ADD COLUMN sold_base INT NOT NULL DEFAULT 0'); } catch (Throwable $e2) {} }
    try {
        $pdo->exec("UPDATE products p
                    SET p.sold_base = 3 * (SELECT COUNT(*) FROM customer_reviews r
                                           WHERE r.product_slug = p.slug
                                             AND r.status = 'published'
                                             AND r.rating IS NOT NULL)");
        setting_set('sold_base_v1', '1');
    } catch (Throwable $e) { /* ignore */ }

    setting_set('reviews_seed_v', MV_REVIEWS_SEED_VERSION);
    return $total;
}

/** Silent, guarded web auto-heal. Never throws. Re-seeds when the version is
 *  new OR when there are somehow no seeded reviews present. */
function mv_autoheal_reviews(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $needs = ((string)setting_get('reviews_seed_v', '') !== MV_REVIEWS_SEED_VERSION);
        if (!$needs) {
            $n = (int) db()->query("SELECT COUNT(*) FROM customer_reviews WHERE ai_generated = 1 AND status='published'")->fetchColumn();
            $needs = ($n === 0);
        }
        if ($needs) {
            mv_seed_reviews(true);
        }
        // SELF-HEAL: any review tied to a real order is a genuine customer
        // review — reclassify it as non-AI so the hard-cap below can never trim
        // it and the admin/storefront counts grow past the baseline as real
        // reviews arrive (fixes reviews mis-tagged ai_generated=1 when the
        // customer picked an AI-suggested comment draft).
        try { db()->exec("UPDATE customer_reviews SET ai_generated = 0 WHERE order_id IS NOT NULL AND ai_generated = 1"); } catch (Throwable $e) {}
        // HARD CAP (idempotent, every load): the fabricated pool can NEVER
        // exceed the fixed baseline. If a stray/legacy seeder ever pushes it
        // over (the 1300 → 2600 doubling), trim the OLDEST excess so admin AND
        // storefront always settle at ~MV_REVIEWS_BASELINE. Real customer
        // reviews (ai_generated=0/NULL) are never touched.
        $seeded = (int) db()->query("SELECT COUNT(*) FROM customer_reviews WHERE ai_generated = 1")->fetchColumn();
        if ($seeded > MV_REVIEWS_BASELINE) {
            $excess = $seeded - MV_REVIEWS_BASELINE;
            db()->exec("DELETE FROM customer_reviews WHERE ai_generated = 1 ORDER BY submitted_at ASC, id ASC LIMIT " . (int)$excess);
        }
    } catch (Throwable $e) { /* DB not ready — retry next request */ }
}


/* ==========================================================================
 * DAILY TRICKLE — keep the stream alive going forward.
 * Adds 3–7 fresh, dated reviews for each day that has passed since the last
 * run (capped so a late deploy can't dump a huge backfill). Unique names,
 * always with a comment. Prunes the oldest seeded rows so the seeded pool
 * never exceeds MV_REVIEWS_MAX_TOTAL. Runs from cron AND opportunistically
 * on web load (once per day).
 * ========================================================================== */

/** Pick a reviewer name not already used anywhere in customer_reviews. */
function mv_unique_review_name(PDO $pdo, array $p): string {
    $chk = $pdo->prepare("SELECT 1 FROM customer_reviews WHERE customer_name = ? LIMIT 1");
    for ($try = 0; $try < 30; $try++) {
        $n = $p['first'][array_rand($p['first'])] . ' ' . $p['last'][array_rand($p['last'])];
        $chk->execute([$n]);
        if (!$chk->fetchColumn()) return $n;
    }
    // Extremely unlikely: add a middle initial to guarantee uniqueness.
    return $p['first'][array_rand($p['first'])] . ' ' . chr(mt_rand(65, 90)) . '. ' . $p['last'][array_rand($p['last'])];
}

/** Add the day-stream for any days elapsed since last run. Returns count added. */
function mv_trickle_reviews(int $maxCatchupDays = 10): int {
    // DISABLED by request: the store no longer fabricates reviews on a daily
    // basis. The baseline stays fixed (MV_REVIEWS_BASELINE) and the review
    // count ONLY grows when a REAL sale produces a real (order_id) review.
    // Kept as a no-op so the existing cron entry never errors.
    setting_set('reviews_trickle_last', date('Y-m-d'));
    return 0;
}

/** Legacy trickle body retained for reference only (never executed). */
function mv_trickle_reviews_legacy(int $maxCatchupDays = 10): int {
    $pdo = db();
    $todayMidnight = strtotime('today');
    $now = time();
    $last = (string)setting_get('reviews_trickle_last', '');

    // First ever run: just mark today; the seed already covers up to today.
    if ($last === '') {
        setting_set('reviews_trickle_last', date('Y-m-d'));
        return 0;
    }
    $lastMidnight = strtotime($last . ' 00:00:00');
    if ($lastMidnight === false) { setting_set('reviews_trickle_last', date('Y-m-d')); return 0; }

    $daysElapsed = (int) floor(($todayMidnight - $lastMidnight) / 86400);
    if ($daysElapsed < 1) return 0;                 // already ran today
    $daysElapsed = min($daysElapsed, $maxCatchupDays);

    $slugs = $pdo->query("SELECT slug FROM products WHERE slug IS NOT NULL AND slug<>''")->fetchAll(PDO::FETCH_COLUMN);
    if (!$slugs) return 0;
    $p = mv_review_pools();

    $insert = $pdo->prepare(
      "INSERT INTO customer_reviews
         (order_id, product_slug, customer_email, customer_name, rating, comment,
          ai_generated, status, request_token, request_sent_at, submitted_at, region)
       VALUES (NULL, ?, ?, ?, ?, ?, 1, 'published', ?, ?, ?, ?)"
    );
    $added = 0;
    $pdo->beginTransaction();
    // Fill each elapsed day (from the day after last-run up to today).
    for ($d = $daysElapsed - 1; $d >= 0; $d--) {
        $dayStart = $todayMidnight - ($d * 86400);
        $perDay = mt_rand(3, 7);
        for ($i = 0; $i < $perDay; $i++) {
            $name = mv_unique_review_name($pdo, $p);
            $ts = $dayStart + mt_rand(28800, 79199);
            if ($ts > $now) { $ts = $now - mt_rand(60, 3600); }
            $submitted = date('Y-m-d H:i:s', $ts);
            $insert->execute([
                $slugs[array_rand($slugs)],
                strtolower(str_replace([' ', '..'], ['.', '.'], $name)) . mt_rand(10, 99) . '@' . $p['domain'][array_rand($p['domain'])],
                $name, mv_review_pick_rating(), $p['text'][array_rand($p['text'])],
                bin2hex(random_bytes(16)), $submitted, $submitted,
                $p['region'][array_rand($p['region'])],
            ]);
            $added++;
        }
    }
    $pdo->commit();

    // Rolling window: never let the seeded pool exceed the target ceiling.
    try {
        $cnt = (int)$pdo->query("SELECT COUNT(*) FROM customer_reviews WHERE order_id IS NULL")->fetchColumn();
        if ($cnt > MV_REVIEWS_MAX_TOTAL) {
            $pdo->exec("DELETE FROM customer_reviews WHERE order_id IS NULL ORDER BY submitted_at ASC LIMIT " . ($cnt - MV_REVIEWS_MAX_TOTAL));
        }
    } catch (Throwable $e) { /* ignore */ }

    setting_set('reviews_trickle_last', date('Y-m-d'));
    return $added;
}

/** Opportunistic web fallback: runs the trickle at most once per calendar day. */
function mv_autoheal_trickle(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting_get('reviews_trickle_last', '') !== date('Y-m-d')) {
            mv_trickle_reviews();
        }
    } catch (Throwable $e) { /* ignore — retry next request */ }
}

/**
 * Generate N realistic, OLD-DATED reviews for a single product.
 * Used when an admin creates/edits a product and types a desired review count.
 * Reviews are spread from ~10 days ago back over ~$spreadDays so the product
 * looks established (never same-day/fresh). Unique names, always a comment,
 * published immediately. order_id stays NULL (seeded, not tied to a real sale).
 * Returns the number actually inserted.
 */
function mv_generate_product_reviews(string $slug, int $count, int $spreadDays = 150): int {
    $count = max(0, min($count, 5000)); // sane cap
    if ($count === 0 || $slug === '') return 0;
    $pdo = db();
    // Product must exist.
    $chk = $pdo->prepare('SELECT 1 FROM products WHERE slug = ? LIMIT 1');
    $chk->execute([$slug]);
    if (!$chk->fetchColumn()) return 0;

    $p = mv_review_pools();
    $insert = $pdo->prepare(
      "INSERT INTO customer_reviews
         (order_id, product_slug, customer_email, customer_name, rating, comment,
          ai_generated, status, request_token, request_sent_at, submitted_at, region)
       VALUES (NULL, ?, ?, ?, ?, ?, 1, 'published', ?, ?, ?, ?)"
    );

    $now      = time();
    $oldest   = $now - ($spreadDays * 86400);   // ~5 months back by default
    $newest   = $now - (10 * 86400);            // never within the last ~10 days
    $span     = max(1, $newest - $oldest);

    $added = 0;
    $pdo->beginTransaction();
    try {
        for ($i = 0; $i < $count; $i++) {
            $name    = mv_unique_review_name($pdo, $p);
            $ts      = $oldest + mt_rand(0, $span);
            $submitted = date('Y-m-d H:i:s', $ts);
            $email   = strtolower(str_replace([' ', '..'], ['.', '.'], $name)) . mt_rand(10, 99) . '@' . $p['domain'][array_rand($p['domain'])];
            $insert->execute([
                $slug, $email, $name,
                mv_review_pick_rating(),
                $p['text'][array_rand($p['text'])],
                bin2hex(random_bytes(16)),
                $submitted, $submitted,
                $p['region'][array_rand($p['region'])],
            ]);
            $added++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        @error_log('[mv_generate_product_reviews] ' . $e->getMessage());
    }
    return $added;
}

/** Count of seeded/generated reviews currently attached to a product. */
function mv_product_review_count(string $slug): int {
    try {
        $st = db()->prepare("SELECT COUNT(*) FROM customer_reviews WHERE product_slug = ? AND status='published' AND rating IS NOT NULL");
        $st->execute([$slug]);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) { return 0; }
}
