<?php
/*
 * Google Review Nudge — one-time follow-up email to happy reviewers (4-5★)
 * who submitted an on-site review but did NOT click "Post on Google".
 * Their exact review text is carried to /google-review.php?t=<token>, which
 * copies it to the clipboard and opens the Google review dialog.
 * Wired into the web bootstrap (functions.php) + cron.php. Hourly guard.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

function mv_gn_ensure_cols(PDO $pdo): void {
    try { $pdo->query("SELECT google_shared_at, google_nudge_sent_at FROM customer_reviews LIMIT 1"); }
    catch (Throwable $e) {
        try { $pdo->exec("ALTER TABLE customer_reviews ADD COLUMN google_shared_at DATETIME NULL"); } catch (Throwable $e2) {}
        try { $pdo->exec("ALTER TABLE customer_reviews ADD COLUMN google_nudge_sent_at DATETIME NULL"); } catch (Throwable $e2) {}
    }
}

/** Send due nudges (max 10/run). Returns number of emails queued. */
function mv_google_nudge_tick(bool $force = false): int {
    $gurl = trim((string)setting_get('google_review_url', ''));
    if ($gurl === '') return 0;
    if (!$force) {
        $last = setting_get('google_nudge_last_tick', '');
        if ($last && (time() - strtotime($last)) < 3600) return 0;
    }
    setting_set('google_nudge_last_tick', date('Y-m-d H:i:s'));

    $pdo = db();
    mv_gn_ensure_cols($pdo);
    $rows = $pdo->query("SELECT cr.id, cr.rating, cr.comment, cr.request_token, o.email, o.first_name, o.id AS oid,
                                (SELECT oi.name FROM order_items oi WHERE oi.order_id = o.id LIMIT 1) AS product_name
                           FROM customer_reviews cr
                           JOIN orders o ON o.id = cr.order_id
                          WHERE cr.rating >= 4 AND cr.ai_generated = 0 AND cr.status = 'published'
                            AND cr.comment IS NOT NULL AND cr.comment <> ''
                            AND cr.submitted_at IS NOT NULL
                            AND cr.submitted_at <= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                            AND cr.submitted_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
                            AND cr.google_shared_at IS NULL AND cr.google_nudge_sent_at IS NULL
                            AND o.email IS NOT NULL AND o.email <> ''
                          ORDER BY cr.submitted_at ASC LIMIT 10")->fetchAll();
    if (!$rows) return 0;

    require_once __DIR__ . '/email.php';
    $base = rtrim(function_exists('public_base_url') ? public_base_url() : site_url(), '/');
    $sent = 0;
    foreach ($rows as $r) {
        $tok = trim((string)($r['request_token'] ?? ''));
        if ($tok === '') {
            $tok = bin2hex(random_bytes(16));
            $pdo->prepare('UPDATE customer_reviews SET request_token=? WHERE id=?')->execute([$tok, (int)$r['id']]);
        }
        $first   = trim((string)$r['first_name']) ?: 'there';
        $stars   = str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']);
        $comment = htmlspecialchars(mb_substr((string)$r['comment'], 0, 900), ENT_QUOTES, 'UTF-8');
        $product = htmlspecialchars((string)($r['product_name'] ?: 'your purchase'), ENT_QUOTES, 'UTF-8');
        $link    = $base . '/google-review.php?t=' . urlencode($tok);
        $firstE  = htmlspecialchars($first, ENT_QUOTES, 'UTF-8');
        $brand   = htmlspecialchars(brand_name(), ENT_QUOTES, 'UTF-8');

        $html = '<!doctype html><html><body style="font-family:Segoe UI,Arial,sans-serif;background:#f8fafc;padding:24px;">'
              . '<div style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;padding:28px;border:1px solid #e2e8f0;box-shadow:0 4px 18px rgba(0,0,0,.05);">'
              . '<h2 style="margin:0 0 6px;color:#0f172a;font-size:20px;">One tiny favour, ' . $firstE . '? 🙏</h2>'
              . '<p style="color:#475569;line-height:1.6;margin:0 0 16px;">Thank you again for the lovely review of <strong>' . $product . '</strong>! '
              . 'Would you mind sharing the <em>same</em> review on Google? It takes about 10 seconds — your words are ready to copy, no re-typing needed.</p>'
              . '<div style="background:#f8fafc;border:1px dashed #cbd5e1;border-radius:12px;padding:14px 16px;margin:0 0 18px;">'
              . '<div style="color:#f59e0b;font-size:18px;letter-spacing:2px;margin-bottom:6px;">' . $stars . '</div>'
              . '<div style="color:#0f172a;font-size:14px;line-height:1.55;font-style:italic;">&ldquo;' . $comment . '&rdquo;</div>'
              . '</div>'
              . '<div style="text-align:center;margin:0 0 14px;">'
              . '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '" '
              . 'style="display:inline-block;padding:13px 26px;background:#2563eb;color:#fff;text-decoration:none;border-radius:999px;font-weight:700;font-size:15px;">Post it on Google — 1 tap, no typing</a>'
              . '<div style="margin-top:10px;font-size:12.5px;"><a href="' . htmlspecialchars($gurl, ENT_QUOTES, 'UTF-8') . '" style="color:#2563eb;text-decoration:underline;">Button not working? Open Google directly &rarr;</a>'
              . '<span style="color:#94a3b8;"> (copy your review above first)</span></div>'
              . '</div>'
              . '<p style="color:#94a3b8;font-size:12px;line-height:1.55;margin:0;">The button copies your review automatically and opens Google — just paste and hit Post. '
              . 'Already shared it? You can ignore this email — we won\'t ask again. Thanks for helping other shoppers buy with confidence! — The ' . $brand . ' team</p>'
              . '</div></body></html>';

        try {
            send_email((string)$r['email'],
                       $first !== 'there' ? ($first . ', mind sharing your ' . (int)$r['rating'] . '-star review on Google?') : 'Mind sharing your review on Google?',
                       $html, (int)$r['oid'], 'google_review_nudge');
            $pdo->prepare('UPDATE customer_reviews SET google_nudge_sent_at = NOW() WHERE id = ?')->execute([(int)$r['id']]);
            $sent++;
        } catch (Throwable $e) {
            @error_log('[google-nudge] ' . $e->getMessage());
        }
    }
    return $sent;
}

/** Silent web auto-tick — never throws, never blocks the page meaningfully. */
function mv_autoheal_google_nudge(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $last = setting_get('google_nudge_last_tick', '');
        if ($last && (time() - strtotime($last)) < 3600) return;
        mv_google_nudge_tick();
    } catch (Throwable $e) { /* retry next hour */ }
}
