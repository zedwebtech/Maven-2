<?php
/**
 * Maventech — self-contained Web Push (VAPID / RFC 8291 + RFC 8292).
 *
 * Zero third-party libraries: uses only ext-openssl (EC prime256v1 + ECDH +
 * AES-128-GCM) and the built-in hash_hkdf() — so it runs on locked-down
 * shared cPanel hosts with just openssl + curl (no gmp/bcmath needed).
 *
 * Public API:
 *   mv_push_available()                 -> bool  (crypto primitives present)
 *   mv_push_public_key()                -> base64url VAPID public key (for JS)
 *   mv_push_save_subscription($sub,$ua) -> store a browser subscription
 *   mv_push_remove($endpoint)           -> delete a subscription
 *   mv_push_broadcast($title,$body,$link,$type) -> push to every admin device
 *
 * Storage: settings(vapid_public_key/vapid_private_pem) + table push_subscriptions.
 * Everything is wrapped so a push failure NEVER bubbles into checkout/lead flows.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

if (!function_exists('mv_push_available')) {

/* ---- base64url helpers ------------------------------------------------- */
function mv_b64u_encode(string $bin): string {
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}
function mv_b64u_decode(string $txt): string {
    $txt = strtr($txt, '-_', '+/');
    $pad = strlen($txt) % 4;
    if ($pad) $txt .= str_repeat('=', 4 - $pad);
    return (string) base64_decode($txt);
}

/* ---- capability probe -------------------------------------------------- */
function mv_push_available(): bool {
    static $ok = null;
    if ($ok !== null) return $ok;
    $ok = function_exists('openssl_pkey_derive')
       && function_exists('hash_hkdf')
       && function_exists('openssl_pkey_new')
       && in_array('aes-128-gcm', openssl_get_cipher_methods(), true);
    return $ok;
}

/* ---- VAPID keypair (generated once, persisted in settings) ------------- */
function mv_push_keys(): array {
    $pub = setting_get('vapid_public_key', '', true);
    $pem = setting_get('vapid_private_pem', '', true);
    if ($pub !== '' && $pem !== '') {
        return ['public' => $pub, 'pem' => $pem];
    }
    if (!mv_push_available()) return ['public' => '', 'pem' => ''];
    // Generate a fresh P-256 keypair.
    $res = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if (!$res) return ['public' => '', 'pem' => ''];
    openssl_pkey_export($res, $pemOut);
    $d = openssl_pkey_get_details($res);
    $raw = "\x04"
         . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT)
         . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT);
    $pubB64 = mv_b64u_encode($raw);
    try {
        setting_set('vapid_public_key', $pubB64);
        setting_set('vapid_private_pem', $pemOut);
    } catch (Throwable $e) { /* still usable this request */ }
    return ['public' => $pubB64, 'pem' => $pemOut];
}

function mv_push_public_key(): string {
    return mv_push_keys()['public'] ?? '';
}

/* ---- subscription table (zero-DDL-safe, self-healing) ------------------ */
function mv_push_ensure_table(): void {
    static $done = false;
    if ($done) return;
    try {
        db()->exec(
            "CREATE TABLE IF NOT EXISTS push_subscriptions (
               id INT AUTO_INCREMENT PRIMARY KEY,
               endpoint VARCHAR(500) NOT NULL,
               p256dh VARCHAR(255) NOT NULL,
               auth   VARCHAR(64)  NOT NULL,
               ua     VARCHAR(255) NULL,
               created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
               last_ok_at DATETIME NULL,
               UNIQUE KEY uq_endpoint (endpoint(191))
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) { @error_log('[webpush] ensure_table ' . $e->getMessage()); }
    $done = true;
}

function mv_push_save_subscription(array $sub, string $ua = ''): bool {
    mv_push_ensure_table();
    $endpoint = trim((string)($sub['endpoint'] ?? ''));
    $p256dh   = trim((string)($sub['keys']['p256dh'] ?? ''));
    $auth     = trim((string)($sub['keys']['auth'] ?? ''));
    if ($endpoint === '' || $p256dh === '' || $auth === '') return false;
    try {
        $st = db()->prepare(
            "INSERT INTO push_subscriptions (endpoint, p256dh, auth, ua)
             VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE p256dh=VALUES(p256dh), auth=VALUES(auth), ua=VALUES(ua)"
        );
        $st->execute([substr($endpoint, 0, 500), substr($p256dh, 0, 255), substr($auth, 0, 64), substr($ua, 0, 255)]);
        return true;
    } catch (Throwable $e) { @error_log('[webpush] save ' . $e->getMessage()); return false; }
}

function mv_push_remove(string $endpoint): void {
    try {
        db()->prepare("DELETE FROM push_subscriptions WHERE endpoint=?")->execute([$endpoint]);
    } catch (Throwable $e) { /* ignore */ }
}

/* ---- DER ECDSA signature -> raw 64-byte R||S (for the ES256 JWT) -------- */
function mv_push_der_to_raw(string $der): string {
    $off = 0;
    if (ord($der[$off++]) !== 0x30) return '';
    // sequence length (skip, may be short-form)
    $seqLen = ord($der[$off++]);
    if ($seqLen & 0x80) { $n = $seqLen & 0x7f; $off += $n; }
    $readInt = function () use ($der, &$off) {
        if (ord($der[$off++]) !== 0x02) return '';
        $len = ord($der[$off++]);
        $v = substr($der, $off, $len); $off += $len;
        $v = ltrim($v, "\x00");                       // strip DER leading zero
        return str_pad($v, 32, "\0", STR_PAD_LEFT);   // left-pad to 32 bytes
    };
    $r = $readInt();
    $s = $readInt();
    return ($r === '' || $s === '') ? '' : ($r . $s);
}

/* ---- VAPID Authorization header for a given endpoint ------------------- */
function mv_push_vapid_header(string $endpoint): string {
    $keys = mv_push_keys();
    if ($keys['pem'] === '' || $keys['public'] === '') return '';
    $p = parse_url($endpoint);
    if (!$p || empty($p['host'])) return '';
    $aud = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    $sub = 'mailto:' . (setting_get('company_email', '') ?: 'admin@maventechsoftware.com');

    $header  = mv_b64u_encode(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $payload = mv_b64u_encode(json_encode(['aud' => $aud, 'exp' => time() + 43200, 'sub' => $sub]));
    $signingInput = $header . '.' . $payload;

    $pk = openssl_pkey_get_private($keys['pem']);
    if (!$pk) return '';
    $der = '';
    if (!openssl_sign($signingInput, $der, $pk, OPENSSL_ALGO_SHA256)) return '';
    $raw = mv_push_der_to_raw($der);
    if ($raw === '') return '';
    $jwt = $signingInput . '.' . mv_b64u_encode($raw);
    return 'vapid t=' . $jwt . ', k=' . $keys['public'];
}

/* ---- payload encryption (aes128gcm, RFC 8291) -------------------------- */
function mv_push_encrypt(string $payload, string $uaPublicB64, string $authB64): ?array {
    if (!mv_push_available()) return null;
    $uaPublic = mv_b64u_decode($uaPublicB64);   // 65 raw bytes
    $authSecret = mv_b64u_decode($authB64);     // 16 raw bytes
    if (strlen($uaPublic) !== 65 || strlen($authSecret) < 16) return null;

    // Ephemeral server keypair.
    $eph = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if (!$eph) return null;
    $ed = openssl_pkey_get_details($eph);
    $asPublic = "\x04"
        . str_pad($ed['ec']['x'], 32, "\0", STR_PAD_LEFT)
        . str_pad($ed['ec']['y'], 32, "\0", STR_PAD_LEFT);

    // Rebuild the UA public key as an OpenSSL key (SPKI DER for P-256 + raw point).
    $spkiPrefix = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200');
    $der = $spkiPrefix . $uaPublic;
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
    $peer = openssl_pkey_get_public($pem);
    if (!$peer) return null;

    $sharedSecret = openssl_pkey_derive($peer, $eph);   // 32-byte ECDH secret
    if (!$sharedSecret) return null;

    // RFC 8291 IKM.
    $keyInfo = "WebPush: info\x00" . $uaPublic . $asPublic;
    $ikm = hash_hkdf('sha256', $sharedSecret, 32, $keyInfo, $authSecret);

    $salt  = random_bytes(16);
    $cek   = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\x00", $salt);
    $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\x00", $salt);

    // Single record: plaintext + 0x02 delimiter, then AES-128-GCM.
    $plain = $payload . "\x02";
    $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
    if ($cipher === false) return null;

    // RFC 8188 body header: salt(16) | rs(uint32 BE) | idlen(1) | keyid(as_public 65).
    $rs = 4096;
    $body = $salt . pack('N', $rs) . chr(strlen($asPublic)) . $asPublic . $cipher . $tag;
    return ['body' => $body];
}

/* ---- send to one subscription ------------------------------------------ */
function mv_push_send_one(array $row, string $payload): int {
    // returns HTTP status (0 on transport error)
    $enc = mv_push_encrypt($payload, $row['p256dh'], $row['auth']);
    if (!$enc) return 0;
    $vapid = mv_push_vapid_header($row['endpoint']);
    if ($vapid === '') return 0;

    $ch = curl_init($row['endpoint']);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS     => $enc['body'],
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER     => [
            'Authorization: ' . $vapid,
            'Content-Type: application/octet-stream',
            'Content-Encoding: aes128gcm',
            'TTL: 86400',
            'Urgency: high',
        ],
    ]);
    curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code;
}

/* ---- broadcast to every stored admin device ---------------------------- */
function mv_push_broadcast(string $title, string $body = '', string $link = '/admin.php', string $type = 'info'): void {
    if (!mv_push_available()) return;
    try {
        mv_push_ensure_table();
        $rows = db()->query("SELECT id, endpoint, p256dh, auth FROM push_subscriptions")->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return;
        $payload = json_encode([
            'title' => $title,
            'body'  => $body,
            'link'  => $link,
            'type'  => $type,
            'id'    => substr(md5($type . '|' . $title . '|' . $link), 0, 12),
            'ts'    => time(),
            // Chat pushes carry the lead id so Android/Windows can offer an inline "Reply" box.
            'lead_id' => (preg_match('/[?&]autochat=(\d+)/', $link, $m) ? (int)$m[1] : 0),
        ]);
        $sent = 0; $failed = 0; $pruned = 0;
        foreach ($rows as $row) {
            $code = mv_push_send_one($row, $payload);
            if ($code === 404 || $code === 410) {
                // Subscription is gone/expired — prune it.
                mv_push_remove($row['endpoint']); $pruned++;
            } elseif ($code >= 200 && $code < 300) {
                $sent++;
                try { db()->prepare("UPDATE push_subscriptions SET last_ok_at=NOW() WHERE id=?")->execute([$row['id']]); } catch (Throwable $e) {}
            } else { $failed++; }
        }
        // Delivery stats surfaced in the admin bell ("Last push: 2 devices, 1 min ago").
        try {
            setting_set('push_last_sent_at', (string)time());
            setting_set('push_last_result', json_encode(['sent' => $sent, 'failed' => $failed, 'pruned' => $pruned, 'type' => $type, 'title' => mb_substr($title, 0, 80)]));
        } catch (Throwable $e) {}
    } catch (Throwable $e) { @error_log('[webpush] broadcast ' . $e->getMessage()); }
}

} // function_exists guard
