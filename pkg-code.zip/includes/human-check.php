<?php
// Built-in "Verify you're human" for the chat lead form — no third-party
// captcha account needed. A genuine browser must:
//   1. fetch a signed challenge (bound to IP + user-agent, valid 15 min),
//   2. wait at least ~2.5 s (humans read the form; bots post instantly),
//   3. solve a small proof-of-work in JS (≈0.1–0.5 s on a phone),
//   4. leave the honeypot field empty,
// and only then receives a signed human_token that ajax/lead.php requires.
// Bots that POST ajax/lead.php directly (the "fake chats") never get one.

const MV_HC_TTL_SEC      = 900;   // challenge + token lifetime
const MV_HC_MIN_DWELL    = 2.5;   // seconds between challenge issue and verify
const MV_HC_DIFF_PREFIX  = '000'; // sha256 hex must start with this …
const MV_HC_DIFF_NIBBLE  = 1;     // … and the 4th hex digit must be <= this (≈15 bits)

function mv_hc_secret(): string
{
    static $s = null;
    if ($s !== null) return $s;
    $s = (string)setting_get('hc_secret', '');
    if (strlen($s) < 32) {
        $s = bin2hex(random_bytes(24));
        try { setting_set('hc_secret', $s); } catch (Throwable $e) {}
    }
    return $s;
}

function mv_hc_client_fp(): string
{
    return client_ip() . '|' . substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 160);
}

function mv_hc_sign(string $data): string
{
    return hash_hmac('sha256', $data, mv_hc_secret());
}

/** New challenge for this browser. */
function mv_hc_challenge(): array
{
    $c = time() . '.' . bin2hex(random_bytes(8));
    return [
        'c'      => $c,
        'sig'    => mv_hc_sign('c|' . $c . '|' . mv_hc_client_fp()),
        'prefix' => MV_HC_DIFF_PREFIX,
        'nibble' => MV_HC_DIFF_NIBBLE,
    ];
}

/** Verify a solved challenge → ['ok'=>bool, 'token'=>…, 'error'=>…]. */
function mv_hc_verify(array $in): array
{
    $c     = (string)($in['c'] ?? '');
    $sig   = (string)($in['sig'] ?? '');
    $nonce = (string)($in['nonce'] ?? '');
    $sid   = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($in['session_id'] ?? '')), 0, 64);
    if (trim((string)($in['website'] ?? '')) !== '') return ['ok' => false, 'error' => 'bot'];        // honeypot
    if (!preg_match('/^(\d{10})\.[a-f0-9]{16}$/', $c, $m) || $sig === '' || $nonce === '' || $sid === '') return ['ok' => false, 'error' => 'bad_request'];
    if (!hash_equals(mv_hc_sign('c|' . $c . '|' . mv_hc_client_fp()), $sig)) return ['ok' => false, 'error' => 'bad_signature'];
    $issued = (int)$m[1];
    $age = microtime(true) - $issued;
    if ($age > MV_HC_TTL_SEC) return ['ok' => false, 'error' => 'expired'];
    if ($age < MV_HC_MIN_DWELL) return ['ok' => false, 'error' => 'too_fast'];
    if (strlen($nonce) > 24 || !ctype_alnum($nonce)) return ['ok' => false, 'error' => 'bad_nonce'];
    $h = hash('sha256', $c . ':' . $nonce);
    if (strpos($h, MV_HC_DIFF_PREFIX) !== 0 || hexdec($h[strlen(MV_HC_DIFF_PREFIX)]) > MV_HC_DIFF_NIBBLE) return ['ok' => false, 'error' => 'bad_pow'];
    $exp = time() + MV_HC_TTL_SEC;
    $payload = $exp . '.' . $sid;
    return ['ok' => true, 'token' => $payload . '.' . mv_hc_sign('t|' . $payload . '|' . mv_hc_client_fp()), 'expires' => $exp];
}

/** True when $token was issued by mv_hc_verify() for this session + browser and is still valid. */
function mv_hc_token_valid(string $token, string $sessionId): bool
{
    $sessionId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionId), 0, 64);
    if (!preg_match('/^(\d{10})\.([a-zA-Z0-9_-]{1,64})\.([a-f0-9]{64})$/', $token, $m)) return false;
    if ((int)$m[1] < time() || $sessionId === '' || !hash_equals($m[2], $sessionId)) return false;
    return hash_equals(mv_hc_sign('t|' . $m[1] . '.' . $m[2] . '|' . mv_hc_client_fp()), $m[3]);
}

/** Per-IP lead creation limits — stops a verified-but-scripted flood. */
function mv_hc_ip_over_limit(PDO $pdo, string $ip): string
{
    if ($ip === '') return '';
    try {
        $st = $pdo->prepare('SELECT SUM(created_at >= NOW() - INTERVAL 1 HOUR), SUM(created_at >= NOW() - INTERVAL 1 DAY) FROM chat_leads WHERE client_ip = ?');
        $st->execute([$ip]);
        [$hour, $day] = array_map('intval', $st->fetch(PDO::FETCH_NUM) ?: [0, 0]);
        if ($hour >= 3 || $day >= 8) return 'rate_limited';
    } catch (Throwable $e) {}
    return '';
}
