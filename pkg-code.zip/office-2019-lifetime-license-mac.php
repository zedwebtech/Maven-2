<?php
/** Landing page — Microsoft Office 2019 for Mac, Lifetime License. */
$OFFICE_VERSION  = '2019';
$OFFICE_PLATFORM = 'mac';
require __DIR__ . '/includes/office-landing.php';
