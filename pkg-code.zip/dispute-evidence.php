<?php
/*
 * Proof of Fulfillment / Dispute Evidence PDF — one-click, bank-ready
 * chargeback rebuttal. Admin-only. Linked from order-view.php.
 * The document body is built by mv_render_proof_of_fulfillment_pdf() in
 * includes/pdf.php so the same output can be bundled into the all-docs ZIP.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/pdf.php';
ensure_admin();
require_admin();

$id = (int)($_GET['id'] ?? 0);
$q = db()->prepare('SELECT * FROM orders WHERE id=?');
$q->execute([$id]);
$o = $q->fetch();
if (!$o) { http_response_code(404); die('Order not found'); }

$pdf = mv_render_proof_of_fulfillment_pdf($o);

header('Content-Type: application/pdf');
header('Content-Disposition: ' . (isset($_GET['view']) ? 'inline' : 'attachment') . '; filename="Proof-of-Fulfillment-' . preg_replace('/[^A-Za-z0-9\-_]/', '', (string)$o['order_number']) . '.pdf"');
header('Cache-Control: no-store');
echo $pdf;
