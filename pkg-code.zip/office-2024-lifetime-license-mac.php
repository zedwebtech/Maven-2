<?php
/** Landing page — Microsoft Office 2024 for Mac, Lifetime License. */
$OFFICE_VERSION  = '2024';
$OFFICE_PLATFORM = 'mac';
require __DIR__ . '/includes/office-landing.php';
