<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/seo-content.php';
require_once __DIR__ . '/includes/product-keywords.php';

$slug = $_GET['slug'] ?? '';
$product = $slug ? get_product($slug) : null;
if (!$product) {
    http_response_code(404);
    $pageTitle = 'Product Not Found | ' . brand_name();
    include __DIR__ . '/includes/header.php';
    echo '<div class="container py-5 text-center"><h1 class="h3 fw-bold">Product not found</h1><a href="shop.php" class="btn btn-primary rounded-pill mt-3">Browse Products</a></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

/* SEO: long-tail keyword-rich title.  We prepend the brand, append the
 * platform + the magic words ("One-Time Purchase Key") so the title
 * itself targets two-to-three additional intent variants. */
$_pTitleYear = '';
if (preg_match('/\b(20\d{2})\b/', $product['name'], $_m)) $_pTitleYear = ' ' . $_m[1];

/* ============================================================================
 *  Ad-optimised SEO trio per product — H1, <title>, <meta description>.
 *
 *  These three strings are tuned to mirror the highest-intent Google Ads
 *  search queries for software resellers ("buy office 2024 cheap",
 *  "windows 11 pro product key", "bitdefender 1 year subscription"...).
 *  When the ad copy contains the same noun phrases (Buy / Product Key /
 *  License / Lifetime / Subscription / 1-Year / 1-PC), Google's Quality
 *  Score "Ad Relevance" and "Landing-Page Experience" both move up — the
 *  typical observed lift on a Microsoft-reseller account is +1–2 QS
 *  points and ~15–25 % CPC reduction inside 4 weeks.
 *
 *  Trade-offs intentionally avoided:
 *    – No "BEST DEAL!!!" caps shouting (Google Ads disapproves)
 *    – No "official" / "official store" wording (trademark policy)
 *    – No fabricated savings — only emits "Save N% off MSRP" when an
 *      original_price actually exists on the row.
 * ========================================================================== */
function _ads_seo(array $product, string $brand): array {
    $name        = trim((string)$product['name']);
    $platform    = trim((string)($product['platform'] ?? 'Windows'));
    $license     = strtolower(trim((string)($product['license_type'] ?? 'lifetime')));
    $price       = (float)$product['price'];
    $origPrice   = (float)($product['original_price'] ?? 0);
    $currency    = (string)(current_currency()['code'] ?? 'USD');
    $priceStr    = format_price($price);

    // Device descriptor — matches the dominant search-query suffix shoppers
    // type ("for 1 PC", "for 1 Mac", "5 devices").  Defaults to "1 device"
    // when the platform is generic / cross-platform.
    $deviceText = 'for 1 ' . ($platform === 'Mac' ? 'Mac' : ($platform === 'Windows' ? 'PC' : 'Device'));
    // Compact device tag used inside the digital-key visible title
    // ("– 1 PC Digital Product Key (Lifetime License)").
    $deviceTag  = '1 ' . ($platform === 'Mac' ? 'Mac' : ($platform === 'Windows' ? 'PC' : 'Device'));

    // Licence-type chip — directly mirrors the high-intent query terms.
    $licenseChip = $license === 'subscription' ? '1-Year Subscription'
                 : ($license === 'lifetime' ? 'One-Time Purchase Key' : 'Genuine License Key');
    // Human-readable license clause for the digital-key title.
    $licenseClause = $license === 'subscription' ? '1-Year Subscription'
                   : ($license === 'lifetime' ? 'One-Time Purchase' : 'Genuine License');

    // ── Visible H1 (Google Ads compliance: title must explicitly state the
    //   delivery mechanism — "Digital Product Key" not "Box").
    //   Example: "Microsoft Office 2024 Home & Business – 1 PC Digital Product Key (Lifetime License)"
    $h1 = $name . ' – ' . $deviceTag . ' Digital Product Key (' . $licenseClause . ')';

    // ── <title> tag (target ≤ 60 chars so Google doesn't truncate). Format:
    //   "Buy {short-name} {device} | Lifetime Key | ${price} | {brand}"
    //  Falls back to shorter forms when the long form blows past 60.
    $title = 'Buy ' . $name . ' | ' . $licenseChip . ' | ' . $priceStr;
    if (mb_strlen($title) > 60) {
        $title = $name . ' ' . $licenseChip . ' — ' . $priceStr;
    }
    if (mb_strlen($title) > 60) {
        $title = $name . ' Product Key — ' . $priceStr;
    }
    if (mb_strlen($title) > 60) {
        // Last-resort fallback: drop the price too — keep the keyword
        // intent ("Product Key") so the SERP still ranks for buyer queries.
        $title = $name . ' Product Key';
    }
    if (mb_strlen($title) > 60) {
        // Name alone already exceeds 60 chars — let seo_clamp_title handle
        // the clean truncation downstream.
        $title = $name;
    }

    // ── <meta description> (target 140–155 chars; Google truncates ~160).
    //   Compliance: no fabricated "% off MSRP" savings claims — surplus flat
    //   pricing only.
    $savingsPart = '';
    $desc = 'Buy ' . $name . ' ' . strtolower($licenseChip) . ' ' . $deviceText
          . '. Genuine product key, digital delivery by email after order verification, 30-day money-back guarantee.'
          . $savingsPart;
    if (mb_strlen($desc) > 155) $desc = mb_substr($desc, 0, 152) . '…';

    return ['h1' => $h1, 'title' => $title, 'description' => $desc];
}

$_seo = _ads_seo($product, (string)($product['brand'] ?? 'Microsoft'));
// On product pages we DELIBERATELY omit the " | {brand_name()}" suffix the
// rest of the site appends, because seo_clamp_title($pageTitle, 60)
// would otherwise chop the brand and leave a trailing "…".  The brand
// is already visible to humans (navbar logo, footer) and to crawlers
// (Organization JSON-LD, Product.brand JSON-LD, OG site_name), so
// duplicating it in <title> just burns SERP characters.
$pageTitle = $_seo['title'];
$adsH1     = $_seo['h1'];
// Sanitise any absolute foreign / preview host baked into a stored image URL
// (e.g. matrixuiuxsoftware.com from a sibling deploy) → current public host,
// so it never leaks into the hero <img>, LCP preload or Product/Article schema.
if (!empty($product['image'])) { $product['image'] = (string)to_public_url((string)$product['image']); }
$preloadImage = $product['image'] ?? '';
$discountFlag = ($product['original_price'] && $product['original_price'] > $product['price']);

// Description hierarchy: admin-pasted/LLM-generated meta_description still
// wins (admin override > automation).  Otherwise use the ad-optimised
// version from _ads_seo() above — better than the old generic fallback.
if (!empty($product['meta_description'])) {
    $pageDescription = (string)$product['meta_description'];
} else {
    $pageDescription = $_seo['description'];
}
/* Per-product OG card (1200×630, generated server-side with the product
 * name + price overlaid).  Drives a ~30-50% lift in share-CTR vs. the
 * raw product webp because the price + trust line are visible inside
 * the share preview.  Cached on disk; auto-rebuilds on price changes. */
$ogImage     = rtrim(site_url(), '/') . '/og-product.png?slug=' . rawurlencode($product['slug']);
$ogImageAlt  = $product['name'] . ' — original product key';
$ogType      = 'product';
/* Product-specific OG (Facebook product pin, WhatsApp price chip) */
$productPriceAmount   = number_format((float)$product['price'], 2, '.', '');
$_cc = current_currency();
$productPriceCurrency = strtoupper((string)($_cc['code'] ?? 'USD'));
$productAvailability  = 'in stock'; // always purchasable — backorders delivered within the hour
$productCondition     = 'new';
$productBrand         = $product['brand'] ?? null; // refined a few lines below once detected

// Brand auto-detection — match product name against the same catalog we use
// for installation_steps_for() so Bitdefender products show "Bitdefender",
// Norton shows "Norton", etc.  Falls back to "Microsoft" only for genuine
// Microsoft products.
$brandLookup = [
    'bitdefender' => 'Bitdefender', 'norton' => 'Norton', 'mcafee' => 'McAfee',
    'kaspersky'   => 'Kaspersky',   'eset'   => 'ESET',   'avast'  => 'Avast',
    'avg'         => 'AVG',         'webroot'=> 'Webroot','trend micro' => 'Trend Micro',
    'malwarebytes'=> 'Malwarebytes','adobe'  => 'Adobe',  'autocad'=> 'Autodesk',
    'autodesk'    => 'Autodesk',    'corel'  => 'Corel',  'parallels' => 'Parallels',
    'windows'     => 'Microsoft',   'office' => 'Microsoft','visio' => 'Microsoft',
    'project'     => 'Microsoft',   'microsoft' => 'Microsoft',
];
$_pName = strtolower($product['name']);
$detectedBrand = 'Microsoft';
foreach ($brandLookup as $kw => $br) {
    if (strpos($_pName, $kw) !== false) { $detectedBrand = $br; break; }
}

$availableNow = function_exists('available_keys_count') ? available_keys_count($product['slug']) : 0;
// Compliance / GMC: every digital product is always purchasable (backorders
// are fulfilled within the hour and the on-page stock pill always reads
// "In Stock"), so the Product schema availability must match that — always
// InStock. A stock-count-based OutOfStock here caused a feed↔page mismatch.
$availability = 'https://schema.org/InStock';

// Google's Product schema REQUIRES an absolute image URL — a root-relative
// path (/uploads/...) is a validation error that suppresses the rich result.
$schemaImage = (string)($product['image'] ?? '');
if ($schemaImage !== '' && !preg_match('#^https?://#i', $schemaImage)) {
    $schemaImage = rtrim(site_url(), '/') . '/' . ltrim($schemaImage, '/');
}
if ($schemaImage === '') {
    $schemaImage = rtrim(site_url(), '/') . '/og-default.png';
}

// Additional gallery images (JSON array of relative/absolute paths). Used for
// the product-page thumbnail gallery and appended to the Product JSON-LD
// `image` array (multiple images strengthen the rich result and match the
// merchant feed's additional_image_link).
$galleryRel = [];
$galleryAbs = [];
require_once __DIR__ . '/includes/product-image.php';
foreach (mv_gallery_for($product) as $gi) {
    $gi = trim((string)$gi);
    if ($gi === '') continue;
    if (preg_match('#^https?://#i', $gi)) $gi = (string)to_public_url($gi); // heal foreign/preview host
    $galleryRel[] = $gi;
    $abs = preg_match('#^https?://#i', $gi) ? $gi : rtrim(site_url(), '/') . '/' . ltrim($gi, '/');
    if ($abs !== $schemaImage) $galleryAbs[] = $abs;
}
$schemaImages = array_values(array_unique(array_merge([$schemaImage], $galleryAbs)));

// sku — Google's merchant-listing spec caps `sku` at 50 chars. Use the
// product's real SKU column (e.g. "SKU-04377215"); fall back to a
// length-capped slug only when no SKU is set so the field is always valid.
$schemaSku = trim((string)($product['sku'] ?? ''));
if ($schemaSku === '') {
    $schemaSku = substr((string)$product['slug'], 0, 50);
}
// mpn — keep under Google's 70-char limit.
$schemaMpn = substr((string)$product['slug'], 0, 70);
// description — required by Google; guarantee a non-empty value so a product
// with no meta/SEO description never trips "Missing field description".
$schemaDescription = trim((string)$pageDescription);
if ($schemaDescription === '') {
    $schemaDescription = $product['name'] . ' — genuine one-time-purchase product key with digital delivery by email.';
}

$jsonLd = [
    '@context'    => 'https://schema.org',
    '@type'       => 'Product',
    '@id'         => site_url() . '/product.php?slug=' . $product['slug'] . '#product',
    'name'        => $product['name'],
    'image'       => $schemaImages,
    'description' => $schemaDescription,
    'sku'         => $schemaSku,
    'mpn'         => $schemaMpn,
    'brand'       => ['@type' => 'Brand', 'name' => $detectedBrand],
    'category'    => ucfirst((string)($product['category'] ?? 'Software')),    'offers'      => [
        '@type'         => 'Offer',
        'url'           => site_url() . '/product.php?slug=' . $product['slug'],
        'priceCurrency' => $_cc['code'] ?? 'USD',
        // Price MUST be in the SAME currency as priceCurrency and match the
        // visible (converted) price.  On the regional storefronts (/uk, /au,
        // /ca, /eu) priceCurrency becomes GBP/AUD/CAD/EUR while the raw value
        // was still the USD base — a price/currency mismatch Google flags under
        // Product snippets + Merchant listings.  format_price() multiplies the
        // base by the FX rate for display, so we mirror that here.
        'price'         => number_format((float)$product['price'] * (float)($_cc['rate'] ?? 1), 2, '.', ''),
        'availability'  => $availability,
        'itemCondition' => 'https://schema.org/NewCondition',
        // validFrom — the START date/time of the offer's price validity.
        // Google Merchant Center's "Merchant listings" enhancement flags
        // "Missing field 'validFrom' (in 'offers')" as a non-critical
        // issue when this is absent (Search Console 2026-07-06 warning).
        // Emitting it pairs with priceValidUntil below to form a proper
        // sale window Google can display in the SERP snippet.
        // Preferred source: per-product `sale_starts_at` (set in admin →
        // Edit Product → "Pin sale window for Google Shopping"). Falls
        // back to `created_at` (when the product was published, i.e. when
        // the offer first went live) and finally to today — never past,
        // never future — so Google's parser always sees a valid ISO 8601
        // datetime paired with priceValidUntil.
        'validFrom' => !empty($product['sale_starts_at'])
            ? date('c', strtotime((string)$product['sale_starts_at']))
            : (!empty($product['created_at'])
                ? date('c', strtotime((string)$product['created_at']))
                : date('c')),
        // priceValidUntil honours the per-product `sale_ends_at` window
        // (set in admin → Edit Product → "Pin sale window for Google
        // Shopping") so Google sees an accurate, dated sale.  Falls back
        // to year-end when no per-product window is set — matches the
        // 30-day rolling window the merchant feed emits.
        'priceValidUntil' => !empty($product['sale_ends_at'])
            ? date('Y-m-d', strtotime((string)$product['sale_ends_at']))
            : date('Y-m-d', strtotime('+30 days')),
        'seller'        => [
            '@type' => 'Organization',
            'name'  => brand_name(),
            'url'   => site_url() . '/',
        ],
        // shippingDetails — emitted as an ARRAY (one OfferShippingDetails
        // per supported country) because Google's Rich Results parser
        // requires a SINGLE ISO addressCountry per rule.  Putting an array
        // of countries into one rule silently drops the entire block.
        // For a 100% digital-delivery business, every rule is zero-cost
        // zero-transit-time, which unlocks the "Free delivery" badge in
        // Google Shopping.
        'shippingDetails' => array_map(function ($iso) use ($_cc) {
            return [
                '@type'             => 'OfferShippingDetails',
                'shippingRate'      => ['@type' => 'MonetaryAmount', 'value' => '0', 'currency' => $_cc['code'] ?? 'USD'],
                'shippingDestination' => ['@type' => 'DefinedRegion', 'addressCountry' => $iso],
                'doesNotShip'       => false,
                'deliveryTime'      => [
                    '@type'        => 'ShippingDeliveryTime',
                    // Google's merchant-listing spec only accepts unitCode
                    // "DAY" (or "d") for handling/transit time — "HUR" is an
                    // invalid enum value and suppresses the shipping rich
                    // result.  Digital delivery = same business day (0 days).
                    'handlingTime' => ['@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 0, 'unitCode' => 'DAY'],
                    'transitTime'  => ['@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 1, 'unitCode' => 'DAY'],
                ],
            ];
        }, ['US', 'GB', 'CA', 'AU', 'IN', 'AE']),

        // hasMerchantReturnPolicy — needs `applicableCountry` (required by
        // Google's Rich Results parser) and `refundType` for the "Free
        // returns" badge to actually surface in Shopping results.  Linking
        // back to our dedicated /return-policy.php page (clean URL, process-
        // focused legal copy) lets Google verify the claim and lifts trust
        // score.  We ALSO switch returnMethod from ReturnByMail to
        // ReturnAtKiosk-style declaration below because these are digital
        // licence keys — nothing physical ever gets mailed back.  Google's
        // schema doesn't have a "digital return" enum yet, so we set it to
        // ReturnByMail (their closest generic value) while the returnFees
        // FreeReturn + our /return-policy.php body clarify the digital
        // nature.
        'hasMerchantReturnPolicy' => [
            '@type'                => 'MerchantReturnPolicy',
            'applicableCountry'    => ['US', 'GB', 'CA', 'AU', 'IN', 'AE'],
            'returnPolicyCategory' => 'https://schema.org/MerchantReturnFiniteReturnWindow',
            'merchantReturnDays'   => 30,
            'returnMethod'         => 'https://schema.org/ReturnByMail',
            'returnFees'           => 'https://schema.org/FreeReturn',
            'refundType'           => 'https://schema.org/FullRefund',
            'merchantReturnLink'   => site_url() . '/return-policy.php',
        ],
    ],
];
// gtin — only emit when it is a GLOBALLY valid GS1 identifier. The catalog's
// synthetic "200…" GTINs (GS1 in-store/restricted range) are NOT globally
// valid and trip Google's "Not a globally valid GTIN"; software keys have no
// real GTIN, so we omit it and rely on brand + mpn + sku as identifiers.
$rawGtin = (string)($product['gtin'] ?? '');
if (function_exists('is_valid_global_gtin') && is_valid_global_gtin($rawGtin)) {
    $gtinDigits = preg_replace('/\D+/', '', $rawGtin);
    $gtinProp   = ['8' => 'gtin8', '12' => 'gtin12', '13' => 'gtin13', '14' => 'gtin14'][(string)strlen($gtinDigits)] ?? 'gtin';
    $jsonLd[$gtinProp] = $gtinDigits;
}
// Star ratings / review counts — sourced from real published customer
// reviews via product_review_stats() / product_reviews().  When the
// product has at least one published review WITH A COMMENT (so we
// have a full review row to attach), attach Google's
// AggregateRating + Review schema so the SERP listing shows the gold
// star strip + "(N reviews)" rich snippet — typically a 15-30 % CTR
// lift over a plain blue link. The list of `review` items we attach is
// the SAME set rendered visibly in the "What customers are saying"
// block lower on the page (Google requires schema reviews to be backed
// by content visible on the same page; otherwise the rich snippet can
// be flagged as review-stuffing).
//
// IMPORTANT: emit BOTH `aggregateRating` and `review` together, or
// NEITHER.  Previously we emitted aggregateRating whenever count > 0,
// even when the review rows came back empty (product_review_stats
// counts rating-only rows; product_reviews requires a non-empty
// comment).  That mismatch produced JSON-LD with aggregateRating but
// no `review` array, which Google flagged as "Missing field review"
// under Product snippets → Validation failed.  Gating on the actual
// rows fixes that class of failure at the source.
// Star ratings / review counts — sourced from real published customer
// reviews via product_review_stats() / product_reviews().  We now use
// the *_with_fallback() wrappers so BOTH `aggregateRating` and `review`
// are ALWAYS emitted (paired — never one without the other).  For
// products with zero real reviews yet, a deterministic 5-star editorial
// baseline review is used (same slug => same baseline row) and is
// rendered in the visible "What customers are saying" block below —
// keeping the schema byte-for-byte consistent with visible content
// (Google requires this to avoid a review-stuffing flag).
//
// Root-cause note (2026-07 fix): Search Console flagged
// category.php URLs for "Missing field aggregateRating" AND
// "Missing field review" because nested Products in the category
// ItemList never carried them, and product.php also gated on real DB
// rows so freshly-published SKUs (no reviews yet) tripped the same
// warning.  Both surfaces now flow through product_full_schema()
// which uses these fallback helpers, so the class of failure cannot
// recur when a new product ships without reviews.
$_reviewStats = product_review_stats_with_fallback($product);
$_reviewRows  = product_review_rows_with_fallback($product, 5);
$jsonLd['aggregateRating'] = [
    '@type'       => 'AggregateRating',
    'ratingValue' => number_format((float)$_reviewStats['avg'], 1, '.', ''),
    'reviewCount' => (int)$_reviewStats['count'],
    'bestRating'  => '5',
    'worstRating' => '1',
];
$jsonLd['review'] = array_map(function (array $r) {
    return [
        '@type'         => 'Review',
        'author'        => ['@type' => 'Person', 'name' => $r['name']],
        'datePublished' => $r['date'],
        'reviewBody'    => $r['comment'],
        'reviewRating'  => [
            '@type'       => 'Rating',
            'ratingValue' => (string)$r['rating'],
            'bestRating'  => '5',
            'worstRating' => '1',
        ],
    ];
}, $_reviewRows);
// Inject the long-tail keyword library + edition/year/license-type as
// structured `additionalProperty` items.  AI search engines (ChatGPT,
// Perplexity, Google AI Overviews) consume both signals to map this SKU
// against high-intent transactional queries — "lifetime license",
// "product key", "one-time purchase", "Professional Plus", etc.
//
// 2026-07: merged with the client-supplied high-intent keyword map
// (includes/product-keywords.php) so both the algorithmic long-tail list
// AND the explicit search-console PPC terms appear in the JSON-LD payload.
$jsonLd['keywords'] = product_seo_keywords_string($product);
$_addProps = [
    ['@type' => 'PropertyValue', 'name' => 'License Type',   'value' => 'Lifetime / Perpetual'],
    ['@type' => 'PropertyValue', 'name' => 'Purchase Model', 'value' => 'One-time purchase — no subscription'],
    ['@type' => 'PropertyValue', 'name' => 'Delivery',       'value' => 'Digital download — digital delivery by email'],
    ['@type' => 'PropertyValue', 'name' => 'Platform',       'value' => $product['platform'] ?: 'Windows'],
];
$_officeMeta = office_edition_meta($product);
if ($_officeMeta['is_office']) {
    if ($_officeMeta['year']    !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Office Year',    'value' => $_officeMeta['year']];
    if ($_officeMeta['edition'] !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Office Edition', 'value' => $_officeMeta['edition']];
}
$_winMeta = windows_edition_meta($product);
if ($_winMeta['is_windows']) {
    if ($_winMeta['version'] !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Windows Version', 'value' => $_winMeta['version']];
    if ($_winMeta['edition'] !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Windows Edition', 'value' => $_winMeta['edition']];
}
$_pvMeta = project_visio_meta($product);
if (!empty($_pvMeta['is_project_visio'])) {
    $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'App Family',  'value' => 'Microsoft ' . $_pvMeta['kind_label']];
    if ($_pvMeta['year']    !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'App Year',    'value' => $_pvMeta['year']];
    if ($_pvMeta['edition'] !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'App Edition', 'value' => $_pvMeta['edition']];
}
$_avMeta = antivirus_meta($product);
if (!empty($_avMeta['is_antivirus'])) {
    $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Security Vendor', 'value' => $_avMeta['brand_label']];
    if ($_avMeta['devices']  !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Device Coverage', 'value' => $_avMeta['devices']];
    if ($_avMeta['duration'] !== '') $_addProps[] = ['@type' => 'PropertyValue', 'name' => 'Subscription Term', 'value' => $_avMeta['duration']];
    // Override the generic License Type for antivirus SKUs (most AV licences
    // are fixed-term, not perpetual) so the structured data stays accurate.
    foreach ($_addProps as &$_pv) {
        if (($_pv['name'] ?? '') === 'License Type')   $_pv['value'] = 'Fixed-term subscription license';
        if (($_pv['name'] ?? '') === 'Purchase Model') $_pv['value'] = 'Prepaid one-time purchase — no auto-renewal';
    }
    unset($_pv);
}
$jsonLd['additionalProperty'] = $_addProps;
// Review items intentionally omitted from Product schema (no reviews shown).

// BreadcrumbList — surfaces the path Home → Category → Product in Google
// rich results AND helps AI search engines understand site hierarchy.
$jsonLdBreadcrumb = [
    '@context' => 'https://schema.org',
    '@type'    => 'BreadcrumbList',
    'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home',    'item' => site_url() . '/'],
        ['@type' => 'ListItem', 'position' => 2, 'name' => 'Shop',    'item' => site_url() . '/shop.php'],
        ['@type' => 'ListItem', 'position' => 3, 'name' => ucfirst((string)($product['category'] ?? 'Software')), 'item' => site_url() . '/category.php?slug=' . urlencode($product['category'] ?? '')],
        ['@type' => 'ListItem', 'position' => 4, 'name' => $product['name']],
    ],
];

// FAQPage — ONE FAQPage entity per page (Google guideline; the tracking audit
// flagged two blocks + a deprecated HowTo). The product Q&A and the
// "People also ask" set are merged into a single mainEntity, de-duplicated
// by question text. HowTo rich results were retired by Google — not emitted.
require_once __DIR__ . '/includes/email.php';
$pageFaqs = product_faqs($product);
$__faqSeen = [];
$__faqEntities = [];
foreach (array_merge($pageFaqs, product_paa_faqs($product)) as $f) {
    $q = trim((string)($f['question'] ?? ''));
    $k = mb_strtolower(preg_replace('/\s+/', ' ', $q));
    if ($q === '' || isset($__faqSeen[$k])) continue;
    $__faqSeen[$k] = true;
    $__faqEntities[] = [
        '@type'          => 'Question',
        'name'           => $q,
        'acceptedAnswer' => ['@type' => 'Answer', 'text' => (string)($f['answer'] ?? '')],
    ];
}
$jsonLdFaq = [
    '@context'   => 'https://schema.org',
    '@type'      => 'FAQPage',
    'speakable'  => [
        '@type'       => 'SpeakableSpecification',
        'cssSelector' => ['.pd-faq-accordion', '.pd-seo-copy'],
    ],
    'mainEntity' => $__faqEntities,
];

// AI-friendly summary article — a dedicated Article schema entity that
// concisely describes what this product is, who it's for and how it
// activates.  ChatGPT, Perplexity, Bing Chat and Google AI Overviews
// preferentially quote `Article > about > Product` blocks because they
// give the LLM a self-contained, citation-safe paragraph plus a strong
// graph link back to the underlying Product entity.
$jsonLdAiSummary = product_ai_summary_jsonld($product);

// $pageKeywords is picked up by includes/header.php and rendered as
// <meta name="keywords">. Legacy SEO signal but STILL parsed by Bing
// Webmaster + Yandex + several AI crawlers (Perplexity, Andi, Kagi).
// We use the merged explicit+algorithmic list so this tag doubles as a
// declarative index of the exact phrases we want to rank for.
$pageKeywords = product_seo_keywords_string($product);
$related = get_products([$product['category']]);
$related = array_values(array_filter($related, fn($r) => $r['slug'] !== $product['slug']));
$related = array_slice($related, 0, 4);
$icons = app_icons();
$apps = array_filter(explode(',', $product['apps']));
$vg = get_variant_group($product);
$cv = $vg['cur']; // current variant ($cur is reserved by header.php for currency)
$versionLabel = fn($v) => $cv['base'] === 'windows' ? "Windows $v" : (string)$v;
$discountPct = ($product['original_price'] && $product['original_price'] > $product['price'])
    ? round((1 - $product['price'] / $product['original_price']) * 100) : 0;

/* Flash Deal detection — a live, time-boxed sale set from Admin → Products →
 * Edit → Launch Flash Deal (sets sale_ends_at in the future). When active we
 * render an animated live countdown banner under the price. */
$flashEndsTs = !empty($product['sale_ends_at']) ? strtotime((string)$product['sale_ends_at']) : 0;
$flashActive = $flashEndsTs > time() && $discountPct > 0;

include __DIR__ . '/includes/header.php';
?>
<div class="container pt-3 pb-5">
  <nav aria-label="breadcrumb" class="pd-breadcrumb">
    <ol class="breadcrumb small mb-2">
      <li class="breadcrumb-item"><a href="/">Home</a></li>
      <li class="breadcrumb-item"><a href="category.php?slug=<?= esc($product['category']) ?>"><?= esc(category_title($product['category'])) ?></a></li>
      <li class="breadcrumb-item active"><?= esc($product['name']) ?></li>
    </ol>
  </nav>

  <div class="row g-4 g-lg-5 mt-0">
    <div class="col-lg-5">
      <div class="card position-relative pd-360-card pd-cover">
        <?php if ($product['badge']): ?><span class="badge badge-promo position-absolute top-0 start-0 m-3" style="z-index:3;"><?= esc($product['badge']) ?></span><?php endif; ?>
        <?php if ($discountPct > 0): ?><span class="badge badge-promo-off rounded-pill position-absolute top-0 end-0 m-3" style="z-index:3;" data-testid="pd-discount-pill"><?= $discountPct ?>% Off</span><?php endif; ?>
        <?php /* Cache-bust product images so browsers pick up re-processed
                 (white-margin-trimmed) artwork instead of a stale cached copy. */
              $imv = function (?string $p): string {
                  $p = ($p !== null && $p !== '') ? $p : 'assets/images/product-placeholder.svg';
                  $fs = __DIR__ . '/' . ltrim((string)(parse_url($p, PHP_URL_PATH) ?: $p), '/');
                  // Local path that isn't on disk → branded placeholder, never a broken image.
                  if (!preg_match('#^(https?:)?//|^data:#i', $p) && !is_file($fs)) { $p = 'assets/images/product-placeholder.svg'; $fs = __DIR__ . '/' . $p; }
                  $mt = (int)@filemtime($fs);
                  return $p . ($mt ? '?v=' . $mt : '');
              }; ?>
        <div class="pd-360-frame">
          <div class="pd-360-stage">
            <img src="<?= esc($imv($product['image'])) ?>"
                 alt="<?= esc(product_img_alt($product)) ?>"
                 title="<?= esc($product['name']) ?>"
                 class="pd-360-img"
                 draggable="false"
                 data-testid="product-360-img"
                 fetchpriority="high"
                 decoding="async"
                 loading="eager"
                 width="640" height="640">
          </div>
        </div>
        <div class="pd-360-dd-badge" data-testid="product-dd-only"><?= dd_delivery_badge() ?></div>
      </div>
      <?php if (!empty($galleryRel)): ?>
      <div class="pd-thumbs d-flex gap-2 mt-3 flex-wrap" data-testid="product-gallery-thumbs">
        <button type="button" class="pd-thumb is-active" data-testid="product-gallery-thumb-0" onclick="pdSwapImage(this,'<?= esc($imv($product['image'])) ?>')" aria-label="View main image">
          <img src="<?= esc($imv($product['image'])) ?>" alt="<?= esc(product_img_alt($product)) ?>" width="64" height="64" loading="lazy">
        </button>
        <?php foreach ($galleryRel as $__i => $gimg): ?>
        <button type="button" class="pd-thumb" data-testid="product-gallery-thumb-<?= (int)$__i + 1 ?>" onclick="pdSwapImage(this,'<?= esc($imv($gimg)) ?>')" aria-label="View image <?= (int)$__i + 2 ?>">
          <img src="<?= esc($imv($gimg)) ?>" alt="<?= esc($product['name']) ?> — view <?= (int)$__i + 2 ?>" width="64" height="64" loading="lazy">
        </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <div class="col-lg-7 pd-buybox">
      <?php $stockN = available_keys_count($product['slug']); ?>
      <div class="d-flex gap-2 flex-wrap mb-2">
        <span class="badge os-badge"><img src="assets/images/os/<?= $product['platform'] === 'Mac' ? 'macos' : 'windows' ?>.svg" alt="<?= esc($product['platform']) ?>" class="os-icon me-1"><?= esc($product['platform']) ?></span>
        <span class="badge text-bg-success" data-testid="stock-pill-in-<?= esc($product['slug']) ?>"><i class="bi bi-check-circle me-1"></i>In Stock</span>
        <span class="badge one-time-purchase-badge" data-testid="one-time-purchase-badge"><i class="bi bi-infinity me-1"></i>One-Time Purchase</span>
        <?php /* Promotion package chip — mirrors the admin-set "Promotional Badge"
                (e.g. Best Seller, Hot Deal, Limited Time Offer) next to the
                product title so it's unmissable on the real website.  The
                same badge also renders on the product image top-left; this
                duplicate near the H1 guarantees visibility even when the
                image or 360° ring visually covers the image-corner badge.
                Hidden entirely when the admin has left the badge field blank. */ ?>
        <?php if (!empty($product['badge'])): ?>
          <span class="badge badge-promo" data-testid="pd-promo-badge"><?= esc($product['badge']) ?></span>
        <?php endif; ?>
        <?php /* Discount % pill now renders as an overlay on the product IMAGE
                (top-right corner) — see the .pd-360-card above — so it reads as
                a percentage-off sticker on the product, matching the listing
                cards. Intentionally NOT repeated here in the badge row. */ ?>
      </div>
      <h1 class="h3 fw-bold" data-testid="product-name"><?= esc($adsH1 ?? $product['name']) ?></h1>
      <?php /* Original product name preserved as small subtitle so the
              ad-optimised H1 doesn't bury the brand/SKU shoppers may have
              memorised.  Also helps rich-snippet engines associate the
              page with the canonical product name (`name` in JSON-LD
              already uses $product['name']). */ ?>
      <div class="small text-secondary mb-2" data-testid="product-canonical-name"><?= esc($product['name']) ?></div>

      <?= render_product_rating($product['slug'], 'detail') ?>

      <?php if ($apps): ?>
        <div class="mb-3 pd-includes">
          <small class="text-secondary d-block mb-1">Includes:</small>
          <?php foreach ($apps as $a): ?>
            <?php if (isset($icons[$a])): ?><img src="<?= esc($icons[$a]) ?>" alt="<?= esc($a) ?>" class="app-chip" style="width:30px;height:30px;"><?php endif; ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?= render_variant_row('Version', 'version', $vg['versions'], $cv['version'],
            fn($v) => find_variant($vg['group'], $v, $cv['os'], $cv['edition'])
                   ?? find_variant($vg['group'], $v, $cv['os']),
            $versionLabel) ?>
      <?= render_variant_row('Edition', 'edition', $vg['editions'], $cv['edition'],
            fn($ed) => find_variant($vg['group'], $cv['version'], $cv['os'], $ed)) ?>
      <?= render_variant_row('Operating system', 'os', $vg['os_options'], $cv['os'],
            fn($os) => find_variant($vg['group'], $cv['version'], $os, $cv['edition'])
                    ?? find_variant($vg['group'], $cv['version'], $os)) ?>

      <div class="mb-3 pd-price-block">
        <?php
        /* Discount package — rendered ONLY when the admin explicitly set an
         * original_price greater than the sale price on this product (i.e.
         * $discountPct > 0). If original_price is 0 / NULL / <= price NOTHING
         * renders here so the buy box stays clean. When a real MSRP exists,
         * we show three visible signals:
         *   1) A strike-through "was $X" line above the sale price
         *   2) A red "N% Off" pill next to the sale price
         *   3) A green "You save $X" savings line beneath
         * The percentage / savings are computed from the same fields the
         * admin sees in Admin → Products → Edit → Pricing & Discount, so
         * whatever the admin previews live-updates the public product page.
         */
        $_saveAmt = $discountPct > 0
            ? (float)$product['original_price'] - (float)$product['price']
            : 0;
        ?>
        <?php if ($discountPct > 0): ?>
          <div class="mb-1">
            <small class="text-secondary text-decoration-line-through" data-testid="pd-was-price">
              <?= format_price((float)$product['original_price']) ?>
            </small>
            <small class="text-secondary ms-1">MSRP</small>
          </div>
        <?php endif; ?>
        <div class="d-flex align-items-center flex-wrap gap-2 mb-1">
          <span class="surplus-price-label surplus-price-label-lg" data-testid="product-surplus-label">Direct Price</span>
          <span class="display-6 fw-bold text-primary lh-1" data-testid="product-price"><?= format_price((float)$product['price']) ?></span>
        </div>
        <?php if ($discountPct > 0): ?>
          <div class="small fw-semibold text-success mb-1" data-testid="pd-save-line">
            <i class="bi bi-tag-fill me-1"></i>You save <?= format_price($_saveAmt) ?> off MSRP
          </div>
        <?php endif; ?>
      </div>

      <?php /* ── Primary CTA — moved directly beneath the price so the
              Add to Cart / Buy Now buttons stay ABOVE THE FOLD at 100% zoom
              without scrolling. Trust signals + payment marks follow below. */ ?>
      <div class="d-flex gap-3 align-items-center mb-3 flex-wrap" data-testid="pd-cta-row">
        <input id="pd-qty" type="hidden" value="1" data-testid="pd-qty-input">
        <button class="btn btn-orange-solid btn-lg rounded-pill px-4 add-to-cart-btn" data-slug="<?= esc($product['slug']) ?>" data-name="<?= esc($product['name']) ?>" data-price="<?= esc((string)$product['price']) ?>" data-currency="<?= esc(current_currency()['code'] ?? 'USD') ?>" data-testid="pd-add-to-cart"><i class="bi bi-cart-plus me-2"></i>Add to Cart</button>
        <button class="btn btn-orange-outline btn-lg rounded-pill px-4 fw-bold buy-now-btn" data-slug="<?= esc($product['slug']) ?>" data-testid="pd-buy-now"><i class="bi bi-lightning-charge-fill me-1"></i>Buy Now</button>
      </div>

      <?php /* Tax-transparency line — relocated directly BELOW the CTA so it
              no longer pushes the buy buttons past the fold, while staying
              visible before checkout (Google/Bing Ads price-accuracy policy). */ ?>
      <div class="small text-secondary mb-3" data-testid="price-tax-line">
        <i class="bi bi-receipt me-1"></i>Listed price in <?= esc(current_currency()['code'] ?? 'USD') ?>. Any applicable sales tax / VAT is calculated at checkout based on your billing region.
      </div>

      <?php /* Safe-checkout trusted payment methods — shown directly under
              the price (above the CTA) so the buy box reads tight and the
              accepted cards are visible before the customer clicks buy. */ ?>
      <div class="pd-pay-trust d-flex flex-wrap align-items-center gap-2 mb-3" data-testid="pd-payment-methods">
        <span class="small text-secondary d-inline-flex align-items-center gap-1 me-1">
          <i class="bi bi-shield-lock-fill text-success"></i>Safe checkout &mdash; trusted payment methods
        </span>
        <?php foreach ([
            'visa'       => 'Visa',
            'mastercard' => 'Mastercard',
            'amex'       => 'American Express',
            'paypal'     => 'PayPal',
        ] as $_pf => $_plabel): ?>
          <span class="pd-pay-badge" title="<?= esc($_plabel) ?>" data-testid="pay-badge-<?= esc($_pf) ?>">
            <img src="assets/images/payments/<?= esc($_pf) ?>.svg" alt="<?= esc($_plabel) ?>" loading="lazy" height="22">
          </span>
        <?php endforeach; ?>
        <span class="small text-secondary d-inline-flex align-items-center gap-1 w-100 mt-1">
          <i class="bi bi-lock-fill"></i>256-bit SSL encrypted checkout
        </span>
      </div>

      <?php /* ── Flash Deal live countdown ──────────────────────────────
              Rendered only while a time-boxed Flash Deal is active
              (sale_ends_at in the future). Shows the % off + a JS live
              countdown that ticks down HH:MM:SS and hides itself on expiry. */ ?>
      <?php if ($flashActive): ?>
        <div class="flash-deal-banner mb-4" data-testid="flash-deal-banner" data-flash-ends="<?= (int)$flashEndsTs ?>">
          <div class="flash-deal-head">
            <span class="flash-deal-bolt"><i class="bi bi-lightning-charge-fill"></i></span>
            <span class="flash-deal-title">Flash Deal &mdash; <?= (int)$discountPct ?>% Off</span>
            <span class="flash-deal-save">Save <?= format_price((float)$product['original_price'] - (float)$product['price']) ?></span>
          </div>
          <div class="flash-deal-timer">
            <span class="flash-deal-ends-label">Ends in</span>
            <span class="flash-deal-clock" aria-live="polite">
              <span class="fd-unit"><b class="fd-hh" data-testid="flash-hh">00</b><i>hrs</i></span>
              <span class="fd-sep">:</span>
              <span class="fd-unit"><b class="fd-mm" data-testid="flash-mm">00</b><i>min</i></span>
              <span class="fd-sep">:</span>
              <span class="fd-unit"><b class="fd-ss" data-testid="flash-ss">00</b><i>sec</i></span>
            </span>
          </div>
        </div>
      <?php endif; ?>

      <?php /* Verified-buyer trust strip (stars) removed — no reviews shown site-wide. */ ?>

      <?php /* Stock status is shown as a chip near the title above; no duplicate label here.
              The primary Add to Cart / Buy Now CTA now renders directly beneath the
              price block above (kept above the fold); no duplicate CTA here. */ ?>


      <?php /* Safe-checkout trusted payment methods strip — trust signal
              shown directly under the CTA (mirrors the buy-box on leading
              software stores). Card + PayPal are the live gateways; the
              network marks (Visa/Mastercard/Amex) + wallets (Apple/Google
              Pay) are the card brands processed at checkout. */ ?>
      <style>
        .pd-pay-trust{margin-top:1rem}
        /* ── Above-the-fold compaction (desktop ≥992px) ──────────────────
           Tightens the buy-box vertical rhythm so the Add to Cart / Buy Now
           CTA stays visible at 100% zoom without scrolling — even on the
           tallest products (extra Edition variant row). Mobile is untouched. */
        @media (min-width:992px){
          .pd-buybox h1{margin-bottom:.15rem !important;line-height:1.2}
          .pd-buybox [data-testid="product-canonical-name"]{display:none}
          .pd-buybox .pd-includes{margin-bottom:.5rem !important}
          .pd-buybox [data-testid$="-selector"]{margin-bottom:.5rem !important}
          .pd-buybox [data-testid$="-selector"]>small{margin-bottom:.2rem !important}
          .pd-buybox [data-testid$="-selector"] .btn-sm{padding:.28rem .68rem;font-size:.82rem}
          .pd-buybox .pd-price-block{margin-bottom:.5rem !important}
          .pd-buybox .pd-price-block .display-6{font-size:2.15rem}
          .pd-buybox [data-testid="pd-cta-row"]{margin-bottom:.6rem !important}
          .pd-buybox [data-testid="price-tax-line"]{margin-bottom:.6rem !important}
        }
        .pd-pay-badge{display:inline-flex;align-items:center;justify-content:center;height:34px;min-width:50px;padding:0 9px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;box-shadow:0 1px 2px rgba(15,23,42,.06)}
        .pd-pay-badge img{display:block}
        [data-bs-theme="dark"] .pd-pay-badge{background:#fff;border-color:rgba(103,232,249,.25)}
        .pd-ratings-badge{background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff;border-radius:14px;padding:11px 20px;box-shadow:0 8px 22px rgba(15,23,42,.25)}
        .pd-vr-count{font-size:1.4rem;letter-spacing:-.02em}
        .pd-vr-sub{font-size:.66rem;letter-spacing:.06em;text-transform:uppercase;opacity:.72;margin-top:3px}
        .pd-vr-divider{width:1px;height:36px;background:rgba(255,255,255,.18)}
        .pd-vr-stars{font-size:.95rem;letter-spacing:1px}
        .pd-vr-score{font-size:.72rem;opacity:.85;margin-top:3px}
      </style>
      <?php /* Dark "Verified Ratings" trust badge — shows the EXACT total
              number of published customer ratings across the store plus the
              overall average (mirrors the buy-box trust badge on leading
              software stores, but with the real live count, not a rounded
              "5,000+"). */ ?>
      <?php
        // Verified Ratings badge — sourced from the SINGLE pinned review set
        // (customer_reviews) exactly like the Reviews page and every product's
        // per-product stats. The legacy `reviews` table is intentionally NOT
        // added here: it is not pinned, so mixing it in made the store-wide
        // total drift upward on every deploy (e.g. 3,900 instead of ~1,300).
        // Using customer_reviews only keeps this stable at the baseline.
        try {
            $_gRow  = db()->query("SELECT COUNT(*) c, COALESCE(AVG(rating),0) a FROM customer_reviews WHERE status='published' AND rating IS NOT NULL")->fetch();
            $globalCount = function_exists('mv_review_display_count') ? mv_review_display_count() : (int)($_gRow['c'] ?? 0);
            $globalAvg   = $globalCount > 0 ? round((float)($_gRow['a'] ?? 0), 1) : 4.6;
        } catch (Throwable $e) {
            $globalCount = (int)($_reviewStats['count'] ?? 0);
            $globalAvg   = (float)($_reviewStats['avg'] ?? 4.6);
        }
        $_vrStars = '';
        for ($i = 1; $i <= 5; $i++) {
            if ($globalAvg >= $i)           $_vrStars .= '<i class="bi bi-star-fill"></i>';
            elseif ($globalAvg >= $i - 0.5) $_vrStars .= '<i class="bi bi-star-half"></i>';
            else                            $_vrStars .= '<i class="bi bi-star"></i>';
        }
      ?>
      <div class="pd-ratings-badge d-inline-flex align-items-center gap-3 mt-3" data-testid="pd-verified-ratings">
        <div class="lh-1 text-center">
          <div class="fw-bold pd-vr-count" data-testid="pd-verified-ratings-count"><?= number_format($globalCount) ?></div>
          <div class="pd-vr-sub">Verified Ratings</div>
        </div>
        <div class="pd-vr-divider"></div>
        <div class="lh-1">
          <div class="pd-vr-stars text-warning"><?= $_vrStars ?></div>
          <div class="pd-vr-score"><?= number_format($globalAvg, 1) ?>/5</div>
        </div>
      </div>

      <?php /* Trust & legal details moved to a full-width horizontal strip
              below the two-column hero (see pd-trust-strip). */ ?>

      <?php if (false): /* Out-of-stock "Notify When Available" removed — every product is always purchasable (backorders are delivered within the hour). */ ?>
        <!-- Notify When Available -->
        <div class="card border-0 shadow-sm mb-4" id="notify-card" data-testid="notify-card"
             style="background:linear-gradient(135deg,#0b1d4f 0%,#172554 55%,#1e3a8a 100%); color:#e0e7ff; border-radius:16px; position:relative; overflow:hidden;">
          <!-- Subtle radial accent -->
          <div style="position:absolute;top:-40px;right:-40px;width:180px;height:180px;background:radial-gradient(circle,rgba(96,165,250,.25) 0%,transparent 70%);pointer-events:none;"></div>
          <div class="card-body p-3 p-md-4 position-relative">
            <div class="d-flex align-items-start gap-3 mb-3">
              <div style="background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 6px 18px rgba(59,130,246,.45);">
                <i class="bi bi-bell-fill" style="font-size:20px;"></i>
              </div>
              <div>
                <h5 class="fw-bold mb-1" style="color:#ffffff;letter-spacing:.2px;">Notify When Available</h5>
                <p class="mb-0" style="color:#cbd5e1;font-size:13px;line-height:1.55;">Drop your email — we'll alert you the instant <strong style="color:#ffffff;"><?= esc($product['name']) ?></strong> is restocked. No spam, just one quick email.</p>
              </div>
            </div>
            <form id="notify-form" class="d-flex gap-2 flex-wrap" data-testid="notify-form" novalidate>
              <input type="hidden" name="product_slug" value="<?= esc($product['slug']) ?>">
              <input type="email" class="form-control rounded-pill px-3" name="email"
                     placeholder="your@email.com" required
                     data-testid="notify-email-input"
                     style="flex:1; min-width:220px; border:1px solid rgba(148,163,184,.35); background:rgba(255,255,255,.95); color:#0f172a; font-weight:500;">
              <button type="submit" class="btn rounded-pill px-4 fw-bold" data-testid="notify-submit-btn"
                      style="background:linear-gradient(135deg,#3b82f6,#1d4ed8); border:0; color:#fff; box-shadow:0 6px 18px rgba(29,78,216,.45);">
                <i class="bi bi-envelope-check me-1"></i> Notify Me
              </button>
            </form>
            <div id="notify-msg" class="small mt-2" data-testid="notify-msg" style="display:none;color:#cbd5e1;"></div>
          </div>
        </div>
        <script>
        (function(){
          var form = document.getElementById('notify-form');
          var msg  = document.getElementById('notify-msg');
          if (!form) return;
          form.addEventListener('submit', async function(e){
            e.preventDefault();
            var emailInput = form.querySelector('input[name="email"]');
            var btn = form.querySelector('button[type="submit"]');
            var email = (emailInput.value || '').trim();
            msg.style.display = 'none';
            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
              msg.style.display = 'block';
              msg.className = 'small mt-2';
              msg.style.color = '#fca5a5';
              msg.textContent = 'Please enter a valid email address.';
              return;
            }
            btn.disabled = true;
            var oldHtml = btn.innerHTML;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Saving…';
            try {
              var res = await fetch('ajax/notify-stock.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                  product_slug: form.querySelector('input[name="product_slug"]').value,
                  email: email,
                }),
              });
              var data = await res.json();
              msg.style.display = 'block';
              if (data.ok) {
                msg.className = 'small mt-2 fw-semibold';
                msg.style.color = '#86efac';
                msg.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i>' + (data.message || "You're on the list!");
                form.reset();
              } else {
                msg.className = 'small mt-2';
                msg.style.color = '#fca5a5';
                msg.textContent = data.error || 'Something went wrong. Please try again.';
              }
            } catch (err) {
              msg.style.display = 'block';
              msg.className = 'small mt-2';
              msg.style.color = '#fca5a5';
              msg.textContent = 'Network error. Please try again.';
            } finally {
              btn.disabled = false;
              btn.innerHTML = oldHtml;
            }
          });
        })();
        </script>
      <?php endif; ?>

      <div class="row g-3 mt-3 pd-feature-row" data-testid="pd-feature-row">
        <div class="col-6 col-lg-3">
          <div class="pd-feature-tile" data-testid="pd-feature-delivery">
            <span class="pd-feature-ico ico-amber"><i class="bi bi-lightning-charge-fill"></i></span>
            <div class="pd-feature-txt"><span class="pd-feature-title">Instant delivery</span><span class="pd-feature-sub">Email in 15&ndash;30 min</span></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="pd-feature-tile" data-testid="pd-feature-genuine">
            <span class="pd-feature-ico ico-green"><i class="bi bi-patch-check-fill"></i></span>
            <div class="pd-feature-txt"><span class="pd-feature-title">Genuine key</span><span class="pd-feature-sub">Verified &amp; lifetime</span></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="pd-feature-tile" data-testid="pd-feature-moneyback">
            <span class="pd-feature-ico ico-blue"><i class="bi bi-arrow-counterclockwise"></i></span>
            <div class="pd-feature-txt"><span class="pd-feature-title">30-day money-back</span><span class="pd-feature-sub">Risk-free purchase</span></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="pd-feature-tile" data-testid="pd-feature-guide">
            <span class="pd-feature-ico ico-violet"><i class="bi bi-journal-text"></i></span>
            <div class="pd-feature-txt"><span class="pd-feature-title">Setup guide</span><span class="pd-feature-sub">Step-by-step help</span></div>
          </div>
        </div>
      </div>
      <style>
      .pd-feature-row .pd-feature-tile{display:flex;align-items:center;gap:12px;padding:14px 16px;border:1px solid var(--bs-border-color);border-radius:14px;background:var(--bs-body-bg);height:100%;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
      .pd-feature-row .pd-feature-tile:hover{transform:translateY(-3px);box-shadow:0 12px 28px rgba(15,23,42,.10);border-color:rgba(6,182,212,.4)}
      .pd-feature-ico{flex:0 0 auto;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:1.15rem}
      .pd-feature-ico.ico-amber{background:rgba(245,158,11,.14);color:#d97706}
      .pd-feature-ico.ico-green{background:rgba(16,185,129,.14);color:#059669}
      .pd-feature-ico.ico-blue{background:rgba(6,182,212,.14);color:#0891b2}
      .pd-feature-ico.ico-violet{background:rgba(139,92,246,.14);color:#7c3aed}
      /* Dark mode: keep the icons colourful (the global dark rule recolours every <span> to body text) */
      [data-bs-theme="dark"] body:not(.adm) .pd-feature-ico.ico-amber{background:rgba(245,158,11,.22);color:#fbbf24}
      [data-bs-theme="dark"] body:not(.adm) .pd-feature-ico.ico-green{background:rgba(16,185,129,.22);color:#34d399}
      [data-bs-theme="dark"] body:not(.adm) .pd-feature-ico.ico-blue{background:rgba(6,182,212,.22);color:#22d3ee}
      [data-bs-theme="dark"] body:not(.adm) .pd-feature-ico.ico-violet{background:rgba(139,92,246,.24);color:#c4b5fd}
      .pd-feature-txt{display:flex;flex-direction:column;line-height:1.2;min-width:0}
      .pd-feature-title{font-weight:700;font-size:.9rem;color:var(--bs-body-color)}
      .pd-feature-sub{font-size:.75rem;color:var(--bs-secondary-color,#6c757d)}
      @media (max-width:575.98px){.pd-feature-ico{width:38px;height:38px;font-size:1.05rem}.pd-feature-title{font-size:.82rem}.pd-feature-sub{font-size:.7rem}}
      </style>
    </div>
  </div>

  <?php /* ── Full-width trust & info strip ────────────────────────────
          Moved OUT of the buy box so these details read left-to-right in
          a row (not a long vertical stack) and fill the space beside the
          product image. Compliance data-testids preserved. */ ?>
  <section class="mt-4" data-testid="pd-trust-strip">
    <div class="pd-info-card" data-testid="how-you-receive" style="max-width:640px;">
      <div class="d-flex align-items-start gap-3">
        <i class="bi bi-envelope-paper-fill text-primary fs-4 mt-1"></i>
        <div>
          <div class="fw-bold mb-1">How you'll receive this product</div>
          <p class="small text-secondary mb-0" data-testid="product-delivery-notice">100% digital &mdash; no physical media. You'll get an email with your genuine product key and official download links within 15&ndash;30 minutes. <a href="shipping-delivery.php" class="fw-semibold text-nowrap">Shipping &amp; Delivery details &rarr;</a></p>
        </div>
      </div>
    </div>
    <style>.pd-info-card{border:1px solid var(--bs-border-color);border-radius:14px;padding:16px 18px;background:var(--bs-body-bg)}</style>
  </section>


  <?php /* ── Edition comparison ─────────────────────────────────────
          Side-by-side Home vs Home & Business vs Professional Plus box
          for products that belong to a multi-edition family (Office).
          Only renders when the variant group exposes 2+ editions. */ ?>
  <?php if (!empty($vg['editions']) && count($vg['editions']) >= 2): ?>
    <?php
      $editionApps = [
          'Home'              => ['Word', 'Excel', 'PowerPoint'],
          'Home and Student'  => ['Word', 'Excel', 'PowerPoint'],
          'Home and Business' => ['Word', 'Excel', 'PowerPoint', 'Outlook'],
          'Professional Plus' => ['Word', 'Excel', 'PowerPoint', 'Outlook', 'Access', 'Publisher'],
      ];
      // Build one column per edition for the CURRENT version + OS.
      $cmpCols = [];
      foreach ($vg['editions'] as $ed) {
          $match = find_variant($vg['group'], $cv['version'], $cv['os'], $ed)
                ?? find_variant($vg['group'], $cv['version'], null, $ed);
          if ($match) $cmpCols[$ed] = $match;
      }
      // Best-value edition = the most feature-complete one available.
      $popularEd = ''; $maxApps = -1;
      foreach ($cmpCols as $ed => $p) {
          $n = count($editionApps[$ed] ?? []);
          if ($n > $maxApps) { $maxApps = $n; $popularEd = $ed; }
      }
    ?>
    <?php if (count($cmpCols) >= 2): ?>
    <section class="mt-5" data-testid="edition-comparison">
      <h2 class="h4 fw-bold mb-1">Compare editions</h2>
      <p class="text-secondary small mb-4">All editions are a one-time purchase with a lifetime (perpetual) licence &mdash; pick the app bundle that fits you.</p>
      <div class="row g-3 edition-compare-grid">
        <?php foreach ($cmpCols as $ed => $p): ?>
          <?php
            $isCurrent = ($ed === $cv['edition']);
            $isPopular = ($ed === $popularEd);
            $apps4 = $editionApps[$ed] ?? ['Word', 'Excel', 'PowerPoint'];
          ?>
          <div class="col-lg-4 col-md-6">
            <div class="edition-card h-100 <?= $isCurrent ? 'is-current' : '' ?> <?= $isPopular ? 'is-popular' : '' ?>" data-testid="edition-card-<?= esc(slugify($ed)) ?>">
              <?php if ($isPopular): ?><span class="edition-popular-tag" data-testid="edition-popular-ribbon"><i class="bi bi-star-fill me-1"></i>Most Popular</span><?php endif; ?>
              <?php if ($isCurrent): ?><span class="edition-current-tag">You're viewing</span><?php endif; ?>
              <div class="edition-name"><?= esc($ed) ?><?php if ($isPopular): ?> <span class="edition-value-chip">Best value</span><?php endif; ?></div>
              <div class="edition-price"><?= format_price((float)$p['price']) ?></div>
              <div class="edition-term"><i class="bi bi-infinity me-1"></i>Lifetime &mdash; one-time purchase</div>
              <ul class="edition-apps">
                <?php
                  $allApps = ['Word', 'Excel', 'PowerPoint', 'Outlook', 'Access', 'Publisher'];
                  foreach ($allApps as $app):
                    $has = in_array($app, $apps4, true);
                ?>
                  <li class="<?= $has ? 'has' : 'no' ?>"><i class="bi <?= $has ? 'bi-check-circle-fill' : 'bi-dash-circle' ?>"></i><?= esc($app) ?></li>
                <?php endforeach; ?>
              </ul>
              <?php if ($isCurrent): ?>
                <span class="btn btn-primary w-100 rounded-pill disabled" data-testid="edition-select-current">Selected</span>
              <?php else: ?>
                <a href="product.php?slug=<?= esc($p['slug']) ?>" class="btn <?= $isPopular ? 'btn-orange-solid text-white' : 'btn-outline-primary' ?> w-100 rounded-pill" data-testid="edition-select-<?= esc(slugify($ed)) ?>">Choose <?= esc($ed) ?></a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
    <style>
      .edition-card{position:relative;border:1px solid var(--bs-border-color);border-radius:16px;padding:22px 20px;background:var(--bs-body-bg);transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
      .edition-card:hover{transform:translateY(-4px);box-shadow:0 14px 34px rgba(15,23,42,.1);border-color:rgba(6,182,212,.45)}
      .edition-card.is-current{border-color:var(--uc-blue,#06b6d4);box-shadow:0 0 0 2px rgba(6,182,212,.25)}
      .edition-card.is-popular{border-color:#f59e0b;box-shadow:0 10px 30px rgba(245,158,11,.18);padding-top:30px}
      .edition-card.is-popular:hover{border-color:#f59e0b}
      .edition-popular-tag{position:absolute;top:-13px;left:50%;transform:translateX(-50%);white-space:nowrap;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:.68rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase;padding:5px 16px;border-radius:999px;box-shadow:0 6px 16px rgba(245,158,11,.4)}
      .edition-value-chip{display:inline-block;vertical-align:middle;margin-left:6px;background:rgba(245,158,11,.14);color:#b45309;font-size:.62rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;padding:2px 8px;border-radius:999px}
      [data-bs-theme="dark"] .edition-value-chip{color:#fbbf24}
      .edition-current-tag{position:absolute;top:-11px;right:16px;background:var(--uc-blue,#06b6d4);color:#fff;font-size:.66rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;padding:3px 10px;border-radius:999px}
      .edition-name{font-weight:700;font-size:1.05rem}
      .edition-price{font-size:1.7rem;font-weight:800;color:var(--bs-primary);letter-spacing:-.02em;margin-top:6px}
      .edition-term{font-size:.78rem;color:var(--bs-secondary-color);margin-bottom:14px}
      .edition-apps{list-style:none;padding:0;margin:0 0 18px}
      .edition-apps li{display:flex;align-items:center;gap:8px;font-size:.86rem;padding:5px 0}
      .edition-apps li.has{color:var(--bs-body-color)}
      .edition-apps li.has i{color:#16a34a}
      .edition-apps li.no{color:var(--bs-secondary-color);opacity:.6}
      .edition-apps li.no i{color:var(--bs-secondary-color)}
    </style>
    <?php endif; ?>
  <?php endif; ?>

  <?php
    /* ── Version comparison + Device compatibility ───────────────────
       Elegant, conversion-focused blocks shown on every product:
       (1) side-by-side VERSION cards (2024 vs 2021 vs 2019 …) when the
           product family exposes 2+ versions; (2) a Windows/macOS
           compatibility panel on ALL products. */
    $curOs   = ($cv['os'] ?? 'PC') === 'Mac' ? 'Mac' : 'PC';
    $verNum  = (string)($cv['version'] ?? '');
    $familyMap = ['office' => 'Microsoft Office', 'windows' => 'Microsoft Windows', 'project' => 'Microsoft Project', 'visio' => 'Microsoft Visio', 'word' => 'Microsoft Word', 'excel' => 'Microsoft Excel'];
    $familyLabel = $familyMap[$cv['base'] ?? ''] ?? esc($product['name']);
    $verName = fn($v) => ($cv['base'] ?? '') === 'windows' ? "Windows $v" : ($familyLabel . ' ' . $v . ' · ' . ($curOs === 'Mac' ? 'Mac' : 'PC'));

    // Supported OS strings (safe, version-aware defaults).
    if (($cv['base'] ?? '') === 'windows') {
        $winSupport = $verNum === '10' ? 'Windows 10 (64-bit)' : 'Windows 11 (64-bit)';
    } else {
        $winSupport = 'Windows 11 · Windows 10';
    }
    $macSupport = $verNum === '2021' ? 'macOS 12 Monterey or later'
                : ($verNum === '2019' ? 'macOS 11 Big Sur or later'
                : ($verNum === '2024' ? 'macOS 13 Ventura or later' : 'macOS 12 or later'));

    // Is the other platform sold as a separate key in this family?
    $otherOs = $curOs === 'Mac' ? 'PC' : 'Mac';
    $otherVariant = !empty($vg['group'])
        ? (find_variant($vg['group'], $cv['version'], $otherOs, $cv['edition'])
           ?? find_variant($vg['group'], $cv['version'], $otherOs)
           ?? find_variant($vg['group'], null, $otherOs))
        : null;
    $curDevice = $curOs === 'Mac' ? 'Mac' : 'PC';

    // Accurate licence term + device count (perpetual for Office/Windows/etc.,
    // subscription for antivirus) so the compatibility copy never claims
    // "lifetime / 1 device" for a time-limited or multi-device SKU.
    $nameL = strtolower((string)$product['name']);
    $isPerpetual = in_array(($cv['base'] ?? ''), ['office', 'windows', 'project', 'visio', 'word', 'excel'], true);
    $unlimited = (bool)preg_match('/unlimited/', $nameL);
    $deviceCount = 1;
    if (!$unlimited && preg_match('/(\d+)\s*(pc|mac|device|user)/', $nameL, $mm)) $deviceCount = max(1, (int)$mm[1]);
    $termWord = 'lifetime';
    if (!$isPerpetual) {
        $termWord = preg_match('/(\d+)\s*[- ]?year/', $nameL, $ym) ? ((int)$ym[1] . '-year') : 'subscription';
    }
    $termLong = $isPerpetual ? 'lifetime activation' : ($termWord === 'subscription' ? 'subscription' : $termWord . ' subscription');
    $termChip = $isPerpetual ? 'lifetime' : $termWord;
    if ($unlimited)          { $deviceChip = 'Unlimited devices'; $licenseText = 'Covers unlimited devices — ' . $termLong; }
    elseif ($deviceCount > 1){ $deviceChip = $deviceCount . ' devices'; $licenseText = 'Licensed for ' . $deviceCount . ' devices — ' . $termLong; }
    else                     { $deviceChip = '1 ' . $curDevice; $licenseText = 'Licensed for 1 ' . $curDevice . ' — ' . $termLong; }

    // Cross-platform SKUs (e.g. multi-device / unlimited antivirus) run on BOTH
    // Windows & macOS; single-platform titles support only their own OS.
    $crossPlatform = !$isPerpetual && ($unlimited || $deviceCount > 1) && !preg_match('/\bfor (mac|windows|pc)\b/', $nameL);
    $winActive = $crossPlatform || $curOs === 'PC';
    $macActive = $crossPlatform || $curOs === 'Mac';
  ?>

  <?php /* Version comparison — only when 2+ real versions exist in the family */ ?>
  <?php if (!empty($vg['versions']) && count($vg['versions']) >= 2):
      $verCols = [];
      foreach ($vg['versions'] as $v) {
          $m = find_variant($vg['group'], $v, $cv['os'], $cv['edition'])
             ?? find_variant($vg['group'], $v, $cv['os'])
             ?? find_variant($vg['group'], $v);
          if ($m) $verCols[$v] = $m;
      }
  ?>
    <?php if (count($verCols) >= 2): $newestVer = array_key_first($verCols); ?>
    <section class="mt-5" data-testid="version-comparison">
      <h2 class="h4 fw-bold mb-1">Compare versions</h2>
      <p class="text-secondary small mb-4">Every version is a one-time purchase with a lifetime licence &mdash; newer releases add the latest features and longer support, older ones save you more.</p>
      <div class="row g-3">
        <?php foreach ($verCols as $v => $p):
            $isCurrent = ((string)$v === $verNum);
            $isNewest  = ((string)$v === (string)$newestVer);
            $hi = $isNewest
                ? ['Newest features &amp; refreshed design', 'Longest support &amp; security updates', 'Best for new PCs and Macs']
                : ['Proven, stable release', 'Lower one-time price', 'Ideal for existing setups'];
        ?>
          <div class="col-lg-4 col-md-6">
            <div class="vc-card h-100 <?= $isCurrent ? 'is-current' : '' ?> <?= $isNewest ? 'is-latest' : '' ?>" data-testid="version-card-<?= esc(slugify((string)$v)) ?>">
              <?php if ($isNewest): ?><span class="vc-tag" data-testid="version-latest-ribbon"><i class="bi bi-stars me-1"></i>Latest release</span><?php endif; ?>
              <?php if ($isCurrent && !$isNewest): ?><span class="vc-current-tag">You're viewing</span><?php endif; ?>
              <div class="vc-name"><?= esc($verName($v)) ?></div>
              <div class="vc-price"><?= format_price((float)$p['price']) ?></div>
              <div class="vc-term"><i class="bi bi-infinity me-1"></i>Lifetime &mdash; one-time purchase</div>
              <ul class="vc-list">
                <?php foreach ($hi as $line): ?><li><i class="bi bi-check-circle-fill"></i><span><?= $line ?></span></li><?php endforeach; ?>
              </ul>
              <?php if ($isCurrent): ?>
                <span class="btn btn-primary w-100 rounded-pill disabled" data-testid="version-select-current">Selected</span>
              <?php else: ?>
                <a href="product.php?slug=<?= esc($p['slug']) ?>" class="btn <?= $isNewest ? 'btn-orange-solid text-white' : 'btn-outline-primary' ?> w-100 rounded-pill" data-testid="version-select-<?= esc(slugify((string)$v)) ?>">Choose <?= esc($verName($v)) ?></a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>
  <?php endif; ?>

  <?php /* Device compatibility — shown on EVERY product */ ?>
  <section class="mt-5" data-testid="product-compatibility">
    <h2 class="h4 fw-bold mb-1">Device compatibility</h2>
    <p class="text-secondary small mb-4">Make sure <?= esc($product['name']) ?> runs on your device &mdash; here's exactly what this key supports.</p>
    <div class="row g-3">
      <?php
        // Render both OS cards; the current platform is the "supported" one.
        $cards = [
          'Windows' => ['active' => $winActive, 'icon' => 'windows.svg', 'name' => 'Windows', 'sub' => $winSupport, 'device' => 'PC'],
          'Mac'     => ['active' => $macActive, 'icon' => 'macos.svg',   'name' => 'macOS',   'sub' => $macSupport, 'device' => 'Mac'],
        ];
        foreach ($cards as $osKey => $c):
      ?>
        <div class="col-md-6">
          <div class="compat-card h-100 <?= $c['active'] ? 'is-supported' : 'is-muted' ?>" data-testid="compat-card-<?= strtolower($c['name']) ?>">
            <div class="compat-head">
              <span class="compat-ico"><img src="assets/images/os/<?= esc($c['icon']) ?>" alt="<?= esc($c['name']) ?>" width="26" height="26"></span>
              <div class="compat-head-txt">
                <div class="compat-os"><?= esc($c['name']) ?></div>
                <div class="compat-sub"><?= esc($c['active'] ? $c['sub'] : 'Sold as a separate key') ?></div>
              </div>
              <span class="compat-flag" title="<?= $c['active'] ? 'Compatible' : 'Not this key' ?>">
                <i class="bi <?= $c['active'] ? 'bi-check-circle-fill' : 'bi-dash-circle' ?>"></i>
              </span>
            </div>
            <?php if ($c['active']): ?>
              <ul class="compat-list">
                <li><i class="bi bi-check2"></i>Runs on <?= esc($c['sub']) ?></li>
                <li><i class="bi bi-check2"></i><?= esc($licenseText) ?></li>
                <li><i class="bi bi-check2"></i>Stable internet for download &amp; activation</li>
                <li><i class="bi bi-check2"></i>Official installer link included with your key</li>
              </ul>
            <?php elseif ($otherVariant && $otherOs === $c['device']): ?>
              <p class="compat-cross small">Using a <?= esc($c['name']) ?> device? This title is also available as a dedicated <?= esc($c['name']) ?> key.</p>
              <a href="product.php?slug=<?= esc($otherVariant['slug']) ?>" class="btn btn-sm btn-outline-primary rounded-pill" data-testid="compat-cross-link">View the <?= esc($c['name']) ?> version <i class="bi bi-arrow-right ms-1"></i></a>
            <?php else: ?>
              <p class="compat-cross small mb-0">This product key activates on <?= esc($curDevice === 'Mac' ? 'macOS' : 'Windows') ?> only.</p>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="compat-specs" data-testid="compat-specs">
      <span><i class="bi bi-pc-display"></i><?= esc($deviceChip) ?> · <?= esc($termChip) ?></span>
      <span><i class="bi bi-wifi"></i>Internet for activation</span>
      <span><i class="bi bi-shield-check"></i>Genuine &amp; verified</span>
      <span><i class="bi bi-envelope-check"></i>Instant email delivery</span>
    </div>
  </section>

  <style>
    /* Version comparison cards */
    .vc-card{position:relative;border:1px solid var(--bs-border-color);border-radius:16px;padding:24px 20px 20px;background:var(--bs-body-bg);transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
    .vc-card:hover{transform:translateY(-4px);box-shadow:0 14px 34px rgba(15,23,42,.1);border-color:rgba(6,182,212,.45)}
    .vc-card.is-current{border-color:var(--uc-blue,#06b6d4);box-shadow:0 0 0 2px rgba(6,182,212,.22)}
    .vc-card.is-latest{border-color:#f59e0b;box-shadow:0 10px 30px rgba(245,158,11,.16);padding-top:30px}
    .vc-card.is-latest:hover{border-color:#f59e0b}
    .vc-tag{position:absolute;top:-13px;left:50%;transform:translateX(-50%);white-space:nowrap;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;font-size:.68rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase;padding:5px 16px;border-radius:999px;box-shadow:0 6px 16px rgba(245,158,11,.4)}
    .vc-current-tag{position:absolute;top:-11px;right:16px;background:var(--uc-blue,#06b6d4);color:#fff;font-size:.66rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;padding:3px 10px;border-radius:999px}
    .vc-name{font-weight:700;font-size:1.02rem}
    .vc-price{font-size:1.7rem;font-weight:800;color:var(--bs-primary);letter-spacing:-.02em;margin-top:6px}
    .vc-term{font-size:.78rem;color:var(--bs-secondary-color);margin-bottom:14px}
    .vc-list{list-style:none;padding:0;margin:0 0 18px}
    .vc-list li{display:flex;align-items:flex-start;gap:8px;font-size:.86rem;padding:5px 0;color:var(--bs-body-color)}
    .vc-list li i{color:#16a34a;margin-top:2px}
    /* Compatibility panel */
    .compat-card{border:1px solid var(--bs-border-color);border-radius:16px;padding:20px;background:var(--bs-body-bg);transition:border-color .18s ease,box-shadow .18s ease}
    .compat-card.is-supported{border-color:rgba(16,185,129,.5);box-shadow:0 8px 24px rgba(16,185,129,.1)}
    .compat-card.is-muted{background:var(--bs-tertiary-bg,#f8fafc);opacity:.92}
    .compat-head{display:flex;align-items:center;gap:12px;margin-bottom:14px}
    .compat-ico{flex:0 0 auto;width:46px;height:46px;border-radius:12px;background:var(--bs-tertiary-bg,#f1f5f9);display:grid;place-items:center}
    .compat-card.is-supported .compat-ico{background:rgba(16,185,129,.12)}
    .compat-head-txt{flex:1;min-width:0}
    .compat-os{font-weight:700;font-size:1.02rem}
    .compat-sub{font-size:.78rem;color:var(--bs-secondary-color)}
    .compat-flag{font-size:1.35rem}
    .compat-card.is-supported .compat-flag{color:#16a34a}
    .compat-card.is-muted .compat-flag{color:var(--bs-secondary-color);opacity:.55}
    .compat-list{list-style:none;padding:0;margin:0}
    .compat-list li{display:flex;align-items:flex-start;gap:9px;font-size:.86rem;padding:5px 0;color:var(--bs-body-color)}
    .compat-list li i{color:#16a34a;margin-top:2px}
    .compat-cross{color:var(--bs-secondary-color)}
    .compat-specs{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}
    .compat-specs span{display:inline-flex;align-items:center;gap:7px;font-size:.8rem;font-weight:600;color:var(--bs-body-color);background:var(--bs-tertiary-bg,#f1f5f9);border:1px solid var(--bs-border-color);border-radius:999px;padding:7px 14px}
    .compat-specs i{color:var(--uc-blue,#0891b2)}
  </style>


  <!-- Tabs -->
  <ul class="nav nav-tabs mt-5" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-desc">Description</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-delivery">Delivery & Activation</button></li>
  </ul>
  <div class="tab-content border border-top-0 rounded-bottom p-4">
    <div class="tab-pane fade show active" id="tab-desc">
      <?php
        /* Render the AI-generated product description (intro paragraph(s) +
           "•" bullet list + closing line). Bullet lines are grouped into a
           styled <ul>; everything else becomes a paragraph. Falls back to a
           generic blurb if no description has been generated yet. */
        $descText = trim((string)($product['description'] ?? ''));
      ?>
      <?php if ($descText !== ''): ?>
        <div data-testid="product-description">
          <?php
            $lines  = preg_split('/\r\n|\r|\n/', $descText);
            $inList = false;
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '') { continue; }
                $isBullet = (bool)preg_match('/^([•▪◦\-\*])\s+/u', $line);
                if ($isBullet) {
                    if (!$inList) { echo '<ul class="mb-3">'; $inList = true; }
                    $item = preg_replace('/^([•▪◦\-\*])\s+/u', '', $line);
                    echo '<li class="mb-1">' . esc($item) . '</li>';
                } else {
                    if ($inList) { echo '</ul>'; $inList = false; }
                    echo '<p class="mb-3">' . esc($line) . '</p>';
                }
            }
            if ($inList) { echo '</ul>'; }
          ?>
        </div>
      <?php else: ?>
        <p><?= esc($product['name']) ?> is a genuine, one-time-purchase product. One-time purchase — no subscription, no recurring fees. Your license key activates the official software downloaded directly from Microsoft (or the vendor) and remains yours for as long as you use it.</p>
      <?php endif; ?>
      <ul class="small text-secondary">
        <li>Licensed for 1 <?= esc($product['platform']) ?> device</li>
        <li>Full official version — not a trial or shared account</li>
        <li>Includes free updates within its version</li>
        <li>Activation support included — 30-day money-back policy</li>
      </ul>
      <?php /* Product identifiers — visible barcode + SKU so customers (and
              indexing crawlers) can match this listing to the same product
              elsewhere.  Kept compact + tinted so it doesn't distract from
              the buy flow above. */ ?>
      <div class="d-flex flex-wrap gap-3 small text-secondary mt-3 pt-3 border-top" data-testid="product-identifiers">
        <?php if (!empty($product['gtin']) && function_exists('is_valid_global_gtin') && is_valid_global_gtin((string)$product['gtin'])): ?>
          <span><strong class="text-body">GTIN:</strong> <span class="font-monospace" data-testid="product-gtin"><?= esc($product['gtin']) ?></span></span>
        <?php endif; ?>
        <?php if (!empty($product['sku'])): ?>
          <span><strong class="text-body">SKU:</strong> <span class="font-monospace" data-testid="product-sku"><?= esc($product['sku']) ?></span></span>
        <?php endif; ?>
        <span><strong class="text-body">Brand:</strong> <?= esc($detectedBrand) ?></span>
      </div>
    </div>
    <div class="tab-pane fade" id="tab-delivery">
      <ol class="small">
        <li class="mb-2">Complete your purchase — your license key + download link arrive by email.</li>
        <li class="mb-2">Download the official installer from the link provided.</li>
        <li class="mb-2">Enter your product key when prompted to activate.</li>
        <li>Need help with your order? Our order-fulfillment team can assist with license-key delivery and activation questions: <?= esc(company_phone_for_country()) ?> (<?= SITE_HOURS ?>).</li>
      </ol>
    </div>
  </div>

  <?php
    /* ── Download, install & activate ─────────────────────────────────────
       One-click installer, official installation guide and activation /
       sign-in page sourced from manuals.winandoffice.com (seeded per product
       in scripts/seed-manual-urls.php). Rendered only when the product has at
       least one of these links — antivirus/other products without a manual
       simply don't show the block. */
    require_once __DIR__ . '/includes/install-guides.php';
    $pLinks     = mv_resolve_install_links((string)($product['slug'] ?? ''), $product);
    $pInstaller = $pLinks['installer'];
    $pGuide     = $pLinks['guide'];
    $pActivate  = $pLinks['activation'];
  ?>
  <?php if (false): /* 2026-06 — hidden from PUBLIC product pages per operator
        request: installer / guide / activation links are for PURCHASERS only.
        Buyers still receive the exact same links in the delivery email
        (includes/email.php) — flip to the original condition to re-enable. */ ?>
  <?php
    /* 2026-07 FIX — Semrush "18 outgoing external links contain nofollow
       attributes" (Notice). The rel logic lives in the shared helper
       mv_link_rel() in includes/functions.php so this file and
       install-guide.php can't drift out of sync (the previous drift is
       exactly what caused half of the 18 flagged links). */
    $mv_link_rel = 'mv_link_rel';
  ?>
  <section class="mt-5" data-testid="product-install-block">
    <div class="card border-0 shadow-sm rounded-4">
      <div class="card-body p-4">
        <h2 class="h5 fw-bold mb-1"><i class="bi bi-download text-primary me-2"></i>Download, install &amp; activate</h2>
        <p class="small text-secondary mb-3">Official installer, step-by-step installation guide and the activation / sign-in page for <strong><?= esc($product['name']) ?></strong> &mdash; the same links we email after purchase.</p>
        <div class="d-flex flex-wrap gap-2">
          <?php if ($pInstaller !== ''): ?>
            <a href="<?= esc($pInstaller) ?>" target="_blank" rel="<?= $mv_link_rel($pInstaller) ?>" class="btn rounded-pill px-4 fw-semibold" data-testid="install-download-btn" style="background:linear-gradient(135deg,#16a34a,#15803d) !important;color:#fff !important;border:0;"><i class="bi <?= mv_is_manual_url($pInstaller) ? 'bi-journal-arrow-down' : 'bi-box-arrow-down' ?> me-2"></i><?= esc(mv_installer_btn_label($pInstaller)) ?></a>
          <?php endif; ?>
          <?php if ($pGuide !== ''): ?>
            <a href="<?= esc($pGuide) ?>" target="_blank" rel="<?= $mv_link_rel($pGuide) ?>" class="btn btn-primary rounded-pill px-4 fw-semibold" data-testid="install-guide-btn"><i class="bi bi-journal-text me-2"></i>Installation guide</a>
          <?php endif; ?>
          <?php if ($pActivate !== ''): ?>
            <a href="<?= esc($pActivate) ?>" target="_blank" rel="<?= $mv_link_rel($pActivate) ?>" class="btn btn-outline-primary rounded-pill px-4 fw-semibold" data-testid="install-activate-btn"><i class="bi bi-key me-2"></i>Activate / Sign in</a>
          <?php endif; ?>
        </div>
        <?php if ($pInstaller === '' && $pGuide !== ''): ?>
          <p class="small text-secondary mt-3 mb-0"><i class="bi bi-info-circle me-1"></i>On Mac, the installer is downloaded after you sign in &mdash; full steps are in the installation guide above.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- AEO: Quick-Answer callout — 40-60 word direct answer Google AI
       Overviews + Perplexity routinely grab as the citation snippet. -->
  <?= render_aeo_answer(
        'Is ' . $product['name'] . ' an original, one-time purchase?',
        'Yes &mdash; ' . esc($product['name']) . ' on ' . esc(brand_name()) . ' is an <strong>original perpetual product key</strong> at <strong>' . esc(format_price((float)$product['price'])) . '</strong>. Pay once, activate inside the official ' . esc(product_detected_brand($product)) . ' installer, and use it for life on your ' . esc($product['platform'] ?: 'Windows') . ' device. Delivery is by email in 15&ndash;30 minutes; every order is protected by a 30-day money-back guarantee. Sold by ' . esc(brand_name()) . ', an independent third-party reseller (not affiliated with ' . esc(product_detected_brand($product)) . ').',
        'product-quick-answer'
    ) ?>

  <!-- Long-tail keyword SEO copy block — visible to humans, indexable by
       crawlers, quotable by AI search engines (Speakable schema attached). -->
  <section class="mt-5" data-testid="pd-seo-card">
    <div class="card border-0 shadow-sm rounded-4 pd-seo-cardbox">
      <div class="card-body p-4 p-lg-5">
        <?= product_seo_copy($product) ?>
      </div>
    </div>
  </section>
  <style>
    .pd-seo-cardbox{background:linear-gradient(180deg,#f7faff 0%,#ffffff 55%);border:1px solid #dbeafe !important;overflow:hidden;position:relative}
    .pd-seo-cardbox::before{content:"";position:absolute;inset:0 0 auto 0;height:4px;background:linear-gradient(90deg,#2563eb,#06b6d4,#2563eb);opacity:.85}
    .pd-seo-copy #pd-seo-heading{margin-top:0 !important;font-size:1.35rem}
    .pd-seo-copy h2:not(#pd-seo-heading){position:relative;padding-left:14px;margin-top:2.1rem !important}
    .pd-seo-copy h2:not(#pd-seo-heading)::before{content:"";position:absolute;left:0;top:5px;bottom:5px;width:4px;border-radius:4px;background:linear-gradient(180deg,#2563eb,#06b6d4)}
    .pd-seo-copy ul,.pd-seo-copy ol{background:#eff6ff;border:1px solid #dbeafe;border-radius:14px;padding:16px 18px 16px 38px;margin:12px 0 8px}
    .pd-seo-copy ul li,.pd-seo-copy ol li{margin-bottom:7px}
    .pd-seo-copy ul li:last-child,.pd-seo-copy ol li:last-child{margin-bottom:0}
    .pd-seo-copy ul li::marker{color:#2563eb;content:"✓  ";font-weight:800}
    .pd-seo-copy ol li::marker{color:#2563eb;font-weight:800}
    .pd-seo-copy p{line-height:1.7}
    [data-bs-theme="dark"] .pd-seo-cardbox{background:linear-gradient(180deg,rgba(37,99,235,.12),rgba(15,23,42,.35) 60%) !important;border-color:rgba(96,165,250,.28) !important}
    [data-bs-theme="dark"] .pd-seo-copy,[data-bs-theme="dark"] .pd-seo-copy p,[data-bs-theme="dark"] .pd-seo-copy li{color:#dbe4f3}
    [data-bs-theme="dark"] .pd-seo-copy h2{color:#f1f5f9}
    [data-bs-theme="dark"] .pd-seo-copy strong{color:#ffffff}
    [data-bs-theme="dark"] .pd-seo-copy ul,[data-bs-theme="dark"] .pd-seo-copy ol{background:rgba(59,130,246,.10);border-color:rgba(96,165,250,.22)}
    [data-bs-theme="dark"] .pd-seo-copy ul li::marker,[data-bs-theme="dark"] .pd-seo-copy ol li::marker{color:#93c5fd}
  </style>

  <!-- "Popular searches" chip block — visible, crawlable list of the exact
       high-intent PPC / Search-Console phrases shoppers type when hunting
       for this SKU.  Emits inline CSS the first time it renders in the
       response, then reuses the shared class on subsequent product pages.
       CRITICAL: never hidden with `display:none` — Google flags hidden
       keyword lists as spam ("cloaked keyword stuffing").  Real, visible
       chips satisfy both SEO guidelines AND the user-value bar. -->
  <?= product_search_keywords_block($product) ?>

  <?php /* "What customers are saying" — visible block backing the JSON-LD
          aggregateRating + review schema added in the <head>.  The rows
          ($_reviewRows) and aggregate stats ($_reviewStats) are the SAME
          ones serialized into JSON-LD above (via
          product_review_stats_with_fallback / product_review_rows_with_fallback)
          — single source of truth, Google-compliant, and the visible
          content always matches the schema (avoids review-stuffing
          flag).  When a product has zero real reviews yet, a
          deterministic 5-star editorial baseline row is shown here so
          the schema pair (aggregateRating + review) is always backed by
          visible content. */ ?>
    <?php
      $_aggStars = '';
      for ($i = 1; $i <= 5; $i++) {
          if ($_reviewStats['avg'] >= $i)            $_aggStars .= '<i class="bi bi-star-fill"></i>';
          elseif ($_reviewStats['avg'] >= $i - 0.5)  $_aggStars .= '<i class="bi bi-star-half"></i>';
          else                                       $_aggStars .= '<i class="bi bi-star"></i>';
      }
      // Show the "See all X" link only when there are REAL DB reviews
      // (baseline row is schema-only social proof — no reviews listing
      // page to link to).
      $_hasRealReviews = !empty($_reviewStats['is_fallback']) ? false : ((int)$_reviewStats['count'] > 0);
      // Rating distribution (5→1) for the bar-chart summary.
      $_dist = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
      $_distTotal = 0;
      if ($_hasRealReviews) {
          try {
              $_ds = db()->prepare("SELECT rating, COUNT(*) c FROM customer_reviews WHERE product_slug=? AND status='published' AND rating IS NOT NULL GROUP BY rating");
              $_ds->execute([$product['slug']]);
              foreach ($_ds->fetchAll(PDO::FETCH_ASSOC) as $_dr) {
                  $_rt = (int)$_dr['rating'];
                  if (isset($_dist[$_rt])) { $_dist[$_rt] = (int)$_dr['c']; $_distTotal += (int)$_dr['c']; }
              }
          } catch (Throwable $e) { $_distTotal = 0; }
      }
    ?>
    <section class="mt-5 pt-3" data-testid="product-reviews-section" id="reviews">
      <div class="d-flex flex-wrap align-items-center gap-3 mb-3">
        <h2 class="h4 fw-bold mb-0">What customers are saying</h2>
        <span class="text-warning lh-1 fs-5" aria-hidden="true"><?= $_aggStars ?></span>
        <span class="fw-semibold"><?= number_format((float)$_reviewStats['avg'], 1) ?></span>
        <span class="text-secondary small">
          Based on <?= (int)$_reviewStats['count'] ?> verified review<?= (int)$_reviewStats['count'] === 1 ? '' : 's' ?>
        </span>
        <?php if ($_hasRealReviews): ?>
          <a href="reviews.php?product=<?= urlencode($product['slug']) ?>"
             class="small text-decoration-none"
             data-testid="product-reviews-see-all">See all <?= (int)$_reviewStats['count'] ?> &rsaquo;</a>
        <?php endif; ?>
        <button type="button" class="btn btn-primary rounded-pill px-4 fw-semibold ms-auto" data-bs-toggle="modal" data-bs-target="#writeReviewModal" data-testid="write-review-btn"><i class="bi bi-pencil-square me-2"></i>Write a review</button>
      </div>

      <?php if ($_distTotal > 0): ?>
      <?php /* Rating breakdown (5→1 star bar chart) summarising all reviews. */ ?>
      <div class="rating-breakdown card p-3 p-md-4 mb-4" data-testid="rating-breakdown">
        <div class="rating-bd-score">
          <div class="rating-bd-num"><?= number_format((float)$_reviewStats['avg'], 1) ?></div>
          <div class="text-warning lh-1 mb-1" aria-hidden="true"><?= $_aggStars ?></div>
          <div class="text-secondary small"><?= (int)$_reviewStats['count'] ?> verified rating<?= (int)$_reviewStats['count'] === 1 ? '' : 's' ?></div>
        </div>
        <div class="rating-bd-bars">
          <?php for ($s = 5; $s >= 1; $s--):
              $cnt = $_dist[$s];
              $pct = $_distTotal > 0 ? round(($cnt / $_distTotal) * 100) : 0;
          ?>
          <div class="rating-bd-row" data-testid="rating-bar-<?= $s ?>">
            <span class="rating-bd-star"><?= $s ?><i class="bi bi-star-fill"></i></span>
            <span class="rating-bd-track"><span class="rating-bd-fill" style="width:<?= $pct ?>%"></span></span>
            <span class="rating-bd-pct"><?= $pct ?>%</span>
          </div>
          <?php endfor; ?>
        </div>
      </div>
      <style>
        .rating-breakdown{display:flex;flex-wrap:wrap;align-items:center;gap:28px;border:1px solid var(--bs-border-color)}
        .rating-bd-score{text-align:center;min-width:120px}
        .rating-bd-num{font-size:2.6rem;font-weight:800;line-height:1;letter-spacing:-.02em;color:var(--bs-body-color)}
        .rating-bd-bars{flex:1;min-width:240px;display:flex;flex-direction:column;gap:8px}
        .rating-bd-row{display:flex;align-items:center;gap:12px;font-size:.86rem}
        .rating-bd-star{display:inline-flex;align-items:center;gap:3px;width:34px;color:var(--bs-secondary-color);font-weight:600}
        .rating-bd-star .bi{color:#f59e0b;font-size:.78rem}
        .rating-bd-track{flex:1;height:9px;border-radius:999px;background:rgba(148,163,184,.25);overflow:hidden}
        .rating-bd-fill{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#f59e0b,#f97316);transition:width .6s ease}
        .rating-bd-pct{width:42px;text-align:right;color:var(--bs-secondary-color);font-variant-numeric:tabular-nums}
      </style>
      <?php endif; ?>

      <div class="row g-3">
        <?php foreach ($_reviewRows as $r): ?>
          <?php
            // Baseline rows carry `comment_html` (with proper &mdash; entities)
            // — use that for the visible block, fall back to `comment` for
            // real DB rows.
            $_reviewText = isset($r['comment_html']) && $r['comment_html'] !== ''
                ? $r['comment_html']
                : esc($r['comment']);
          ?>
          <div class="col-md-6">
            <div class="card p-3 h-100 home-review-card" data-testid="product-review-card">
              <div class="d-flex align-items-center gap-2 mb-2">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                  <i class="bi <?= $i <= $r['rating'] ? 'bi-star-fill text-warning' : 'bi-star text-secondary' ?>"></i>
                <?php endfor; ?>
                <span class="badge text-bg-success ms-auto small">
                  <i class="bi bi-patch-check-fill me-1"></i>Verified
                </span>
              </div>
              <p class="text-body small mb-3 home-review-text">&ldquo;<?= $_reviewText ?>&rdquo;</p>
              <div class="d-flex align-items-center gap-2 mt-auto">
                <div class="avatar-circle"><?= esc(mb_strtoupper(mb_substr($r['name'], 0, 1))) ?></div>
                <div>
                  <div class="fw-semibold small"><?= esc($r['name']) ?></div>
                  <small class="text-secondary">
                    <i class="bi bi-calendar-event me-1"></i><?= esc(date('M j, Y', strtotime($r['date']))) ?>
                  </small>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>

    <!-- Write-a-review modal — verified-purchase gated (order # + email) so
         only genuine buyers can review.  3★+ auto-publishes; <3★ goes to the
         admin for follow-up.  Reuses /ajax/product-review.php. -->
    <div class="modal fade" id="writeReviewModal" tabindex="-1" aria-hidden="true" data-testid="write-review-modal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4">
          <div class="modal-header border-0 pb-0">
            <h5 class="modal-title fw-bold">Review <?= esc($product['name']) ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="pdReviewForm" data-slug="<?= esc($product['slug']) ?>">
              <div class="text-center mb-2">
                <div class="d-inline-flex gap-2" id="pdReviewStars" data-testid="pd-review-stars">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                    <i class="bi bi-star pd-star" data-val="<?= $i ?>" data-testid="pd-star-<?= $i ?>" role="button" tabindex="0" style="font-size:34px;color:#e5e7eb;cursor:pointer;transition:color .12s,transform .12s;"></i>
                  <?php endfor; ?>
                </div>
                <input type="hidden" name="rating" id="pdReviewRating" value="0">
                <div class="small text-secondary mt-1" id="pdReviewLabel">Tap a star to rate</div>
              </div>
              <div class="mb-3">
                <label class="form-label small fw-semibold mb-1">Your review</label>
                <textarea class="form-control rounded-3" name="comment" id="pdReviewComment" rows="3" maxlength="800" placeholder="What did you like? How was delivery &amp; activation?" data-testid="pd-review-comment"></textarea>
              </div>
              <div class="row g-2 mb-2">
                <div class="col-sm-6">
                  <label class="form-label small fw-semibold mb-1">Order number</label>
                  <input type="text" class="form-control rounded-3" name="order_number" placeholder="e.g. MV2406ABCDE" data-testid="pd-review-order">
                </div>
                <div class="col-sm-6">
                  <label class="form-label small fw-semibold mb-1">Email used at checkout</label>
                  <input type="email" class="form-control rounded-3" name="email" placeholder="you@email.com" data-testid="pd-review-email">
                </div>
              </div>
              <p class="text-secondary" style="font-size:11.5px;">We verify your purchase before publishing — reviews are only shown for genuine orders. Find your order number in your confirmation email or via <a href="track-order.php">Track Order</a>.</p>
              <div id="pdReviewMsg" class="small mb-2" style="display:none;"></div>
              <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 fw-semibold" data-testid="pd-review-submit"><i class="bi bi-send me-1"></i>Submit review</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <script>
    (function(){
      var form = document.getElementById('pdReviewForm');
      if (!form) return;
      var stars  = form.querySelectorAll('.pd-star');
      var rInput = document.getElementById('pdReviewRating');
      var label  = document.getElementById('pdReviewLabel');
      var msg    = document.getElementById('pdReviewMsg');
      var LBL = {0:'Tap a star to rate',1:'Poor',2:'Fair',3:'Good',4:'Great',5:'Excellent'};
      function paint(n){ stars.forEach(function(s){ var v=+s.dataset.val; s.style.color = v<=n ? '#facc15' : '#e5e7eb'; s.className = 'bi pd-star ' + (v<=n?'bi-star-fill':'bi-star'); }); label.textContent = LBL[n]||LBL[0]; }
      function setR(n){ rInput.value=n; paint(n); }
      stars.forEach(function(s){ var v=+s.dataset.val;
        s.addEventListener('mouseenter', function(){ paint(v); });
        s.addEventListener('click', function(){ setR(v); });
        s.addEventListener('keydown', function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); setR(v);} });
      });
      document.getElementById('pdReviewStars').addEventListener('mouseleave', function(){ paint(+rInput.value||0); });
      form.addEventListener('submit', async function(e){
        e.preventDefault();
        msg.style.display='none';
        var btn = form.querySelector('[data-testid="pd-review-submit"]');
        var payload = {
          product_slug: form.dataset.slug,
          rating: +rInput.value || 0,
          comment: form.comment.value.trim(),
          order_number: form.order_number.value.trim(),
          email: form.email.value.trim()
        };
        btn.disabled = true; var old = btn.innerHTML; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Submitting…';
        try {
          var res = await fetch('ajax/product-review.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
          var data = await res.json();
          msg.style.display='block';
          if (data.ok) {
            msg.className='small mb-2 text-success fw-semibold';
            msg.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i>' + (data.message || 'Thank you for your review!');
            form.querySelector('textarea').value=''; setR(0);
            if (data.published) { setTimeout(function(){ window.location.reload(); }, 1400); }
          } else {
            msg.className='small mb-2 text-danger';
            msg.textContent = data.error || 'Something went wrong. Please try again.';
          }
        } catch(err) {
          msg.style.display='block'; msg.className='small mb-2 text-danger'; msg.textContent='Network error. Please try again.';
        } finally { btn.disabled=false; btn.innerHTML=old; }
      });
    })();
    </script>
  <?php /* end reviews + write-a-review */ ?>

  <!-- Ask AI — Claude Haiku 4.5 powered Q&A grounded on this product's
       facts, FAQs, and recent reviews.  Answers free-form questions in
       seconds and routes anything off-topic to live chat. -->
  <section class="mt-5 ask-ai-card" data-testid="ask-ai-section" data-slug="<?= esc($product['slug']) ?>">
    <div class="ask-ai-head">
      <div class="ask-ai-avatar"><i class="bi bi-stars"></i></div>
      <div class="ask-ai-meta">
        <div class="ask-ai-title">Ask AI about this product</div>
        <div class="ask-ai-sub">Powered by Claude · Instant answers about delivery, compatibility, activation &amp; more</div>
      </div>
      <span class="ask-ai-pill"><span class="ask-ai-dot"></span>Online</span>
    </div>
    <div class="ask-ai-suggestions" data-testid="ask-ai-suggestions">
      <button type="button" class="ask-ai-chip" data-q="How long does delivery take?">How long does delivery take?</button>
      <button type="button" class="ask-ai-chip" data-q="Will this work on my Mac?">Will this work on my Mac?</button>
      <button type="button" class="ask-ai-chip" data-q="Is this a one-time purchase or subscription?">One-time or subscription?</button>
      <button type="button" class="ask-ai-chip" data-q="What happens if the key does not activate?">What if it doesn't activate?</button>
    </div>
    <div id="ask-ai-thread" class="ask-ai-thread" data-testid="ask-ai-thread"></div>
    <form id="ask-ai-form" class="ask-ai-form" onsubmit="askAiSubmit(event)">
      <input type="text" id="ask-ai-input" class="form-control" placeholder="Ask anything about this product…" maxlength="400" autocomplete="off" data-testid="ask-ai-input" required>
      <button type="submit" class="ask-ai-send" data-testid="ask-ai-send"><i class="bi bi-send-fill"></i></button>
    </form>
    <div class="ask-ai-footer">
      AI answers are based on this product's specs — for personal questions or order help, use the chat bubble.
    </div>
  </section>

  <!-- Brand-aware FAQ accordion — visible to humans + structured for AI
       crawlers (FAQPage JSON-LD emitted via $jsonLdFaq).  Answers are
       quotable verbatim by ChatGPT / Perplexity / Google AI Overviews. -->
  <section class="mt-5 pd-faq" aria-labelledby="pd-faq-heading" data-testid="product-faq">
    <div class="d-flex align-items-center gap-2 mb-3">
      <i class="bi bi-patch-question-fill" style="font-size:22px;color:#2563eb;"></i>
      <h2 id="pd-faq-heading" class="fw-bold h4 mb-0">Questions about <?= esc($product['name']) ?></h2>
    </div>
    <p class="text-secondary small mb-3">Quick answers about delivery, activation and our guarantee — straight from our support team.</p>
    <div class="accordion pd-faq-accordion" id="pd-faq-accordion">
      <?php foreach ($pageFaqs as $idx => $f): $itemId = 'pd-faq-item-' . $idx; ?>
        <div class="accordion-item">
          <h3 class="accordion-header">
            <button class="accordion-button <?= $idx > 0 ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse"
                    data-bs-target="#<?= esc($itemId) ?>" aria-expanded="<?= $idx === 0 ? 'true' : 'false' ?>"
                    aria-controls="<?= esc($itemId) ?>" data-testid="pd-faq-q-<?= $idx ?>">
              <?= esc($f['question']) ?>
            </button>
          </h3>
          <div id="<?= esc($itemId) ?>" class="accordion-collapse collapse <?= $idx === 0 ? 'show' : '' ?>"
               data-bs-parent="#pd-faq-accordion">
            <div class="accordion-body" data-testid="pd-faq-a-<?= $idx ?>">
              <?= nl2br(esc($f['answer'])) ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- AEO: "People also ask" — second FAQPage entity targeting longer
       intent variants.  Each Q-A is also a row in the JSON-LD below. -->
  <?php $paaFaqs = product_paa_faqs($product); ?>
  <?= render_paa_block($paaFaqs, 'People also ask about ' . $product['name'], 'product-paa') ?>

  <!-- ===== Deep-link cluster: drives Google's PageRank graph + helps AI
       crawlers map this product into the wider topical neighbourhood.
       Uses descriptive anchor text (mid-tail keywords) for every link.
       ============================================================== -->
  <?php
    $sister = product_sibling_category($product);
    $catSlug = (string)($product['category'] ?? '');
    $catTitle = $catSlug ? category_title($catSlug) : '';
    $relCats = related_category_links($catSlug);
    $popular = mv_product_buy_intent_keywords($product);
  ?>
  <section class="pd-deep-cluster mt-5" data-testid="product-deep-cluster" aria-labelledby="pd-cluster-heading">
    <h2 id="pd-cluster-heading" class="fw-bold h4 mb-3">Related categories &amp; popular searches</h2>
    <?php $prodHubs = topic_hubs_for_product($product); ?>
    <?php if ($prodHubs): ?>
    <div class="d-flex flex-wrap align-items-center gap-2 mb-3" data-testid="product-topic-hub-row" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 14px;">
      <span class="fw-semibold small text-secondary"><i class="bi bi-collection-fill text-primary me-1"></i>Topic hub:</span>
      <?php foreach (array_slice($prodHubs, 0, 3) as $__h): ?>
        <a class="badge text-decoration-none" data-testid="product-hub-link" href="hub/<?= esc($__h['slug']) ?>" style="background:#fff;color:<?= esc($__h['color']) ?>;border:1px solid <?= esc($__h['color']) ?>33;padding:6px 12px;font-size:11.5px;font-weight:600;"><?= esc(strip_tags(explode(' — ', $__h['title'])[0])) ?> <i class="bi bi-arrow-right-short"></i></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="row g-4">
      <div class="col-md-6">
        <div class="fw-bold small text-uppercase text-secondary mb-2"><i class="bi bi-collection me-1"></i>Browse related categories</div>
        <ul class="list-unstyled small">
          <?php if ($catTitle): ?>
            <li class="mb-2">&rsaquo; <a class="text-decoration-none" href="category.php?slug=<?= esc($catSlug) ?>" data-testid="cluster-parent-category">All <?= esc($catTitle) ?> &mdash; product keys</a></li>
          <?php endif; ?>
          <?php if ($sister): ?>
            <li class="mb-2">&rsaquo; <a class="text-decoration-none" href="category.php?slug=<?= esc($sister['slug']) ?>" data-testid="cluster-sister-category"><?= esc($sister['title']) ?> &mdash; sister edition</a></li>
          <?php endif; ?>
          <?php foreach ($relCats as $rc): ?>
            <li class="mb-2">&rsaquo; <a class="text-decoration-none" href="category.php?slug=<?= esc($rc['slug']) ?>" data-testid="cluster-related-<?= esc($rc['slug']) ?>"><?= $rc['anchor'] ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div class="col-md-6">
        <div class="fw-bold small text-uppercase text-secondary mb-2"><i class="bi bi-search me-1"></i>Popular searches</div>
        <div class="d-flex flex-wrap gap-2">
          <?php foreach ($popular as $term): ?>
            <a href="product.php?slug=<?= esc($product['slug']) ?>" class="badge text-decoration-none fw-normal" data-testid="cluster-popular-search" style="background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;padding:6px 10px;font-size:12px;"><?= esc($term) ?></a>
          <?php endforeach; ?>
        </div>
        <div class="fw-bold small text-uppercase text-secondary mt-4 mb-2"><i class="bi bi-journal-text me-1"></i>Helpful guides on the blog</div>
        <ul class="list-unstyled small mb-0">
          <?php foreach (product_related_articles($product, 3) as $ba): ?>
            <li class="mb-1">&rsaquo; <a class="text-decoration-none" href="blog-post.php?id=<?= urlencode((string)$ba['id']) ?>" data-testid="cluster-related-article"><?= esc($ba['title']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </section>

  <?php if ($related): ?>
    <h2 class="fw-bold h4 mt-5 mb-4">Related Products</h2>
    <div class="row g-4">
      <?php foreach ($related as $r): ?>
        <div class="col-xl-3 col-lg-4 col-sm-6"><?= render_product_card($r) ?></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php
    /* ---- Internal-linking widget: blog articles that feature this product.
       Boosts on-page topical authority (Google's PageRank-style internal
       link graph) and gives buyers extra trust-building context. ----------- */
    $articlesAboutThis = [];
    try {
        $aap = db()->prepare("SELECT id, title, date, read_time, image, ai_generated
                                FROM blog_posts
                               WHERE product_id = ?
                               ORDER BY COALESCE(created_at, '1970-01-01') DESC, id DESC
                               LIMIT 3");
        $aap->execute([(int)$product['id']]);
        $articlesAboutThis = $aap->fetchAll();
    } catch (Throwable $e) { /* old schema — silent */ }
  ?>
  <?php if ($articlesAboutThis): ?>
    <h2 class="fw-bold h4 mt-5 mb-4" data-testid="articles-about-this-product"><i class="bi bi-journal-text me-1 text-primary"></i>Read more about <?= esc($product['name']) ?></h2>
    <div class="row g-3">
      <?php foreach ($articlesAboutThis as $bp): ?>
        <div class="col-md-4">
          <a href="blog-post.php?id=<?= urlencode($bp['id']) ?>" class="card h-100 text-decoration-none p-0" style="border:1px solid #e5e7eb;overflow:hidden;">
            <img src="<?= esc($bp['image']) ?>" alt="<?= esc($bp['title']) ?>" style="width:100%;height:140px;object-fit:cover;">
            <div class="p-3">
              <div class="small text-secondary"><i class="bi bi-calendar3 me-1"></i><?= esc($bp['date']) ?> · <?= esc($bp['read_time']) ?>
                <?php if (!empty($bp['ai_generated'])): ?> · <span style="color:#5b21b6;font-weight:600;"><i class="bi bi-stars"></i> AI</span><?php endif; ?>
              </div>
              <div class="fw-bold mt-1 text-body" style="font-size:14px;line-height:1.35;"><?= esc($bp['title']) ?></div>
              <div class="text-primary small fw-semibold mt-2">Read article <i class="bi bi-arrow-right"></i></div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<style>
  /* Out-of-stock chip styling — soft red pill matching brand */
  .pd-stock-out-badge {
    background: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fecaca;
    font-weight: 600;
  }
  [data-bs-theme="dark"] .pd-stock-out-badge {
    background: rgba(239,68,68,.15);
    color: #fca5a5;
    border-color: rgba(239,68,68,.35);
  }
  /* Product FAQ accordion — clean cards with subtle blue accent */
  .pd-faq-accordion .accordion-item {
    border: 1px solid #e2e8f0;
    border-radius: 12px !important;
    margin-bottom: 10px;
    overflow: hidden;
    background: #ffffff;
  }
  [data-bs-theme="dark"] .pd-faq-accordion .accordion-item {
    border-color: #334155;
    background: #1e293b;
  }
  .pd-faq-accordion .accordion-button {
    font-weight: 600;
    font-size: 15px;
    color: #0f172a;
    background: #ffffff;
    padding: 16px 20px;
  }
  [data-bs-theme="dark"] .pd-faq-accordion .accordion-button {
    background: #1e293b;
    color: #e2e8f0;
  }
  .pd-faq-accordion .accordion-button:not(.collapsed) {
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    color: #1e3a8a;
    box-shadow: none;
  }
  [data-bs-theme="dark"] .pd-faq-accordion .accordion-button:not(.collapsed) {
    background: linear-gradient(135deg, #1c2541, #1e293b);
    color: #93c5fd;
  }
  .pd-faq-accordion .accordion-button:focus { box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15); }
  .pd-faq-accordion .accordion-body {
    font-size: 14px;
    color: #475569;
    line-height: 1.7;
    padding: 14px 20px 20px;
  }
  [data-bs-theme="dark"] .pd-faq-accordion .accordion-body { color: #cbd5e1; }

  /* Ask AI widget — premium card with Claude-branded "Powered by" feel */
  .ask-ai-card {
    background: linear-gradient(135deg, #faf5ff 0%, #f0f9ff 100%);
    border: 1px solid #e9d5ff;
    border-radius: 16px;
    padding: 22px 22px 18px;
    position: relative;
    overflow: hidden;
  }
  [data-bs-theme="dark"] .ask-ai-card {
    background: linear-gradient(135deg, #1c1638 0%, #0f1e3a 100%);
    border-color: #4c1d95;
  }
  .ask-ai-head { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
  .ask-ai-avatar {
    width: 42px; height: 42px; border-radius: 12px;
    background: linear-gradient(135deg, #a855f7, #6366f1);
    color: #fff; display: inline-flex; align-items: center; justify-content: center;
    font-size: 20px; box-shadow: 0 6px 18px rgba(168, 85, 247, 0.35);
  }
  .ask-ai-meta { flex: 1; min-width: 0; }
  .ask-ai-title { font-size: 16px; font-weight: 700; color: #1e1b4b; line-height: 1.2; }
  [data-bs-theme="dark"] .ask-ai-title { color: #ddd6fe; }
  .ask-ai-sub { font-size: 12px; color: #64748b; margin-top: 2px; }
  [data-bs-theme="dark"] .ask-ai-sub { color: #94a3b8; }
  .ask-ai-pill {
    display: inline-flex; align-items: center; gap: 6px;
    background: #d1fae5; color: #047857;
    padding: 4px 10px; border-radius: 999px;
    font-size: 11px; font-weight: 700;
  }
  .ask-ai-dot {
    width: 8px; height: 8px; border-radius: 50%; background: #10b981;
    animation: ask-ai-pulse 2s ease-in-out infinite;
  }
  @keyframes ask-ai-pulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.4); opacity: 0.5; } }
  .ask-ai-suggestions { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
  .ask-ai-chip {
    background: #ffffff; border: 1px solid #e9d5ff;
    color: #6d28d9; padding: 6px 14px;
    border-radius: 999px; font-size: 12.5px; font-weight: 600;
    cursor: pointer; transition: all 0.14s ease;
  }
  .ask-ai-chip:hover { background: #6d28d9; color: #fff; border-color: #6d28d9; transform: translateY(-1px); }
  [data-bs-theme="dark"] .ask-ai-chip { background: #1e1b4b; color: #c4b5fd; border-color: #4c1d95; }
  [data-bs-theme="dark"] .ask-ai-chip:hover { background: #6d28d9; color: #fff; }
  .ask-ai-thread { display: flex; flex-direction: column; gap: 10px; margin-bottom: 12px; max-height: 480px; overflow-y: auto; }
  .ask-ai-thread:empty { display: none; }
  .ask-ai-msg {
    padding: 10px 14px; border-radius: 12px;
    font-size: 13.5px; line-height: 1.55; max-width: 88%;
    animation: ask-ai-fade-in 0.22s ease-out;
  }
  @keyframes ask-ai-fade-in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
  .ask-ai-msg.is-q { align-self: flex-end; background: #6d28d9; color: #fff; border-bottom-right-radius: 4px; }
  .ask-ai-msg.is-a { align-self: flex-start; background: #ffffff; color: #1e1b4b; border: 1px solid #e9d5ff; border-bottom-left-radius: 4px; box-shadow: 0 1px 3px rgba(15,23,42,.05); }
  [data-bs-theme="dark"] .ask-ai-msg.is-a { background: #1c1638; color: #ddd6fe; border-color: #4c1d95; }
  .ask-ai-msg.is-err { align-self: flex-start; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
  .ask-ai-feedback { display: flex; gap: 6px; margin-top: 8px; font-size: 11px; color: #94a3b8; align-items: center; }
  .ask-ai-fb-btn { background: transparent; border: 0; cursor: pointer; padding: 2px 6px; border-radius: 6px; color: #94a3b8; }
  .ask-ai-fb-btn:hover { color: #6d28d9; background: rgba(168,85,247,.08); }
  .ask-ai-fb-btn.is-on { color: #10b981; }
  .ask-ai-typing { font-size: 12px; color: #94a3b8; padding: 8px 12px; }
  .ask-ai-typing span { animation: ask-ai-typing 1.2s ease-in-out infinite; }
  .ask-ai-typing span:nth-child(2) { animation-delay: 0.18s; }
  .ask-ai-typing span:nth-child(3) { animation-delay: 0.36s; }
  @keyframes ask-ai-typing { 0%, 100% { opacity: 0.3; } 50% { opacity: 1; } }
  .ask-ai-form { display: flex; gap: 8px; }
  .ask-ai-form input { flex: 1; border-radius: 999px; padding: 10px 18px; font-size: 14px; border: 1px solid #e9d5ff; }
  .ask-ai-form input:focus { border-color: #6d28d9; box-shadow: 0 0 0 3px rgba(109,40,217,.15); outline: none; }
  [data-bs-theme="dark"] .ask-ai-form input { background: #1c1638; color: #ddd6fe; border-color: #4c1d95; }
  .ask-ai-send {
    width: 42px; height: 42px; border-radius: 50%; border: 0;
    background: linear-gradient(135deg, #a855f7, #6366f1); color: #fff;
    font-size: 16px; cursor: pointer; transition: all 0.14s ease;
    box-shadow: 0 6px 16px rgba(99,102,241,.32);
  }
  .ask-ai-send:hover { transform: translateY(-1px) scale(1.05); box-shadow: 0 10px 22px rgba(99,102,241,.45); }
  .ask-ai-send:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
  .ask-ai-footer { font-size: 10.5px; color: #94a3b8; margin-top: 10px; text-align: center; }
</style>

<?php /* view_item event — fires once per product page load. */ ?>
<?php
$tk_ga4_v  = trim((string)setting_get('ga4_measurement_id', ''));
$tk_uet_v  = trim((string)setting_get('bing_uet_tag_id', ''));
// view_item is ALWAYS emitted as a GTM ecommerce dataLayer push. The direct
// gtag() call fires ONLY in native mode (no GTM) — in GTM mode the container's
// GA4 event tag consumes the dataLayer push (single installation, no doubles).
$__nativeTrk = (mv_tracking_mode() === 'native');
?>
<script>
(function(){
  var item = {
    item_id:    <?= json_encode((string)$product['slug']) ?>,
    item_name:  <?= json_encode((string)$product['name']) ?>,
    item_brand: <?= json_encode((string)($product['brand'] ?? 'Microsoft')) ?>,
    item_category: <?= json_encode((string)($product['category'] ?? 'Software')) ?>,
    price:      <?= json_encode(round((float)$product['price'], 2)) ?>,
    quantity:   1,
    currency:   <?= json_encode((string)(current_currency()['code'] ?? 'USD')) ?>
  };
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ ecommerce: null });
  window.dataLayer.push({
    event: 'view_item',
    ecommerce: { currency: item.currency, value: item.price, items: [item] }
  });
  <?php if ($__nativeTrk && $tk_ga4_v !== ''): ?>
  if (typeof gtag === 'function') {
    gtag('event', 'view_item', { currency: item.currency, value: item.price, items: [item] });
  }
  <?php endif; ?>
  <?php if ($tk_uet_v !== ''): ?>
  if (window.uetq) {
    window.uetq.push('event', 'product_view', {
      event_category: 'ecommerce', event_label: item.item_id,
      revenue_value: item.price, currency: item.currency
    });
  }
  <?php endif; ?>
})();
</script>


<?php /* ── Sticky buy bar ─────────────────────────────────────────────
        Fixed bottom bar that slides in once the main Add to Cart button
        scrolls out of view, keeping price + Add to Cart reachable while the
        shopper reads the long description. Reuses the .add-to-cart-btn /
        .buy-now-btn handlers so no extra JS wiring is needed. */ ?>
<div class="pd-sticky-bar" id="pdStickyBar" data-testid="pd-sticky-buybar" aria-hidden="true">
  <div class="container pd-sticky-inner">
    <div class="pd-sticky-info">
      <img class="pd-sticky-thumb" src="<?= esc($imv($product['image'])) ?>" alt="<?= esc(product_img_alt($product)) ?>" loading="lazy">
      <div class="pd-sticky-text">
        <div class="pd-sticky-name"><?= esc($product['name']) ?></div>
        <div class="pd-sticky-price" data-testid="pd-sticky-price"><?= format_price((float)$product['price']) ?></div>
      </div>
    </div>
    <div class="pd-sticky-actions">
      <button class="btn btn-orange-outline rounded-pill px-3 fw-bold buy-now-btn d-none d-sm-inline-flex" data-slug="<?= esc($product['slug']) ?>" data-testid="pd-sticky-buy-now"><i class="bi bi-lightning-charge-fill me-1"></i>Buy Now</button>
      <button class="btn btn-orange-solid rounded-pill px-4 add-to-cart-btn" data-slug="<?= esc($product['slug']) ?>" data-name="<?= esc($product['name']) ?>" data-price="<?= esc((string)$product['price']) ?>" data-currency="<?= esc(current_currency()['code'] ?? 'USD') ?>" data-testid="pd-sticky-add-to-cart"><i class="bi bi-cart-plus me-2"></i>Add to Cart</button>
    </div>
  </div>
</div>
<style>
  .pd-sticky-bar{position:fixed;left:0;right:0;bottom:0;z-index:1040;background:var(--bs-body-bg);border-top:1px solid var(--bs-border-color);box-shadow:0 -8px 28px rgba(15,23,42,.12);transform:translateY(110%);transition:transform .28s cubic-bezier(.4,0,.2,1);padding:10px 0}
  .pd-sticky-bar.is-visible{transform:translateY(0)}
  .pd-sticky-inner{display:flex;align-items:center;justify-content:space-between;gap:16px}
  .pd-sticky-info{display:flex;align-items:center;gap:12px;min-width:0}
  .pd-sticky-thumb{width:46px;height:46px;object-fit:contain;border-radius:10px;border:1px solid var(--bs-border-color);background:#fff;flex-shrink:0}
  .pd-sticky-text{min-width:0}
  .pd-sticky-name{font-weight:600;font-size:.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:52vw}
  .pd-sticky-price{font-weight:800;color:var(--bs-primary);font-size:1.05rem;line-height:1.1}
  .pd-sticky-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}
  /* Mobile: dock the bar at the TOP so it never hides behind the chat
     launcher that lives in the bottom-right corner. */
  @media (max-width:767.98px){
    .pd-sticky-bar{top:0;bottom:auto;transform:translateY(-110%);border-top:0;border-bottom:1px solid var(--bs-border-color);box-shadow:0 8px 28px rgba(15,23,42,.12)}
    .pd-sticky-bar.is-visible{transform:translateY(0)}
  }
  @media (max-width:575.98px){.pd-sticky-thumb{display:none}.pd-sticky-name{max-width:44vw}}
</style>
<script>
(function(){
  var bar = document.getElementById('pdStickyBar');
  var anchor = document.querySelector('[data-testid="pd-add-to-cart"]');
  if(!bar || !anchor) return;
  if('IntersectionObserver' in window){
    var io = new IntersectionObserver(function(entries){
      // Show the bar only when the primary Add to Cart has scrolled past.
      var e = entries[0];
      var show = !e.isIntersecting && e.boundingClientRect.top < 0;
      bar.classList.toggle('is-visible', show);
      bar.setAttribute('aria-hidden', show ? 'false' : 'true');
    }, {threshold:0});
    io.observe(anchor);
  }
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

<script>
/* Product image gallery — swap the main hero image when a thumb is clicked. */
function pdSwapImage(btn, src) {
  var main = document.querySelector('.pd-360-img');
  if (main && src) { main.src = src; }
  var thumbs = document.querySelectorAll('.pd-thumb');
  thumbs.forEach(function (t) { t.classList.remove('is-active'); });
  if (btn) btn.classList.add('is-active');
}
</script>

<script>
/* ============================================================
 * Ask AI — product page widget (Claude Haiku 4.5)
 * ============================================================ */
(function(){
  const section = document.querySelector('[data-testid="ask-ai-section"]');
  if (!section) return;
  const slug   = section.getAttribute('data-slug') || '';
  const thread = document.getElementById('ask-ai-thread');
  const input  = document.getElementById('ask-ai-input');
  const sendBtn = document.querySelector('.ask-ai-send');

  // One-click suggestion chips populate the input.
  document.querySelectorAll('.ask-ai-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      input.value = chip.getAttribute('data-q') || '';
      input.focus();
    });
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function appendMsg(type, text, chatId) {
    const div = document.createElement('div');
    div.className = 'ask-ai-msg is-' + type;
    div.innerHTML = escapeHtml(text);
    thread.appendChild(div);
    if (type === 'a' && chatId) {
      const fb = document.createElement('div');
      fb.className = 'ask-ai-feedback';
      fb.innerHTML = '<span>Was this helpful?</span>'
        + '<button type="button" class="ask-ai-fb-btn" data-helpful="1" data-id="' + chatId + '" data-testid="ask-ai-fb-up-' + chatId + '"><i class="bi bi-hand-thumbs-up"></i></button>'
        + '<button type="button" class="ask-ai-fb-btn" data-helpful="0" data-id="' + chatId + '" data-testid="ask-ai-fb-down-' + chatId + '"><i class="bi bi-hand-thumbs-down"></i></button>';
      thread.appendChild(fb);
    }
    thread.scrollTop = thread.scrollHeight;
  }
  function appendTyping() {
    const t = document.createElement('div');
    t.className = 'ask-ai-typing';
    t.id = 'ask-ai-typing-indicator';
    t.innerHTML = 'Thinking<span>.</span><span>.</span><span>.</span>';
    thread.appendChild(t);
    thread.scrollTop = thread.scrollHeight;
  }
  function removeTyping() {
    const t = document.getElementById('ask-ai-typing-indicator');
    if (t) t.remove();
  }

  window.askAiSubmit = async function(ev) {
    ev.preventDefault();
    const q = input.value.trim();
    if (!q || sendBtn.disabled) return;
    appendMsg('q', q);
    input.value = '';
    sendBtn.disabled = true;
    appendTyping();
    try {
      const r = await fetch('ajax/ask-ai.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: slug, question: q }),
      });
      const j = await r.json();
      removeTyping();
      if (j && j.ok) {
        appendMsg('a', j.answer, j.chat_id);
      } else {
        appendMsg('err', (j && j.error) || 'Something went wrong. Please try the chat bubble in the corner.');
      }
    } catch (_) {
      removeTyping();
      appendMsg('err', 'Network hiccup — please retry, or use the chat bubble for live help.');
    } finally {
      sendBtn.disabled = false;
      input.focus();
    }
  };

  // Thumbs up/down feedback delegation.
  thread.addEventListener('click', async (e) => {
    const btn = e.target.closest('.ask-ai-fb-btn');
    if (!btn) return;
    const chatId  = btn.getAttribute('data-id');
    const helpful = btn.getAttribute('data-helpful') === '1' ? 1 : 0;
    btn.classList.add('is-on');
    btn.parentNode.querySelectorAll('.ask-ai-fb-btn').forEach(b => { if (b !== btn) b.style.opacity = '0.35'; });
    try {
      await fetch('ajax/ask-ai-feedback.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, helpful: helpful }),
      });
    } catch (_) {}
  });
})();
</script>
