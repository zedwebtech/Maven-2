<?php
/**
 * /about  →  canonical About trust page (HTTP 200, no redirect).
 *
 * Agent-readiness "trust anchor pages" audits probe /about directly. The full
 * About content lives in about-us.php; serve it in place at /about so both
 * /about and /about-us return the same real 200 page. Force the canonical to
 * the clean /about URL to avoid a duplicate-content pair with /about-us.
 */
require_once __DIR__ . '/includes/functions.php';
$canonicalUrl = site_url() . '/about';
require __DIR__ . '/about-us.php';
