<?php
/**
 * blog-image.php — streams a blog post's cover image straight from the
 * database (blog_media table).  This makes blog covers DEPLOY-PROOF: the
 * bytes live in the DB, which a code re-upload never overwrites, so a post
 * keeps its exact image no matter how many times the project is redeployed.
 *
 *   /blog-image.php?id=<postId>
 *
 * Falls back with a 302 to a shipped on-brand cover if the row is missing,
 * so the <img> tag can never break.
 */

require_once __DIR__ . '/includes/db.php'; // lean bootstrap: just db(), no session/schema

$id = (string)($_GET['id'] ?? '');
if ($id === '' || strlen($id) > 100) {
    header('Location: /assets/images/blog-covers/cover-tech.jpg', true, 302);
    exit;
}

$row = null;
try {
    $st = db()->prepare("SELECT mime, bytes FROM blog_media WHERE post_id = ? LIMIT 1");
    $st->execute([$id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $row = null; }

if (!$row || (string)($row['bytes'] ?? '') === '') {
    header('Location: /assets/images/blog-covers/cover-tech.jpg', true, 302);
    exit;
}

$bytes = (string)$row['bytes'];
$mime  = (string)($row['mime'] ?: 'image/webp');
$etag  = '"' . md5($id . ':' . strlen($bytes)) . '"';

if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304);
    exit;
}

while (ob_get_level() > 0) { @ob_end_clean(); }
header('Content-Type: ' . $mime);
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: public, max-age=31536000, immutable');
header('ETag: ' . $etag);
echo $bytes;
