<?php
// Detached worker: php seo-job-run.php <job> <region> <args-json>
// Accepts real CLI *and* cgi-style CLI invocations (some hosts alias php to
// php-cgi) — but never a web request (web always carries REMOTE_ADDR).
if (!empty($_SERVER['REMOTE_ADDR']) || !empty($_SERVER['HTTP_HOST'])) {
    http_response_code(403);
    exit('CLI only');
}
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/seo-jobs.php';

$argvv  = $argv ?? ($_SERVER['argv'] ?? []);
$job    = (string)($argvv[1] ?? '');
$region = (string)($argvv[2] ?? '');
$args   = json_decode((string)($argvv[3] ?? '[]'), true) ?: [];
if ($job === '') { fwrite(STDERR, "usage: seo-job-run.php <job> [region] [args-json]\n"); exit(1); }

$res = seo_job_execute($job, $region, $args);
echo json_encode($res), "\n";
exit(empty($res['ok']) ? 1 : 0);
