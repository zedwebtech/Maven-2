<?php
/**
 * cron/weekly-reviews.php — keep products looking active over time.
 *
 * Adds a fresh batch of dated reviews (4–7 per elapsed day, capped) so the
 * review stream keeps flowing forward. Idempotent per day (won't double-add).
 * Real customer-submitted reviews are never touched.
 *
 * cPanel cron (weekly, Monday 04:10):
 *   10 4 * * 1 /usr/local/bin/php /home/USER/public_html/cron/weekly-reviews.php >/dev/null 2>&1
 * (a daily cron also works — it just adds ~5 reviews/day)
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/reviews-seed.php';

$added = mv_trickle_reviews();
echo "[weekly-reviews] added {$added} fresh reviews (as of " . date('Y-m-d') . ").\n";
