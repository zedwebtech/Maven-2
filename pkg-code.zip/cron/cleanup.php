<?php
/**
 * cron/cleanup.php — housekeeping so the project never bloats again.
 *
 * Deletes stray log files and clears the regenerable image-thumbnail cache.
 * Safe to run anytime (CLI or scheduled). Never touches source, uploads
 * (except uploads/cache), vendor, or the database.
 *
 * cPanel cron (runs daily at 03:15):
 *   15 3 * * * /usr/local/bin/php /home/USER/public_html/cron/cleanup.php >/dev/null 2>&1
 * (adjust the PHP path + public_html path to your account)
 */

$ROOT = dirname(__DIR__);
$isCli = (PHP_SAPI === 'cli');
$deleted = 0; $bytes = 0;
$log = [];

/* 1) Log files anywhere in the app (excluding vendor + .git) */
$rii = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($ROOT, FilesystemIterator::SKIP_DOTS)
);
foreach ($rii as $file) {
    $p = $file->getPathname();
    if (strpos($p, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR) !== false) continue;
    if (strpos($p, DIRECTORY_SEPARATOR . '.git' . DIRECTORY_SEPARATOR) !== false) continue;
    $base = $file->getFilename();
    $isLog = ($base === 'error_log' || $base === 'php_errorlog'
              || substr($base, -4) === '.log');
    if ($isLog && $file->isFile()) {
        $sz = $file->getSize();
        if (@unlink($p)) { $deleted++; $bytes += $sz; $log[] = "log: $p"; }
    }
}

/* 2) Regenerable image-thumbnail cache */
$cacheDir = $ROOT . '/uploads/cache';
if (is_dir($cacheDir)) {
    $cri = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($cacheDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($cri as $f) {
        if ($f->isFile()) {
            $sz = $f->getSize();
            if (@unlink($f->getPathname())) { $deleted++; $bytes += $sz; }
        } elseif ($f->isDir()) {
            @rmdir($f->getPathname());
        }
    }
    @mkdir($cacheDir . '/thumbs', 0775, true);
}

$msg = sprintf("[cleanup] removed %d files, freed %.0f KB", $deleted, $bytes / 1024);
if ($isCli) { echo $msg . "\n"; foreach ($log as $l) { /* verbose */ } }
else { header('Content-Type: text/plain'); echo $msg; }
