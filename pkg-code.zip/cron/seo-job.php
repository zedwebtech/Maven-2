<?php
// HTTP worker endpoint (token-guarded) — hit fire-and-forget by seo_job_spawn()
// when php-cli exec isn't available on the host.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/seo-bot.php';
require_once __DIR__ . '/../includes/seo-jobs.php';

if (!hash_equals(seo_bot_cron_token(), (string)($_GET['token'] ?? ''))) {
    http_response_code(403);
    exit('forbidden');
}

ignore_user_abort(true);       // keep running even after the spawner disconnects
@set_time_limit(900);
while (ob_get_level() > 0) @ob_end_clean();

$job    = (string)($_GET['job'] ?? '');
$region = (string)($_GET['region'] ?? '');
$args   = json_decode((string)($_GET['args'] ?? '[]'), true) ?: [];

header('Content-Type: application/json');
echo json_encode(seo_job_execute($job, $region, $args));
