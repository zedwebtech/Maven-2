<?php
/**
 * Daily Digest cron entry.
 * Schedule once a day in cPanel, e.g.:
 *   0 8 * * *  php /home/USER/public_html/cron/daily-digest.php
 * Safe to run more often — the once-a-day guard prevents duplicate emails.
 */
require_once __DIR__ . '/../includes/daily-digest.php';
$res = mv_daily_digest_maybe_send();
echo json_encode($res) . "\n";
