<?php
/**
 * /developers  (+ /developers.php, /api/docs) — Developer & Agent Resources hub.
 *
 * A single, name-searchable landing page that makes every machine-readable
 * resource (OpenAPI spec, JSON API, MCP server card, agents.json, llms.txt,
 * auth docs) discoverable by name. Product name appears in the <title> + H1 so
 * search engines surface it for "maventechsoftware developer/API" queries.
 */
require_once __DIR__ . '/includes/functions.php';

$brand = brand_name();
$base  = rtrim(site_url(), '/');

$pageTitle       = $brand . ' Developer & Agent API — OpenAPI, MCP & JSON Catalog';
$pageDescription = $brand . ' developer resources: a public read-only Catalog API (OpenAPI 3.1), MCP server card, agents.json manifest and llms.txt — everything an AI agent or developer needs to browse the software-license catalog programmatically.';
$canonicalUrl      = $base . '/developers';
$canonicalPathBare = '/developers';

// Public base for the machine-readable links (production host on live).
$pub = function_exists('public_base_url') ? rtrim(public_base_url(), '/') : $base;

$sections = [
    'Catalog API (OpenAPI 3.1)' => [
        ['GET ' . $pub . '/api',              'API index — version, links and available endpoints.'],
        ['GET ' . $pub . '/api/products',     'List active products. Filter with ?q= and ?category=, page with ?limit=&offset=.'],
        ['GET ' . $pub . '/api/products/{slug}', 'Fetch one product with live price, edition, platform, stock and activation URL.'],
        ['GET ' . $pub . '/api/categories',   'All categories with product counts and price ranges.'],
        ['GET ' . $pub . '/api/health',       'Service health check.'],
        ['GET ' . $pub . '/openapi.json',     'OpenAPI 3.1 specification (also at /api/openapi.json and /api/openapi.yaml).'],
    ],
    'Agent discovery' => [
        ['GET ' . $pub . '/.well-known/api-catalog',       'RFC 9727 API catalog (linkset) tying every resource together.'],
        ['GET ' . $pub . '/.well-known/mcp.json',          'Model Context Protocol (MCP) server card.'],
        ['GET ' . $pub . '/.well-known/agent-skills.json', 'Agent skills index (browse_catalog, get_product, …).'],
        ['GET ' . $pub . '/agents.json',                   'agents.json manifest — capabilities, endpoints and etiquette.'],
        ['GET ' . $pub . '/auth.md',                       'Authentication guide (spoiler: catalog reads need none).'],
    ],
    'AI content & policy' => [
        ['GET ' . $pub . '/llms.txt',      'llmstxt.org site summary with the live product index.'],
        ['GET ' . $pub . '/llms-full.txt', 'Expanded context — full catalog, policies, guides & FAQs inlined.'],
        ['GET ' . $pub . '/AGENTS.md',     'When-to-use guidance for agents.'],
        ['GET ' . $pub . '/robots.txt',    'Crawler policy (AI user-agents explicitly allowed).'],
        ['GET ' . $pub . '/sitemap.xml',   'Full URL list.'],
    ],
];

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5" style="max-width: 920px;" data-testid="developers-page">
  <style>
    [data-testid="developers-page"] code { word-break: break-word; overflow-wrap: anywhere; }
    [data-testid="developers-page"] pre { max-width: 100%; overflow-x: auto; white-space: pre-wrap; word-break: break-word; }
    [data-testid="developers-page"] .card h3 a code { word-break: break-all; }
  </style>
  <h1 class="fw-bold" data-testid="developers-title"><?= esc($brand) ?> Developer &amp; Agent Resources</h1>
  <p class="lead text-secondary" data-testid="developers-intro">
    <?= esc($brand) ?> publishes a <strong>public, read-only Catalog API</strong> plus a full set of AI-agent
    discovery documents. No API key, OAuth or bearer token is required to browse products or read prices.
    Every endpoint returns JSON, and every error is a structured JSON object with a stable
    <code>error.code</code>, a human <code>error.message</code> and an actionable <code>error.hint</code>.
  </p>

  <div class="alert alert-success d-flex gap-2 align-items-start" role="note">
    <i class="bi bi-lightning-charge-fill fs-5"></i>
    <div>
      <strong>Quick start:</strong> fetch the machine-readable API surface from
      <a href="<?= esc($pub) ?>/openapi.json" data-testid="dev-openapi-link"><code><?= esc($pub) ?>/openapi.json</code></a>,
      or list products at
      <a href="<?= esc($pub) ?>/api/products" data-testid="dev-products-link"><code><?= esc($pub) ?>/api/products</code></a>.
    </div>
  </div>

  <?php foreach ($sections as $heading => $rows): ?>
    <h2 class="fw-bold mt-4 mb-3"><?= esc($heading) ?></h2>
    <div class="row g-3">
      <?php foreach ($rows as [$endpoint, $desc]): ?>
        <?php [$verb, $url] = array_pad(explode(' ', $endpoint, 2), 2, ''); ?>
        <div class="col-12">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-body py-3">
              <h3 class="h6 fw-bold mb-1" style="word-break:break-all;">
                <span class="badge text-bg-dark me-2"><?= esc($verb) ?></span>
                <a href="<?= esc($url) ?>" class="text-decoration-none"><code><?= esc($url) ?></code></a>
              </h3>
              <p class="text-secondary small mb-0"><?= esc($desc) ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>

  <h2 class="fw-bold mt-5 mb-3">Example request</h2>
  <pre class="bg-dark text-light p-3 rounded" data-testid="developers-example" style="overflow:auto;"><code>curl -s "<?= esc($pub) ?>/api/products?category=windows-11&amp;limit=5" \
  -H "Accept: application/json"</code></pre>
  <p class="text-secondary small">
    All responses are cached for a few minutes and are safe to poll politely (please keep it
    under ~30 requests/minute). For anything beyond catalog reads (orders, accounts) a human is
    required — see <a href="<?= esc($pub) ?>/auth.md">the auth guide</a>.
  </p>

  <p class="mt-4">
    Questions? Contact <?= esc($brand) ?> support at
    <a href="/contact.php" data-testid="developers-contact">/contact.php</a>.
  </p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
