-- Maventech: set MSRP-style original prices so the "% Off" badge shows.
-- Safe to run on a live DB: only touches the products.original_price column
-- (does NOT affect orders, license keys, settings, or customers).
-- Discounts vary ~23% / ~30% / ~35% for a natural look. Adjust per product
-- anytime in Admin -> Products.
UPDATE products
SET original_price = ROUND(price * (CASE MOD(id,3) WHEN 0 THEN 1.30 WHEN 1 THEN 1.43 ELSE 1.54 END) / 10) * 10 - 0.01
WHERE price > 0;
