<?php
/**
 * /api/* — Maventech Software PUBLIC, read-only catalog API.
 *
 * Returns JSON for every route, including STRUCTURED JSON ERRORS (with a stable
 * error.code, human error.message and an actionable error.hint) so agents never
 * receive an HTML error page. No authentication required.
 *
 * Routed from router.php (dev preview) and .htaccess (Apache) for any /api/…
 * path. The sub-path is derived from REQUEST_URI here so both work identically.
 *
 * Routes:
 *   GET /api                    → API index (links + version)
 *   GET /api/health             → health check
 *   GET /api/products           → list (q, category, limit, offset)
 *   GET /api/products/{slug}    → single product
 *   GET /api/categories         → categories with counts + price ranges
 *   GET /api/openapi.json|.yaml → OpenAPI 3.1 spec
 */
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Accept, Content-Type');
header('Cache-Control: public, max-age=300');
header('X-Content-Type-Options: nosniff');

$base = function_exists('public_base_url') ? rtrim(public_base_url(), '/') : rtrim(site_url(), '/');

/** Emit a structured JSON error and stop. */
function api_error(int $status, string $code, string $message, string $hint = ''): void {
    global $base;
    http_response_code($status);
    echo json_encode([
        'error' => array_filter([
            'code'    => $code,
            'message' => $message,
            'hint'    => $hint !== '' ? $hint : null,
        ], static fn($v) => $v !== null),
        'status'        => $status,
        'documentation' => $base . '/developers',
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/** Emit a JSON success body and stop. */
function api_ok(array $body, int $status = 200): void {
    http_response_code($status);
    echo json_encode($body, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/** Shape a DB product row into the public API resource. */
function api_product_resource(array $p, array $availMap, string $base): array {
    $img = (string)($p['image'] ?? '');
    if ($img !== '' && !preg_match('#^https?://#i', $img)) {
        $img = $base . '/' . ltrim($img, '/');
    }
    $desc = trim((string)($p['description'] ?? ''));
    if ($desc !== '') {
        $desc = trim(preg_replace('/\s+/u', ' ', strip_tags($desc)));
        if (mb_strlen($desc) > 600) $desc = rtrim(mb_substr($desc, 0, 600), " ,;:-—") . '…';
    }
    $orig = (float)($p['original_price'] ?? 0);
    return [
        'slug'             => (string)$p['slug'],
        'name'             => (string)$p['name'],
        'price'            => round((float)$p['price'], 2),
        'compare_at_price' => $orig > (float)$p['price'] ? round($orig, 2) : null,
        'currency'         => 'USD',
        'category'         => (string)($p['category'] ?? ''),
        'brand'            => ($p['brand'] ?? '') ?: null,
        'platform'         => ($p['platform'] ?? '') ?: null,
        'version'          => ($p['version'] ?? '') ?: null,
        'year'             => ($p['year'] ?? '') ? (string)$p['year'] : null,
        'license_type'     => ($p['license_type'] ?? '') ?: null,
        'sku'              => ($p['sku'] ?? '') ?: null,
        'gtin'             => ($p['gtin'] ?? '') ?: null,
        'in_stock'         => (($availMap[$p['slug']] ?? 0) > 0),
        'badge'            => ($p['badge'] ?? '') ?: null,
        'description'      => $desc !== '' ? $desc : null,
        'activation_url'   => ($p['activation_url'] ?? '') ?: null,
        'url'              => $base . '/product.php?slug=' . rawurlencode((string)$p['slug']),
        'image'            => $img !== '' ? $img : null,
    ];
}

// ---- Method guard: read-only surface -------------------------------------
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method === 'OPTIONS') { http_response_code(204); exit; }
if ($method !== 'GET' && $method !== 'HEAD') {
    api_error(405, 'method_not_allowed', 'This endpoint is read-only and only supports GET.', 'Retry the request with the GET method.');
}

// ---- Derive the sub-path under /api --------------------------------------
$uriPath = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
$uriPath = rawurldecode($uriPath);
$sub = preg_replace('#^/api/?#', '', $uriPath);   // "" | "health" | "products" | "products/{slug}" | ...
$sub = trim($sub, '/');
$parts = $sub === '' ? [] : explode('/', $sub);

try {
    // GET /api  → index
    if (count($parts) === 0) {
        api_ok([
            'name'          => brand_name() . ' Catalog API',
            'version'       => '1.0.0',
            'access'        => 'public, read-only, no authentication',
            'documentation' => $base . '/developers',
            'openapi'       => $base . '/openapi.json',
            'endpoints'     => [
                'health'        => $base . '/api/health',
                'products'      => $base . '/api/products',
                'product'       => $base . '/api/products/{slug}',
                'categories'    => $base . '/api/categories',
            ],
        ]);
    }

    // OpenAPI spec under /api
    if ($parts[0] === 'openapi.json' || $parts[0] === 'openapi') {
        require __DIR__ . '/openapi.php';
        exit;
    }
    if ($parts[0] === 'openapi.yaml' || $parts[0] === 'openapi.yml') {
        $GLOBALS['MV_OPENAPI_FORMAT'] = 'yaml';
        require __DIR__ . '/openapi.php';
        exit;
    }

    $pdo = db();

    if ($parts[0] === 'health' && count($parts) === 1) {
        $n = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1")->fetchColumn();
        api_ok(['status' => 'ok', 'time' => gmdate('c'), 'products_active' => $n]);
    }

    if ($parts[0] === 'categories' && count($parts) === 1) {
        $rows = $pdo->query("SELECT COALESCE(category,'other') AS category, COUNT(*) c, MIN(price) min_p, MAX(price) max_p
                               FROM products WHERE is_active=1 GROUP BY category ORDER BY c DESC")->fetchAll();
        $data = array_map(static fn($r) => [
            'category'  => (string)$r['category'],
            'count'     => (int)$r['c'],
            'min_price' => round((float)$r['min_p'], 2),
            'max_price' => round((float)$r['max_p'], 2),
        ], $rows);
        api_ok(['data' => $data, 'meta' => ['total' => count($data)]]);
    }

    if ($parts[0] === 'products') {
        // Availability map (shared).
        $availMap = [];
        try {
            foreach ($pdo->query("SELECT product_slug, COUNT(*) c FROM license_keys WHERE status='available' GROUP BY product_slug") as $r) {
                $availMap[$r['product_slug']] = (int)$r['c'];
            }
        } catch (Throwable $e) {}

        // GET /api/products/{slug}
        if (count($parts) >= 2) {
            $slug = $parts[1];
            $st = $pdo->prepare("SELECT * FROM products WHERE slug = ? AND is_active = 1 LIMIT 1");
            $st->execute([$slug]);
            $p = $st->fetch();
            if (!$p) {
                api_error(404, 'not_found', 'No active product matches slug "' . $slug . '".',
                          'List valid slugs with GET ' . $base . '/api/products.');
            }
            api_ok(['data' => api_product_resource($p, $availMap, $base)]);
        }

        // GET /api/products  (list + filter + paginate)
        $q       = trim((string)($_GET['q'] ?? ''));
        $cat     = trim((string)($_GET['category'] ?? ''));
        $limit   = (int)($_GET['limit'] ?? 20);
        $offset  = (int)($_GET['offset'] ?? 0);
        if (isset($_GET['limit']) && (!ctype_digit((string)$_GET['limit']) || $limit < 1 || $limit > 100)) {
            api_error(400, 'invalid_request', 'The "limit" parameter must be an integer between 1 and 100.', 'Try ?limit=20.');
        }
        if (isset($_GET['offset']) && (!ctype_digit((string)$_GET['offset']))) {
            api_error(400, 'invalid_request', 'The "offset" parameter must be a non-negative integer.', 'Try ?offset=0.');
        }
        $limit  = max(1, min(100, $limit));
        $offset = max(0, $offset);

        $where = ['is_active = 1'];
        $args  = [];
        if ($cat !== '') { $where[] = 'category = ?'; $args[] = $cat; }
        if ($q !== '')   { $where[] = '(name LIKE ? OR brand LIKE ? OR category LIKE ?)'; $like = '%' . $q . '%'; array_push($args, $like, $like, $like); }
        $whereSql = implode(' AND ', $where);

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE $whereSql");
        $countStmt->execute($args);
        $total = (int)$countStmt->fetchColumn();

        $listStmt = $pdo->prepare("SELECT * FROM products WHERE $whereSql ORDER BY category, name LIMIT $limit OFFSET $offset");
        $listStmt->execute($args);
        $rows = $listStmt->fetchAll();

        $data = array_map(static fn($p) => api_product_resource($p, $availMap, $base), $rows);
        api_ok(['data' => $data, 'meta' => ['total' => $total, 'limit' => $limit, 'offset' => $offset]]);
    }

    // Nothing matched.
    api_error(404, 'not_found', 'Unknown API route: /api/' . $sub . '.',
              'See the available routes at GET ' . $base . '/api or the OpenAPI spec at ' . $base . '/openapi.json.');
} catch (Throwable $e) {
    @error_log('[api] ' . $e->getMessage());
    api_error(500, 'internal_error', 'An unexpected error occurred while handling the request.',
              'Retry shortly. If it persists, contact support via ' . $base . '/contact.php.');
}
