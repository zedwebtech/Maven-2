<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle       = 'Customer Reviews | ' . brand_name();
$pageDescription = 'Read verified customer reviews of ' . brand_name() . ' - real feedback on Microsoft Office keys, Windows 11 activations and antivirus purchases, plus star-by-star ratings from independent buyers.';

/* ----- Write a Review (verified buyers only) ----- */
$user = current_user();
$purchased = [];
if ($user) {
    $stmt = db()->prepare("SELECT DISTINCT oi.name FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.status = 'paid' AND (o.user_id = ? OR o.email = ?)");
    $stmt->execute([$user['id'], $user['email']]);
    $purchased = array_column($stmt->fetchAll(), 'name');
}
$reviewErr = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['write_review'])) {
    $text = trim($_POST['text'] ?? '');
    $location = trim($_POST['location'] ?? '');
    // Customer must explicitly pick a star — no default fallback to 5.  When
    // no rating is submitted, the form will show an inline error and reopen.
    $ratingRaw = $_POST['rating'] ?? '';
    $rating = is_numeric($ratingRaw) ? min(5, max(1, (int)$ratingRaw)) : 0;
    $product = (string)($_POST['product'] ?? '');
    if (!$user) {
        $reviewErr = 'Please sign in to write a review.';
    } elseif (!$purchased) {
        $reviewErr = 'Only verified buyers can write reviews.';
    } elseif ($rating < 1) {
        $reviewErr = 'Please pick a star rating before submitting.';
    } elseif (strlen($text) < 10) {
        $reviewErr = 'Please write at least 10 characters.';
    } else {
        if (!in_array($product, $purchased, true)) $product = $purchased[0];
        $parts = preg_split('/\s+/', trim($user['name']));
        $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
        $ins = db()->prepare('INSERT INTO reviews (name, initials, location, review_date, rating, text, product, verified) VALUES (?, ?, ?, CURDATE(), ?, ?, ?, 1)');
        $ins->execute([$user['name'], $initials, $location !== '' ? $location : 'Verified Buyer', $rating, $text, $product]);
        // Bubble up to the admin PWA bell so the team can moderate / share.
        admin_notify(
            'review',
            $rating . '★ on-site review from ' . $user['name'],
            mb_substr($text, 0, 140, 'UTF-8'),
            '/admin.php?tab=reviews'
        );
        header('Location: reviews.php?submitted=1');
        exit;
    }
}

$perPage = 10;
$page = max(1, (int)($_GET['p'] ?? 1));
// Reviews page is driven SOLELY by the verified customer_reviews set (the same
// source as each product page). The legacy `reviews` table is intentionally
// excluded so counts stay consistent (~4-7/day over ~2 months) on every host.
$totalStatic = 0;
$totalCustomer = 0;
try {
    // PINNED to the baseline (mv_review_display_count) so the shown total never
    // drifts/multiplies on redeploys — the store always displays ~1300.
    $totalCustomer = function_exists('mv_review_display_count')
        ? mv_review_display_count()
        : (int)db()->query("SELECT COUNT(*) c FROM customer_reviews WHERE status='published' AND rating IS NOT NULL")->fetch()['c'];
} catch (Throwable $e) {}
$total = $totalCustomer;
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;
$list = db()->query("
    SELECT id + 100000 AS id,
           customer_name COLLATE utf8mb4_unicode_ci AS name,
           UPPER(LEFT(customer_name, 2)) COLLATE utf8mb4_unicode_ci AS initials,
           'Verified Buyer' AS location,
           DATE(submitted_at) AS review_date,
           rating,
           comment COLLATE utf8mb4_unicode_ci AS text,
           COALESCE((SELECT p.name FROM products p WHERE p.slug = cr.product_slug LIMIT 1), 'Software Product') COLLATE utf8mb4_unicode_ci AS product,
           1 AS verified,
           'internal' COLLATE utf8mb4_unicode_ci AS source,
           '' COLLATE utf8mb4_unicode_ci AS source_url,
           '' COLLATE utf8mb4_unicode_ci AS avatar_url
    FROM customer_reviews cr
    WHERE cr.status = 'published' AND cr.rating IS NOT NULL
    ORDER BY review_date DESC, id DESC
    LIMIT $perPage OFFSET $offset
")->fetchAll();

// Real aggregate rating + star distribution computed from customer_reviews only.
$avgRow = db()->query("
    SELECT COALESCE(AVG(rating),0) avg FROM customer_reviews WHERE status='published' AND rating IS NOT NULL
")->fetch();
$avgRating = round((float)$avgRow['avg'], 1);
$dist = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
foreach (db()->query("
    SELECT ROUND(rating) r, COUNT(*) c FROM customer_reviews WHERE status='published' AND rating IS NOT NULL GROUP BY ROUND(rating)
")->fetchAll() as $dr) {
    $rk = (int)$dr['r'];
    if (isset($dist[$rk])) $dist[$rk] = (int)$dr['c'];
}
$distPct = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
$distTotal = array_sum($dist); // RAW per-star total (may exceed pinned $total)
if ($distTotal > 0) { foreach ($dist as $k => $v) $distPct[$k] = min(100, (int)round($v * 100 / $distTotal)); }

include __DIR__ . '/includes/header.php';
?>
<?= render_page_head('Customer Reviews', 'Independent, verified feedback from real customers — updated continuously.', ['Reviews' => null]) ?>
<div class="container py-4 py-lg-5">

  <!-- Summary panel -->
  <?php if ($total > 0): ?>
  <div class="card p-4 p-lg-5 mb-5" data-testid="reviews-summary">
    <div class="row g-4 align-items-center">
      <div class="col-lg-4 text-center">
        <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
          <?= render_logo(34) ?>
          <span class="fw-bold small"><?= esc(brand_name()) ?></span>
        </div>
        <div class="display-3 fw-bold text-primary lh-1" data-testid="reviews-overall"><?= number_format($avgRating, 1) ?></div>
        <div class="text-warning fs-5"><?= render_stars($avgRating) ?></div>
        <div class="small text-secondary mt-1"><strong class="text-body"><?= number_format($total) ?></strong> verified review<?= $total === 1 ? '' : 's' ?></div>
        <span class="badge text-bg-success mt-2"><i class="bi bi-patch-check-fill me-1"></i>Verified Customer Reviews</span>
        <?php $googleProfileUrl = setting_get('google_reviews_profile_url', ''); if ($googleProfileUrl !== ''): ?>
          <div class="mt-3">
            <a href="<?= esc($googleProfileUrl) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary rounded-pill px-3 d-inline-flex align-items-center gap-2" data-testid="reviews-see-on-google-cta">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
              See all reviews on Google
            </a>
          </div>
        <?php endif; ?>
      </div>
      <div class="col-lg-8">
        <?php foreach ($distPct as $stars => $pct): ?>
          <div class="d-flex align-items-center gap-2 py-1 small">
            <span style="width:14px;" class="fw-bold"><?= $stars ?></span><i class="bi bi-star-fill text-warning"></i>
            <div class="progress flex-grow-1" style="height:8px;"><div class="progress-bar <?= $stars >= 4 ? 'bg-success' : ($stars === 3 ? 'bg-warning' : 'bg-danger') ?>" style="width:<?= $pct ?>%"></div></div>
            <span class="text-secondary" style="width:36px;"><?= $pct ?>%</span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Reviews list -->
  <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <div class="d-flex align-items-center gap-3 flex-wrap">
      <h2 class="h5 fw-bold mb-0">Customer Reviews</h2>
      <small class="text-secondary" data-testid="reviews-range"><?php if ($total > 0): ?>Showing <?= $offset + 1 ?>–<?= min($offset + $perPage, $total) ?> of <?= $total ?> reviews<?php else: ?>No reviews yet<?php endif; ?></small>
    </div>
    <?php if ($user): ?>
      <button class="btn btn-primary btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#writeReviewModal" data-testid="write-review-btn"><i class="bi bi-pencil-square me-1"></i>Write a Review</button>
    <?php else: ?>
      <a href="login.php?next=reviews.php" class="btn btn-primary btn-sm rounded-pill px-3" data-testid="write-review-btn"><i class="bi bi-pencil-square me-1"></i>Write a Review</a>
    <?php endif; ?>
  </div>

  <?php if (isset($_GET['submitted'])): ?>
    <div class="alert alert-success d-flex align-items-center gap-2" data-testid="review-success-alert"><i class="bi bi-patch-check-fill"></i>Thank you! Your verified review has been published.</div>
  <?php elseif ($reviewErr): ?>
    <div class="alert alert-danger" data-testid="review-error-alert"><?= esc($reviewErr) ?></div>
  <?php endif; ?>

  <div class="d-grid gap-3 mb-4" data-testid="reviews-list">
    <?php if (!$list): ?>
      <div class="card p-5 text-center" data-testid="reviews-empty">
        <i class="bi bi-chat-square-heart fs-1 text-secondary"></i>
        <p class="fw-semibold mt-2 mb-1">No reviews yet</p>
        <p class="small text-secondary mb-0">Be the first verified buyer to share your experience.</p>
      </div>
    <?php endif; ?>
    <?php foreach ($list as $r): $isGoogle = ($r['source'] ?? '') === 'google'; ?>
      <div class="card p-4<?= $isGoogle ? ' border-primary' : '' ?>" data-testid="review-<?= (int)$r['id'] ?>" data-source="<?= esc($r['source'] ?? 'internal') ?>">
        <div class="d-flex gap-3">
          <?php if ($isGoogle && !empty($r['avatar_url'])): ?>
            <img src="<?= esc($r['avatar_url']) ?>" alt="<?= esc($r['name']) ?>" class="rounded-circle flex-shrink-0" style="width:44px;height:44px;object-fit:cover;" loading="lazy">
          <?php else: ?>
            <span class="logo-mark flex-shrink-0" style="width:44px;height:44px;font-size:.85rem;"><?= esc($r['initials']) ?></span>
          <?php endif; ?>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between flex-wrap gap-2">
              <div>
                <strong><?= esc($r['name']) ?></strong>
                <?php if ($isGoogle): ?>
                  <span class="badge d-inline-flex align-items-center gap-1 ms-1" style="background:#fff;color:#3c4043;border:1px solid #dadce0;font-size:.62rem;padding:.28rem .55rem;" title="Review from Google">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
                    From Google
                  </span>
                <?php elseif ($r['verified']): ?>
                  <span class="badge text-bg-success ms-1" style="font-size:.62rem;"><i class="bi bi-patch-check-fill me-1"></i>Verified</span>
                <?php endif; ?>
                <small class="text-secondary ms-1"><?= esc($r['location']) ?></small>
              </div>
              <small class="text-secondary"><?= esc(date('M j, Y', strtotime($r['review_date']))) ?></small>
            </div>
            <div class="text-warning small my-1"><?= str_repeat('★', (int)$r['rating']) ?><span class="text-secondary opacity-50"><?= str_repeat('★', 5 - (int)$r['rating']) ?></span></div>
            <p class="mb-1"><?= esc($r['text']) ?></p>
            <?php if ($r['product']): ?><small class="text-secondary"><i class="bi bi-bag-check-fill text-primary me-1"></i>Purchased: <?= esc($r['product']) ?></small><?php endif; ?>
            <?php if ($isGoogle && !empty($r['source_url'])): ?>
              <div class="mt-2"><a href="<?= esc($r['source_url']) ?>" target="_blank" rel="noopener" class="small text-decoration-none" data-testid="google-review-source-link"><i class="bi bi-box-arrow-up-right me-1"></i>View this review on Google</a></div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Pagination -->
  <?php if ($total > 0): ?>
  <?php
    // Compact windowed pagination — show at most 5 page numbers around the
    // current page, with First / … / Last shortcuts so the bar stays elegant
    // even with hundreds of pages.
    $win   = 5;
    $start = max(1, $page - (int)floor($win / 2));
    $end   = min($pages, $start + $win - 1);
    $start = max(1, $end - $win + 1);
  ?>
  <nav class="d-flex justify-content-center align-items-center flex-wrap gap-2" data-testid="reviews-pagination">
    <a class="btn btn-sm btn-outline-secondary rounded-pill px-3 <?= $page <= 1 ? 'disabled' : '' ?>" href="?p=<?= max(1, $page - 1) ?>" data-testid="reviews-prev">&lsaquo; Previous</a>
    <?php if ($start > 1): ?>
      <a class="btn btn-sm btn-outline-secondary rounded-circle d-flex align-items-center justify-content-center" style="width:38px;height:38px;" href="?p=1" data-testid="reviews-page-1">1</a>
      <?php if ($start > 2): ?><span class="px-1 text-secondary">&hellip;</span><?php endif; ?>
    <?php endif; ?>
    <?php for ($i = $start; $i <= $end; $i++): ?>
      <a class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-circle d-flex align-items-center justify-content-center" style="width:38px;height:38px;" href="?p=<?= $i ?>" data-testid="reviews-page-<?= $i ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($end < $pages): ?>
      <?php if ($end < $pages - 1): ?><span class="px-1 text-secondary">&hellip;</span><?php endif; ?>
      <a class="btn btn-sm btn-outline-secondary rounded-circle d-flex align-items-center justify-content-center" style="width:38px;height:38px;" href="?p=<?= $pages ?>" data-testid="reviews-page-<?= $pages ?>"><?= $pages ?></a>
    <?php endif; ?>
    <a class="btn btn-sm btn-outline-secondary rounded-pill px-3 <?= $page >= $pages ? 'disabled' : '' ?>" href="?p=<?= min($pages, $page + 1) ?>" data-testid="reviews-next">Next &rsaquo;</a>
  </nav>
  <p class="text-center small text-secondary mt-2">Page <?= $page ?> of <?= $pages ?></p>
  <?php endif; ?>

  <div class="rounded-4 text-center text-white p-5 mt-5" style="background: linear-gradient(135deg, #2563eb, #4338ca);">
    <h2 class="fw-bold h3">Join Our Happy Customers</h2>
    <p class="opacity-75">product keys, digital delivery, and support that actually helps.</p>
    <a href="shop.php" class="btn btn-light rounded-pill px-4 fw-semibold">Browse Products</a>
  </div>
</div>

<!-- Write a Review modal -->
<div class="modal fade" id="writeReviewModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2 text-primary"></i>Write a Review</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?php if ($user && $purchased): ?>
      <form method="post" data-testid="write-review-form">
        <div class="modal-body">
          <?php if ($reviewErr): ?>
            <div class="alert alert-warning py-2 small" data-testid="review-error"><i class="bi bi-exclamation-triangle-fill me-1"></i><?= esc($reviewErr) ?></div>
          <?php endif; ?>
          <input type="hidden" name="write_review" value="1">
          <div class="mb-1 small fw-semibold">Your rating <span class="text-danger">*</span></div>
          <div class="star-input mb-1" data-testid="review-star-input" role="radiogroup" aria-label="Star rating">
            <?php for ($s = 5; $s >= 1; $s--): ?>
              <input type="radio" name="rating" id="star<?= $s ?>" value="<?= $s ?>" data-testid="star-radio-<?= $s ?>">
              <label for="star<?= $s ?>" title="<?= $s ?> star<?= $s > 1 ? 's' : '' ?>" data-testid="star-label-<?= $s ?>">★</label>
            <?php endfor; ?>
          </div>
          <div class="small text-secondary mb-3" data-testid="star-hint">Tap a star — left to right. The picked count fills in gold; the rest stay empty.</div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Product purchased</label>
            <select name="product" class="form-select" data-testid="review-product-select">
              <?php foreach ($purchased as $pn): ?><option><?= esc($pn) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Location <span class="text-secondary fw-normal">(optional)</span></label>
            <input name="location" class="form-control" placeholder="e.g. Austin, TX" maxlength="60" data-testid="review-location-input">
          </div>
          <div class="mb-2">
            <label class="form-label small fw-semibold">Your review</label>
            <textarea name="text" class="form-control" rows="4" required minlength="10" maxlength="1000" placeholder="Share your experience with the product and our service..." data-testid="review-text-input"></textarea>
          </div>
          <small class="text-secondary"><i class="bi bi-patch-check-fill text-success me-1"></i>Posting as <strong><?= esc($user['name']) ?></strong> — Verified Buyer</small>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary rounded-pill px-4" data-testid="review-submit-btn">Submit Review</button>
        </div>
      </form>
      <?php elseif ($user): ?>
      <div class="modal-body text-center py-4" data-testid="review-not-buyer">
        <i class="bi bi-bag-x fs-1 text-secondary"></i>
        <p class="fw-semibold mt-2 mb-1">Only verified buyers can write reviews</p>
        <p class="small text-secondary mb-3">Reviews are limited to customers with a completed purchase — that's how we keep every rating genuine.</p>
        <a href="shop.php" class="btn btn-primary rounded-pill px-4">Browse Products</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php if ($reviewErr): ?>
<script>document.addEventListener('DOMContentLoaded', () => new bootstrap.Modal(document.getElementById('writeReviewModal')).show());</script>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
