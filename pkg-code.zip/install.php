<?php
/**
 * install.php — one-click guided database installer for cPanel / shared hosting.
 *
 * Reads the DB credentials from config.php, then imports the bundled
 * zedwgsyk_maventech.sql into the database with a single click. Standalone:
 * it does NOT boot the app (so it works before the DB exists).
 *
 * SECURITY: DELETE this file after a successful install. It also self-locks
 * (uploads/.installed) and requires typing IMPORT to confirm.
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);

$ROOT     = __DIR__;
$SQL_FILE = $ROOT . '/zedwgsyk_maventech.sql';
$LOCK     = $ROOT . '/uploads/.installed';

// Pull DB credentials from config.php constants (fallback to form input).
@require_once $ROOT . '/config.php';
$cfg = [
    'host' => defined('DB_HOST') ? DB_HOST : 'localhost',
    'name' => defined('DB_NAME') ? DB_NAME : '',
    'user' => defined('DB_USER') ? DB_USER : '',
    'pass' => defined('DB_PASS') ? DB_PASS : '',
];

$msg = null; $err = null; $done = false;
$host = $_POST['host'] ?? $cfg['host'];
$name = $_POST['name'] ?? $cfg['name'];
$user = $_POST['user'] ?? $cfg['user'];
$pass = $_POST['pass'] ?? $cfg['pass'];
$action = $_POST['action'] ?? '';

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }

if ($action === 'test' || $action === 'import') {
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = @mysqli_connect($host, $user, $pass);
    if (!$c) {
        $err = 'Could not connect to MySQL: ' . mysqli_connect_error();
    } else {
        @mysqli_query($c, "CREATE DATABASE IF NOT EXISTS `" . str_replace('`','',$name) . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        if (!@mysqli_select_db($c, $name)) {
            $err = "Connected, but database '" . h($name) . "' does not exist and could not be created.";
        } elseif ($action === 'test') {
            $msg = "✓ Connection OK. Database '" . h($name) . "' is reachable and ready for import.";
        } elseif ($action === 'import') {
            if (($_POST['confirm'] ?? '') !== 'IMPORT') {
                $err = 'Please type IMPORT in the confirmation box to proceed.';
            } elseif (!is_file($SQL_FILE)) {
                $err = 'Bundled SQL file not found: zedwgsyk_maventech.sql';
            } else {
                $sql = file_get_contents($SQL_FILE);
                mysqli_query($c, 'SET FOREIGN_KEY_CHECKS=0');
                $ok = mysqli_multi_query($c, $sql);
                $stmts = 0; $ferr = null;
                if ($ok) {
                    do { $stmts++; if ($r = mysqli_store_result($c)) mysqli_free_result($r); }
                    while (mysqli_more_results($c) && mysqli_next_result($c));
                    if (mysqli_errno($c)) $ferr = mysqli_error($c);
                } else {
                    $ferr = mysqli_error($c);
                }
                mysqli_query($c, 'SET FOREIGN_KEY_CHECKS=1');
                if ($ferr) {
                    $err = 'Import error: ' . h($ferr);
                } else {
                    @file_put_contents($LOCK, date('c'));
                    $pc = (int)@mysqli_fetch_row(mysqli_query($c, "SELECT COUNT(*) FROM products"))[0];
                    $msg = "✓ Database imported successfully ({$stmts} statements, {$pc} products). "
                         . "Your store is ready. IMPORTANT: delete install.php now.";
                    $done = true;
                }
            }
        }
        mysqli_close($c);
    }
}
$already = is_file($LOCK);
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Maventech — Database Installer</title>
<style>
  :root{--ink:#0f172a;--mut:#64748b;--bd:#e2e8f0;--blue:#2563eb;--ok:#047857;--bad:#b91c1c}
  *{box-sizing:border-box}
  body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#f1f5f9;color:var(--ink);line-height:1.5}
  .wrap{max-width:640px;margin:40px auto;padding:0 18px}
  .card{background:#fff;border:1px solid var(--bd);border-radius:16px;padding:28px;box-shadow:0 10px 30px rgba(15,23,42,.06)}
  h1{font-size:1.45rem;margin:0 0 4px}
  .sub{color:var(--mut);margin:0 0 22px;font-size:.95rem}
  .step{font-size:.72rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--blue);margin:18px 0 6px}
  label{display:block;font-size:.8rem;font-weight:600;color:var(--mut);margin:10px 0 4px}
  input[type=text],input[type=password]{width:100%;padding:10px 12px;border:1px solid var(--bd);border-radius:9px;font-size:.95rem}
  .row{display:flex;gap:12px}.row>div{flex:1}
  .btn{display:inline-flex;align-items:center;gap:8px;border:0;border-radius:999px;padding:11px 22px;font-weight:700;font-size:.95rem;cursor:pointer;text-decoration:none}
  .btn-primary{background:var(--blue);color:#fff}.btn-ghost{background:#f1f5f9;color:var(--ink)}
  .btn-go{background:#f97316;color:#fff}
  .alert{padding:12px 14px;border-radius:10px;margin:14px 0;font-size:.9rem}
  .alert.ok{background:#ecfdf5;color:var(--ok);border:1px solid #a7f3d0}
  .alert.bad{background:#fef2f2;color:var(--bad);border:1px solid #fecaca}
  .alert.warn{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
  .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
  code{background:#f1f5f9;padding:1px 6px;border-radius:5px;font-size:.85rem}
  hr{border:0;border-top:1px solid var(--bd);margin:22px 0}
</style></head><body>
<div class="wrap"><div class="card">
  <h1>Maventech — Database Installer</h1>
  <p class="sub">Import your store database in one click. This page is standalone and safe to run before the app is set up.</p>

  <?php if ($msg): ?><div class="alert ok"><?= $msg ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert bad"><?= $err ?></div><?php endif; ?>
  <?php if ($already && !$done): ?><div class="alert warn">This site already has an install lock (<code>uploads/.installed</code>). Re-importing will OVERWRITE existing data. Only continue if you are sure.</div><?php endif; ?>

  <?php if ($done): ?>
    <div class="alert warn"><strong>Final step —</strong> for security, delete <code>install.php</code> from your server now. Then visit your homepage.</div>
    <div class="actions"><a class="btn btn-primary" href="/">Open the store →</a></div>
  <?php else: ?>
  <form method="post">
    <div class="step">Step 1 · Database credentials</div>
    <p class="sub" style="margin:0 0 6px">Pre-filled from <code>config.php</code>. Edit only if your cPanel database differs.</p>
    <div class="row">
      <div><label>DB Host</label><input type="text" name="host" value="<?= h($host) ?>"></div>
      <div><label>Database name</label><input type="text" name="name" value="<?= h($name) ?>"></div>
    </div>
    <div class="row">
      <div><label>DB User</label><input type="text" name="user" value="<?= h($user) ?>"></div>
      <div><label>DB Password</label><input type="password" name="pass" value="<?= h($pass) ?>"></div>
    </div>
    <div class="actions">
      <button class="btn btn-ghost" name="action" value="test">Test connection</button>
    </div>

    <hr>
    <div class="step">Step 2 · Import database</div>
    <p class="sub" style="margin:0 0 6px">Imports the bundled <code>zedwgsyk_maventech.sql</code> (products, pages, settings, reviews). Type <code>IMPORT</code> to confirm.</p>
    <label>Confirmation</label>
    <input type="text" name="confirm" placeholder="Type IMPORT here" autocomplete="off">
    <div class="actions">
      <button class="btn btn-go" name="action" value="import">Import database now</button>
    </div>
  </form>
  <?php endif; ?>
</div>
<p class="sub" style="text-align:center;margin-top:14px">Payment credentials &amp; sample reviews self-configure on first page load — no extra steps.</p>
</div></body></html>
