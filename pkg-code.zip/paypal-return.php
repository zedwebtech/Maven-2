<?php
/**
 * paypal-return.php
 *
 * Buyer lands here after approving (or cancelling) a PayPal payment.
 * We capture the approved order via the PayPal Orders API and mark our order
 * paid ONLY when the capture status is COMPLETED. Never trust the redirect
 * alone — the capture call is the source of truth.
 *
 * Query: ?order=<our order_number>&token=<paypal order id>&PayerID=<...>
 *        ?paypal=cancel                                  (buyer cancelled)
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/email.php';      // fulfill_order()
require_once __DIR__ . '/includes/recovery.php';   // mv_mark_payment_failed()
require_once __DIR__ . '/includes/gateways/paypal-api.php';

$orderNumber   = trim((string)($_GET['order'] ?? ''));
$paypalOrderId = trim((string)($_GET['token'] ?? ''));

function pp_bounce(string $url): void { header('Location: ' . $url, true, 302); exit; }

// Buyer cancelled on PayPal.
if (($_GET['paypal'] ?? '') === 'cancel' || $orderNumber === '') {
    pp_bounce('checkout.php?paypal=cancel');
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM orders WHERE order_number = ? LIMIT 1');
$stmt->execute([$orderNumber]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) { pp_bounce('checkout.php?paypal=error'); }

$orderId = (int)$order['id'];

// Already paid? (e.g. double click / refresh) — just show success.
if (in_array((string)($order['payment_status'] ?? ''), ['succeeded', 'paid'], true)
    || (string)($order['status'] ?? '') === 'paid') {
    pp_bounce('order-success.php?order=' . urlencode($orderNumber));
}

// Fall back to the PayPal order id we stashed on the order (PP:xxxx).
if ($paypalOrderId === '') {
    $stored = (string)($order['transaction_id'] ?? '');
    if (str_starts_with($stored, 'PP:')) $paypalOrderId = substr($stored, 3);
}
if ($paypalOrderId === '') {
    if (function_exists('mv_mark_payment_failed')) {
        mv_mark_payment_failed($order, ['code'=>'paypal_no_token', 'message'=>'Missing PayPal order token on return.']);
    }
    pp_bounce('checkout.php?paypal=error');
}

// Mode: use the mode the order was created in, else the current gateway mode.
$mode = (string)($order['gw_mode'] ?? '') ?: (setting_get('gw_mode', 'test') === 'live' ? 'live' : 'test');
$mode = ($mode === 'live') ? 'live' : 'test';

try {
    $cap = paypal_capture_order($paypalOrderId, $mode);
} catch (Throwable $e) {
    @error_log('[paypal-return capture] ' . $e->getMessage());
    $cap = ['ok'=>false, 'pending'=>false, 'status'=>'ERROR', 'capture_id'=>'', 'code'=>'EXCEPTION', 'error'=>'PayPal capture failed.'];
}

if (!empty($cap['ok'])) {
    // Marks paid ONLY when the capture is COMPLETED and the captured amount +
    // currency equal the order total (paypal_settle_order). Fulfilment is
    // best-effort inside — a glitch never 500s the buyer after a good capture.
    $settle = paypal_settle_order($order, $cap, 'paypal_return');
    if (!empty($settle['ok'])) {
        pp_bounce('order-success.php?order=' . urlencode($orderNumber));
    }
    // Captured but amount mismatch → held for review (order-success shows "pending").
    pp_bounce('order-success.php?order=' . urlencode($orderNumber));
}

// Capture not completed — record the exact reason (single failure funnel) and
// keep the order resumable. PENDING (PayPal review / eCheck) is held, not failed.
paypal_record_not_paid($order, $cap, $paypalOrderId, 'paypal_return');
if (!empty($cap['pending'])) {
    pp_bounce('order-success.php?order=' . urlencode($orderNumber));
}
$_SESSION['mv_resume_order_id'] = $orderId;
$_SESSION['mv_paypal_error'] = (string)($cap['error'] ?? '');
pp_bounce('checkout.php?paypal=error');
