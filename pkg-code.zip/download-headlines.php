<?php
// Download endpoint for the full Google Ads plan with updated headlines.
$f = __DIR__ . '/Maventech_Google_Ads_Campaign_Plan_Updated.xlsx';
if (!is_file($f)) { http_response_code(404); exit('not found'); }
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Maventech_Google_Ads_Campaign_Plan_Updated.xlsx"');
header('Content-Length: ' . filesize($f));
header('Cache-Control: no-store');
readfile($f);
