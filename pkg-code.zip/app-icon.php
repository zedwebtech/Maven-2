<?php
/* ===========================================================================
 *  APP ICON  —  /app-icon.php?size=N   (also answers /favicon.ico)
 *  ---------------------------------------------------------------------------
 *  Serves the favicon, apple-touch-icon, PWA install icon and admin-tab icon
 *  at any requested size, generated LIVE from the logo uploaded in
 *  Admin → Company Info — or an automatic company-name monogram when no logo
 *  is set. See includes/brand-icon.php. Each size is cached to disk, keyed by
 *  app_icon_version(), so a new upload busts the cache and repeat hits are
 *  instant. Referenced by includes/header.php, includes/admin-shell.php,
 *  manifest-webmanifest.php, admin-manifest.php and admin-sw.js.
 *  =========================================================================== */

require_once __DIR__ . '/includes/functions.php';

if (!function_exists('imagecreatetruecolor')) { http_response_code(500); echo 'GD not available'; exit; }

$allowed = [16, 32, 48, 64, 96, 120, 152, 167, 180, 192, 256, 384, 512];
$size = (int)($_GET['size'] ?? 512);
if (!in_array($size, $allowed, true)) $size = 512;

$file = brand_icon_png_path($size);
if (!is_file($file) || filesize($file) === 0) { http_response_code(500); echo 'icon render failed'; exit; }

header('Content-Type: image/png');
// Versioned URLs (&v=…) never change content → immutable. Bare URLs (service
// worker, /favicon.ico) revalidate hourly so a new logo shows up without a redeploy.
header('Cache-Control: ' . (isset($_GET['v']) ? 'public, max-age=31536000, immutable' : 'public, max-age=3600'));
header('Content-Length: ' . filesize($file));
readfile($file);
