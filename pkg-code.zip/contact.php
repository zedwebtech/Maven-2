<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Contact ' . brand_name() . ' | Sales, Support & Activation';
$pageDescription = 'Get in touch with ' . brand_name() . ' for sales, activation help, refunds or partnerships. Live chat, email and phone support Mon–Sat.';

/* ================== SEO + AEO + GEO: ContactPage + Organization =====
   Tells Google / Bing / ChatGPT / Perplexity exactly who to contact
   and how.  The ContactPoint nodes power AI assistant answers like
   "How do I reach Maventech support?" with a clickable
   phone number + email + opening hours. */
$jsonLdContact = [
    '@context' => 'https://schema.org',
    '@type'    => 'ContactPage',
    '@id'      => site_url() . '/contact.php#contactpage',
    'url'      => site_url() . '/contact.php',
    'name'     => 'Contact ' . brand_name(),
    'description' => $pageDescription,
    'inLanguage'  => 'en',
    'isPartOf' => ['@id' => site_url() . '/#website'],
    'about'    => [
        '@type'   => 'Organization',
        '@id'     => site_url() . '/#organization',
        'name'    => brand_name(),
        'url'     => site_url() . '/',
        'logo'    => site_url() . '/assets/images/badges/microsoft-verified.svg',
        'sameAs'  => array_values(array_filter([
            (string)(setting_get('contact_facebook_url', '')),
            (string)(setting_get('contact_twitter_url',  '')),
            (string)(setting_get('contact_linkedin_url', '')),
            (string)(setting_get('contact_youtube_url',  '')),
            (string)(setting_get('contact_instagram_url',''))
        ])),
        // Single contactPoint array with BOTH support tracks — gives AI
        // assistants a clean 2-entry block to extract for queries like
        // "How do I contact Maventech?" / "Where's their sales line?".
        'contactPoint' => array_values(array_filter([
            [
                '@type'             => 'ContactPoint',
                'contactType'       => 'customer support',
                'telephone'         => (string)setting_get('contact_phone', ''),
                'email'             => (string)setting_get('contact_email', '') ?: (string)(company_info()['email'] ?? ''),
                'availableLanguage' => ['English'],
                'areaServed'        => ['US', 'GB', 'CA', 'AU'],
                'hoursAvailable'    => 'Mo-Sa 09:00-18:00',
            ],
            [
                '@type'             => 'ContactPoint',
                'contactType'       => 'sales',
                'email'             => (string)setting_get('contact_sales_email', setting_get('contact_email', '')) ?: (string)(company_info()['email'] ?? ''),
                'availableLanguage' => ['English'],
                'areaServed'        => ['US', 'GB', 'CA', 'AU'],
            ],
        ])),
    ],
];

$sent = false;
$formError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ── Anti-bot gate: stylish slide-to-verify + honeypot + time-trap ──
    $mvHoneypot = trim((string)($_POST['mv_hp'] ?? ''));   // hidden field; only bots fill it
    $mvHuman    = (($_POST['mv_human'] ?? '') === '1');     // set to 1 by the slide-to-verify widget
    $mvTs       = (int)($_POST['mv_ts'] ?? 0);
    $mvTooFast  = ($mvTs > 0 && (time() - $mvTs) < 2);      // submitted impossibly fast = bot
    $botBlocked = ($mvHoneypot !== '' || !$mvHuman || $mvTooFast);
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    // Server-truth age of the signed capture token (null = forged / absent).
    $mvCapTok = is_string($_POST['mv_cap'] ?? null) ? $_POST['mv_cap'] : null;
    $mvCapAge = mv_captcha_age($mvCapTok);
    // Silent bot drop — we fake success ($sent=true) so the bot moves on and
    // nothing is saved, emailed or rung on the bell. Dropped when: honeypot
    // filled; token forged/absent; no genuine human behaviour (dwell + real
    // keystrokes / taps / focus); a subject that isn't a real dropdown option;
    // spam-signature content; OR the signed token was already used once (a
    // replayed token is the classic flood vector). claim_once() is LAST so it
    // only consumes the token for an otherwise-clean submission.
    $silentDrop = ($mvHoneypot !== ''
        || $mvCapAge === null
        || !mv_behavior_ok($_POST['mv_bh'] ?? null, $mvCapAge)
        || ($subject !== '' && !mv_contact_subject_allowed($subject))
        || mv_looks_like_spam([$name, $subject, $message])
        || !mv_captcha_claim_once($mvCapTok));
    if ($silentDrop) {
        $sent = true; // pretend it worked; store nothing, notify no one
    } elseif ($botBlocked) {
        $formError = 'Please slide to verify you are human, then send your message.';
    } elseif ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $subject === '' || $message === '') {
        $formError = 'Please fill in all required fields with a valid email.';
    } else {
        // Reject typo domains (gmail.con / yaho.com etc.) BEFORE we save
        // the ticket so the auto-acknowledgement email isn't sent into
        // the void.  Mirror of the validation we apply at checkout +
        // notify-stock + lead form.
        require_once __DIR__ . '/includes/mailer.php';
        $deliv = function_exists('email_address_deliverable')
            ? email_address_deliverable($email)
            : ['ok' => true];
        if (!$deliv['ok'] && in_array($deliv['reason'] ?? '', ['no_mx','invalid_syntax'], true)) {
            $formError = $deliv['detail'] ?: 'That email address looks undeliverable — please double-check the spelling.';
        } elseif (form_rate_limit_hit('contact', 5, 24)) {
            // Per-IP throttle: up to 5 messages per 24h are fine; block beyond.
            $formError = 'You have reached the message limit from your network. Please email us directly at '
                . esc((string)setting_get('company_email', 'services@maventechsoftware.com'))
                . ' or try again later.';
        } else {
            save_support_message([
                'name' => $name, 'email' => strtolower($email),
                'phone' => trim($_POST['phone'] ?? ''), 'order_number' => trim($_POST['order_number'] ?? ''),
                'subject' => $subject, 'message' => $message, 'source' => 'contact',
            ]);
            // Customer-service auto-acknowledgement (5-minute delayed delivery)
            require_once __DIR__ . '/includes/email.php';
            send_customer_service_ack(strtolower($email), $name, $subject, $message, 'contact');

            // Email the COMPANY the actual enquiry. Sent to the SMTP email you
            // configure (Admin → SMTP From / username) first, so alerts always
            // go to the mailbox you actually run the site from; falls back to
            // Company Info / contact email only if the SMTP email is blank.
            try {
                $co        = function_exists('company_info') ? company_info() : [];
                $companyTo = trim((string)setting_get('smtp_from_email', setting_get('smtp_username', '')));
                if ($companyTo === '') $companyTo = trim((string)($co['email'] ?? ''));
                if ($companyTo === '') $companyTo = trim((string)setting_get('company_email', setting_get('contact_email', '')));
                if ($companyTo === '') $companyTo = brand_email();
                if ($companyTo !== '' && filter_var($companyTo, FILTER_VALIDATE_EMAIL)) {
                    $brand  = $co['name'] ?? brand_name();
                    $phoneC = trim((string)($_POST['phone'] ?? ''));
                    $ordC   = trim((string)($_POST['order_number'] ?? ''));
                    $nameE  = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
                    $emailE = htmlspecialchars(strtolower($email), ENT_QUOTES, 'UTF-8');
                    $subjE  = htmlspecialchars($subject, ENT_QUOTES, 'UTF-8');
                    $msgE   = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
                    $phoneE = htmlspecialchars($phoneC, ENT_QUOTES, 'UTF-8');
                    $ordE   = htmlspecialchars($ordC, ENT_QUOTES, 'UTF-8');
                    $brandE = htmlspecialchars((string)$brand, ENT_QUOTES, 'UTF-8');
                    $html = '<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:620px;margin:0 auto;color:#0f172a">'
                        . '<div style="background:#0f172a;padding:18px 22px;border-radius:10px 10px 0 0;color:#fff;">'
                        . '<div style="font-size:11px;letter-spacing:.12em;font-weight:800;text-transform:uppercase;color:#60a5fa;">' . $brandE . ' — Contact Form</div>'
                        . '<div style="font-size:19px;font-weight:800;margin-top:4px;">New message from ' . $nameE . '</div></div>'
                        . '<div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 10px 10px;padding:22px;line-height:1.55;">'
                        . '<table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:14px;">'
                        . '<tr><td style="padding:6px 0;color:#64748b;width:120px;">From</td><td style="padding:6px 0;font-weight:600;">' . $nameE . '</td></tr>'
                        . '<tr><td style="padding:6px 0;color:#64748b;">Email</td><td style="padding:6px 0;"><a href="mailto:' . $emailE . '" style="color:#2563eb;text-decoration:none;">' . $emailE . '</a></td></tr>'
                        . ($phoneC !== '' ? '<tr><td style="padding:6px 0;color:#64748b;">Phone</td><td style="padding:6px 0;">' . $phoneE . '</td></tr>' : '')
                        . ($ordC !== '' ? '<tr><td style="padding:6px 0;color:#64748b;">Order #</td><td style="padding:6px 0;">' . $ordE . '</td></tr>' : '')
                        . '<tr><td style="padding:6px 0;color:#64748b;">Subject</td><td style="padding:6px 0;font-weight:600;">' . $subjE . '</td></tr>'
                        . '</table>'
                        . '<div style="font-weight:700;margin-bottom:4px;">Message</div>'
                        . '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 14px;font-size:13px;color:#334155;">' . $msgE . '</div>'
                        . '<p style="margin:16px 0 0;font-size:12px;color:#94a3b8;">Reply directly to this email to respond to ' . $nameE . '.</p>'
                        . '</div></div>';
                    send_email($companyTo, '[Contact] ' . $subject . ' — ' . $name, $html, null, 'contact_form', 0, [], false, ['name' => $name, 'reply_to' => strtolower($email)]);
                }
            } catch (Throwable $e) { @error_log('[contact company email] ' . $e->getMessage()); }

            // Admin bell notification too.
            try {
                if (function_exists('admin_notify')) {
                    admin_notify('lead', 'New contact message — ' . $name, $subject, '/admin.php?tab=leads');
                }
            } catch (Throwable $e) { /* best-effort */ }

            $sent = true;
        }
    }
}

$contactFaqs = [
    ['How long does it take to receive my license key?', 'Your license key and download instructions are delivered by email once the order is processed. Full timing details are on our Shipping & Delivery page.'],
    ['What if my license key doesn\'t work?', 'First make sure the key is entered exactly (no extra spaces, watch 0 vs O). If it still fails, contact our support team with your order number and we\'ll resolve it or replace the key.'],
    ['Do you offer refunds?', 'Yes — we offer a 30-day money-back guarantee. See our <a href="return-policy.php" class="text-decoration-none">Return Policy</a> for the return process, or the <a href="refund-policy.php" class="text-decoration-none">Refund Policy</a> for refund amounts, methods and timing. Start a request on the <a href="returns.php" class="text-decoration-none">Return &amp; Refund</a> page.'],
    ['How do I activate my Microsoft Office license?', 'Download the official installer from setup.office.com, sign in with a Microsoft account, and enter your 25-character product key when prompted. Full steps are in our Activation Help guide.'],
    ['Can I use my license on multiple devices?', 'Most licenses are valid for 1 PC or Mac unless the product states otherwise. Buying for a team? Ask us about volume licensing.'],
];

include __DIR__ . '/includes/header.php';
?>

<!-- Hero -->
<div class="page-head">
  <div class="container py-5 text-center">
    <span class="eyebrow">WE'RE HERE TO HELP</span>
    <h1 class="fw-bold display-6 mt-1" data-testid="contact-title">Contact <?= esc(brand_name()) ?> — Sales &amp; Support</h1>
    <p class="text-secondary mx-auto" style="max-width:620px;">Questions about your order, license-key delivery, or activation? Our order-fulfillment team is ready to help.</p>
    <div class="d-flex justify-content-center gap-4 flex-wrap small mt-3">
      <span><i class="bi bi-patch-check-fill text-success me-1"></i>Microsoft Product Keys</span>
      <span><i class="bi bi-shield-check text-primary me-1"></i>Secure Checkout</span>
      <span><i class="bi bi-arrow-counterclockwise text-primary me-1"></i>30-Day Money Back Guarantee</span>
    </div>
  </div>
</div>

<div class="container py-5">
  <!-- Contact methods -->
  <div class="row g-4 mb-5">
    <div class="col-lg-4">
      <div class="card h-100 p-4 text-center position-relative d-flex flex-column" data-testid="contact-card-email">
        <span class="badge text-bg-primary position-absolute top-0 start-50 translate-middle">Recommended</span>
        <i class="bi bi-envelope-fill text-primary fs-2"></i>
        <h3 class="h6 fw-bold mt-2 mb-1">Email Support</h3>
        <small class="text-secondary d-block mb-3">Get a response within 24 hours</small>
        <a href="mailto:<?= brand_email() ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 mx-auto mt-auto text-truncate mw-100"><i class="bi bi-envelope me-1"></i><?= brand_email() ?></a>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="card h-100 p-4 text-center position-relative d-flex flex-column" data-testid="contact-card-chat">
        <span class="badge text-bg-success position-absolute top-0 start-50 translate-middle">Instant</span>
        <i class="bi bi-chat-dots-fill text-primary fs-2"></i>
        <h3 class="h6 fw-bold mt-2 mb-1">Live Chat</h3>
        <small class="text-secondary d-block mb-3">Chat with our support team</small>
        <button class="btn btn-sm btn-outline-primary rounded-pill px-3 mx-auto mt-auto" onclick="toggleChat()"><i class="bi bi-chat-dots me-1"></i>Start a chat · <?= SITE_HOURS ?></button>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="card h-100 p-4 text-center d-flex flex-column" data-testid="contact-card-phone">
        <i class="bi bi-telephone-fill text-primary fs-2"></i>
        <h3 class="h6 fw-bold mt-2 mb-1">Phone Support</h3>
        <small class="text-secondary d-block mb-3">Talk to a specialist</small>
        <a href="tel:<?= esc(tel_e164(company_phone_for_country())) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 mx-auto mt-auto"><i class="bi bi-telephone me-1"></i><?= esc(company_phone_for_country()) ?></a>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <!-- Form -->
    <div class="col-lg-7">
      <div class="card p-4 p-lg-5" id="contact-form" data-testid="contact-form">
        <h2 class="h4 fw-bold mb-1">Send Us a Message</h2>
        <p class="text-secondary small mb-4">Fill out the form below and we'll respond as soon as possible.</p>

        <?php if ($sent): ?>
          <div class="alert alert-success" data-testid="contact-success"><i class="bi bi-check-circle-fill me-2"></i>Thanks! Your message has been received — we'll get back to you within 24 hours.</div>
        <?php else: ?>
          <?php if ($formError): ?><div class="alert alert-danger py-2 small" data-testid="contact-error"><?= esc($formError) ?></div><?php endif; ?>
          <form method="post" action="contact.php#contact-form" data-testid="contact-form-el" novalidate>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Full Name *</label>
                <input name="name" class="form-control" placeholder="John Doe" required data-testid="contact-name">
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Email Address *</label>
                <input type="email" name="email" class="form-control" placeholder="john@example.com" required data-testid="contact-email">
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Phone Number <span class="text-secondary fw-normal">(Optional)</span></label>
                <input name="phone" class="form-control" placeholder="+1 (555) 123-4567" data-testid="contact-phone">
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Order Number <span class="text-secondary fw-normal">(Optional)</span></label>
                <input name="order_number" class="form-control" placeholder="UC-XXXXXX" data-testid="contact-order">
              </div>
              <div class="col-12">
                <label class="form-label small fw-semibold">Subject *</label>
                <select name="subject" class="form-select" required data-testid="contact-subject">
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Order Support">Order Support</option>
                  <option value="Technical Support">Technical Support</option>
                  <option value="Billing Question">Billing Question</option>
                  <option value="Refund Request">Refund Request</option>
                  <option value="License Activation Help">License Activation Help</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label small fw-semibold">Message *</label>
                <textarea name="message" class="form-control" rows="5" placeholder="Please describe your question or issue in detail..." required data-testid="contact-message"></textarea>
              </div>
              <!-- Honeypot: hidden from humans, bots fill it and get silently blocked -->
              <div aria-hidden="true" style="position:absolute!important;left:-9999px!important;top:-9999px!important;width:1px;height:1px;overflow:hidden;">
                <label>Leave this field empty<input type="text" name="mv_hp" tabindex="-1" autocomplete="off"></label>
              </div>
              <input type="hidden" name="mv_ts" value="<?= (int)time() ?>">
              <input type="hidden" name="mv_cap" value="<?= htmlspecialchars(mv_captcha_token(), ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="mv_human" id="mvHumanField" value="">
              <input type="hidden" name="mv_bh" id="mvBehaviorField" value="">

              <div class="col-12">
                <div class="mv-verify-box" data-testid="human-verify-box">
                  <div class="mv-verify-head">
                    <span class="mv-verify-icon"><i class="bi bi-shield-lock-fill"></i></span>
                    <div>
                      <div class="mv-verify-title">Please verify you&rsquo;re human</div>
                      <div class="mv-verify-sub">Press and drag the <strong>slider button all the way to the right</strong> to unlock the Send button.</div>
                    </div>
                  </div>
                  <div class="mv-slider" id="mvSlider" data-testid="human-verify-slider">
                    <div class="mv-slider-fill"></div>
                    <span class="mv-slider-hints" aria-hidden="true"><i class="bi bi-chevron-right"></i><i class="bi bi-chevron-right"></i><i class="bi bi-chevron-right"></i></span>
                    <span class="mv-slider-text">Slide to verify</span>
                    <div class="mv-slider-thumb" role="button" tabindex="0" aria-label="Slide to verify you are human" data-testid="human-verify-thumb">
                      <i class="bi bi-shield-check"></i>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-12">
                <button class="btn btn-primary rounded-pill px-4 fw-semibold" id="contactSend" data-testid="contact-send" disabled>Send Message</button>
              </div>
            </div>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-5">
      <div class="card p-4 mb-4" data-testid="contact-office">
        <h3 class="h6 fw-bold mb-2"><i class="bi bi-geo-alt-fill text-primary me-2"></i>Our Office</h3>
        <p class="small text-secondary mb-3"><strong class="text-body"><?= brand_legal() ?></strong><br><?= SITE_ADDRESS ?><br>United States</p>
        <?php $officePhone = company_phone_for_country(); $officeTel = tel_e164($officePhone); ?>
        <div class="d-flex flex-wrap gap-2 mb-3" data-testid="contact-office-lines">
          <a href="tel:<?= esc($officeTel) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3" data-testid="contact-office-phone"><i class="bi bi-telephone-fill me-1"></i>Toll-free <?= esc($officePhone) ?></a>
          <a href="sms:<?= esc($officeTel) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3" data-testid="contact-office-sms"><i class="bi bi-chat-dots-fill me-1"></i>Text us</a>
          <a href="mailto:<?= esc(brand_email()) ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3" data-testid="contact-office-email"><i class="bi bi-envelope-fill me-1"></i><?= esc(brand_email()) ?></a>
        </div>
        <p class="small text-secondary mb-0 lh-lg" data-testid="contact-office-sms-consent" style="border-top:1px dashed rgba(37,99,235,.25);padding-top:.75rem;">
          <i class="bi bi-chat-dots text-primary me-1"></i>
          <strong class="text-body">Texting us?</strong> By texting <?= esc(brand_legal()) ?> at <?= esc($officePhone) ?> you agree to receive customer-care text messages from <?= esc(brand_legal()) ?>.
          Reply <strong>STOP</strong> to opt out, <strong>HELP</strong> for support. Message &amp; data rates may apply; message frequency may vary. Consent is not a condition of purchase.
          Your number and SMS consent are never sold or shared for marketing — see our <a href="page.php?slug=privacy-policy#sms-policy">Privacy Policy</a> and <a href="page.php?slug=terms-of-service#sms-terms">Terms of Service</a>.
        </p>
      </div>
      <div class="card p-4 mb-4" data-testid="contact-hours">
        <h3 class="h6 fw-bold mb-2"><i class="bi bi-clock-fill text-primary me-2"></i>Business Hours</h3>
        <div class="small d-grid gap-1">
          <div class="d-flex justify-content-between"><span class="text-secondary">Monday - Friday</span><span class="fw-semibold">9:00 AM - 6:00 PM EST</span></div>
          <div class="d-flex justify-content-between"><span class="text-secondary">Saturday</span><span class="fw-semibold">10:00 AM - 4:00 PM EST</span></div>
          <div class="d-flex justify-content-between"><span class="text-secondary">Sunday</span><span class="fw-semibold">Closed</span></div>
        </div>
        <small class="text-secondary mt-2"><i class="bi bi-chat-dots me-1"></i>Live chat: <?= SITE_HOURS ?></small>
      </div>
      <div class="card p-4" style="background: rgba(37,99,235,.05);">
        <h3 class="h6 fw-bold mb-1"><i class="bi bi-lightning-charge-fill text-warning me-2"></i>Quick Response</h3>
        <small class="text-secondary">We typically respond to all inquiries within 24 hours. For urgent matters, please use our live chat for immediate assistance.</small>
      </div>
    </div>
  </div>

  <!-- SMS disclosure (same wording as Terms + About) -->
  <div class="mt-4" data-testid="contact-sms-disclosure"><?= sms_disclosure_html() ?></div>

  <!-- FAQ -->
  <div class="mt-5 mx-auto" style="max-width: 760px;">
    <div class="text-center mb-4">
      <h2 class="fw-bold h3">Frequently Asked Questions</h2>
      <p class="text-secondary small">Find quick answers to common questions</p>
    </div>
    <div class="accordion" id="contactFaq" data-testid="contact-faq">
      <?php foreach ($contactFaqs as $i => [$q, $a]): ?>
        <div class="accordion-item">
          <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cfaq<?= $i ?>"><?= esc($q) ?></button></h2>
          <div id="cfaq<?= $i ?>" class="accordion-collapse collapse" data-bs-parent="#contactFaq"><div class="accordion-body small text-secondary"><?= esc($a) ?></div></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- CTA -->
  <div class="rounded-4 text-center text-white p-5 mt-5" style="background: linear-gradient(135deg, #2563eb, #4338ca);">
    <h2 class="fw-bold h3">Still Need Help?</h2>
    <p class="opacity-75 mx-auto" style="max-width:520px;">Our dedicated support team is here to ensure you have the best experience. Don't hesitate to reach out!</p>
    <div class="d-flex justify-content-center gap-2 flex-wrap">
      <a href="mailto:<?= brand_email() ?>" class="btn btn-light rounded-pill px-4 fw-semibold">Email Support</a>
      <button class="btn btn-outline-light rounded-pill px-4" onclick="toggleChat()">Start Live Chat</button>
    </div>
  </div>
</div>

<style>
  .mv-verify-box{background:linear-gradient(135deg,#f8fbff,#eef4ff);border:1px solid #dbe6f5;border-radius:16px;padding:18px 18px 20px;}
  .mv-verify-head{display:flex;align-items:center;gap:12px;margin-bottom:14px;}
  .mv-verify-icon{flex:0 0 auto;width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:21px;background:linear-gradient(135deg,#2563eb,#4338ca);box-shadow:0 5px 14px rgba(37,99,235,.35);}
  .mv-verify-title{font-size:15.5px;font-weight:800;color:#0f172a;letter-spacing:.1px;}
  .mv-verify-sub{font-size:12.5px;color:#64748b;margin-top:2px;line-height:1.45;}
  .mv-slider{position:relative;height:60px;border-radius:14px;background:#e9eef6;border:1px solid #d4deec;overflow:hidden;user-select:none;touch-action:none;box-shadow:inset 0 2px 6px rgba(15,23,42,.09);}
  .mv-slider-fill{position:absolute;inset:0;width:58px;border-radius:14px;background:linear-gradient(135deg,#2563eb,#4338ca);transition:width .18s ease;}
  .mv-slider.done .mv-slider-fill{background:linear-gradient(135deg,#16a34a,#15803d);}
  .mv-slider-hints{position:absolute;top:0;bottom:0;right:20px;display:flex;align-items:center;gap:1px;color:#9db4d6;font-size:20px;pointer-events:none;}
  .mv-slider-hints i{animation:mvHint 1.4s ease-in-out infinite;}
  .mv-slider-hints i:nth-child(2){animation-delay:.18s;} .mv-slider-hints i:nth-child(3){animation-delay:.36s;}
  @keyframes mvHint{0%,100%{opacity:.25;transform:translateX(0);}50%{opacity:1;transform:translateX(3px);}}
  .mv-slider.done .mv-slider-hints{display:none;}
  .mv-slider-text{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:14.5px;font-weight:800;letter-spacing:.4px;pointer-events:none;padding-left:28px;
     background:linear-gradient(90deg,#7c8aa0 25%,#0f172a 50%,#7c8aa0 75%);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:mvShine 2.4s linear infinite;}
  .mv-slider.done .mv-slider-text{padding-left:0;-webkit-text-fill-color:#fff;background:none;color:#fff;animation:none;}
  @keyframes mvShine{0%{background-position:200% 0;}100%{background-position:-200% 0;}}
  .mv-slider-thumb{position:absolute;top:4px;left:4px;width:52px;height:52px;border-radius:11px;background:#fff;display:flex;align-items:center;justify-content:center;color:#2563eb;font-size:22px;cursor:grab;box-shadow:0 3px 11px rgba(15,23,42,.24);transition:left .05s linear;z-index:2;}
  .mv-slider-thumb::after{content:"";position:absolute;inset:-4px;border-radius:14px;border:2px solid rgba(37,99,235,.4);animation:mvPulse 1.6s ease-out infinite;}
  .mv-slider.done .mv-slider-thumb::after{display:none;}
  .mv-slider-thumb:active{cursor:grabbing;}
  .mv-slider.done .mv-slider-thumb{color:#16a34a;cursor:default;left:auto!important;right:4px;}
  @keyframes mvPulse{0%{opacity:.6;transform:scale(1);}100%{opacity:0;transform:scale(1.28);}}
  #contactSend:disabled{opacity:.55;cursor:not-allowed;}
  @media (prefers-reduced-motion: reduce){.mv-slider-fill,.mv-slider-thumb{transition:none;}.mv-slider-hints i,.mv-slider-text,.mv-slider-thumb::after{animation:none;}}
</style>
<script>
(function(){
  var slider = document.getElementById('mvSlider');
  if (!slider) return;
  var thumb = slider.querySelector('.mv-slider-thumb');
  var fill  = slider.querySelector('.mv-slider-fill');
  var text  = slider.querySelector('.mv-slider-text');
  var field = document.getElementById('mvHumanField');
  var send  = document.getElementById('contactSend');
  var dragging = false, done = false, startX = 0, thumbW = 52, pad = 4;

  function maxX(){ return slider.clientWidth - thumbW - pad*2; }
  function setX(x){
    x = Math.max(0, Math.min(x, maxX()));
    thumb.style.left = (pad + x) + 'px';
    fill.style.width = (thumbW + x) + 'px';
    return x;
  }
  function complete(){
    done = true;
    slider.classList.add('done');
    thumb.style.left = ''; fill.style.width = '100%';
    thumb.innerHTML = '<i class="bi bi-check-lg"></i>';
    text.textContent = 'Verified \u2014 you can send now';
    field.value = '1';
    if (send) send.disabled = false;
  }
  function down(e){ if(done) return; dragging = true; startX = (e.touches?e.touches[0].clientX:e.clientX) - parseFloat(thumb.style.left||pad); thumb.style.transition='none'; }
  function move(e){
    if(!dragging||done) return;
    var cx = (e.touches?e.touches[0].clientX:e.clientX);
    var x = setX(cx - startX);
    if (x >= maxX() - 2){ dragging=false; complete(); }
    if(e.cancelable) e.preventDefault();
  }
  function up(){ if(done||!dragging) return; dragging=false; thumb.style.transition='left .18s ease'; setX(0); }

  thumb.addEventListener('mousedown', down);
  window.addEventListener('mousemove', move);
  window.addEventListener('mouseup', up);
  thumb.addEventListener('touchstart', down, {passive:true});
  window.addEventListener('touchmove', move, {passive:false});
  window.addEventListener('touchend', up);
  // keyboard accessibility: Enter/Space completes it
  thumb.addEventListener('keydown', function(e){ if(!done && (e.key==='Enter'||e.key===' ')){ e.preventDefault(); complete(); } });
})();
// ── Smart behaviour tracker ── records real human interaction into mv_bh so
// the server can tell a genuine browser from a scripted post / replayed token.
(function(){
  var form = document.querySelector('[data-testid="contact-form-el"]') || document.querySelector('form');
  if (!form || !document.getElementById('mvBehaviorField')) return;
  var bh = {kd:0, pm:0, tc:0, fl:0, ps:0};
  function inc(k){ if(bh[k] < 100000) bh[k]++; }
  document.addEventListener('mousemove',  function(){ inc('pm'); }, {passive:true});
  document.addEventListener('pointermove',function(){ inc('pm'); }, {passive:true});
  document.addEventListener('touchmove',  function(){ inc('tc'); }, {passive:true});
  document.addEventListener('touchstart', function(){ inc('tc'); }, {passive:true});
  document.addEventListener('pointerdown',function(){ inc('tc'); }, {passive:true});
  form.addEventListener('keydown', function(){ inc('kd'); }, true);
  form.addEventListener('focusin', function(){ inc('fl'); }, true);
  form.addEventListener('paste',   function(){ inc('ps'); }, true);
  form.addEventListener('submit', function(){
    var el = document.getElementById('mvBehaviorField');
    if (el) el.value = JSON.stringify(bh);
  }, true); // capture phase → runs before the POST leaves
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
