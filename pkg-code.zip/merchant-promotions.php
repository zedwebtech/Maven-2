<?php
/**
 * /merchant-promotions.xml — Google Merchant Center Promotions feed.
 *
 * Clears the "Promotions: Incomplete" item in Merchant Center by publishing
 * a valid promotions feed (RSS 2.0 + g: namespace). The featured promotion is
 * a site-wide percent-off coupon (configurable via the `promo_feed_code`
 * setting; defaults to WELCOME10). The matching <g:promotion_id> is also
 * emitted on every item in /merchant-feed.xml so the promotion is linked to
 * the products (Google requires both).
 *
 * Submit in Merchant Center → Marketing/Promotions → Promotion feeds, using:
 *   https://<your-domain>/merchant-promotions.xml
 */
session_cache_limiter('');
@ini_set('session.use_cookies', '0');
@ini_set('session.use_only_cookies', '0');

require_once __DIR__ . '/includes/functions.php';

foreach (['Cache-Control', 'Pragma', 'Expires', 'Set-Cookie'] as $h) header_remove($h);
header('Content-Type: application/xml; charset=UTF-8');
header('Cache-Control: public, max-age=3600');
header('X-Robots-Tag: noindex, nofollow');

$site = rtrim(function_exists('public_base_url') ? public_base_url() : (defined('SITE_URL') ? SITE_URL : ''), '/');
$ci    = function_exists('company_info') ? company_info() : [];
$brand = $ci['name'] ?? brand_name();

function promo_xml_esc(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

// Featured promotion — code + percent (from the live coupons() map).
$codes   = function_exists('coupons') ? coupons() : ['WELCOME10' => 10];
$feature = strtoupper(trim((string)(function_exists('setting_get') ? setting_get('promo_feed_code', 'WELCOME10') : 'WELCOME10')));
if ($feature === '' || !isset($codes[$feature])) {
    $feature = isset($codes['WELCOME10']) ? 'WELCOME10' : (string)array_key_first($codes);
}
$percent = max(1, min(95, (int)($codes[$feature] ?? 10)));

// Effective window: now → +1 year (Merchant Center requires start/end).
$start = gmdate('Y-m-d\TH:i:s\Z', time() - 300);
$end   = gmdate('Y-m-d\TH:i:s\Z', time() + 365 * 24 * 3600);
$title = $percent . '% off your order with code ' . $feature;

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">' . "\n";
echo "  <channel>\n";
echo '    <title>' . promo_xml_esc($brand . ' — Promotions') . "</title>\n";
echo '    <link>' . promo_xml_esc($site) . "</link>\n";
echo "    <description>Active store-wide promotions</description>\n";
echo "    <item>\n";
echo '      <g:promotion_id>' . promo_xml_esc($feature) . "</g:promotion_id>\n";
echo "      <g:product_applicability>all_products</g:product_applicability>\n";
echo "      <g:offer_type>generic_code</g:offer_type>\n";
echo '      <g:generic_redemption_code>' . promo_xml_esc($feature) . "</g:generic_redemption_code>\n";
echo '      <g:long_title>' . promo_xml_esc($title) . "</g:long_title>\n";
echo "      <g:redemption_channel>online</g:redemption_channel>\n";
echo '      <g:promotion_effective_dates>' . $start . '/' . $end . "</g:promotion_effective_dates>\n";
echo "      <g:coupon_value_type>percent_off</g:coupon_value_type>\n";
echo '      <g:percent_off>' . $percent . "</g:percent_off>\n";
echo '      <g:promotion_display_dates>' . $start . '/' . $end . "</g:promotion_display_dates>\n";
echo "    </item>\n";
echo "  </channel>\n";
echo "</rss>\n";
