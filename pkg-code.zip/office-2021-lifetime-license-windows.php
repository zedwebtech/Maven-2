<?php
/** Landing page — Microsoft Office 2021 for Windows, Lifetime License. */
$OFFICE_VERSION  = '2021';
$OFFICE_PLATFORM = 'win';
require __DIR__ . '/includes/office-landing.php';
