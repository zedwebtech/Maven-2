<?php
/**
 * cron.php — queue worker for shared-hosting cron jobs.
 *
 * Usage on cPanel / Plesk:
 *   * * * * * /usr/bin/curl -s "https://your-domain.com/cron.php?token=YOUR_SECRET" >/dev/null
 *
 * The token is the value of the `cron_token` setting (auto-generated on first
 * access). Hits without a valid token return 403.
 */
define('MV_NO_AUTOCRON', true); // this IS the scheduler — don't arm the page-view fallback
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mailer.php';
require_once __DIR__ . '/includes/seo-bot.php';
require_once __DIR__ . '/includes/ai-citation-tracker.php';
require_once __DIR__ . '/includes/dmca-watchdog.php';
require_once __DIR__ . '/includes/recovery.php';
require_once __DIR__ . '/includes/followup-emails.php';

// Generate a cron token once (so the admin can copy it from the SMTP page).
$token = setting_get('cron_token', '');
if ($token === '') {
    $token = bin2hex(random_bytes(20));
    setting_set('cron_token', $token);
}

$given = $_GET['token'] ?? $_SERVER['HTTP_X_CRON_TOKEN'] ?? '';
if (!hash_equals($token, (string)$given)) {
    http_response_code(403);
    header('Content-Type: text/plain');
    echo "Forbidden — invalid cron token.\n";
    exit;
}

header('Content-Type: text/plain');
try { setting_set('cron_last_hit', date('Y-m-d H:i:s')); } catch (Throwable $e) {}
$batch = max(1, min(200, (int)($_GET['batch'] ?? 50)));
$start = microtime(true);
$count = smtp_process_queue($batch);
$ms    = (int)((microtime(true) - $start) * 1000);
echo "[" . date('c') . "] cron.php: processed=$count batch=$batch elapsed_ms=$ms\n";

// ---- Offline live-chat replies → customer email ----
try {
    require_once __DIR__ . '/includes/chat-relay.php';
    $crSent = chat_relay_sweep(20);
    echo "[" . date('c') . "] chat-relay: emailed=$crSent\n";
} catch (Throwable $e) {
    echo "[" . date('c') . "] chat-relay: ERROR " . $e->getMessage() . "\n";
}

// ---- Follow-up emails (post-purchase activation check-ins) ----
// Queues the 24h "did it install/activate OK?" and 72h "need a hand?"
// emails whose scheduled_at has arrived, then drains them right away.
// Skips unsubscribed / refunded orders automatically.
try {
    $fuStart = microtime(true);
    $fuSent  = send_pending_followups(25);
    if ($fuSent > 0) { smtp_process_queue(min(50, $fuSent)); }
    $fuMs    = (int)((microtime(true) - $fuStart) * 1000);
    echo "[" . date('c') . "] followups: queued=$fuSent elapsed_ms=$fuMs\n";
} catch (Throwable $e) {
    echo "[" . date('c') . "] followups: ERROR " . $e->getMessage() . "\n";
    @error_log('[cron followups] ' . $e->getMessage());
}

// ---- Google review nudge (happy 4-5★ reviewers who didn't post on Google) ----
try {
    require_once __DIR__ . '/includes/google-nudge.php';
    $gnSent = mv_google_nudge_tick();
    echo "[" . date('c') . "] google-nudge: sent=$gnSent\n";
} catch (Throwable $e) {
    echo "[" . date('c') . "] google-nudge: ERROR " . $e->getMessage() . "\n";
}

// SEO / GEO / AEO automation — runs once every 24h.
// IndexNow ping + Google/Bing sitemap ping + Claude Haiku content refresh
// (meta description + AI summary for stale products).
// NEW (2026-07): auto-publishing new blog posts is opt-in via the
// admin toggle. When disabled, we skip the publish step but still emit
// a status line so cron logs remain readable.
try {
    $seoForce = !empty($_GET['seo_force']);
    if (!seo_bot_auto_publish_enabled() && !$seoForce) {
        echo "[" . date('c') . "] seo-bot: skipped — auto-publish is OFF (enable in Admin → AI Auto-Blogger).\n";
    } else {
    $seoReport = seo_bot_run_if_due($seoForce);
    if (!empty($seoReport['skipped'])) {
        echo "[" . date('c') . "] seo-bot: skipped — " . $seoReport['reason'] . "\n";
    } else {
        echo "[" . date('c') . "] seo-bot: indexnow={$seoReport['indexnow_status']} ({$seoReport['indexnow_count']} urls) "
           . "google={$seoReport['google_ping']} bing={$seoReport['bing_ping']} "
           . "llm_calls={$seoReport['llm_calls']} updated={$seoReport['products_updated']}"
           . (!empty($seoReport['blog_post_id']) ? ' blog_post="' . $seoReport['blog_post_title'] . '"' : '')
           . (empty($seoReport['errors']) ? '' : ' errors=' . count($seoReport['errors']))
           . "\n";
    }
    }
} catch (Throwable $e) {
    echo "[" . date('c') . "] seo-bot: ERROR " . $e->getMessage() . "\n";
}

// AI Citation Tracker — once every 7 days, ask Claude / GPT-4o-mini / Gemini
// "what does <brand> sell?" and store the answer. Lets the dashboard surface
// whether the AI engines actually know about us yet.
try {
    $citForce = !empty($_GET['citations_force']);
    $citReport = ai_citations_run_if_due($citForce);
    if (!empty($citReport['skipped'])) {
        echo "[" . date('c') . "] ai-citations: skipped — " . $citReport['reason'] . "\n";
    } else {
        $engineCount = count($citReport['engines'] ?? []);
        $brandHits = 0; $urlHits = 0;
        foreach (($citReport['engines'] ?? []) as $e) {
            if (!empty($e['mentions_brand'])) $brandHits++;
            if (!empty($e['mentions_url']))   $urlHits++;
        }
        echo "[" . date('c') . "] ai-citations: probed=$engineCount brand_mentions=$brandHits url_mentions=$urlHits\n";
    }
} catch (Throwable $e) {
    echo "[" . date('c') . "] ai-citations: ERROR " . $e->getMessage() . "\n";
}

// DMCA Scraper Watchdog — weekly sample of AI posts asked against Claude
// for content-clone detection. Logs findings to dmca_findings.
try {
    $dmcaForce = !empty($_GET['dmca_force']);
    $dmcaReport = dmca_run_if_due($dmcaForce);
    if (!empty($dmcaReport['skipped'])) {
        echo "[" . date('c') . "] dmca-watchdog: skipped — " . $dmcaReport['reason'] . "\n";
    } else {
        echo "[" . date('c') . "] dmca-watchdog: checked={$dmcaReport['checked']} findings={$dmcaReport['findings']}\n";
    }
} catch (Throwable $e) {
    echo "[" . date('c') . "] dmca-watchdog: ERROR " . $e->getMessage() . "\n";
}

// Daily featured-trends article — one editorial-style post per day, picked
// independently from the regional batch.
try {
    require_once __DIR__ . '/includes/seo-bot.php';
    $trReport = ['errors' => []];
    $tr = seo_publish_featured_trends_article($trReport, false);
    if (!empty($tr['skipped'])) {
        echo "[" . date('c') . "] trends-article: skipped — " . $tr['reason'] . "\n";
    } elseif (!empty($tr['blog_post_id'])) {
        echo "[" . date('c') . "] trends-article: published — " . $tr['blog_post_title'] . "\n";
    } else {
        echo "[" . date('c') . "] trends-article: error — " . ($trReport['errors'][0] ?? ($tr['error'] ?? '?')) . "\n";
    }
} catch (Throwable $e) {
    echo "[" . date('c') . "] trends-article: ERROR " . $e->getMessage() . "\n";
}

// Bounce reconciliation — read the mailbox for delivery failures and flip the
// matching Email Activity rows to BOUNCED so the admin shows the real status.
try {
    require_once __DIR__ . '/includes/mailer.php';
    $bnc = email_sync_bounces();
    if (!empty($bnc['ok'])) {
        echo "[" . date('c') . "] bounce-sync: checked={$bnc['checked']} bounced={$bnc['bounced']}\n";
    } else {
        echo "[" . date('c') . "] bounce-sync: skipped — " . ($bnc['error'] ?? '?') . "\n";
    }
} catch (Throwable $e) {
    echo "[" . date('c') . "] bounce-sync: ERROR " . $e->getMessage() . "\n";
}

// Abandoned-cart recovery sweep — fires the Paddle-style "Looks like you
// left something behind!" email once per order when the customer clicked
// Pay but never completed a successful payment, and 30+ minutes have
// elapsed since the last activity.  Single-shot per order (guarded by
// orders.recovery_email_sent).  Never releases license keys.
try {
    $sweepBatch = max(1, min(200, (int)($_GET['recovery_batch'] ?? 50)));
    $sweepMin   = max(1, (int)($_GET['recovery_min_minutes'] ?? 30));
    $sweep = mv_abandoned_cart_sweep($sweepBatch, $sweepMin);
    echo "[" . date('c') . "] abandoned-cart-sweep: scanned={$sweep['scanned']} sent={$sweep['sent']} errors={$sweep['errors']}\n";
} catch (Throwable $e) {
    echo "[" . date('c') . "] abandoned-cart-sweep: ERROR " . $e->getMessage() . "\n";
}
