<?php
/**
 * /wellknown.php — unified handler for AI-agent "well-known" discovery
 * documents that agent-readiness audits probe. One lean file, routed from
 * router.php (dev preview) and .htaccess (Apache) for each path:
 *
 *   /.well-known/api-catalog              RFC 9727  application/linkset+json
 *   /.well-known/oauth-authorization-server  RFC 8414  application/json
 *   /.well-known/oauth-protected-resource    RFC 9728  application/json
 *   /.well-known/mcp.json                 MCP Server Card
 *   /.well-known/agent-skills.json        Agent Skills index
 *   /auth.md  +  /.well-known/auth.md     Agent auth-registration guide (markdown)
 *
 * Everything describes the store's REAL public, read-only, no-auth agent
 * surface (catalog browse + product detail + llms.txt). Nothing here claims
 * a capability the site does not actually offer.
 */
require_once __DIR__ . '/includes/functions.php';

$base = function_exists('public_base_url') ? rtrim(public_base_url(), '/') : rtrim(site_url(), '/');
$ci   = function_exists('company_info') ? company_info() : ['name' => 'Maventech', 'email' => '', 'phone' => ''];

// Resolve which document was requested (router passes it; else derive from URI).
$doc = $GLOBALS['MV_WELLKNOWN'] ?? ($_GET['doc'] ?? '');
if ($doc === '') {
    $p   = strtolower((string)parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH));
    $doc = preg_replace('#^.*/#', '', $p);          // basename
    if ($doc === 'auth.md') $doc = 'auth.md';
}

header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=3600');

switch ($doc) {

    /* ---- RFC 9727 API Catalog (linkset) --------------------------------- */
    case 'api-catalog':
        header('Content-Type: application/linkset+json; charset=UTF-8');
        echo json_encode([
            'linkset' => [[
                'anchor' => $base . '/',
                'item' => [
                    ['href' => $base . '/agents.json',            'type' => 'application/json',    'title' => 'Agent discovery manifest'],
                    ['href' => $base . '/openapi.json',           'type' => 'application/json',    'title' => 'OpenAPI 3.1 specification (Catalog API)'],
                    ['href' => $base . '/api',                    'type' => 'application/json',    'title' => 'Public read-only JSON Catalog API'],
                    ['href' => $base . '/developers',             'type' => 'text/html',           'title' => 'Developer & agent resources hub'],
                    ['href' => $base . '/.well-known/mcp.json',   'type' => 'application/json',    'title' => 'MCP server card'],
                    ['href' => $base . '/.well-known/agent-skills.json', 'type' => 'application/json', 'title' => 'Agent skills index'],
                    ['href' => $base . '/llms.txt',               'type' => 'text/plain',          'title' => 'AI site summary (llmstxt.org)'],
                    ['href' => $base . '/llms-full.txt',          'type' => 'text/plain',          'title' => 'AI full context — inlined catalog, policies, guides & FAQs'],
                    ['href' => $base . '/AGENTS.md',              'type' => 'text/markdown',       'title' => 'Agent instructions / when-to-use'],
                    ['href' => $base . '/sitemap.xml',            'type' => 'application/xml',      'title' => 'XML sitemap'],
                    ['href' => $base . '/merchant-feed.xml',      'type' => 'application/rss+xml',  'title' => 'Product catalog feed'],
                ],
                'service-desc' => [
                    ['href' => $base . '/openapi.json', 'type' => 'application/json'],
                    ['href' => $base . '/.well-known/agent-skills.json', 'type' => 'application/json'],
                ],
            ]],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return;

    /* ---- RFC 8414 OAuth Authorization Server metadata ------------------- */
    // The store's agent surface is public / read-only. We publish valid
    // metadata so MCP/agent clients can DISCOVER that no interactive auth is
    // required (no scopes, no grant needed) rather than guessing.
    case 'oauth-authorization-server':
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'issuer'                                => $base,
            'authorization_endpoint'                => $base . '/.well-known/oauth-authorization-server',
            'token_endpoint'                        => $base . '/.well-known/oauth-authorization-server',
            'response_types_supported'              => ['none'],
            'grant_types_supported'                 => ['none'],
            'token_endpoint_auth_methods_supported' => ['none'],
            'scopes_supported'                      => ['catalog:read'],
            'service_documentation'                 => $base . '/auth.md',
            'access'                                => 'public',
            'note'                                  => 'Public read-only catalog. No interactive authorization is required to browse products or read content.',
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;

    /* ---- RFC 9728 OAuth Protected Resource metadata --------------------- */
    case 'oauth-protected-resource':
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'resource'                  => $base,
            'authorization_servers'     => [$base . '/.well-known/oauth-authorization-server'],
            'scopes_supported'          => ['catalog:read'],
            'bearer_methods_supported'  => [],
            'resource_documentation'    => $base . '/auth.md',
            'access'                    => 'public',
            'note'                      => 'All catalog and content endpoints are public and require no bearer token.',
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;

    /* ---- MCP Server Card ------------------------------------------------ */
    case 'mcp.json':
    case 'mcp':
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'schema_version' => '2025-06-18',
            'name'           => ($ci['name'] ?: 'Maventech') . ' Catalog',
            'description'    => 'Read-only MCP surface for browsing the software-license catalog and fetching product details & prices.',
            'transport'      => 'http',
            'authentication' => ['type' => 'none', 'access' => 'public'],
            'capabilities'   => ['tools' => true, 'resources' => true, 'prompts' => false],
            'skills_url'     => $base . '/.well-known/agent-skills.json',
            'openapi_url'    => $base . '/openapi.json',
            'api_base_url'   => $base . '/api',
            'documentation'  => $base . '/developers',
            'contact'        => ['email' => $ci['email'] ?? '', 'url' => $base . '/contact.php'],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;

    /* ---- Agent Skills index --------------------------------------------- */
    case 'agent-skills.json':
    case 'agent-skills':
    case 'skills.json':
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'schema_version' => '1.0',
            'provider'       => $ci['name'] ?: 'Maventech',
            'skills' => [
                [
                    'name'        => 'browse_catalog',
                    'description' => 'Browse or search the software-license catalog by category or keyword.',
                    'method'      => 'GET',
                    'url'         => $base . '/shop.php?q={query}&category={category}',
                    'parameters'  => ['query' => 'string (optional)', 'category' => 'string (optional)'],
                    'auth'        => 'none',
                ],
                [
                    'name'        => 'get_product',
                    'description' => 'Fetch a single product page with live price, edition, platform and activation details.',
                    'method'      => 'GET',
                    'url'         => $base . '/product.php?slug={slug}',
                    'parameters'  => ['slug' => 'string (required)'],
                    'auth'        => 'none',
                ],
                [
                    'name'        => 'query_catalog_api',
                    'description' => 'Public read-only JSON API: list/filter products and fetch a product as JSON. Returns structured JSON errors. OpenAPI: ' . $base . '/openapi.json.',
                    'method'      => 'GET',
                    'url'         => $base . '/api/products?q={query}&category={category}&limit={limit}&offset={offset}',
                    'parameters'  => ['query' => 'string (optional)', 'category' => 'string (optional)', 'limit' => 'int 1-100 (optional)', 'offset' => 'int (optional)'],
                    'auth'        => 'none',
                    'openapi'     => $base . '/openapi.json',
                ],
                [
                    'name'        => 'catalog_feed',
                    'description' => 'Machine-readable feed of every active product (RSS/XML).',
                    'method'      => 'GET',
                    'url'         => $base . '/merchant-feed.xml',
                    'auth'        => 'none',
                ],
                [
                    'name'        => 'track_order',
                    'description' => 'Look up an order status. Requires order number + the email on the order.',
                    'method'      => 'GET',
                    'url'         => $base . '/track-order.php?order={order_number}&email={email}',
                    'parameters'  => ['order_number' => 'string (required)', 'email' => 'string (required)'],
                    'auth'        => 'customer-owned (order number + email)',
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;

    /* ---- auth.md — agent auth registration guide (markdown) ------------- */
    case 'auth.md':
    default:
        header('Content-Type: text/markdown; charset=UTF-8');
        $name = $ci['name'] ?: 'Maventech';
        echo "# Agent Authentication — {$name}\n\n";
        echo "## Summary\n\n";
        echo "The {$name} catalog is a **public, read-only** agent surface. Browsing products, ";
        echo "reading content and fetching prices require **no authentication** — no API key, no OAuth, no bearer token.\n\n";
        echo "## Discovery\n\n";
        echo "- OpenAPI 3.1 spec: `{$base}/openapi.json`\n";
        echo "- JSON Catalog API: `{$base}/api` (products, categories, health)\n";
        echo "- Developer hub: `{$base}/developers`\n";
        echo "- API catalog (RFC 9727): `{$base}/.well-known/api-catalog`\n";
        echo "- Agent skills: `{$base}/.well-known/agent-skills.json`\n";
        echo "- MCP server card: `{$base}/.well-known/mcp.json`\n";
        echo "- Manifest: `{$base}/agents.json` · Summary: `{$base}/llms.txt` · Instructions: `{$base}/AGENTS.md`\n\n";
        echo "## OAuth metadata\n\n";
        echo "- Authorization server: `{$base}/.well-known/oauth-authorization-server`\n";
        echo "- Protected resource: `{$base}/.well-known/oauth-protected-resource`\n\n";
        echo "Both advertise `access: public` / `grant_types: none` — i.e. there is nothing to authorize for catalog reads.\n\n";
        echo "## Customer-scoped actions\n\n";
        echo "Order status is retrieved with the customer's own order number **and** the email on that order ";
        echo "(`{$base}/track-order.php`). Purchases and account changes are intentionally **not** available to agents ";
        echo "and require a human in the loop.\n\n";
        echo "## Contact\n\n";
        echo "- Email: " . ($ci['email'] ?? '') . "\n";
        echo "- Support: `{$base}/contact.php`\n";
        return;
}
