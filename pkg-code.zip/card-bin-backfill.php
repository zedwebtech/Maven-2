<?php
/**
 * card-bin-backfill.php
 *
 * One-click backfill of Funding + Issuing Country for EXISTING paid/attempted
 * card orders that have a stored BIN but empty funding/country (i.e. every
 * NMI / Authorize.Net / Custom order captured before the BIN-lookup feature).
 *
 * Admin-only. Safe to re-run — it only fills blanks and dedupes lookups per
 * BIN via the shared cache, so re-running costs almost nothing.
 *
 * Visit /card-bin-backfill.php while logged into the admin panel.
 */

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/bin_lookup.php';
ensure_admin();
$admin = require_admin();
$pdo   = db();

@set_time_limit(120);

$rows = $pdo->query(
    "SELECT id, card_bin, card_funding, card_country
       FROM orders
      WHERE card_bin IS NOT NULL AND card_bin <> ''
        AND ( card_funding IS NULL OR card_funding = '' OR card_funding = 'unknown'
              OR card_country IS NULL OR card_country = '' )
      ORDER BY id ASC"
)->fetchAll();

$scanned = 0; $updated = 0; $unresolved = 0; $details = [];
$upd = $pdo->prepare(
    "UPDATE orders SET
        card_funding = CASE WHEN (card_funding IS NULL OR card_funding='' OR card_funding='unknown') THEN NULLIF(?, '') ELSE card_funding END,
        card_country = CASE WHEN (card_country IS NULL OR card_country='') THEN NULLIF(?, '') ELSE card_country END
     WHERE id = ?"
);

foreach ($rows as $r) {
    $scanned++;
    $bl = mv_bin_lookup((string)$r['card_bin']);
    if (($bl['funding'] ?? '') !== '' || ($bl['country'] ?? '') !== '') {
        $upd->execute([$bl['funding'], $bl['country'], (int)$r['id']]);
        $updated++;
        $details[] = ['id' => (int)$r['id'], 'bin' => $r['card_bin'], 'funding' => $bl['funding'], 'country' => $bl['country'], 'ok' => true];
    } else {
        $unresolved++;
        $details[] = ['id' => (int)$r['id'], 'bin' => $r['card_bin'], 'funding' => '', 'country' => '', 'ok' => false];
    }
}

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Card BIN backfill</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f1f5f9;color:#0f172a;margin:0;padding:32px}
  .wrap{max-width:760px;margin:0 auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:28px 30px;box-shadow:0 10px 26px rgba(2,6,23,.08)}
  h1{font-size:22px;margin:0 0 4px} .sub{color:#64748b;font-size:13px;margin:0 0 20px}
  .stats{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 22px}
  .stat{flex:1;min-width:120px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px 16px}
  .stat b{display:block;font-size:26px} .stat span{color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:.05em}
  .ok b{color:#047857}.warn b{color:#b45309}.mut b{color:#334155}
  table{width:100%;border-collapse:collapse;font-size:13px} th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #eef2f7}
  th{color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.05em}
  .pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700}
  .pill.y{background:#d1fae5;color:#047857}.pill.n{background:#fef3c7;color:#b45309}
  a.btn{display:inline-block;margin-top:18px;background:#1d4ed8;color:#fff;text-decoration:none;padding:9px 16px;border-radius:10px;font-size:13px;font-weight:600}
</style></head><body>
<div class="wrap" data-testid="bin-backfill">
  <h1>Card BIN backfill</h1>
  <p class="sub">Fills <b>Funding</b> and <b>Issuing Country</b> from the stored BIN for existing card orders. Safe to re-run.</p>
  <div class="stats">
    <div class="stat mut"><b data-testid="bf-scanned"><?= (int)$scanned ?></b><span>Scanned</span></div>
    <div class="stat ok"><b data-testid="bf-updated"><?= (int)$updated ?></b><span>Updated</span></div>
    <div class="stat warn"><b data-testid="bf-unresolved"><?= (int)$unresolved ?></b><span>Unresolved</span></div>
  </div>
  <?php if ($scanned === 0): ?>
    <p>✅ Nothing to backfill — every card order already has funding &amp; issuing country.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Order</th><th>BIN</th><th>Funding</th><th>Country</th><th>Result</th></tr></thead>
      <tbody>
      <?php foreach ($details as $d): ?>
        <tr>
          <td><a href="order-view.php?id=<?= (int)$d['id'] ?>">#<?= (int)$d['id'] ?></a></td>
          <td><code><?= h($d['bin']) ?></code></td>
          <td><?= h($d['funding'] ?: '—') ?></td>
          <td><?= h($d['country'] ?: '—') ?></td>
          <td><span class="pill <?= $d['ok'] ? 'y' : 'n' ?>"><?= $d['ok'] ? 'updated' : 'not found' ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php if ($unresolved > 0): ?>
      <p class="sub" style="margin-top:16px">Unresolved rows had a BIN the lookup couldn't classify (rare/private BIN or a temporary rate limit). Re-run later to retry them.</p>
    <?php endif; ?>
  <?php endif; ?>
  <a class="btn" href="admin.php">← Back to admin</a>
</div>
</body></html>
