<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Shopping Cart | ' . brand_name();
$items = cart_items();
$subtotal = cart_subtotal();
$hasCoupon = !empty($_SESSION['coupon']);
$hasProAssist = !empty($_SESSION['proassist']);
$savings = 0;
foreach ($items as $i) {
    if ($i['original_price'] && $i['original_price'] > $i['price']) {
        $savings += ($i['original_price'] - $i['price']) * $i['qty'];
    }
}
include __DIR__ . '/includes/header.php';
?>
<?= render_page_head('Shopping Cart', $items ? cart_count() . ' item(s) in your cart — product keys delivered by email after order verification' : '', ['Cart' => null]) ?>
<div class="container py-4 py-lg-5">
 <div id="cart-page-root" data-testid="cart-page-root" data-count="<?= (int)cart_count() ?>">

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-warning" data-testid="cart-flash-error"
         style="border-radius:12px;background:linear-gradient(90deg,#fff7ed,#fef3c7);border:1px solid #fed7aa;color:#7c2d12;">
      <?= esc((string)$_SESSION['flash_error']) ?>
    </div>
    <?php unset($_SESSION['flash_error']); ?>
  <?php endif; ?>

  <?= render_vibe_promo_banner('cart') ?>

  <?php if (!$items): ?>
    <div class="text-center py-5">
      <i class="bi bi-cart-x display-1 text-secondary"></i>
      <p class="text-secondary mt-3">Your cart is empty.</p>
      <a href="shop.php" class="btn btn-primary rounded-pill px-4">Continue Shopping</a>
    </div>
  <?php else: ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <?php foreach ($items as $i): ?>
          <?php
          $hasDisc = $i['original_price'] && $i['original_price'] > $i['price'];
          $pct = $hasDisc ? round((1 - $i['price'] / $i['original_price']) * 100) : 0;
          ?>
          <div class="card mb-3 p-3" data-testid="cart-item-<?= esc($i['slug']) ?>">
            <div class="d-flex gap-3 align-items-center flex-wrap flex-md-nowrap">
              <img src="<?= esc($i['image']) ?>" alt="<?= esc($i['name']) ?> — one-time purchase license key, instant digital delivery | <?= brand_name() ?>" title="<?= esc($i['name']) ?>" style="width:72px;height:72px;object-fit:contain;" class="bg-body-tertiary rounded p-1 flex-shrink-0">
              <div class="flex-grow-1" style="min-width:0;">
                <a href="product.php?slug=<?= esc($i['slug']) ?>" class="fw-semibold text-decoration-none text-body d-block"><?= esc($i['name']) ?></a>
                <small class="text-secondary"><?= esc($i['platform']) ?> · One-Time Purchase</small>
                <?php
                  // Multi-seat seats badge — shown only when qty > 1.  Same noun-pick
                  // logic as order-success.php / email so the wording matches end-to-end.
                  $_seats = max(1, (int)$i['qty']);
                  if ($_seats > 1) {
                      $_isMS = (stripos((string)($i['brand'] ?? ''), 'microsoft') !== false)
                            || (stripos((string)$i['name'], 'microsoft') !== false)
                            || (stripos((string)$i['name'], 'office')    !== false)
                            || (stripos((string)$i['name'], 'windows')   !== false);
                      $_noun = $_isMS ? 'PC' : 'device';
                ?>
                  <div class="mt-1" data-testid="cart-seats-<?= esc($i['slug']) ?>">
                    <span style="display:inline-flex;align-items:center;gap:.3rem;background:linear-gradient(135deg,#e0f2fe,#bae6fd);color:#075985;border:1px solid #7dd3fc;border-radius:999px;padding:2px 9px;font-size:.7rem;font-weight:700;letter-spacing:.2px;">
                      <i class="bi bi-shield-check"></i>1 key · valid for <?= $_seats ?> <?= $_noun ?><?= $_seats > 1 ? 's' : '' ?>
                    </span>
                  </div>
                <?php } ?>
                <?php if ($hasDisc): ?>
                  <div class="small mt-1" data-testid="cart-discount-<?= esc($i['slug']) ?>">
                    <span class="text-secondary text-decoration-line-through me-1"><?= format_price((float)$i['original_price']) ?></span>
                    <span class="text-success fw-semibold"><i class="bi bi-piggy-bank me-1"></i>You save <?= format_price(($i['original_price'] - $i['price']) * $i['qty']) ?></span>
                  </div>
                <?php endif; ?>
              </div>
              <div class="d-flex align-items-center gap-2 gap-md-3 ms-auto flex-shrink-0">
                <div class="input-group" style="width: 120px;">
                  <button class="btn btn-sm btn-outline-secondary" data-cart-qty="<?= $i['qty'] - 1 ?>" data-slug="<?= esc($i['slug']) ?>">−</button>
                  <span class="form-control form-control-sm text-center"><?= (int)$i['qty'] ?></span>
                  <button class="btn btn-sm btn-outline-secondary" data-cart-qty="<?= $i['qty'] + 1 ?>" data-slug="<?= esc($i['slug']) ?>">+</button>
                </div>
                <div style="width:96px; text-align:right;">
                  <?php if ($hasDisc): ?><small class="text-secondary text-decoration-line-through d-block"><?= format_price($i['original_price'] * $i['qty']) ?></small><?php endif; ?>
                  <span class="fw-bold text-primary"><?= format_price($i['price'] * $i['qty']) ?></span>
                </div>
                <button class="cart-remove-btn" data-cart-remove="<?= esc($i['slug']) ?>" title="Remove item" aria-label="Remove item" data-testid="remove-<?= esc($i['slug']) ?>"><i class="bi bi-trash3-fill"></i></button>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <a href="shop.php" class="text-decoration-none"><i class="bi bi-arrow-left me-1"></i>Continue shopping</a>
      </div>

      <div class="col-lg-4">
        <div class="card p-4">
          <h5 class="fw-bold mb-3">Order Summary</h5>
          <?php if ($savings > 0): ?>
            <div class="d-flex justify-content-between small mb-2"><span class="text-secondary">Original price</span><span class="text-secondary text-decoration-line-through"><?= format_price($subtotal + $savings) ?></span></div>
            <div class="d-flex justify-content-between small mb-2 text-success"><span><i class="bi bi-tag-fill me-1"></i>You Save</span><span>-<?= format_price($savings) ?></span></div>
            <div class="d-flex justify-content-between small mb-2"><span class="text-secondary">Subtotal</span><span class="fw-semibold"><?= format_price($subtotal) ?></span></div>
          <?php else: ?>
            <div class="d-flex justify-content-between small mb-2"><span class="text-secondary">Subtotal</span><span class="fw-semibold"><?= format_price($subtotal) ?></span></div>
          <?php endif; ?>
          <hr>
          <div class="d-flex justify-content-between mb-3"><span class="fw-bold">Total</span><span class="fw-bold text-primary fs-5"><?= format_price($subtotal) ?></span></div>
          <a href="checkout.php" class="btn btn-primary btn-lg rounded-pill w-100" data-testid="proceed-checkout">Proceed to Checkout</a>
          <div class="text-center mt-3 small text-secondary"><i class="bi bi-shield-lock me-1"></i>Secure 256-bit SSL checkout</div>
        </div>
      </div>
    </div>
  <?php endif; ?>
 </div>
</div>

<?php if ($items): ?>
<?php /* ── Idle "don't leave" discount popup (admin-toggle + configurable %) ── */ ?>
<?php $save5On = (setting_get('save5_popup_enabled', '1') === '1'); $save5Pct = max(1, min(95, (int)setting_get('save5_percent', '5'))); $save5Code = function_exists('save5_code_config') ? save5_code_config()['code'] : 'SAVE5'; ?>
<?php if ($save5On): ?>
<div class="mv-save5-overlay" id="mvSave5Modal" data-testid="cart-save5-modal" data-has-coupon="<?= $hasCoupon ? '1' : '0' ?>" aria-hidden="true">
  <div class="mv-save5-card" role="dialog" aria-modal="true" aria-labelledby="mvSave5Title">
    <div class="mv-save5-head">
      <span id="mvSave5Title">Wait! Don't Leave Empty-Handed</span>
      <button type="button" class="mv-save5-x" data-mv-save5-close aria-label="Close" data-testid="cart-save5-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="mv-save5-body">
      <div class="mv-save5-ico"><i class="bi bi-tag-fill"></i></div>
      <p class="mv-save5-lead">Complete your purchase now and get</p>
      <div class="mv-save5-off" data-testid="cart-save5-percent"><?= $save5Pct ?>% OFF</div>
      <p class="mv-save5-sub">Copy this code &amp; paste it at checkout · valid for 24 hours</p>
      <div class="mv-save5-code-row">
        <code class="mv-save5-code" id="mvSave5Code" data-testid="cart-save5-code"><?= esc($save5Code) ?></code>
        <button type="button" class="mv-save5-copy" id="mvSave5Copy" data-testid="cart-save5-copy"><i class="bi bi-clipboard"></i> Copy</button>
      </div>
      <div class="mv-save5-timer" data-testid="cart-save5-timer"><i class="bi bi-clock-history"></i>Offer expires in <strong id="mvSave5Countdown">10:00</strong></div>
      <div class="mv-save5-trust">
        <div><i class="bi bi-clock-history"></i><span>Fast Delivery</span></div>
        <div><i class="bi bi-shield-lock"></i><span>Secure Payment</span></div>
        <div><i class="bi bi-headset"></i><span>Expert Support</span></div>
      </div>
      <button type="button" class="mv-save5-apply" id="mvSave5Apply" data-testid="cart-save5-apply">Copy code &amp; go to checkout</button>
      <button type="button" class="mv-save5-decline" data-mv-save5-close data-testid="cart-save5-decline">No thanks, I'll pay full price</button>
    </div>
  </div>
</div>
<?php endif; ?>
<style>
.mv-save5-overlay{position:fixed;inset:0;z-index:1080;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.55);backdrop-filter:blur(3px)}
.mv-save5-overlay.open{display:flex;animation:mvSave5Fade .22s ease}
@keyframes mvSave5Fade{from{opacity:0}to{opacity:1}}
.mv-save5-card{width:100%;max-width:380px;background:var(--bs-body-bg,#fff);border-radius:18px;overflow:hidden;box-shadow:0 30px 70px rgba(15,23,42,.35);transform:translateY(8px);animation:mvSave5Up .28s cubic-bezier(.2,.8,.2,1) forwards}
@keyframes mvSave5Up{to{transform:translateY(0)}}
.mv-save5-head{display:flex;align-items:center;justify-content:center;position:relative;background:linear-gradient(135deg,#2563eb,#0891b2);color:#fff;font-weight:800;font-size:1.02rem;letter-spacing:.2px;padding:15px 44px;text-align:center}
.mv-save5-x{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.15);border:0;color:#fff;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;cursor:pointer;font-size:.8rem;transition:background .15s ease}
.mv-save5-x:hover{background:rgba(255,255,255,.3)}
.mv-save5-body{padding:26px 26px 22px;text-align:center}
.mv-save5-ico{width:60px;height:60px;margin:0 auto 14px;border-radius:16px;display:grid;place-items:center;font-size:1.5rem;color:#2563eb;background:rgba(37,99,235,.1)}
.mv-save5-lead{margin:0;color:var(--bs-secondary-color,#64748b);font-size:.95rem}
.mv-save5-off{font-size:2.5rem;font-weight:900;line-height:1.1;background:linear-gradient(135deg,#2563eb,#0891b2);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin:2px 0 6px}
.mv-save5-sub{margin:0 0 12px;color:var(--bs-secondary-color,#94a3b8);font-size:.78rem}
.mv-save5-code-row{display:flex;align-items:stretch;gap:8px;justify-content:center;margin:0 0 14px}
.mv-save5-code{display:inline-flex;align-items:center;justify-content:center;min-width:120px;padding:9px 16px;border:2px dashed #2563eb;border-radius:10px;background:rgba(37,99,235,.06);color:#1d4ed8;font-weight:800;font-size:1.05rem;letter-spacing:2px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
.mv-save5-copy{border:0;border-radius:10px;padding:9px 14px;background:#0891b2;color:#fff;font-weight:700;font-size:.85rem;cursor:pointer;white-space:nowrap;transition:background .15s ease}
.mv-save5-copy:hover{background:#0e7490}
.mv-save5-timer{display:inline-flex;align-items:center;gap:7px;margin:0 auto 18px;padding:7px 15px;border-radius:999px;background:rgba(239,68,68,.1);color:#dc2626;font-size:.82rem;font-weight:700}
.mv-save5-timer strong{font-variant-numeric:tabular-nums;letter-spacing:.5px}
.mv-save5-trust{display:flex;justify-content:space-between;gap:8px;padding:14px 0;margin-bottom:18px;border-top:1px solid var(--bs-border-color,#e2e8f0);border-bottom:1px solid var(--bs-border-color,#e2e8f0)}
.mv-save5-trust>div{flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;color:var(--bs-secondary-color,#64748b);font-size:.72rem;font-weight:600}
.mv-save5-trust i{font-size:1.05rem;color:#0891b2}
.mv-save5-apply{width:100%;border:0;border-radius:12px;padding:13px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;font-weight:800;font-size:1rem;letter-spacing:.2px;cursor:pointer;box-shadow:0 10px 24px rgba(37,99,235,.32);transition:transform .15s ease,box-shadow .15s ease}
.mv-save5-apply:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(37,99,235,.42)}
.mv-save5-apply:disabled{opacity:.7;cursor:default;transform:none}
.mv-save5-decline{display:block;width:100%;margin-top:12px;background:none;border:0;color:var(--bs-secondary-color,#94a3b8);font-size:.85rem;cursor:pointer;text-decoration:underline;text-underline-offset:2px}
.mv-save5-decline:hover{color:var(--bs-body-color,#475569)}
</style>
<script>
(function(){
  var modal = document.getElementById('mvSave5Modal');
  if (!modal) return;
  if (modal.getAttribute('data-has-coupon') === '1') return;      // a coupon is already applied
  if (sessionStorage.getItem('mv_save5_shown')) return;           // show once per browser SESSION
  var IDLE = 8000, timer = null, fired = false, body = document.body, cdInt = null;
  function startCountdown(){
    var el = document.getElementById('mvSave5Countdown');
    if (!el) return;
    var remaining = 10 * 60;  // 10:00
    function tick(){
      if (remaining < 0) remaining = 0;
      var m = Math.floor(remaining / 60), s = remaining % 60;
      el.textContent = m + ':' + (s < 10 ? '0' + s : s);
      if (remaining <= 0) { clearInterval(cdInt); return; }
      remaining--;
    }
    tick();
    cdInt = setInterval(tick, 1000);
  }
  function show(){
    if (fired) return; fired = true;
    try { sessionStorage.setItem('mv_save5_shown','1'); } catch(e){}
    modal.classList.add('open'); modal.setAttribute('aria-hidden','false');
    body.style.overflow = 'hidden';
    startCountdown();
  }
  function hide(){
    modal.classList.remove('open'); modal.setAttribute('aria-hidden','true');
    body.style.overflow = '';
    if (cdInt) clearInterval(cdInt);
  }
  function arm(){ if (fired) return; clearTimeout(timer); timer = setTimeout(show, IDLE); }
  // PRIMARY trigger: exit-intent — the shopper flicks the cursor up toward the
  // browser tab bar / back button / address bar (leaves through the top edge).
  function onExit(e){
    if (fired) return;
    if (e.relatedTarget || e.toElement) return;   // cursor is still inside the page
    if ((e.clientY || 0) > 0) return;             // only when it exits via the TOP edge
    show();
  }
  document.addEventListener('mouseout', onExit, true);
  // FALLBACK trigger: 8s of inactivity — covers touch devices (no exit-intent)
  // and shoppers who simply hesitate on the cart without moving to leave.
  // Reset only on meaningful actions (clicks / typing), not passive scroll.
  ['click','keydown'].forEach(function(ev){ document.addEventListener(ev, arm, true); });
  arm();
  modal.addEventListener('click', function(e){
    if (e.target === modal || e.target.closest('[data-mv-save5-close]')) { hide(); }
  });
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && modal.classList.contains('open')) hide(); });
  var applyBtn = document.getElementById('mvSave5Apply');
  var codeEl   = document.getElementById('mvSave5Code');
  var copyBtn  = document.getElementById('mvSave5Copy');
  function copyCode(){
    var code = (codeEl ? codeEl.textContent : '').trim();
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(code); }
      else { var t=document.createElement('textarea'); t.value=code; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); }
    } catch(e){}
    if (copyBtn){ copyBtn.innerHTML = '<i class="bi bi-check2"></i> Copied'; setTimeout(function(){ copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copy'; }, 1800); }
  }
  if (copyBtn) copyBtn.addEventListener('click', copyCode);
  // Primary button: copy the code, then take the shopper to checkout where
  // they paste it into the coupon box (customer-applied, not auto-applied).
  applyBtn.addEventListener('click', function(){
    copyCode();
    window.location.href = 'checkout.php';
  });
})();
</script>
<?php endif; ?>

<?php if ($items && proassist_enabled()): ?>
<?php /* ── ProAssist Premium Installation upsell ─────────────────────────
        Shown when the shopper clicks "Proceed to Checkout" (once per session,
        skipped if already added). "Add ProAssist" flags the session and the
        checkout bills it + notifies admin (install schedule) + emails team. */ ?>
<div class="pa-overlay" id="paModal" data-testid="cart-proassist-modal" data-added="<?= $hasProAssist ? '1' : '0' ?>" aria-hidden="true">
  <div class="pa-card" role="dialog" aria-modal="true" aria-labelledby="paTitle">
    <div class="pa-head">
      <span id="paTitle">Add ProAssist Premium Installation</span>
      <button type="button" class="pa-x" data-pa-close aria-label="Close" data-testid="cart-proassist-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="pa-body">
      <div class="pa-badge">
        <span class="pa-badge-ico"><i class="bi bi-lightning-charge-fill"></i></span>
        <span class="pa-badge-name">ProAssist Premium Installation</span>
      </div>
      <div class="pa-content">
        <div class="pa-content-title">Professional Installation + 1-Year Tech Support</div>
        <ul class="pa-benefits">
          <li><i class="bi bi-check-circle-fill"></i>Professional Remote Installation</li>
          <li><i class="bi bi-check-circle-fill"></i>Same-Business-Day Setup</li>
          <li><i class="bi bi-check-circle-fill"></i>1-Year Technical Support</li>
          <li><i class="bi bi-check-circle-fill"></i>Secure Encrypted Connection</li>
          <li><i class="bi bi-check-circle-fill"></i>Software Setup &amp; Activation Assistance</li>
          <li><i class="bi bi-check-circle-fill"></i>Troubleshooting Support</li>
          <li><i class="bi bi-check-circle-fill"></i>Money-Back Guarantee</li>
        </ul>
      </div>
    </div>
    <div class="pa-actions">
      <button type="button" class="pa-decline" data-pa-decline data-testid="cart-proassist-decline">No thanks, continue to checkout</button>
      <button type="button" class="pa-add" id="paAdd" data-testid="cart-proassist-add">Add ProAssist <?= format_price(proassist_price()) ?></button>
    </div>
    <div class="pa-notes">
      <p><sup>1</sup>Installation service guaranteed within business hours (Monday&ndash;Saturday, 9AM&ndash;5PM EST).</p>
      <p><sup>2</sup>We guarantee a successful installation of your software or we refund you for the service.</p>
    </div>
  </div>
</div>
<style>
.pa-overlay{position:fixed;inset:0;z-index:1085;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.55);backdrop-filter:blur(3px)}
.pa-overlay.open{display:flex;animation:mvSave5Fade .22s ease}
.pa-card{width:100%;max-width:430px;background:var(--bs-body-bg,#fff);border-radius:16px;overflow:hidden;box-shadow:0 24px 56px rgba(15,23,42,.32);transform:translateY(8px);animation:mvSave5Up .28s cubic-bezier(.2,.8,.2,1) forwards}
.pa-head{position:relative;text-align:center;padding:13px 42px;font-weight:800;font-size:.96rem;border-bottom:1px solid var(--bs-border-color)}
.pa-x{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:0;color:var(--bs-secondary-color);width:28px;height:28px;border-radius:50%;cursor:pointer;font-size:.85rem;display:grid;place-items:center;transition:background .15s ease}
.pa-x:hover{background:var(--bs-tertiary-bg,#f1f5f9)}
.pa-body{display:flex;gap:14px;padding:16px 18px 6px}
.pa-badge{flex:0 0 96px;background:linear-gradient(150deg,#2563eb,#1d4ed8);color:#fff;border-radius:12px;padding:14px 10px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:8px;align-self:flex-start;box-shadow:0 10px 22px rgba(37,99,235,.28)}
.pa-badge-ico{width:42px;height:42px;border-radius:12px;background:rgba(255,255,255,.18);display:grid;place-items:center;font-size:1.25rem}
.pa-badge-name{font-size:.74rem;font-weight:800;line-height:1.2}
.pa-content-title{font-weight:800;font-size:.94rem;margin-bottom:9px}
.pa-benefits{list-style:none;padding:0;margin:0}
.pa-benefits li{display:flex;align-items:center;gap:8px;font-size:.82rem;padding:3px 0;color:var(--bs-body-color)}
.pa-benefits li i{color:#16a34a;font-size:.92rem}
.pa-actions{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px 18px 6px;flex-wrap:nowrap}
.pa-decline{flex:1 1 auto;min-width:0;text-align:left;background:none;border:0;color:var(--bs-secondary-color);font-size:.82rem;text-decoration:underline;text-underline-offset:2px;cursor:pointer;padding:6px 0}
.pa-decline:hover{color:var(--bs-body-color)}
.pa-add{flex:0 0 auto;white-space:nowrap;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border:0;border-radius:11px;padding:10px 20px;font-weight:800;font-size:.9rem;cursor:pointer;box-shadow:0 10px 24px rgba(37,99,235,.32);transition:transform .15s ease,box-shadow .15s ease}
.pa-add:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(37,99,235,.42)}
.pa-add:disabled{opacity:.7;cursor:default;transform:none}
.pa-notes{padding:6px 18px 16px;border-top:1px solid var(--bs-border-color);margin-top:8px}
.pa-notes p{margin:6px 0 0;font-size:.7rem;color:var(--bs-secondary-color);line-height:1.4}
@media (max-width:520px){.pa-body{flex-direction:column;align-items:center}.pa-badge{flex-basis:auto;width:100%}.pa-actions{flex-direction:column-reverse;align-items:stretch;gap:8px}.pa-add{width:100%;text-align:center}.pa-decline{flex:0 0 auto;text-align:center}}
</style>
<script>
(function(){
  var modal = document.getElementById('paModal');
  var checkoutBtn = document.querySelector('[data-testid="proceed-checkout"]');
  if (!modal || !checkoutBtn) return;
  var body = document.body;
  var goCheckout = function(){ window.location.href = 'checkout.php'; };
  function show(){ modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); body.style.overflow='hidden'; }
  function hide(){ modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); body.style.overflow=''; }
  checkoutBtn.addEventListener('click', function(e){
    if (modal.getAttribute('data-added') === '1') return;               // already added → proceed
    e.preventDefault();
    show();
  });
  modal.addEventListener('click', function(e){
    if (e.target === modal || e.target.closest('[data-pa-close]')) hide();
  });
  document.addEventListener('keydown', function(e){ if (e.key==='Escape' && modal.classList.contains('open')) hide(); });
  modal.querySelector('[data-pa-decline]').addEventListener('click', goCheckout);
  var addBtn = document.getElementById('paAdd');
  addBtn.addEventListener('click', function(){
    addBtn.disabled = true;
    addBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adding…';
    fetch('ajax/cart.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ action:'proassist', value:1 })
    }).then(function(r){ return r.json(); }).then(goCheckout).catch(goCheckout);
  });
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
