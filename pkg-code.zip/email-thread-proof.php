<?php
/*
 * Email Thread & Delivery Proof PDF — a per-customer, bank-ready record of
 * every email we sent for an order. Admin-only. Linked from order-view.php.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/pdf.php';
ensure_admin();
require_admin();

$id = (int)($_GET['id'] ?? 0);
$q = db()->prepare('SELECT * FROM orders WHERE id=?');
$q->execute([$id]);
$o = $q->fetch();
if (!$o) { http_response_code(404); die('Order not found'); }

$pdf = mv_render_email_thread_proof_pdf($o);

header('Content-Type: application/pdf');
header('Content-Disposition: ' . (isset($_GET['view']) ? 'inline' : 'attachment') . '; filename="Email-Thread-Proof-' . preg_replace('/[^A-Za-z0-9\-_]/', '', (string)$o['order_number']) . '.pdf"');
header('Cache-Control: no-store');
echo $pdf;
