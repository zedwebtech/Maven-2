<?php
/**
 * Deploy helper — clears PHP OPcache and confirms which admin.php is live.
 *
 * WHY THIS EXISTS
 * ---------------
 * On cPanel/LiteSpeed shared hosting, PHP keeps a compiled copy of every
 * .php file in memory (OPcache). After you upload a new admin.php the server
 * can keep running the OLD compiled copy until OPcache is reset — which makes
 * it look like "my fix didn't deploy" even though the file on disk is correct.
 *
 * HOW TO USE (after uploading any update zip)
 * -------------------------------------------
 *   1. Make sure you are logged into the admin panel in this browser.
 *   2. Visit:  https://YOURDOMAIN.com/opcache-reset.php
 *   3. Read the report. It tells you whether the NEW admin.php is on disk and
 *      clears the cache so the new code runs right away. Then hard-refresh the
 *      admin page (Ctrl/Cmd + Shift + R).
 *
 * It is safe to run any time. It only clears the bytecode cache — it never
 * touches your database, orders, leads or settings.
 */
require_once __DIR__ . '/includes/functions.php';

// ── Admin-only: never expose cache controls to the public ──────────────────
$u = function_exists('current_user') ? current_user() : null;
if (!($u && in_array(($u['role'] ?? ''), ['admin', 'staff'], true))) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Forbidden — please log into the admin panel first, then reload this page.");
}

header('Content-Type: text/html; charset=utf-8');

// A string that ONLY exists in the FIXED admin.php. If it's present on disk,
// the new file really was uploaded; if absent, the upload didn't replace it.
$fixMarker = 'emails-bulk-wrap';
$adminPath = __DIR__ . '/admin.php';
$onDisk    = is_file($adminPath) ? (string)file_get_contents($adminPath) : '';
$hasFix    = $onDisk !== '' && strpos($onDisk, $fixMarker) !== false;
$adminMtime = is_file($adminPath) ? date('Y-m-d H:i:s', filemtime($adminPath)) : 'missing';
$adminSize  = is_file($adminPath) ? number_format(filesize($adminPath)) . ' bytes' : '—';

// ── Clear every layer of PHP bytecode / realpath cache we can ───────────────
$opcacheEnabled = function_exists('opcache_get_status');
$reset = false;
if (function_exists('opcache_reset')) {
    $reset = @opcache_reset();
}
// Also force-invalidate the two files that matter most, in case reset is
// restricted on this host.
if (function_exists('opcache_invalidate')) {
    @opcache_invalidate($adminPath, true);
    @opcache_invalidate(__FILE__, true);
}
clearstatcache(true);
if (function_exists('apcu_clear_cache')) @apcu_clear_cache();

// ── Volume-licensing email block: verify it is on disk + sweep the queue ──
$mailerOnDisk   = (string)@file_get_contents(__DIR__ . '/includes/mailer.php');
$volBlockOnDisk = strpos($mailerOnDisk, 'function mv_email_blocked') !== false;
$volLive = $volSent24h = $volCancelled = 0;
try {
    $pdoV = db();
    $pdoV->exec("UPDATE email_outbox SET status='cancelled', next_retry_at=NULL,
                   last_error='Volume licensing removed — email suppressed'
                 WHERE status <> 'sent'
                   AND (template_code='volume_request_admin' OR subject LIKE '%Volume%'
                        OR subject LIKE '%Business Pricing%' OR subject LIKE '%Bulk Licens%')");
    $volWhere = "(template_code='volume_request_admin' OR subject LIKE '%Volume%' OR subject LIKE '%Business Pricing%' OR subject LIKE '%Bulk Licens%')";
    $volLive      = (int)$pdoV->query("SELECT COUNT(*) FROM email_outbox WHERE status IN ('queued','retrying') AND $volWhere")->fetchColumn();
    $volCancelled = (int)$pdoV->query("SELECT COUNT(*) FROM email_outbox WHERE status='cancelled' AND $volWhere")->fetchColumn();
    $volSent24h   = (int)$pdoV->query("SELECT COUNT(*) FROM email_outbox WHERE status='sent' AND delivered_at >= (NOW() - INTERVAL 24 HOUR) AND $volWhere")->fetchColumn();
} catch (Throwable $e) { /* best-effort */ }

$okColor  = '#16a34a';
$badColor = '#dc2626';
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cache reset — Maventech</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f1f5f9;color:#0f172a;margin:0;padding:32px;}
  .card{max-width:640px;margin:0 auto;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:28px;box-shadow:0 8px 30px rgba(15,23,42,.06);}
  h1{font-size:20px;margin:0 0 6px;}
  .row{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px dashed #e2e8f0;font-size:14px;}
  .row:last-child{border-bottom:0;}
  .k{color:#64748b;}
  .v{font-weight:700;text-align:right;}
  .pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:700;color:#fff;}
  .note{margin-top:18px;font-size:13px;line-height:1.6;color:#475569;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;}
  a.btn{display:inline-block;margin-top:16px;background:#0ea5e9;color:#fff;text-decoration:none;padding:10px 18px;border-radius:10px;font-weight:700;font-size:14px;}
</style></head>
<body><div class="card">
  <h1>🧹 Deploy cache reset</h1>
  <p style="color:#64748b;font-size:14px;margin-top:0;">Safe to run anytime. This never touches your database.</p>

  <div class="row"><span class="k">New admin.php uploaded to server?</span>
    <span class="v"><span class="pill" style="background:<?= $hasFix ? $okColor : $badColor ?>;"><?= $hasFix ? 'YES — new file is on disk' : 'NO — still the OLD file' ?></span></span></div>
  <div class="row"><span class="k">admin.php last modified</span><span class="v"><?= htmlspecialchars($adminMtime) ?></span></div>
  <div class="row"><span class="k">admin.php size</span><span class="v"><?= htmlspecialchars($adminSize) ?></span></div>
  <div class="row"><span class="k">OPcache available</span><span class="v"><?= $opcacheEnabled ? 'yes' : 'no' ?></span></div>
  <div class="row"><span class="k">OPcache reset</span>
    <span class="v"><span class="pill" style="background:<?= $reset ? $okColor : '#64748b' ?>;"><?= $reset ? 'CLEARED' : ($opcacheEnabled ? 'reset restricted — invalidated instead' : 'not enabled') ?></span></span></div>
  <div class="row" data-testid="volume-block-row"><span class="k">Volume / Business Pricing email block</span>
    <span class="v"><span class="pill" style="background:<?= $volBlockOnDisk ? $okColor : $badColor ?>;"><?= $volBlockOnDisk ? 'ACTIVE on this server' : 'MISSING — upload includes/mailer.php' ?></span></span></div>
  <div class="row"><span class="k">Volume emails waiting to send / cancelled / sent last 24h</span>
    <span class="v" data-testid="volume-queue-stats"><?= $volLive ?> / <?= $volCancelled ?> / <?= $volSent24h ?></span></div>

  <?php if (!$hasFix): ?>
    <div class="note">⚠️ <strong>The new admin.php is NOT on your server yet.</strong> The upload didn't replace the old file. Re-upload <code>admin.php</code> from the update zip to your site's root folder (overwrite the existing one), then reload this page — the top row must turn green before the fix can work.</div>
  <?php else: ?>
    <div class="note">✅ <strong>The fixed admin.php is live and the cache is cleared.</strong> Now hard-refresh the admin panel: press <strong>Ctrl + Shift + R</strong> (Windows) or <strong>Cmd + Shift + R</strong> (Mac), go to <em>Email Activity</em>, tick some emails and try <em>Mark read / Archive / Delete</em> — they will work.</div>
  <?php endif; ?>

  <a class="btn" href="admin.php?tab=emails">Go to Email Activity →</a>
</div></body></html>
