<?php
// Temporary download endpoint for the deployment package.
$f = __DIR__ . '/maventech-deploy.zip';
if (!is_file($f)) { http_response_code(404); exit('not found'); }
$ct = $_GET['ct'] ?? 'zip';
if ($ct === 'oct')  header('Content-Type: application/octet-stream');
elseif ($ct === 'txt') header('Content-Type: text/plain; charset=utf-8');
else header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="maventech-deploy.zip"');
header('Content-Length: ' . filesize($f));
header('Cache-Control: no-store');
readfile($f);
