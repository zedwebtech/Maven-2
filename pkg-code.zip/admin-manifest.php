<?php
/* ===========================================================================
 *  ADMIN PWA MANIFEST  —  /admin-manifest.json
 *  Generated live so the install name + every icon follow Admin → Company
 *  Info (brand name, uploaded logo / auto-monogram). Routed here by
 *  router.php (preview) and .htaccess (Apache / cPanel).
 *  =========================================================================== */
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/manifest+json');
header('Cache-Control: public, max-age=3600');

$brand = (string)(company_info()['name'] ?? '') ?: brand_name();
$short = preg_replace('/\s+software\s*$/i', '', $brand);
if (mb_strlen($short) > 12) $short = mb_substr($short, 0, 12);
$icon  = fn(int $s) => ['src' => app_icon_url($s), 'sizes' => $s . 'x' . $s, 'type' => 'image/png', 'purpose' => 'any'];
$sc    = fn(string $name, string $tab) => ['name' => $name, 'url' => '/admin.php?tab=' . $tab, 'icons' => [['src' => app_icon_url(192), 'sizes' => '192x192']]];

echo json_encode([
    'name'             => $brand . ' Admin',
    'short_name'       => $short,
    'description'      => $brand . ' admin console — orders, leads, reviews, emails and installs at a glance.',
    'start_url'        => '/admin.php?source=pwa',
    'scope'            => '/',
    'display'          => 'standalone',
    'orientation'      => 'any',
    'background_color' => '#0b1220',
    'theme_color'      => '#0B5CFF',
    'id'               => '/admin.php?source=pwa',
    'categories'       => ['business', 'productivity'],
    'icons'            => [$icon(192), $icon(256), $icon(384), $icon(512)],
    'shortcuts'        => [
        $sc('Orders', 'orders'), $sc('Sales Detail', 'sales'), $sc('Lead Management', 'leads'),
        $sc('Install Schedule', 'installs'), $sc('Email Activity', 'emails'),
        $sc('Customer Reviews', 'reviews'), $sc('Email Templates', 'templates'),
    ],
], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
