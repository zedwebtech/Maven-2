<?php
// CLI: php tools/gen-ads-images.php [slug ...] | --all [--force]
// Generates the Google Ads image asset (square + landscape) for products via mv_generate_ads_image().
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/product-image.php';
$pdo = db();

$args  = array_slice($argv, 1);
$force = in_array('--force', $args, true);
$all   = in_array('--all', $args, true);
$slugs = array_values(array_filter($args, fn($a) => $a[0] !== '-'));
if ($all) {
    $slugs = $pdo->query('SELECT slug FROM products WHERE is_active=1 ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
}
if (!$slugs) { fwrite(STDERR, "usage: php tools/gen-ads-images.php <slug>... | --all [--force]\n"); exit(1); }

foreach ($slugs as $slug) {
    $st = $pdo->prepare('SELECT slug, name, brand, category, platform, apps FROM products WHERE slug=? LIMIT 1');
    $st->execute([$slug]);
    $p = $st->fetch();
    if (!$p) { echo "[skip] $slug — not found\n"; continue; }
    $have = mv_ads_image_for($p);
    if (!$force && $have['square'] !== '') { echo "[ok  ] $slug — exists\n"; continue; }
    $t = microtime(true);
    $r = mv_generate_ads_image($p);
    printf("[%s] %s — %s (%.0fs)\n", !empty($r['ok']) ? 'done' : 'FAIL', $slug, !empty($r['ok']) ? $r['square'] : ($r['error'] ?? '?'), microtime(true) - $t);
}
