/* WebMCP — in-browser Model Context Protocol tools.
 * Exposes read-only catalog tools to WebMCP-aware agents via
 * navigator.modelContext (W3C Web Agents / WebMCP proposal). All tools call
 * the site's REAL public endpoints and return markdown (via the site's
 * ?format=md content negotiation) — no auth, read-only, no side effects. */
(function () {
  function registerTools(ctx) {
    if (!ctx || typeof ctx.registerTool !== 'function') return;
    ctx.registerTool({
      name: 'search_products',
      description: 'Search the Maventech software-license catalog by keyword (Office, Windows, antivirus, etc.).',
      inputSchema: { type: 'object', properties: { query: { type: 'string', description: 'Search keywords' } }, required: ['query'] },
      async execute(args) {
        var q = (args && args.query) || '';
        var r = await fetch('/shop.php?q=' + encodeURIComponent(q), { headers: { 'Accept': 'text/markdown' } });
        return { content: [{ type: 'text', text: await r.text() }] };
      }
    });
    ctx.registerTool({
      name: 'get_product',
      description: 'Fetch a single product (price, edition, platform, activation) by its URL slug.',
      inputSchema: { type: 'object', properties: { slug: { type: 'string', description: 'Product slug' } }, required: ['slug'] },
      async execute(args) {
        var s = (args && args.slug) || '';
        var r = await fetch('/product.php?slug=' + encodeURIComponent(s), { headers: { 'Accept': 'text/markdown' } });
        return { content: [{ type: 'text', text: await r.text() }] };
      }
    });
  }

  try {
    if (!('modelContext' in navigator)) {
      // Minimal registry so WebMCP-aware agents can still discover our tools.
      Object.defineProperty(navigator, 'modelContext', {
        value: { tools: [], registerTool: function (t) { this.tools.push(t); } },
        configurable: true, writable: true
      });
    }
    registerTools(navigator.modelContext);
    window.__WEBMCP__ = {
      version: '0.1',
      transport: 'in-browser',
      tools: (navigator.modelContext.tools || []).map(function (t) { return t.name; })
    };
  } catch (e) { /* non-fatal */ }
})();
