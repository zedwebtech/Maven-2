/* Resolve AJAX endpoints against the CURRENT page origin so a <base href>
 * (set on /hub/ landing pages to the canonical root) can never redirect
 * same-site POSTs to a different host — which was silently breaking
 * Add to Cart / Buy Now on the deployed domain. */
function mvUrl(p){ return window.location.origin + '/' + String(p).replace(/^\/+/, ''); }

// UCODE SOFTTECH Store - shared JS (theme, cart, chat, checkout)

/* ---------- Theme: LIGHT by default — dark only when the visitor toggles it ----------
   <html data-bs-theme> is ALWAYS decided before first paint (server-side from the
   account/cookie preference, or header.php's inline boot script from localStorage).
   main.js is deferred and runs AFTER paint, so it must never re-decide the theme —
   when the two sources disagreed the page painted dark and then flipped to light
   (the "black screen, then the checkout appears" flash). Only mirror the applied
   value into localStorage so every later navigation agrees with it. */
(function () {
  const html = document.documentElement;
  let t = html.getAttribute('data-bs-theme');
  if (t !== 'dark' && t !== 'light') {
    t = localStorage.getItem('uc_theme') === 'dark' ? 'dark' : 'light';
    html.setAttribute('data-bs-theme', t);
  }
  try { localStorage.setItem('uc_theme', t); } catch (_) {}
})();
function toggleTheme() {
  const html = document.documentElement;
  const next = html.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-bs-theme', next);
  localStorage.setItem('uc_theme', next);
  // Fire-and-forget: when the user is logged in (admin, customer, anyone
  // with a session cookie), the choice is also written to users.theme_pref
  // so it follows them across browsers / devices.  When not logged in,
  // the server quietly sets matching uc_theme/adm_mode cookies and the
  // localStorage flag continues to drive the per-browser experience.
  try {
    fetch('ajax/user-theme.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ theme: next })
    }).catch(() => { /* offline / 5xx — local cookie + localStorage still win */ });
  } catch (_) {}
  syncThemeIcon();
}
function syncThemeIcon() {
  const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
  const cls    = isDark ? 'bi bi-sun' : 'bi bi-moon';
  // Sync BOTH the desktop topbar icon AND the mobile-menu icon so the
  // sun/moon glyph matches the current theme on every viewport.
  const ids = ['theme-icon', 'theme-icon-mobile'];
  for (const id of ids) {
    const el = document.getElementById(id);
    if (el) el.className = cls;
  }
}
document.addEventListener('DOMContentLoaded', syncThemeIcon);

/* ---------- Toast (rich notification card) ---------- */
function showToast(msg, opts = {}) {
  let wrap = document.getElementById('toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'toast-wrap';
    wrap.className = 'mv-toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className = 'mv-toast' + (opts.className ? ' ' + opts.className : '');
  el.setAttribute('data-testid', opts.title ? 'rich-toast' : 'toast');
  const ttl = opts.duration || 3200;
  el.style.setProperty('--toast-ttl', ttl + 'ms');
  el.innerHTML =
    (opts.icon ? '<span class="mv-toast-icon">' + opts.icon + '</span>' : '') +
    '<div class="mv-toast-body">' +
      (opts.title ? '<div class="mv-toast-title">' + opts.title + '</div>' : '') +
      '<div class="mv-toast-msg">' + msg + '</div>' +
      (opts.actionHref
        ? '<a href="' + opts.actionHref + '" class="mv-toast-action" data-testid="toast-open-cart">' + opts.actionLabel + ' <i class="bi bi-arrow-right"></i></a>'
        : '') +
      (opts.actionText
        ? '<button type="button" class="mv-toast-action mv-toast-action-btn" data-testid="toast-action-btn">' + opts.actionText + '</button>'
        : '') +
    '</div>' +
    '<button class="mv-toast-close" aria-label="Dismiss" data-testid="toast-close"><i class="bi bi-x-lg"></i></button>' +
    '<span class="mv-toast-progress"></span>';
  wrap.appendChild(el);
  let timer;
  const dismiss = () => {
    clearTimeout(timer);
    el.classList.add('hide');
    setTimeout(() => el.remove(), 320);
  };
  el.querySelector('.mv-toast-close').addEventListener('click', dismiss);
  if (opts.actionText && typeof opts.onAction === 'function') {
    const ab = el.querySelector('.mv-toast-action-btn');
    if (ab) ab.addEventListener('click', (ev) => { ev.preventDefault(); try { opts.onAction(); } finally { dismiss(); } });
  }
  // Whole-card click handler (e.g. "added to cart" toast opens the cart).
  if (typeof opts.onClick === 'function') {
    el.classList.add('mv-toast-clickable');
    el.style.cursor = 'pointer';
    el.setAttribute('role', 'button');
    el.addEventListener('click', (ev) => {
      // Ignore clicks on the close button or any inner link/button.
      if (ev.target.closest('.mv-toast-close') || ev.target.closest('a,button')) return;
      try { opts.onClick(); } finally { dismiss(); }
    });
  }
  timer = setTimeout(dismiss, ttl);
}

/* ---------- Cart ---------- */
async function cartAction(payload) {
  const res = await fetch('ajax/cart.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

function updateCartBadge(count) {
  document.querySelectorAll('.cart-count-badge').forEach((b) => {
    b.textContent = count;
    b.classList.toggle('d-none', count === 0);
    // brief bounce so the cart is noticed (especially on mobile)
    b.classList.remove('cart-bump');
    void b.offsetWidth;
    b.classList.add('cart-bump');
  });
}

/* Added-to-cart button state */
function markAdded(btn) {
  if (!btn.dataset.origHtml) btn.dataset.origHtml = btn.innerHTML;
  btn.classList.add('added');
  btn.dataset.added = '1';
  const big = btn.classList.contains('btn-lg');
  btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i>' + (big ? 'Added to Cart — View' : 'Added');
  btn.title = 'Already in your cart — click to view';
}

/* Revert add-to-cart buttons for a slug back to "Add to Cart" (used when an
   item is removed from the mini-cart drawer / cleared). */
function markRemoved(slug) {
  if (!slug) return;
  document.querySelectorAll('.add-to-cart-btn').forEach(function (b) {
    if (b.dataset.slug !== slug) return;
    b.classList.remove('added');
    delete b.dataset.added;
    if (b.dataset.origHtml) b.innerHTML = b.dataset.origHtml;
    b.title = 'Add to cart';
  });
  if (window.CART_SLUGS) window.CART_SLUGS = window.CART_SLUGS.filter(function (s) { return s !== slug; });
}
window.markRemoved = markRemoved;

document.addEventListener('DOMContentLoaded', () => {
  const inCart = window.CART_SLUGS || [];
  document.querySelectorAll('.add-to-cart-btn').forEach((b) => {
    if (inCart.includes(b.dataset.slug)) markAdded(b);
  });
});

document.addEventListener('click', async (e) => {
  const btn = e.target.closest('.add-to-cart-btn');
  if (btn) {
    e.preventDefault();
    if (btn.dataset.added) { if (window.openCartDrawer) { openCartDrawer(); } else { window.location.href = 'cart.php'; } return; }
    const qty = parseInt(btn.dataset.qty || document.getElementById('pd-qty')?.value || '1', 10);
    const data = await cartAction({ action: 'add', slug: btn.dataset.slug, qty });
    /* 2026-07 FIX — "Add to Cart not working on Microsoft Project product"
       report.  ajax/cart.php now returns { ok:false, error:'…' } when the
       slug can't be resolved instead of silently reporting ok:true count:0.
       Surface the message to the user so they know the click was
       registered but the add failed — no more silent no-op. */
    if (data && data.ok === false) {
      showToast(data.error || 'We could not add that item to your cart. Please refresh and try again.', {
        title: 'Add to cart failed',
        icon: '<i class="bi bi-exclamation-triangle-fill"></i>',
        duration: 5000,
      });
      return;
    }
    updateCartBadge(data.count);
    markAdded(btn);
    if (window.CART_SLUGS && !window.CART_SLUGS.includes(btn.dataset.slug)) window.CART_SLUGS.push(btn.dataset.slug);
    /* add_to_cart event — fires to whichever tracker is configured (GA4 +
       Bing UET).  Reads price/name from the data attributes the server
       renders onto the button when available; falls back gracefully. */
    try {
      var ev = {
        item_id: btn.dataset.slug,
        item_name: btn.dataset.name || (data && data.name) || btn.dataset.slug,
        price: parseFloat(btn.dataset.price || data.unitPrice || (data && data.price) || 0) || 0,
        quantity: qty,
        currency: btn.dataset.currency || data.currency || 'USD'
      };
      /* GTM ecommerce push — always fires so GTM-only setups work. */
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({ ecommerce: null });
      window.dataLayer.push({
        event: 'add_to_cart',
        ecommerce: { currency: ev.currency, value: ev.price * ev.quantity, items: [ev] }
      });
      /* Direct gtag() only in native mode — in GTM mode the container's GA4
         event tag consumes the push above (one installation, no doubles). */
      if (window.MV_TRK_MODE !== 'gtm' && typeof gtag === 'function') {
        gtag('event', 'add_to_cart', { currency: ev.currency, value: ev.price * ev.quantity, items: [ev] });
      }
      if (window.uetq) {
        window.uetq.push('event', 'add_to_cart', {
          event_category: 'ecommerce', event_label: ev.item_id,
          revenue_value: ev.price * ev.quantity, currency: ev.currency
        });
      }
    } catch (_) { /* tracking is best-effort */ }
    // Show a compact confirmation toast anchored near the cart button.
    // The side cart drawer opens only when the customer clicks the cart.
    var addedName = ((data && data.name) || btn.dataset.name || 'Item').replace(/[<>&\x22]/g, function (c) { return { '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]; });
    showToast('<strong>' + addedName + '</strong> added to cart <span class="mv-toast-hint">— tap to view cart</span>', {
      icon: '<i class="bi bi-bag-check-fill"></i>', className: 'mv-toast-blue mv-toast-sm', duration: 3200,
      onClick: function () { if (window.openCartDrawer) { window.openCartDrawer(); } else { window.location.href = 'cart.php'; } }
    });
    return;
  }
  const buy = e.target.closest('.buy-now-btn');
  if (buy) {
    e.preventDefault();
    // Buy Now semantics: set the cart line to EXACTLY the selected qty (1 by default).
    // Clicking Buy Now repeatedly never accumulates extra units.
    const qty = parseInt(buy.dataset.qty || document.getElementById('pd-qty')?.value || '1', 10);
    const buyData = await cartAction({ action: 'set', slug: buy.dataset.slug, qty });
    // 2026-07 FIX — same defensive surface as Add to Cart above: don't
    // silently navigate to /cart.php if the server rejected the slug.
    if (buyData && buyData.ok === false) {
      showToast(buyData.error || 'We could not process Buy Now. Please refresh and try again.', {
        title: 'Buy Now failed',
        icon: '<i class="bi bi-exclamation-triangle-fill"></i>',
        duration: 5000,
      });
      return;
    }
    window.location.href = 'cart.php';
    return;
  }
  // "Notify Me" — out-of-stock waitlist subscribe.  Opens a small modal
  // asking for the customer's email, then POSTs to /ajax/notify-stock.php
  // and shows the confirmation message inline.
  const notify = e.target.closest('.notify-me-btn');
  if (notify) {
    e.preventDefault();
    openNotifyModal(notify.dataset.slug || '', notify.dataset.name || 'this product');
  }
});

/* ---------- Notify-Me modal ---------- */
function openNotifyModal(slug, name) {
  // Build the modal once and reuse on subsequent clicks.
  let modal = document.getElementById('notify-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'notify-modal';
    modal.className = 'notify-modal-overlay';
    modal.innerHTML = `
      <div class="notify-modal-card" role="dialog" aria-modal="true" aria-labelledby="notify-modal-title">
        <button type="button" class="notify-modal-close" onclick="closeNotifyModal()" aria-label="Close" data-testid="notify-modal-close"><i class="bi bi-x-lg"></i></button>
        <div class="notify-modal-icon"><i class="bi bi-bell-fill"></i></div>
        <h3 class="notify-modal-title" id="notify-modal-title">Get notified when it's back</h3>
        <p class="notify-modal-sub">We'll email you the moment <strong id="notify-modal-product">this product</strong> is back in stock. No spam, ever.</p>
        <form id="notify-modal-form" onsubmit="submitNotify(event)">
          <input type="email" id="notify-modal-email" class="form-control" placeholder="you@company.com" required autocomplete="email" data-testid="notify-modal-email">
          <button type="submit" class="notify-modal-submit" data-testid="notify-modal-submit"><i class="bi bi-bell-fill me-2"></i>Notify me</button>
        </form>
        <div id="notify-modal-msg" class="notify-modal-msg" data-testid="notify-modal-msg"></div>
      </div>`;
    document.body.appendChild(modal);
    // close on overlay click
    modal.addEventListener('click', (ev) => { if (ev.target === modal) closeNotifyModal(); });
    document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') closeNotifyModal(); });
  }
  modal.dataset.slug = slug;
  document.getElementById('notify-modal-product').textContent = name;
  document.getElementById('notify-modal-email').value = '';
  document.getElementById('notify-modal-msg').textContent = '';
  document.getElementById('notify-modal-msg').className = 'notify-modal-msg';
  modal.classList.add('is-open');
  setTimeout(() => document.getElementById('notify-modal-email').focus(), 100);
}
function closeNotifyModal() {
  const m = document.getElementById('notify-modal');
  if (m) m.classList.remove('is-open');
}
async function submitNotify(ev) {
  ev.preventDefault();
  const modal = document.getElementById('notify-modal');
  const email = document.getElementById('notify-modal-email').value.trim();
  const msg   = document.getElementById('notify-modal-msg');
  const slug  = modal.dataset.slug || '';
  if (!email || !slug) return;
  msg.textContent = 'Saving…';
  msg.className = 'notify-modal-msg is-pending';
  try {
    const r = await fetch('ajax/notify-stock.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_slug: slug, email })
    });
    const j = await r.json();
    if (j && j.ok) {
      msg.textContent = j.message || "You're on the list!";
      msg.className = 'notify-modal-msg is-ok';
      setTimeout(closeNotifyModal, 2200);
    } else {
      msg.textContent = (j && j.error) || 'Something went wrong — please try again.';
      msg.className = 'notify-modal-msg is-err';
    }
  } catch (e) {
    msg.textContent = 'Network error — please retry.';
    msg.className = 'notify-modal-msg is-err';
  }
}

// Helper: on the checkout page, refresh ONLY the right-column order
// summary in place so the customer's typed Contact / Billing / Card
// details aren't wiped out by a full page reload.
async function refreshCheckoutSummary() {
  const host = document.getElementById('checkout-summary');
  if (!host) return false;
  let qs = window.location.search || '';
  // Billing country drives the "You'll be charged … approx …" statement note.
  const ccEl = document.getElementById('co-country');
  if (ccEl && ccEl.value) qs += (qs ? '&' : '?') + 'cc=' + encodeURIComponent(ccEl.value);
  try {
    const r = await fetch('ajax/checkout-summary.php' + qs, { credentials: 'same-origin' });
    if (r.status === 204) { window.location.href = 'cart.php'; return true; }
    if (!r.ok) return false;
    host.innerHTML = await r.text();
    // Keep the "Pay Securely · $X" button in sync with the refreshed total
    // (the button lives outside #checkout-summary, so it isn't replaced above).
    const totalEl = host.querySelector('[data-testid="checkout-total"]');
    const payAmt = document.getElementById('pay-btn-amount');
    if (totalEl && payAmt) payAmt.textContent = totalEl.textContent.trim();
    return true;
  } catch (e) { return false; }
}

/* Re-render the Shopping Cart page in place (items + order summary + the
   "N item(s)" line) after ANY cart change — from the page's own buttons or
   from the slide-out mini-cart — so both views always agree in real time. */
async function refreshCartPage() {
  const root = document.getElementById('cart-page-root');
  if (!root) return false;
  try {
    const r = await fetch(window.location.pathname + window.location.search, { credentials: 'same-origin', cache: 'no-store', headers: { 'X-Requested-With': 'fetch' } });
    if (!r.ok) return false;
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const fresh = doc.getElementById('cart-page-root');
    if (!fresh) return false;
    root.innerHTML = fresh.innerHTML;
    root.dataset.count = fresh.dataset.count || '0';
    const sub = document.querySelector('.page-head p.text-secondary'), freshSub = doc.querySelector('.page-head p.text-secondary');
    if (sub) sub.textContent = freshSub ? freshSub.textContent : '';
    return true;
  } catch (e) { return false; }
}
/* One hook for "the cart changed somewhere": refresh whichever cart view is
   on screen (checkout summary, cart page) and the open mini-cart drawer. */
async function cartViewsChanged() {
  if (!(await refreshCheckoutSummary())) await refreshCartPage();
  if (typeof window.syncCartDrawer === 'function') await window.syncCartDrawer();
}
window.cartViewsChanged = cartViewsChanged;

// Cart page qty / remove
document.addEventListener('click', async (e) => {
  const qbtn = e.target.closest('[data-cart-qty]');
  if (qbtn) {
    const data = await cartAction({ action: 'update', slug: qbtn.dataset.slug, qty: parseInt(qbtn.dataset.cartQty, 10) });
    updateCartBadge(data.count);
    if (await refreshCheckoutSummary()) { if (window.syncCartDrawer) window.syncCartDrawer(); return; }
    if (await refreshCartPage()) { if (window.syncCartDrawer) window.syncCartDrawer(); return; }
    location.reload();
    return;
  }
  const rbtn = e.target.closest('[data-cart-remove]');
  if (rbtn) {
    const slug = rbtn.dataset.cartRemove;
    const row = rbtn.closest('[data-testid^="summary-item-"], [data-testid^="cart-item-"]');
    const nmEl = row ? row.querySelector('.fw-semibold') : null;
    const nm = nmEl ? nmEl.textContent.trim() : 'Item';
    let qty = 1;
    const qEl = row ? row.querySelector('.input-group .form-control') : null;
    if (qEl) { const q = parseInt(qEl.textContent, 10); if (q > 0) qty = q; }
    const esc = (s) => String(s).replace(/[&<>\x22]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const data = await cartAction({ action: 'remove', slug });
    updateCartBadge(data.count);
    markRemoved(slug);
    const refreshed = (await refreshCheckoutSummary()) || (await refreshCartPage());
    if (!refreshed) { location.reload(); return; }
    if (window.syncCartDrawer) window.syncCartDrawer();
    showToast('<strong>' + esc(nm) + '</strong> removed', {
      icon: '<i class="bi bi-trash3"></i>', duration: 9000, className: 'mv-toast-blue',
      actionText: 'Undo', onAction: async () => {
        const d = await cartAction({ action: 'set', slug, qty });
        updateCartBadge(d.count);
        await cartViewsChanged();
        showToast('Item restored to your order', { icon: '<i class="bi bi-arrow-counterclockwise"></i>', className: 'mv-toast-blue' });
      }
    });
    return;
  }
  const pbtn = e.target.closest('[data-cart-proassist-remove]');
  if (pbtn) {
    const data = await cartAction({ action: 'proassist', value: 0 });
    if (data && typeof data.count !== 'undefined') updateCartBadge(data.count);
    const refreshed = (await refreshCheckoutSummary()) || (await refreshCartPage());
    if (!refreshed) { location.reload(); return; }
    showToast('<strong>ProAssist Premium Installation</strong> removed', {
      icon: '<i class="bi bi-trash3"></i>', duration: 9000, className: 'mv-toast-blue',
      actionText: 'Undo', onAction: async () => {
        const d = await cartAction({ action: 'proassist', value: 1 });
        if (d && typeof d.count !== 'undefined') updateCartBadge(d.count);
        await cartViewsChanged();
        showToast('ProAssist Installation restored', { icon: '<i class="bi bi-arrow-counterclockwise"></i>', className: 'mv-toast-blue' });
      }
    });
  }
});

/* ---------- Newsletter + coupon ---------- */
function subscribeNewsletter(ev) {
  ev.preventDefault();
  const input = ev.target.querySelector('input[type="email"]');
  if (!input || !input.value) return;
  const email = input.value.trim();
  const btn = ev.target.querySelector('button[type="submit"]');
  if (btn) btn.disabled = true;
  fetch('ajax/newsletter.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email })
  })
    .then((r) => r.json().catch(() => ({ ok: false })))
    .then((data) => {
      if (data && data.ok) {
        showToast('<i class="bi bi-check-circle me-1"></i> Subscribed! You\'ll receive exclusive deals soon.');
        input.value = '';
      } else {
        showToast('<i class="bi bi-x-circle me-1"></i> ' + ((data && data.error) || 'Could not subscribe — please try again.'));
      }
    })
    .catch(() => showToast('<i class="bi bi-x-circle me-1"></i> Could not subscribe — please try again.'))
    .finally(() => { if (btn) btn.disabled = false; });
}

async function applyCoupon(code) {
  const data = await cartAction({ action: 'coupon', code: code || '' });
  if (data.ok) {
    showToast(data.coupon ? '<i class="bi bi-tag-fill me-1"></i> Coupon applied — ' + (data.pct || '') + '% off!' : 'Coupon removed.');
    // On the checkout page, refresh only the right-column summary so the
    // customer's typed details on the left don't get wiped.
    if (await refreshCheckoutSummary()) return;
    location.reload();
  } else {
    showToast('<i class="bi bi-x-circle me-1"></i> ' + (data.error || 'Invalid coupon code'));
  }
}

/* ---------- Bootstrap tooltips + coupon Enter-key guard ---------- */
document.addEventListener('DOMContentLoaded', () => {
  if (window.bootstrap) {
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach((el) => new bootstrap.Tooltip(el));
  }
  // Coupon input lives inside the checkout form — Enter must apply the coupon,
  // not submit the whole checkout form silently.
  const couponInput = document.getElementById('coupon-input');
  if (couponInput) {
    couponInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        applyCoupon(couponInput.value);
      }
    });
  }
});

/* ---------- Checkout payment method toggle ---------- */
function syncPhoneFlag(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (opt) sel.style.setProperty('--phone-flag', "url('https://flagcdn.com/w40/" + (opt.dataset.iso || 'us') + ".png')");
}

/* Card field formatting: number groups of 4, MM/YY expiry, numeric CVV + live brand detect.
   NB: the real detectCardBrand() + Luhn helpers live in the block below —
   this stub is kept only as a comment marker for grep-based tooling. */
/* ============================================================
   Card-brand detection & Luhn validation.
   Card patterns (BIN + length) cover the four brands the storefront
   accepts. detectCardBrand() returns the brand + expected length +
   CVV length so the caller can reformat the input + validate.
   ============================================================ */
const CARD_PATTERNS = [
  // Accepted brands only. `len` lists every valid PAN length for the brand so
  // longer cards (some Visa/Discover run to 19 digits) validate and are not
  // truncated — otherwise we would lose those sales. Amex stays 15.
  { brand: 'visa',       re: /^4/,                       len: [13, 16, 19],   cvv: 3 },
  { brand: 'mastercard', re: /^(5[1-5]|2[2-7])/,         len: [16],           cvv: 3 },
  { brand: 'amex',       re: /^3[47]/,                   len: [15],           cvv: 4 },
  { brand: 'discover',   re: /^(6011|65|64[4-9]|622)/,   len: [16, 19],       cvv: 3 },
];
function detectCardBrand(cardNumber) {
  const digits = (cardNumber || '').toString().replace(/\D/g, '');
  for (const p of CARD_PATTERNS) if (p.re.test(digits)) return { brand: p.brand, len: p.len, cvv: p.cvv };
  return { brand: '', len: [16, 19], cvv: 3 };
}
// Icon-only brand from the FIRST digit(s) so the accepted-card icon highlights
// the moment the shopper starts typing (we accept Visa/MC/Amex/Discover only).
function brandForIcon(cardNumber) {
  const d = (cardNumber || '').toString().replace(/\D/g, '');
  if (!d) return '';
  if (d[0] === '4') return 'visa';
  if (d[0] === '5' || /^2[2-7]/.test(d)) return 'mastercard';
  if (d[0] === '3') return 'amex';
  if (d[0] === '6') return 'discover';
  return '';
}
function luhnCheck(cardNumber) {
  const digits = (cardNumber || '').toString().replace(/\D/g, '');
  if (digits.length < 12) return false;
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits.charAt(i), 10);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
}

function setCardFieldValidity(el, ok, errorMsg) {
  if (!el) return;
  el.classList.toggle('is-valid',   ok === true);
  el.classList.toggle('is-invalid', ok === false);
  // Plain-text inline error in the label row.  Empty string when valid or
  // still-being-typed — the whole point of this UX pass is: no messages
  // until the customer has actually entered something wrong.
  const errorEl = document.getElementById(el.id + '-error');
  if (errorEl) errorEl.textContent = (ok === false && errorMsg) ? errorMsg : '';
}

document.addEventListener('input', (e) => {
  if (window.__mvCardUI) return; // checkout.php's first-party card controller owns these fields
  if (e.target.id === 'card-number') {
    const raw   = e.target.value.replace(/\D/g, '');
    const info  = detectCardBrand(raw);
    const maxL  = info.len[info.len.length - 1] || 16;
    const digits = raw.slice(0, maxL);
    // Amex format: 4-6-5 spacing; everything else: 4-4-4-4.
    let formatted;
    if (info.brand === 'amex') {
      formatted = digits.replace(/^(\d{4})(\d{0,6})(\d{0,5}).*/, function (_, a, b, c) {
        return [a, b, c].filter(Boolean).join(' ');
      });
    } else {
      formatted = digits.replace(/(\d{4})(?=\d)/g, '$1 ');
    }
    if (e.target.value !== formatted) e.target.value = formatted;
    // Show the detected brand logo INSIDE the card-number field (PayPal-style).
    // FIRST-DIGIT map so it lights up immediately (4→Visa, 5/2→Mastercard,
    // 3→Amex, 6→Discover) — strict detectCardBrand needs 2 digits and is kept
    // for validation/CVV length only.
    const brand = brandForIcon(digits);
    if (typeof window.mvShowCardBrand === 'function') window.mvShowCardBrand(brand);
    // Field-level validity — SILENT while the customer is still typing.
    // We only surface an error once they've typed the FULL card number
    // (16 digits for Visa/MC/Discover, 15 for Amex) so a mid-type partial
    // like "5456" doesn't flash "Invalid card number" before they're done.
    //
    // Rules:
    //   digits.length === 0                         → neutral
    //   digits.length < brand.maxLength             → neutral (still typing)
    //   digits.length === brand.maxLength + Luhn OK → is-valid
    //   digits.length === brand.maxLength + Luhn NG → is-invalid, "Invalid card number"
    //   digits.length === 16 (default) & no brand   → is-invalid, "Invalid card number"
    if (!digits.length)                    setCardFieldValidity(e.target, null);
    else if (brand && info.len.indexOf(digits.length) !== -1 && luhnCheck(digits))
                                           setCardFieldValidity(e.target, true);   // a complete, valid length → green
    else if (!brand && digits.length >= maxL)
                                           setCardFieldValidity(e.target, false, 'Invalid card number'); // we only accept Visa/MC/Amex/Discover
    else if (digits.length >= maxL)        setCardFieldValidity(e.target, false, 'Invalid card number'); // reached max length, still wrong
    else                                   setCardFieldValidity(e.target, null);   // still typing → silent
    // Re-validate CVV since the required length depends on the brand.
    const cvvEl = document.getElementById('card-cvv');
    if (cvvEl && cvvEl.value) cvvEl.dispatchEvent(new Event('input', { bubbles: true }));
  } else if (e.target.id === 'card-exp') {
    let v = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (v.length >= 3) v = v.slice(0, 2) + '/' + v.slice(2);
    e.target.value = v;
    const digits = v.replace(/\D/g, '');
    if (digits.length < 4) { setCardFieldValidity(e.target, null); return; }
    const mm = parseInt(digits.slice(0, 2), 10);
    const yy = parseInt(digits.slice(2, 4), 10);
    if (mm < 1 || mm > 12)          setCardFieldValidity(e.target, false, 'Bad month');
    else {
      const now = new Date();
      const curYY = now.getFullYear() % 100;
      const curMM = now.getMonth() + 1;
      if (yy < curYY || (yy === curYY && mm < curMM)) setCardFieldValidity(e.target, false, 'Expired');
      else setCardFieldValidity(e.target, true);
    }
  } else if (e.target.id === 'card-cvv') {
    e.target.value = e.target.value.replace(/\D/g, '').slice(0, 4);
    const cardEl = document.getElementById('card-number');
    const info   = detectCardBrand(cardEl ? cardEl.value : '');
    const need   = info.cvv || 3;
    if (!e.target.value)                    setCardFieldValidity(e.target, null);
    else if (e.target.value.length < need)  setCardFieldValidity(e.target, null); // silent while incomplete
    else                                    setCardFieldValidity(e.target, true);
    // If already at max length but still not enough digits (e.g. Amex needs 4
    // but they entered 3 & typed something invalid), surface the error.
    if (e.target.value.length > 0 && e.target.value.length === e.target.maxLength && e.target.value.length < need) {
      setCardFieldValidity(e.target, false, 'Invalid CVV');
    }
  }
});

function selectPayMethod(method) {
  // method = 'card' (NMI) | 'paypal' (PayPal account) | 'ppcard' (our card tile
  // powered by PayPal card fields — shown only when NMI card is switched off).
  document.querySelectorAll('.pay-option').forEach((o) => o.classList.remove('active'));
  const opt = document.getElementById('pay-' + method);
  if (opt) opt.classList.add('active');
  // Move the radio checkmark to match the selected tile
  const radios = document.querySelectorAll('input[name="pm_radio"]');
  radios.forEach((r) => { r.checked = false; });
  const sel = document.querySelector('#pay-' + method + ' input[name="pm_radio"]');
  if (sel) sel.checked = true;
  const cardForm = document.getElementById('card-form');
  const paypalInfo = document.getElementById('paypal-info');
  const cardBtn = document.getElementById('btn-pay-card');
  const ppBtn = document.getElementById('btn-pay-paypal');
  const input = document.getElementById('payment-method-input');
  if (input) input.value = method === 'ppcard' ? 'paypal' : method; // server knows only card | paypal
  if (cardForm) cardForm.classList.toggle('d-none', method !== 'card');
  if (paypalInfo) paypalInfo.classList.toggle('d-none', method !== 'paypal');
  if (cardBtn) cardBtn.classList.toggle('d-none', method !== 'card');
  if (ppBtn) ppBtn.classList.toggle('d-none', method !== 'paypal');
  const ppCard = document.getElementById('pp-guest-card');
  if (ppCard) {
    // With its own tile the card box belongs to 'ppcard'; otherwise it sits under the PayPal tile.
    const ownTile = ppCard.getAttribute('data-own-tile') === '1';
    ppCard.classList.toggle('d-none', ownTile ? method !== 'ppcard' : method !== 'paypal');
  }
}

/* ---------- Ask AI chat widget ---------- */
let _lastChatToggle = 0;
function toggleChat() {
  // Debounce: if both the inline onclick AND the JS listener fire (non-CSP
  // hosts), only toggle once.
  const _now = Date.now();
  if (_now - _lastChatToggle < 150) return;
  _lastChatToggle = _now;
  const panel = document.getElementById('chat-panel');
  if (!panel) return;
  panel.classList.toggle('open');
  // Hide the blue "Hi, How can I help?" launcher card while the chat window
  // is open, and bring it back when the panel is closed. (body.chat-open is
  // consumed by a CSS rule that toggles the launcher's visibility.)
  document.body.classList.toggle('chat-open', panel.classList.contains('open'));
  if (panel.classList.contains('open')) {
    // Customer opened the chat → clear the unread bell + dismiss any preview.
    clearChatBell();
    if (typeof hideChatMsgPreview === 'function') hideChatMsgPreview();
    // Iteration 20 — chat opens straight to the 3-field contact form by
    // default.  The AI welcome bubble + quick chips are kept in the DOM
    // for the legacy ProAssist auto-chat flow (where uc_lead_done is
    // already set) but stay hidden on the first-touch human-support flow.
    if (!localStorage.getItem('uc_lead_done')) {
      const form = document.getElementById('chat-lead-form');
      if (form) form.style.display = 'block';
      // Hard-hide the AI welcome + chips on a fresh open so the customer
      // sees ONLY the contact form (no AI bubble distracting them).
      const welcome = document.getElementById('chat-welcome-msg');
      const chips   = document.getElementById('chat-chips');
      if (welcome) welcome.style.display = 'none';
      if (chips)   chips.style.display   = 'none';
      updateStartOverVisibility();
      // Focus the first empty field for keyboard users.
      setTimeout(() => {
        const ne = document.getElementById('lead-first');
        if (ne && !ne.value) ne.focus();
      }, 60);
    } else {
      // Returning visitor — lead already done; surface the composer AND
      // restore their saved conversation so they're always back in the
      // same thread with full history and a place to type.
      revealChatInputRow();
      startAdminPolling();
      // Hide the contact form too — they've already given us their details
      // on a previous visit (or on the order-success ProAssist flow).
      const form = document.getElementById('chat-lead-form');
      if (form) form.style.display = 'none';
      // Keep the AI welcome + chips HIDDEN (human-only chat mode).  The
      // customer should see only their own prior messages + real admin
      // replies, never the legacy "Max · AI Assistant" greeting.
      const welcome = document.getElementById('chat-welcome-msg');
      const chips   = document.getElementById('chat-chips');
      if (welcome) welcome.style.display = 'none';
      if (chips)   chips.style.display   = 'none';
      updateStartOverVisibility();
      // Returning after a past chat / idle gap → offer a "Start over" prompt.
      maybeShowChatRestartPrompt();
    }
  }
}

/* ---------- Chat "Start over" + idle / returning-visitor prompt ---------- */
const UC_ACTIVITY_KEY = 'uc_chat_last_activity';
const UC_CHAT_IDLE_MS = 5 * 60 * 1000; // 5 minutes of no messaging = idle

// Stamp "last activity" — called whenever the customer or admin actually
// exchanges a message, so an idle gap can be measured on the next open.
function touchChatActivity() {
  try { localStorage.setItem(UC_ACTIVITY_KEY, String(Date.now())); } catch (e) {}
}

// True once a lead/conversation exists in this browser.
function chatHasHistory() {
  return !!(localStorage.getItem('uc_chat_token') || localStorage.getItem('uc_lead_done') === '1');
}

// Per-browser chat session id — sent with every chat request so the server
// can prove this browser is the one that opened the conversation.
function chatSid() {
  let sid = localStorage.getItem('uc_chat_session');
  if (!sid) { sid = 's' + Date.now() + Math.random().toString(36).slice(2, 8); localStorage.setItem('uc_chat_session', sid); }
  return sid;
}

const UC_CHAT_KEYS = ['uc_chat_token', 'uc_lead_id', 'uc_lead_done', 'uc_chat_human_only', 'uc_chat_session', 'uc_pa_greeted', 'uc_chat_origin'];

// Admin/staff browsing the storefront: the widget ALWAYS starts fresh and can
// never resume a customer's conversation (server enforces the same rule).
if (typeof window !== 'undefined' && window.MV_ADMIN_SESSION) {
  UC_CHAT_KEYS.concat([UC_ACTIVITY_KEY, 'uc_chat_unread']).forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
}

// Server told us this browser's saved thread is not ours any more (unknown /
// deleted token, or an admin browser) → wipe it and show the fresh form.
function chatHandleGuard(j) {
  if (!j || j.ok) return false;
  if (j.reset) { startOverChat(true); return true; }
  if (j.verify) { chatShowVerify(); return true; }
  return false;
}

// Hard IP lock re-verification card — the chat was opened from a different
// network; the customer confirms the email they used to continue.
function chatShowVerify() {
  if (_adminPollTimer) { clearInterval(_adminPollTimer); _adminPollTimer = null; }
  const body = document.getElementById('chat-body');
  if (!body || document.getElementById('chat-verify-card')) return;
  const row = document.getElementById('chat-input-row');
  if (row) { row.classList.add('d-none'); row.classList.remove('d-flex'); row.style.display = ''; }
  const card = document.createElement('div');
  card.className = 'chat-lead-card';
  card.id = 'chat-verify-card';
  card.setAttribute('data-testid', 'chat-verify-card');
  card.innerHTML =
    '<div class="chat-lead-title"><i class="bi bi-shield-lock me-1"></i>Your network changed. To keep this conversation private, confirm the email you used to start the chat.</div>' +
    '<div class="chat-lead-field-row"><input id="chat-verify-email" type="email" class="form-control form-control-sm chat-lead-input" placeholder="Email address" autocomplete="email" data-testid="chat-verify-email"></div>' +
    '<div class="chat-lead-field-row chat-lead-row-send"><button type="button" class="chat-lead-send-btn chat-lead-send-btn-wide" onclick="chatVerifySubmit()" data-testid="chat-verify-btn"><i class="bi bi-check2 me-1"></i><span>Confirm &amp; continue</span></button></div>' +
    '<div id="chat-verify-error" class="chat-lead-error" style="display:none;" data-testid="chat-verify-error"></div>' +
    '<button type="button" class="btn btn-link btn-sm p-0 mt-1" style="font-size:12px;" onclick="startOverChat()" data-testid="chat-verify-startover">Start a new chat instead</button>';
  body.appendChild(card);
  body.scrollTop = body.scrollHeight;
  setTimeout(() => { const i = document.getElementById('chat-verify-email'); if (i) i.focus(); }, 80);
}

async function chatVerifySubmit() {
  const token = localStorage.getItem('uc_chat_token');
  const inp = document.getElementById('chat-verify-email');
  const err = document.getElementById('chat-verify-error');
  const email = (inp && inp.value || '').trim();
  if (!/\S+@\S+\.\S+/.test(email)) { if (err) { err.textContent = 'Please enter a valid email address.'; err.style.display = 'block'; } return; }
  try {
    const r = await fetch('ajax/chat-customer.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'verify', token: token, session_id: chatSid(), email: email }),
    });
    const j = await r.json().catch(() => ({}));
    if (j && j.ok) {
      const card = document.getElementById('chat-verify-card'); if (card) card.remove();
      revealChatInputRow();
      _historyLoaded = false;
      startAdminPolling();
      if (typeof showToast === 'function') showToast('Verified — you\'re back in your conversation.');
      return;
    }
    if (j && j.reset) { startOverChat(true); return; }
    if (err) { err.textContent = 'That email doesn\'t match this conversation. Check the spelling or start a new chat.'; err.style.display = 'block'; }
  } catch (e) {
    if (err) { err.textContent = 'Network error — please try again.'; err.style.display = 'block'; }
  }
}

// Show the header "Start over" button only when there's a chat to reset.
function updateStartOverVisibility() {
  const btn = document.getElementById('chat-startover-btn');
  if (btn) btn.style.display = chatHasHistory() ? 'inline-flex' : 'none';
}

// Wipe the current conversation and reset the widget to a clean first-touch
// state so the customer starts a brand-new chat from the very beginning.
function startOverChat(silent) {
  if (_adminPollTimer) { clearInterval(_adminPollTimer); _adminPollTimer = null; }
  _adminLastMsgId = 0;
  _historyLoaded = false;
  _paSchedInitDone = false;
  if (typeof _renderedMsgIds !== 'undefined' && _renderedMsgIds.clear) _renderedMsgIds.clear();
  UC_CHAT_KEYS.concat([UC_ACTIVITY_KEY, UC_UNREAD_KEY])
    .forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
  const vc = document.getElementById('chat-verify-card'); if (vc) vc.remove();
  if (typeof clearChatBell === 'function') clearChatBell();
  // Remove every dynamically-added bubble/banner/attachment, keeping only the
  // seed UI (greeting, hidden welcome, chips, lead form, choice card).
  const body = document.getElementById('chat-body');
  if (body) {
    body.querySelectorAll('.chat-msg:not(#chat-welcome-msg), .chat-restart-banner, .chat-attachment-msg, #chat-intro-typing')
      .forEach(el => el.remove());
  }
  // Reset the contact form + choice + composer to first-open state.
  const form = document.getElementById('chat-lead-form');
  const choice = document.getElementById('chat-lead-choice');
  const row = document.getElementById('chat-input-row');
  const err = document.getElementById('chat-lead-error');
  const greeting = document.getElementById('chat-addie-greeting');
  const welcome = document.getElementById('chat-welcome-msg');
  const chips = document.getElementById('chat-chips');
  if (form) { form.style.display = 'block'; form.querySelectorAll('input, textarea').forEach(i => { i.value = ''; }); }
  if (choice) choice.style.display = 'none';
  if (row) { row.classList.add('d-none'); row.classList.remove('d-flex'); row.style.display = ''; row.style.visibility = ''; }
  if (err) err.style.display = 'none';
  if (greeting) greeting.style.display = '';
  if (welcome) welcome.style.display = 'none';
  if (chips) chips.style.display = 'none';
  window._leadSubmitInFlight = false;
  updateStartOverVisibility();
  setTimeout(() => { const ne = document.getElementById('lead-first'); if (ne) ne.focus(); }, 80);
  if (!silent && typeof showToast === 'function') showToast("Fresh start — tell us how to reach you and we'll help you from the top.");
}

// When a returning / idle customer opens the chat, drop a friendly card at the
// top of the thread offering to continue or start a brand-new conversation.
function maybeShowChatRestartPrompt() {
  if (!chatHasHistory()) return;
  // Pro Assist buyers are bound to their order's install thread — never nudge
  // them to "start over" (that would detach them from their technician chat).
  if (localStorage.getItem('uc_chat_origin') === 'order') return;
  const last = parseInt(localStorage.getItem(UC_ACTIVITY_KEY) || '0', 10);
  const idle = !last || (Date.now() - last > UC_CHAT_IDLE_MS);
  if (!idle) return;
  const body = document.getElementById('chat-body');
  if (!body || document.getElementById('chat-restart-banner')) return;
  const b = document.createElement('div');
  b.className = 'chat-restart-banner';
  b.id = 'chat-restart-banner';
  b.setAttribute('data-testid', 'chat-restart-banner');
  b.innerHTML =
    '<div class="chat-restart-title"><i class="bi bi-clock-history me-1"></i>Welcome back</div>' +
    "<div class=\"chat-restart-sub\">Start a fresh conversation and a support agent will get right back to you.</div>" +
    '<div class="chat-restart-actions">' +
      '<button type="button" class="chat-restart-btn chat-restart-new" onclick="startOverChat()" data-testid="chat-restart-new"><i class="bi bi-arrow-counterclockwise me-1"></i>Start over</button>' +
    '</div>';
  body.insertBefore(b, body.firstChild);
}

function dismissChatRestartPrompt() {
  const b = document.getElementById('chat-restart-banner');
  if (b) b.remove();
  touchChatActivity();
}

// First-open typing-dots intro — hides the static welcome + chips, drops
// a `.typing` bubble at the top of the chat body, then ~1.2 s later swaps
// it for a fade-in of the real welcome and quick-reply chips.
function playChatTypingIntro() {
  const welcome = document.getElementById('chat-welcome-msg');
  const chips   = document.getElementById('chat-chips');
  if (!welcome) return;
  welcome.style.display = 'none';
  if (chips) chips.style.display = 'none';
  // Build the typing bubble — same `.typing` styling used after sendChat().
  const typing = document.createElement('div');
  typing.className = 'chat-msg bot typing';
  typing.id = 'chat-intro-typing';
  typing.setAttribute('data-testid', 'chat-intro-typing');
  typing.innerHTML = '<span></span><span></span><span></span>';
  const body = document.getElementById('chat-body');
  if (body) body.insertBefore(typing, body.firstChild);
  // After ~1.2 s, remove the dots and reveal the welcome content with a
  // soft fade-in so it doesn't snap into existence.
  setTimeout(() => {
    typing.remove();
    welcome.style.display = '';
    welcome.classList.add('is-fade-in');
    if (chips) {
      chips.style.display = '';
      chips.classList.add('is-fade-in');
    }
  }, 1200);
}

/* ---------- Chat unread badge (customer side) ---------- */
/* Persisted via localStorage so the bright red count survives page
   navigations — admin replies that arrive while the customer is on a
   different page still surface a badge on the chat bubble. */
let _chatBellCount = 0;
const UC_UNREAD_KEY = 'uc_chat_unread';
function _persistUnread(n) {
  try { (n > 0) ? localStorage.setItem(UC_UNREAD_KEY, String(n)) : localStorage.removeItem(UC_UNREAD_KEY); } catch (e) {}
}
function _renderBell() {
  const bell = document.getElementById('chat-bell');
  const cnt  = document.getElementById('chat-bell-count');
  if (!bell || !cnt) return;
  if (_chatBellCount > 0) {
    bell.style.display = 'inline-flex';
    cnt.textContent = _chatBellCount > 9 ? '9+' : String(_chatBellCount);
  } else {
    bell.style.display = 'none';
  }
}
function showChatBell(addCount) {
  _chatBellCount = (typeof addCount === 'number' ? _chatBellCount + addCount : _chatBellCount + 1);
  _persistUnread(_chatBellCount);
  _renderBell();
}
function clearChatBell() {
  _chatBellCount = 0;
  _persistUnread(0);
  _renderBell();
  hideChatMsgPreview();
}
/* Restore badge from localStorage on every page load. */
document.addEventListener('DOMContentLoaded', () => {
  try {
    const stored = parseInt(localStorage.getItem(UC_UNREAD_KEY) || '0', 10);
    if (stored > 0) { _chatBellCount = stored; _renderBell(); }
  } catch (e) {}
});

/* ---------- Messenger-style admin-reply preview ---------- */
let _msgPreviewTimer = null;
function showChatMsgPreview(text) {
  const card = document.getElementById('chat-msg-preview');
  const body = document.getElementById('chat-msg-preview-body');
  if (!card || !body) return;
  // Trim to a friendly preview length (CSS line-clamp handles the visual
  // truncation but a server-side cap keeps DOM lean for long messages).
  let preview = String(text || '').trim();
  if (preview.length > 180) preview = preview.slice(0, 177) + '…';
  body.textContent = preview;
  card.style.display = 'block';
  card.classList.remove('is-hiding');
  // Persist until the customer dismisses it (X) or taps to reply — we no
  // longer auto-open the chat, so the preview shouldn't vanish on its own.
  // The unread bell on the bubble stays regardless.
  if (_msgPreviewTimer) { clearTimeout(_msgPreviewTimer); _msgPreviewTimer = null; }
}
function hideChatMsgPreview() {
  const card = document.getElementById('chat-msg-preview');
  if (!card) return;
  card.classList.add('is-hiding');
  if (_msgPreviewTimer) { clearTimeout(_msgPreviewTimer); _msgPreviewTimer = null; }
  // Hide after the CSS transition finishes.
  setTimeout(() => { if (card.classList.contains('is-hiding')) card.style.display = 'none'; }, 220);
}
function openChatFromPreview() {
  hideChatMsgPreview();
  const panel = document.getElementById('chat-panel');
  if (panel && !panel.classList.contains('open')) {
    if (typeof toggleChat === 'function') toggleChat();
  }
}
// Swap the chat header identity to the live agent once they join the thread.
function updateChatAgentName(name) {
  if (!name) return;
  const el = document.querySelector('[data-testid="chat-head-name"]');
  if (el && el.textContent.trim() !== name) el.textContent = name;
  const sub = document.querySelector('.chat-head-sub');
  if (sub) sub.textContent = 'Support agent · online';
}
// Tiny WebAudio chime — same approach as the admin shell so we don't ship
// an asset.  Plays a soft 2-note bell when an admin message arrives.
function _chatChime() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    const tone = (freq, start, dur) => {
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(0.18, start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      o.connect(g); g.connect(ctx.destination);
      o.start(start); o.stop(start + dur + 0.05);
    };
    tone(880, now, 0.18); tone(1320, now + 0.12, 0.22);
    setTimeout(() => ctx.close && ctx.close(), 800);
  } catch (_) {}
}

function leadValues() {
  const issueEl = document.getElementById('lead-issue');
  const v = (id) => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
  const first = v('lead-first'), last = v('lead-last');
  return {
    first_name: first,
    last_name: last,
    name: (first + ' ' + last).trim(),
    email: v('lead-email'),
    phone: v('lead-phone'),
    issue: issueEl ? issueEl.value.trim() : '',
  };
}
// A "name" that is really a sentence/question (what customers type when they
// skip the labels) must never become the lead's name in Lead Management.
function leadNameLooksLikeText(s) {
  s = String(s || '').trim();
  return /[?!@]/.test(s) || /\d{3,}/.test(s) || s.split(/\s+/).length > 3 || s.length > 40;
}

// Fixed default greeting shown after a customer shares their details (or
// opts into a ProAssist plan): we'll call them, and they can type anything
// further. Includes the support phone from Company Info when available.
function chatDefaultGreeting(firstName) {
  var phone = (window.SITE_PHONE || '').trim();
  return 'Thanks for contacting us' + (firstName ? ', ' + firstName : '') + '! '
    + (phone ? '\ud83d\udcde Please call our support line at ' + phone + ', or one of our representatives'
             : 'One of our representatives')
    + ' will give you a call on your registered phone number \u2014 so please stay near your phone. '
    + 'For any further message, just type below and we\u2019ll get right back to you.';
}

/* ===== "Verify you're human" (chat lead form) =====================
   Signed challenge from the server (bound to IP + browser, 15 min) +
   a small proof-of-work solved here + a minimum dwell time + a honeypot.
   The resulting human_token is REQUIRED by ajax/lead.php, so scripted
   posts that never run this code cannot create chats. */
let _hcChallenge = null, _hcToken = null, _hcBusy = false;
function mvSha256Hex(str){
  var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  var bytes=new TextEncoder().encode(str), l=bytes.length, padLen=((l+9+63)>>6)<<6, m=new Uint8Array(padLen); m.set(bytes); m[l]=0x80;
  var dv=new DataView(m.buffer); dv.setUint32(padLen-4,(l*8)>>>0); dv.setUint32(padLen-8,Math.floor(l*8/0x100000000));
  var h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19], w=new Uint32Array(64);
  for(var i=0;i<padLen;i+=64){
    for(var t=0;t<16;t++) w[t]=dv.getUint32(i+t*4);
    for(t=16;t<64;t++){ var x=w[t-15],y=w[t-2]; var s0=((x>>>7)|(x<<25))^((x>>>18)|(x<<14))^(x>>>3); var s1=((y>>>17)|(y<<15))^((y>>>19)|(y<<13))^(y>>>10); w[t]=(w[t-16]+s0+w[t-7]+s1)>>>0; }
    var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for(t=0;t<64;t++){ var S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)); var ch=(e&f)^(~e&g); var t1=(hh+S1+ch+K[t]+w[t])>>>0; var S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)); var maj=(a&b)^(a&c)^(b&c); var t2=(S0+maj)>>>0; hh=g; g=f; f=e; e=(d+t1)>>>0; d=c; c=b; b=a; a=(t1+t2)>>>0; }
    h=[(h[0]+a)>>>0,(h[1]+b)>>>0,(h[2]+c)>>>0,(h[3]+d)>>>0,(h[4]+e)>>>0,(h[5]+f)>>>0,(h[6]+g)>>>0,(h[7]+hh)>>>0];
  }
  var out=''; for(i=0;i<8;i++) out+=('00000000'+h[i].toString(16)).slice(-8); return out;
}
function chatHumanState(state, label, sub) {
  const btn = document.getElementById('chat-human-btn'); if (!btn) return;
  btn.dataset.state = state;
  btn.setAttribute('aria-checked', state === 'ok' ? 'true' : 'false');
  const l = btn.querySelector('.chat-human-label'), su = btn.querySelector('.chat-human-sub');
  if (l && label) l.textContent = label;
  if (su && sub !== undefined) su.textContent = sub;
  const send = document.querySelector('[data-testid="lead-send-btn"]');
  if (send) send.disabled = (state !== 'ok');
}
// Pre-fetch the challenge when the form is visible so the dwell timer starts
// while the customer is typing — Verify then feels instant.
async function chatHumanPrefetch() {
  if (_hcChallenge || _hcToken) return;
  try {
    const r = await fetch('ajax/human-check.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'challenge' }) });
    const j = await r.json(); if (j && j.ok) _hcChallenge = j;
  } catch (e) {}
}
function chatHumanSolve(ch) {
  // Yields to the UI every 1,500 hashes so the spinner keeps animating.
  return new Promise((resolve) => {
    let n = 0; const prefix = ch.prefix || '000', nib = typeof ch.nibble === 'number' ? ch.nibble : 1;
    (function step() {
      for (let i = 0; i < 1500; i++, n++) {
        const h = mvSha256Hex(ch.c + ':' + n);
        if (h.indexOf(prefix) === 0 && parseInt(h.charAt(prefix.length), 16) <= nib) { resolve(String(n)); return; }
      }
      if (n > 4000000) { resolve(null); return; }
      setTimeout(step, 0);
    })();
  });
}
async function chatHumanVerify() {
  if (_hcBusy || _hcToken) return;
  _hcBusy = true;
  chatHumanState('working', 'Verifying…', 'Checking this browser');
  try {
    if (!_hcChallenge) await chatHumanPrefetch();
    if (!_hcChallenge) throw new Error('offline');
    const hp = document.getElementById('lead-website');
    const nonce = await chatHumanSolve(_hcChallenge);
    if (nonce === null) throw new Error('nosolve');
    const r = await fetch('ajax/human-check.php', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'verify', c: _hcChallenge.c, sig: _hcChallenge.sig, nonce, session_id: chatSid(), website: hp ? hp.value : '' }) });
    const j = await r.json().catch(() => ({}));
    if (j && j.ok && j.token) {
      _hcToken = j.token;
      chatHumanState('ok', "You're verified", 'Now tap Send');
      const send = document.querySelector('[data-testid="lead-send-btn"]');
      if (send) { send.disabled = false; send.classList.add('is-fade-in'); }
    } else {
      _hcChallenge = null;                           // get a fresh challenge next time
      chatHumanState('error', 'Try again', (j && j.error) || 'We could not verify this browser.');
      setTimeout(() => { if (!_hcToken) chatHumanState('idle', "Verify you're human", 'Tap once — takes a second'); chatHumanPrefetch(); }, 2600);
    }
  } catch (e) {
    _hcChallenge = null;
    chatHumanState('error', 'Try again', 'Connection problem — please retry.');
    setTimeout(() => { if (!_hcToken) chatHumanState('idle', "Verify you're human", 'Tap once — takes a second'); chatHumanPrefetch(); }, 2600);
  }
  _hcBusy = false;
}
window.chatHumanVerify = chatHumanVerify;
// Start the dwell clock as soon as the customer touches the form.
document.addEventListener('focusin', (e) => { if (e.target && e.target.closest && e.target.closest('#chat-lead-form')) chatHumanPrefetch(); }, true);

async function submitLead() {
  // In-flight guard — the Send button fires this via BOTH an inline onclick
  // AND the CSP-safe delegated click handler, so on non-CSP hosts it would
  // otherwise run twice and create two lead rows. Ignore re-entrant calls.
  if (window._leadSubmitInFlight) return;
  window._leadSubmitInFlight = true;
  const v = leadValues();
  const errBox = document.getElementById('chat-lead-error');
  const sendBtn = document.querySelector('[data-testid="lead-send-btn"]');
  const sendBtnHtml = '<i class="bi bi-send-fill me-1"></i><span>Send</span>';
  if (errBox) errBox.style.display = 'none';
  function showErr(msg) {
    window._leadSubmitInFlight = false;
    if (errBox) { errBox.textContent = msg; errBox.style.display = 'block'; }
    else { showToast(msg); }
  }
  if (!v.first_name) { showErr('Please enter your first name.'); return; }
  if (leadNameLooksLikeText(v.first_name) || leadNameLooksLikeText(v.last_name)) { showErr('Please put only your name in the name boxes \u2014 type your question in the \u201cWhat do you need help with?\u201d box below.'); return; }
  if (!/\S+@\S+\.\S+/.test(v.email)) { showErr('Please enter a valid email address.'); return; }
  if (v.phone.length < 7) { showErr('Please enter your phone number.'); return; }
  if (!v.issue) { showErr('Please tell us what issue you\u2019re facing.'); return; }
  if (!_hcToken) { showErr('Please tap \u201cVerify you\u2019re human\u201d first.'); const hb = document.getElementById('chat-human-btn'); if (hb) hb.focus(); return; }
  if (sendBtn) { sendBtn.disabled = true; sendBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'; }
  let sid = localStorage.getItem('uc_chat_session');
  if (!sid) { sid = 's' + Date.now() + Math.random().toString(36).slice(2, 8); localStorage.setItem('uc_chat_session', sid); }
  try {
    const r = await fetch('ajax/lead.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sid, ...v, human_token: _hcToken, website: (document.getElementById('lead-website') || {}).value || '' }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.status >= 400 || (j && j.ok === false)) {
      const detail = (j && (j.error || j.message)) || 'Something went wrong — please try again.';
      if (j && j.code === 'human_required') { _hcToken = null; _hcChallenge = null; chatHumanState('idle', "Verify you're human", 'Tap once — takes a second'); chatHumanPrefetch(); }
      showErr(detail);
      if (sendBtn) { sendBtn.disabled = false; sendBtn.innerHTML = sendBtnHtml; }
      return;
    }
    if (j && j.chat_token) {
      localStorage.setItem('uc_chat_token', j.chat_token);
      localStorage.setItem('uc_lead_id', String(j.lead_id || ''));
      localStorage.setItem('uc_chat_origin', 'form');
      startAdminPolling();
    }
  } catch (e) {
    showErr('Network error — please check your connection and try again.');
    if (sendBtn) { sendBtn.disabled = false; sendBtn.innerHTML = sendBtnHtml; }
    return;
  }
  localStorage.setItem('uc_lead_done', '1');
  // Flag this session as a "human-only" thread — sendChat() will skip the
  // AI auto-reply and route directly to the admin lead-management chat.
  localStorage.setItem('uc_chat_human_only', '1');
  window._leadSubmitInFlight = false;
  touchChatActivity();
  updateStartOverVisibility();
  if (sendBtn) { sendBtn.disabled = false; sendBtn.innerHTML = sendBtnHtml; }
  // Hide the form and present the post-send choice (callback vs keep chatting).
  document.getElementById('chat-lead-form').style.display = 'none';
  const choice = document.getElementById('chat-lead-choice');
  if (choice) choice.style.display = 'block';
}

// Customer chose "Request a callback" on the post-send card.
async function chooseCallback() {
  const choice = document.getElementById('chat-lead-choice');
  if (choice) choice.style.display = 'none';
  await leadSendChoice('callback');
  revealChatInputRow();
  const phone = (window.SITE_PHONE || '').trim();
  const bubble = chatAppend('bot',
    'Great \u2014 a support agent will call you shortly on the number you provided, so please keep your phone handy.'
    + (phone ? ' You can also reach us directly at ' + phone + '.' : '')
    + ' Feel free to add anything else below in the meantime.');
  if (bubble) bubble.classList.add('agent-greeting');
  _paSchedInitDone = false;
  setTimeout(paSchedInit, 200);
}

// Tell the server which way the customer wants to be helped. This is what
// e-mails the admin and rings the bell / phone (callback → 'lead' alert with
// the phone number; chat → 'chat' alert that opens the live thread).
async function leadSendChoice(choice) {
  try {
    await fetch('ajax/lead-choice.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        choice,
        lead_id: localStorage.getItem('uc_lead_id') || '',
        chat_token: localStorage.getItem('uc_chat_token') || '',
      }),
    });
  } catch (e) { /* non-blocking — the lead is already saved */ }
}

// Customer chose "Continue with chat" on the post-verify card.
async function chooseContinueChat() {
  const choice = document.getElementById('chat-lead-choice');
  if (choice) choice.style.display = 'none';
  await leadSendChoice('chat');
  revealChatInputRow();
  const phone = (window.SITE_PHONE || '').trim();
  const bubble = chatAppend('bot',
    'Great \u2014 you\u2019re all set! \ud83d\udcac A support agent will be connecting with you right here on chat in just a moment. '
    + 'Feel free to type your question below in the meantime'
    + (phone ? ', or if it\u2019s urgent you can reach us directly at ' + phone + '.' : '.'));
  if (bubble) bubble.classList.add('agent-greeting');
  const inp = document.getElementById('chat-input');
  if (inp) setTimeout(() => inp.focus(), 80);
}

function skipLead() {
  localStorage.setItem('uc_lead_done', '1');
  document.getElementById('chat-lead-form').style.display = 'none';
  revealChatInputRow();
  chatAppend('bot', 'No problem — ask me anything about products, pricing, order delivery or activation. I\'m happy to help.');
}

// Show the "Type a message…" composer.  Hidden by default so customers
// must first share their contact info via the lead form (or skip it).
// On reveal, smooth slide-in + auto-focus the input.
// Defensive: also sets inline `style.display` so a stuck `d-none` class
// (which sometimes lingers when other JS rewrites the className) cannot
// keep the composer invisible.
function revealChatInputRow() {
  const row = document.getElementById('chat-input-row');
  if (!row) return;
  row.classList.remove('d-none');
  row.classList.add('d-flex');
  row.style.display = 'flex';
  row.style.visibility = 'visible';
  if (!row.classList.contains('is-fade-in')) row.classList.add('is-fade-in');
  const inp = document.getElementById('chat-input');
  if (inp) setTimeout(() => inp.focus(), 60);
}

function chatAppend(role, text) {
  const body = document.getElementById('chat-body');
  const div = document.createElement('div');
  div.className = 'chat-msg ' + role;
  div.textContent = text;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}

// ===== Live admin chat polling (after lead is captured) =====
let _adminPollTimer = null;
let _adminLastMsgId = 0;
let _historyLoaded = false;
// IDs of chat messages already rendered into the customer thread — prevents
// the SAME server message from appearing twice (e.g. a history-load / live-poll
// race, or an admin reply that gets re-fetched). Guarantees one bubble per id.
const _renderedMsgIds = new Set();

// Load the FULL saved conversation (both sides) so a returning/reloading
// customer always lands back in the same thread with every message intact.
// Runs at most once per page load; sets _adminLastMsgId so the live poller
// then only fetches genuinely new admin replies (no duplicates).
async function loadChatHistory() {
  if (_historyLoaded) return;
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  _historyLoaded = true; // guard immediately to avoid double-loads on rapid opens
  try {
    const r = await fetch('ajax/chat-customer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'history', token: token, session_id: chatSid() }),
    });
    const j = await r.json();
    if (chatHandleGuard(j)) return;
    if (j && j.ok && Array.isArray(j.messages)) {
      for (const m of j.messages) {
        if (m.id && _renderedMsgIds.has(m.id)) { if (m.id > _adminLastMsgId) _adminLastMsgId = m.id; continue; }
        if (m.id) _renderedMsgIds.add(m.id);
        const role = (m.sender === 'customer') ? 'user' : 'bot';
        if (m.attachment_url) { chatAppendAttachment(role, m); }
        else if (m.message)   { chatAppend(role, m.message); }
        if (m.id > _adminLastMsgId) _adminLastMsgId = m.id;
      }
      if (j.messages.length) localStorage.setItem('uc_chat_human_only', '1');
    }
  } catch (e) { _historyLoaded = false; /* allow a retry on next open */ }
}

async function startAdminPolling() {
  if (_adminPollTimer) return;
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  // Restore the saved thread first, THEN start polling for new replies.
  await loadChatHistory();
  _adminPollTimer = setInterval(adminPollOnce, 5000);
  adminPollOnce();
}
async function adminPollOnce() {
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  try {
    const r = await fetch('ajax/chat-customer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'poll', token: token, session_id: chatSid(), since: _adminLastMsgId }),
    });
    const j = await r.json();
    if (chatHandleGuard(j)) return;
    // An agent joined → switch to a one-to-one human conversation (no AI) and
    // show the agent's name in the chat header.
    if (j && j.ok && j.agent_joined) {
      localStorage.setItem('uc_chat_human_only', '1');
      if (j.agent_name) updateChatAgentName(j.agent_name);
    }
    if (j && j.ok && Array.isArray(j.messages) && j.messages.length) {
      const panel = document.getElementById('chat-panel');
      const panelOpen = panel && panel.classList.contains('open');
      let _appended = 0;
      for (const m of j.messages) {
        if (m.id && _renderedMsgIds.has(m.id)) { if (m.id > _adminLastMsgId) _adminLastMsgId = m.id; continue; }
        if (m.id) _renderedMsgIds.add(m.id);
        if (m.attachment_url) { chatAppendAttachment('bot', m); } else { chatAppend('bot', m.message); }
        _appended++;
        if (m.id > _adminLastMsgId) _adminLastMsgId = m.id;
      }
      // New admin reply arrived while the customer's chat panel is closed.
      // DON'T auto-open the panel (that's intrusive). Instead: badge the
      // chat bubble with the unread count, play a soft chime, and show a
      // dismissible Messenger-style preview with the latest message — the
      // customer taps "Tap to reply" (or the bubble) when THEY are ready.
      if (!panelOpen && _appended > 0) {
        showChatBell(_appended);
        _chatChime();
        const latest = j.messages[j.messages.length - 1];
        showChatMsgPreview(latest && latest.message ? latest.message : '');
      }
      if (_appended > 0) touchChatActivity();
    }
    // Show "Live agent is typing…" indicator while the admin's beacon
    // is fresh (≤5 sec).  Hides automatically when the next poll comes
    // back with admin_typing=false.
    const t = document.getElementById('chat-typing');
    if (t) {
      const show = !!(j && j.admin_typing);
      t.style.display = show ? 'block' : 'none';
      if (show) { const body = document.getElementById('chat-body'); if (body) body.scrollTop = body.scrollHeight; }
    }
  } catch (e) { /* keep retrying silently */ }
}

// Throttled customer "I'm typing" beacon — fires at most every 2 sec
// while the chat-input has non-empty content.  Admin chat panel sees
// "● Customer is typing…" within 1 polling tick (3-5 sec).
let _custTypingAt = 0;
function pingCustomerTyping(on){
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  const now = Date.now();
  if (on && (now - _custTypingAt) < 2000) return;
  _custTypingAt = on ? now : 0;
  try {
    fetch('ajax/chat-customer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'typing', token: token, session_id: chatSid(), typing: on ? 1 : 0 }),
    });
  } catch(_) {}
}
// Hook the public chat input — fires on every keystroke, with "off"
// pings on blur / message-send so the admin's indicator disappears
// quickly when the customer stops typing.  Also clears the unread bell
// the moment the customer starts replying.
document.addEventListener('DOMContentLoaded', () => {
  const i = document.getElementById('chat-input');
  if (!i) return;
  i.addEventListener('input', () => {
    if (i.value.trim().length > 0) clearChatBell();
    pingCustomerTyping(i.value.trim().length > 0);
    maybeShowLeadNudge();
  });
  i.addEventListener('focus', () => { clearChatBell(); maybeShowLeadNudge(); });
  i.addEventListener('blur',  () => pingCustomerTyping(false));
});

// Surface the "Don't lose this — agent on the way" sticky banner on the
// lead form the moment the customer starts typing without having
// submitted their contact details.  Highest-intent moment → highest
// conversion ROI on the lead capture.  Once the customer submits the
// form (uc_lead_done='1') the nudge stays hidden forever.
function maybeShowLeadNudge(){
  if (localStorage.getItem('uc_lead_done') === '1') return;
  const form  = document.getElementById('chat-lead-form');
  const nudge = document.getElementById('chat-lead-nudge');
  const input = document.getElementById('chat-input');
  if (!form || !nudge || !input) return;
  // Only show when there's actual typing intent — empty input shouldn't
  // bug a returning visitor.
  const hasIntent = input.value.trim().length > 0 || document.activeElement === input;
  if (!hasIntent) { nudge.style.display = 'none'; return; }
  // Make sure the form is visible (skipLead may have hidden it).
  if (form.style.display === 'none') form.style.display = '';
  nudge.style.display = 'flex';
  // Smooth-scroll the lead form into view so the customer can't miss
  // the new banner.  Bottom-anchored so the input stays visible.
  try { form.scrollIntoView({behavior:'smooth', block:'end'}); } catch(_) {}
}
async function relayCustomerMessageToAdmin(text) {
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  try {
    const r = await fetch('ajax/chat-customer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'send', token: token, session_id: chatSid(), message: text }),
    });
    const j = await r.json().catch(() => null);
    chatHandleGuard(j);
  } catch (e) {}
}
// Resume polling on page load if a token is already saved
if (typeof window !== 'undefined' && localStorage.getItem('uc_chat_token')) {
  document.addEventListener('DOMContentLoaded', () => startAdminPolling());
}
if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    updateStartOverVisibility();
    // Deep link from the "reply delivered by email" message: open the widget.
    try {
      const q = new URLSearchParams(window.location.search);
      if (q.get('chat') === 'open') {
        setTimeout(() => {
          const panel = document.getElementById('chat-panel');
          if (panel && !panel.classList.contains('open') && typeof toggleChat === 'function') toggleChat();
        }, 600);
      }
    } catch (e) {}
  });
}

// =====================================================================
// ProAssist install-call scheduler — inline calendar inside chat panel.
//
// Lifecycle:
//   1. paSchedInit() runs whenever the chat panel opens with a stored
//      uc_chat_token.  It POSTs action=status to discover whether this
//      visitor is a ProAssist lead (and whether they already booked).
//   2. If proassist + no schedule yet → render the date pills.
//   3. Pick a date → action=slots → render time pills.
//   4. Pick a time → action=book → swap to the confirmation card.
//   5. Reschedule → flip back to step (2) from the confirmation card.
// =====================================================================
let _paSchedSelectedDate = null;
let _paSchedInitDone     = false;
let _paSchedTz           = 'America/New_York';
let _paSchedTzList       = null;

// Guess the visitor's IANA timezone (falls back to US Eastern).
function _paGuessTz() {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/New_York'; }
  catch (e) { return 'America/New_York'; }
}
function _paSchedEl(id) { return document.getElementById(id); }
function _paSchedError(msg) {
  const e = _paSchedEl('pa-sched-error');
  if (!e) return;
  if (msg) { e.textContent = msg; e.style.display = 'block'; }
  else { e.style.display = 'none'; e.textContent = ''; }
}

function paSchedInit() {
  if (_paSchedInitDone) return;
  const token = localStorage.getItem('uc_chat_token');
  if (!token) return;
  _paSchedInitDone = true;
  fetch('ajax/proassist-schedule.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'status', token, session_id: chatSid() }),
  })
    .then(r => r.json())
    .then(j => {
      if (!j || !j.ok || !j.is_proassist) return;
      _paSchedTzList = j.timezones || {};
      // Known ProAssist customer → hide the lead form, reveal the composer
      // so they can still type, and show either the picker or (if they've
      // already booked) the confirmation card.
      const lf = document.getElementById('chat-lead-form');
      if (lf) lf.style.display = 'none';
      revealChatInputRow();
      // NOTE: no client-side greeting here. For ProAssist order-success chats
      // the server already inserts a tailored welcome (naming the registered
      // callback number + how to update it), so appending the generic
      // chatDefaultGreeting() would duplicate/contradict it.
      localStorage.setItem('uc_pa_greeted', '1');
      paShowOptions(j);
    })
    .catch(() => {});
}

// Two-option Pro Assist post-purchase UI shown in the chat: (a) request a
// call back on the (editable, pre-filled) registered number, or (b) call the
// toll-free line now. Both record the choice server-side (action=choice),
// which mirrors it into the chat thread and emails + bells the admin.
function paShowOptions(j) {
  const host = document.getElementById('chat-body');
  if (!host || document.getElementById('pa-options')) return;
  const phone = (j.customer && j.customer.phone ? String(j.customer.phone) : '').trim();
  const tel = ((j.toll_free || window.SITE_PHONE) || '').trim();
  const telHref = tel.replace(/[^\d+]/g, '');
  const esc = (s) => String(s).replace(/[&<>\x22]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const wrap = document.createElement('div');
  wrap.id = 'pa-options';
  wrap.className = 'pa-opts';
  wrap.setAttribute('data-testid', 'pa-options');
  const doneHtml = (choice, num) => choice === 'callback'
    ? '<div class="pa-opts-done" data-testid="pa-opts-done"><i class="bi bi-check-circle-fill"></i> Call back requested — a technician will call you on <strong>' + esc(num || phone) + '</strong> shortly to complete your installation.</div>'
    : '<div class="pa-opts-done" data-testid="pa-opts-done"><i class="bi bi-check-circle-fill"></i> Our technicians are ready for your call' + (tel ? ' on <a href="tel:' + telHref + '"><strong>' + esc(tel) + '</strong></a>' : '') + '. Have your order number ready.</div>';
  // Already chose earlier (page reload / re-opened widget) → just show the state.
  if (j.choice === 'callback' || j.choice === 'calling') {
    wrap.innerHTML = doneHtml(j.choice, phone);
    host.appendChild(wrap);
    if (typeof scrollChatToBottom === 'function') scrollChatToBottom();
    return;
  }
  wrap.innerHTML =
    '<div class="pa-opts-title">How would you like us to help you get set up?</div>'
    + '<button type="button" class="pa-opt" id="pa-opt-callback" data-testid="pa-opt-callback"><i class="bi bi-telephone-inbound"></i><span><strong>Request a call back</strong><small>A technician calls you' + (phone ? ' on ' + esc(phone) : '') + '</small></span></button>'
    + (tel ? '<button type="button" class="pa-opt" id="pa-opt-calling" data-testid="pa-opt-callnow"><i class="bi bi-telephone-outbound"></i><span><strong>I\'ll call you</strong><small>Toll-free: ' + esc(tel) + '</small></span></button>' : '')
    + '<div class="pa-sched-form" id="pa-sched-form" style="display:none;">'
    + '<label class="pa-sched-label">Confirm the number we should call</label>'
    + '<div class="pa-sched-row"><input type="tel" id="pa-sched-phone" class="pa-sched-input" value="' + esc(phone) + '" placeholder="Your phone number" data-testid="pa-sched-phone"><button type="button" class="pa-sched-submit" id="pa-sched-submit" data-testid="pa-sched-submit" aria-label="Request call back"><i class="bi bi-arrow-right"></i></button></div>'
    + '<div class="pa-sched-err" id="pa-choice-err" style="display:none;"></div>'
    + '</div>';
  host.appendChild(wrap);
  if (typeof scrollChatToBottom === 'function') scrollChatToBottom();

  const sendChoice = (choice, num) => fetch('ajax/proassist-schedule.php', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'choice', choice, phone: num || '', token: localStorage.getItem('uc_chat_token'), session_id: chatSid() }),
  }).then(r => r.json());

  const form = document.getElementById('pa-sched-form');
  document.getElementById('pa-opt-callback').addEventListener('click', function(){
    form.style.display = 'block';
    const inp = document.getElementById('pa-sched-phone');
    if (inp) inp.focus();
    if (typeof scrollChatToBottom === 'function') scrollChatToBottom();
  });
  const callingBtn = document.getElementById('pa-opt-calling');
  if (callingBtn) callingBtn.addEventListener('click', function(){
    callingBtn.disabled = true;
    sendChoice('calling').then(j2 => {
      if (!j2 || !j2.ok) { callingBtn.disabled = false; return; }
      wrap.innerHTML = doneHtml('calling');
      if (typeof adminPollOnce === 'function') adminPollOnce();
      touchChatActivity();
      if (telHref) { try { window.location.href = 'tel:' + telHref; } catch (_) {} }
    }).catch(() => { callingBtn.disabled = false; });
  });
  const submit = document.getElementById('pa-sched-submit');
  submit.addEventListener('click', function(){
    const inp = document.getElementById('pa-sched-phone');
    const err = document.getElementById('pa-choice-err');
    const num = (inp && inp.value ? inp.value : phone).trim();
    if (num.replace(/\D/g, '').length < 7) { if (inp) inp.focus(); if (err) { err.textContent = 'Please enter a valid phone number.'; err.style.display = 'block'; } return; }
    submit.disabled = true;
    sendChoice('callback', num).then(j2 => {
      if (!j2 || !j2.ok) { submit.disabled = false; if (err) { err.textContent = (j2 && j2.error) || 'Could not save — please try again.'; err.style.display = 'block'; } return; }
      wrap.innerHTML = doneHtml('callback', j2.phone || num);
      if (typeof adminPollOnce === 'function') adminPollOnce();
      touchChatActivity();
    }).catch(() => { submit.disabled = false; });
  });
}

// Populate the timezone dropdown (once) + select the best default.
function _paSchedRenderTzSelect() {
  const sel = _paSchedEl('pa-sched-tz');
  if (!sel || !_paSchedTzList) return;
  if (sel.options.length === 0) {
    Object.keys(_paSchedTzList).forEach(function (value) {
      const opt = document.createElement('option');
      opt.value = value;
      opt.textContent = _paSchedTzList[value];
      sel.appendChild(opt);
    });
    const guess = _paGuessTz();
    _paSchedTz = (_paSchedTzList[guess]) ? guess : 'America/New_York';
    sel.value = _paSchedTz;
    sel.addEventListener('change', function () {
      _paSchedTz = sel.value || 'America/New_York';
      if (_paSchedSelectedDate) paSchedLoadSlots(_paSchedSelectedDate);
    });
  } else {
    sel.value = _paSchedTz;
  }
}

function paSchedShowPicker() {
  const card = _paSchedEl('pa-sched-card');
  const conf = _paSchedEl('pa-sched-confirm');
  if (conf) conf.style.display = 'none';
  if (card) card.style.display = 'block';
  _paSchedError('');
  _paSchedRenderTzSelect();
  paSchedRenderDates();
  const step = _paSchedEl('pa-sched-times-step');
  if (step) step.style.display = 'none';
  _paSchedSelectedDate = null;
  revealChatInputRow();
}

// Render the next 21 selectable dates (any future date, weekends included).
function paSchedRenderDates() {
  const wrap = _paSchedEl('pa-sched-dates');
  if (!wrap) return;
  wrap.innerHTML = '';
  const dows = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const mons = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const today = new Date();
  for (let i = 0; i < 21; i++) {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() + i);
    const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pa-sched-date';
    btn.dataset.date = iso;
    btn.setAttribute('data-testid', 'pa-sched-date-' + iso);
    btn.innerHTML = '<span class="pa-sched-date-dow">' + (i === 0 ? 'Today' : dows[d.getDay()]) + '</span>'
                  + '<span class="pa-sched-date-day">' + d.getDate() + '</span>'
                  + '<span class="pa-sched-date-mon">' + mons[d.getMonth()] + '</span>';
    btn.addEventListener('click', function () { paSchedSelectDate(iso, btn); });
    wrap.appendChild(btn);
  }
}

function paSchedSelectDate(iso, btn) {
  _paSchedSelectedDate = iso;
  document.querySelectorAll('#pa-sched-dates .pa-sched-date').forEach(function (b) {
    b.classList.toggle('is-selected', b === btn);
  });
  paSchedLoadSlots(iso);
}

function paSchedBackToDates() {
  const step = _paSchedEl('pa-sched-times-step');
  if (step) step.style.display = 'none';
  _paSchedSelectedDate = null;
  document.querySelectorAll('#pa-sched-dates .pa-sched-date').forEach(b => b.classList.remove('is-selected'));
}

function paSchedLoadSlots(date) {
  _paSchedError('');
  const step  = _paSchedEl('pa-sched-times-step');
  const times = _paSchedEl('pa-sched-times');
  const tzLab = _paSchedEl('pa-sched-times-tz');
  if (!step || !times) return;
  step.style.display = 'block';
  times.innerHTML = '<div class="pa-sched-empty">Loading…</div>';
  if (tzLab && _paSchedTzList) tzLab.textContent = '(' + (_paSchedTzList[_paSchedTz] || _paSchedTz) + ')';
  const token = localStorage.getItem('uc_chat_token');
  fetch('ajax/proassist-schedule.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'slots', token, session_id: chatSid(), date, tz: _paSchedTz }),
  })
    .then(r => r.json())
    .then(j => {
      if (!j || !j.ok) { times.innerHTML = '<div class="pa-sched-empty">Could not load times.</div>'; return; }
      times.innerHTML = '';
      const avail = (j.slots || []).filter(s => !s.past && !s.taken);
      if (avail.length === 0) {
        times.innerHTML = '<div class="pa-sched-empty">No times left on this day — try another date.</div>';
        return;
      }
      (j.slots || []).forEach(function (s) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'pa-sched-time' + (s.taken ? ' is-taken' : '') + (s.past ? ' is-past' : '');
        b.textContent = s.label;
        b.setAttribute('data-testid', 'pa-sched-time-' + s.time);
        if (!s.taken && !s.past) {
          b.addEventListener('click', function () { paSchedBook(date, s.time); });
        }
        times.appendChild(b);
      });
    })
    .catch(() => { times.innerHTML = '<div class="pa-sched-empty">Network error — please retry.</div>'; });
}

function paSchedBook(date, time) {
  _paSchedError('');
  const token = localStorage.getItem('uc_chat_token');
  fetch('ajax/proassist-schedule.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'book', token, session_id: chatSid(), date, time, tz: _paSchedTz }),
  })
    .then(r => r.json())
    .then(j => {
      if (!j || !j.ok) { _paSchedError((j && j.error) || 'Could not book that slot — please try another.'); return; }
      paSchedShowConfirmed(j.schedule, j.rescheduled);
      const verb = j.rescheduled ? 'Rescheduled' : 'Confirmed';
      chatAppend('bot', '✅ ' + verb + ' — your callback is booked for ' + ((j.schedule && j.schedule.pretty) || '') + '.');
    })
    .catch(() => _paSchedError('Network error — please retry.'));
}

function paSchedShowConfirmed(sched, rescheduled) {
  const card = _paSchedEl('pa-sched-card');
  const conf = _paSchedEl('pa-sched-confirm');
  if (card) card.style.display = 'none';
  if (!conf) return;
  const pretty = (sched && sched.pretty) || 'your selected time';
  conf.innerHTML =
      '<div class="pa-sched-confirm-icon"><i class="bi bi-check-circle-fill"></i></div>'
    + '<div class="pa-sched-confirm-title">Callback ' + (rescheduled ? 'rescheduled' : 'scheduled') + '!</div>'
    + '<div class="pa-sched-confirm-when">' + pretty + '</div>'
    + '<button type="button" class="pa-sched-reschedule" onclick="paSchedReschedule()" data-testid="pa-sched-reschedule">Reschedule</button>';
  conf.style.display = 'block';
  revealChatInputRow();
}

function paSchedReschedule() { paSchedShowPicker(); }

// Hook into the chat toggle so paSchedInit runs every time the panel
// opens (cheap — internally guarded by _paSchedInitDone).
(function(){
  const origToggle = window.toggleChat;
  window.toggleChat = function(){
    if (typeof origToggle === 'function') origToggle.apply(this, arguments);
    const panel = document.getElementById('chat-panel');
    if (panel && panel.classList.contains('open')) {
      // Defer to next tick — give the chat panel time to render the body.
      setTimeout(paSchedInit, 50);
    }
  };
})();

// Also run after submitLead() succeeds, since that's when the chat
// transitions from "lead form" to "live conversation" and we want the
// scheduler card to surface immediately if the visitor turns out to
// be ProAssist (e.g. they just completed a ProAssist checkout).
document.addEventListener('DOMContentLoaded', () => {
  // First-load auto-init for visitors landing with a token already
  // bound (e.g. order-success page injected localStorage values).
  if (localStorage.getItem('uc_chat_token')) {
    setTimeout(paSchedInit, 400);
  }
});

function quickAsk(text) {
  const chips = document.getElementById('chat-chips');
  if (chips) chips.remove();
  const input = document.getElementById('chat-input');
  input.value = text;
  sendChat(new Event('submit'));
}

async function sendChat(ev) {
  ev.preventDefault();
  const input = document.getElementById('chat-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';
  pingCustomerTyping(false); // sent — clear the "typing" beacon
  chatAppend('user', msg);
  touchChatActivity();
  // Forward the customer's message to the admin chat thread.  This is the
  // ONLY downstream route now — no AI auto-reply.  An admin agent reads
  // the message in lead-mgmt and replies manually; that reply comes back
  // to the customer via adminPollOnce() polling /ajax/chat-customer.php.
  relayCustomerMessageToAdmin(msg);
  // Human-only mode (set by submitLead) — do NOT call the AI chat endpoint.
  // The customer waits for a real agent reply.  We render a small "agent
  // notified" status line once per session so the customer knows their
  // message landed.
  if (localStorage.getItem('uc_chat_human_only') === '1') {
    if (!window._humanOnlyAckedOnce) {
      window._humanOnlyAckedOnce = true;
      const ack = chatAppend('bot',
        'Got it — your message was sent to our support team. A live agent will reply here as soon as they\'re free.'
      );
      if (ack) ack.classList.add('agent-greeting');
    }
    return;
  }
  // Legacy fall-through (no lead captured yet, e.g. ProAssist auto-chat
  // bound to a paid order's lead): still ping the AI assistant so the
  // customer isn't left in silence.
  const typing = chatAppend('bot', '');
  typing.classList.add('typing');
  typing.innerHTML = '<span></span><span></span><span></span>';
  let sid = localStorage.getItem('uc_chat_session');
  if (!sid) { sid = 's' + Date.now() + Math.random().toString(36).slice(2, 8); localStorage.setItem('uc_chat_session', sid); }
  try {
    const res = await fetch('ajax/chat.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, session_id: sid }),
    });
    const data = await res.json();
    typing.classList.remove('typing');
    typing.textContent = data.reply;
  } catch (err) {
    typing.classList.remove('typing');
    typing.textContent = 'Sorry, something went wrong. Call us at ' + (window.SITE_PHONE || '(888) 812-0952') + ' or email us.';
  }
}

// =====================================================================
// Chat composer extras — file attachments, voice notes, emoji picker.
// =====================================================================
function chatAttachClick() {
  const inp = document.getElementById('chat-file-input');
  if (inp) inp.click();
}
document.addEventListener('DOMContentLoaded', function () {
  const inp = document.getElementById('chat-file-input');
  if (inp) {
    inp.addEventListener('change', function () {
      if (inp.files && inp.files[0]) { chatUploadFile(inp.files[0], 'file'); inp.value = ''; }
    });
  }
});

function _chatAttachStatus(msg, isErr) {
  const s = document.getElementById('chat-attach-status');
  if (!s) return;
  if (!msg) { s.style.display = 'none'; s.textContent = ''; return; }
  s.textContent = msg;
  s.style.display = 'block';
  s.style.color = isErr ? '#dc2626' : 'var(--chat-text-soft,#64748b)';
}

function _chatEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>\x22\x27]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
function renderAttachmentHTML(att) {
  const url = _chatEsc(att.attachment_url);
  const name = _chatEsc(att.attachment_name || 'attachment');
  if (att.attachment_type === 'image') {
    return '<a href="' + url + '" target="_blank" rel="noopener"><img src="' + url + '" alt="' + name + '" class="chat-msg-img"></a>';
  }
  if (att.attachment_type === 'audio') {
    return '<audio controls preload="metadata" src="' + url + '" class="chat-msg-audio"></audio>';
  }
  return '<a href="' + url + '" target="_blank" rel="noopener" download class="chat-msg-file"><i class="bi bi-paperclip"></i> ' + name + '</a>';
}
function chatAppendAttachment(role, att) {
  const body = document.getElementById('chat-body');
  if (!body) return null;
  const div = document.createElement('div');
  div.className = 'chat-msg ' + role + ' chat-msg-attach';
  div.innerHTML = renderAttachmentHTML(att);
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}

async function chatUploadFile(file, kind) {
  const token = localStorage.getItem('uc_chat_token');
  if (!token) {
    _chatAttachStatus('Please share your contact details first, then you can attach files.', true);
    const form = document.getElementById('chat-lead-form');
    if (form) form.style.display = 'block';
    return;
  }
  _chatAttachStatus(kind === 'voice' ? 'Sending voice message…' : 'Uploading…', false);
  const fd = new FormData();
  fd.append('file', file, file.name || (kind === 'voice' ? 'voice.webm' : 'file'));
  fd.append('token', token);
  fd.append('session_id', chatSid());
  fd.append('kind', kind || 'file');
  try {
    const r = await fetch('ajax/chat-upload.php', { method: 'POST', body: fd });
    const j = await r.json().catch(() => ({}));
    if (!j || !j.ok) { _chatAttachStatus((j && j.error) || 'Upload failed — please try again.', true); return; }
    _chatAttachStatus('', false);
    chatAppendAttachment('user', j.message);
  } catch (e) {
    _chatAttachStatus('Network error — please retry.', true);
  }
}

/* ---- Emoji picker ---- */
const _CHAT_EMOJIS = ['😀','😃','😁','😉','😊','😍','😘','😎','🤔','🙂','🙏','👍','👎','👌','👏','🙌','💪','🎉','🔥','✨','❤️','💙','💚','💜','😢','😅','😂','🤣','😭','😡','😱','🤝','💻','📎','📧','📞','✅','❌','⭐','💯'];
function chatToggleEmoji(ev) {
  if (ev) ev.stopPropagation();
  const panel = document.getElementById('chat-emoji-panel');
  if (!panel) return;
  if (panel.style.display === 'grid') { panel.style.display = 'none'; return; }
  if (!panel.dataset.built) {
    _CHAT_EMOJIS.forEach(function (e) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'chat-emoji-item';
      b.textContent = e;
      b.addEventListener('click', function () {
        const inp = document.getElementById('chat-input');
        if (inp) { inp.value += e; inp.focus(); }
      });
      panel.appendChild(b);
    });
    panel.dataset.built = '1';
  }
  panel.style.display = 'grid';
}
document.addEventListener('click', function (e) {
  const panel = document.getElementById('chat-emoji-panel');
  const btn = document.getElementById('chat-emoji-btn');
  if (!panel || panel.style.display !== 'grid') return;
  if (panel.contains(e.target) || (btn && btn.contains(e.target))) return;
  panel.style.display = 'none';
});

/* ---- Voice typing (Web Speech API → text in the input, sent as a normal
   text message, NOT an audio recording) ---- */
/* ---- Voice typing (record → Whisper transcription → text in the input).
   Uses MediaRecorder (universal: Chrome/Edge/Firefox/Safari) + server-side
   Whisper, which is far more reliable than the browser Web Speech API. ---- */
let _chatRec = null, _chatRecChunks = [], _chatRecStream = null, _chatRecTimer = null, _chatRecStart = 0, _chatRecBusy = false;
function _chatStopTracks() {
  if (_chatRecStream) { try { _chatRecStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} _chatRecStream = null; }
}
function _chatVoiceTimer(on) {
  const t = document.getElementById('chat-voice-timer'), tm = document.getElementById('chat-voice-time');
  if (!t) return;
  if (on) {
    t.style.display = 'inline-flex'; _chatRecStart = Date.now();
    _chatRecTimer = setInterval(function () {
      const s = Math.floor((Date.now() - _chatRecStart) / 1000);
      if (tm) tm.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
      if (s >= 90 && _chatRec && _chatRec.state === 'recording') _chatRec.stop(); // 90s cap
    }, 250);
  } else {
    if (_chatRecTimer) { clearInterval(_chatRecTimer); _chatRecTimer = null; }
    t.style.display = 'none';
  }
}
async function chatToggleVoice() {
  const micBtn = document.getElementById('chat-mic-btn');
  // Tap again → stop + transcribe.
  if (_chatRec && _chatRec.state === 'recording') { try { _chatRec.stop(); } catch (e) {} return; }
  if (_chatRecBusy) return;

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || typeof MediaRecorder === 'undefined') {
    _chatAttachStatus('Voice typing is not supported on this browser — please type your message.', true);
    return;
  }
  _chatAttachStatus('Starting microphone…', false);
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (e) {
    let msg = 'Microphone is blocked. Allow mic access in your browser and try again.';
    const n = (e && e.name) || '';
    if (n === 'NotFoundError' || n === 'DevicesNotFoundError') msg = 'No microphone was found on this device.';
    else if (n === 'NotReadableError') msg = 'Your microphone is in use by another app.';
    else if (window.self !== window.top) msg += ' If it stays blocked, open the site in its own browser tab.';
    _chatAttachStatus(msg, true);
    return;
  }
  _chatRecStream = stream;
  _chatRecChunks = [];
  let mime = '';
  ['audio/webm', 'audio/mp4', 'audio/ogg'].some(function (m) { if (MediaRecorder.isTypeSupported(m)) { mime = m; return true; } return false; });
  try { _chatRec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream); }
  catch (e) { _chatRec = new MediaRecorder(stream); }

  _chatRec.ondataavailable = function (e) { if (e.data && e.data.size) _chatRecChunks.push(e.data); };
  _chatRec.onstart = function () {
    if (micBtn) micBtn.classList.add('is-recording');
    _chatAttachStatus('Listening… tap the mic again when you\u2019re done', false);
    _chatVoiceTimer(true);
  };
  _chatRec.onstop = async function () {
    if (micBtn) micBtn.classList.remove('is-recording');
    _chatVoiceTimer(false);
    _chatStopTracks();
    const blob = new Blob(_chatRecChunks, { type: (_chatRec && _chatRec.mimeType) || 'audio/webm' });
    if (!blob.size) { _chatAttachStatus('Didn\u2019t catch any audio — try again.', true); return; }
    _chatRecBusy = true;
    _chatAttachStatus('Transcribing…', false);
    const token = localStorage.getItem('uc_chat_token');
    const fd = new FormData();
    fd.append('audio', blob, 'voice.webm');
    if (token) { fd.append('token', token); fd.append('session_id', chatSid()); }
    try {
      const r = await fetch('ajax/transcribe.php', { method: 'POST', body: fd, credentials: 'same-origin' });
      const j = await r.json().catch(function () { return null; });
      if (j && j.ok && (j.text || '').trim()) {
        const inp = document.getElementById('chat-input');
        if (inp) {
          inp.value = (inp.value ? inp.value.trim() + ' ' : '') + j.text.trim();
          inp.focus();
          pingCustomerTyping(true);
        }
        _chatAttachStatus('', false);
      } else if (j && j.ok) {
        _chatAttachStatus('Didn\u2019t catch that — please try again.', true);
      } else {
        _chatAttachStatus((j && j.error) || 'Could not transcribe — please type your message.', true);
      }
    } catch (e) {
      _chatAttachStatus('Network error — please try again or type your message.', true);
    } finally {
      _chatRecBusy = false;
    }
  };
  try { _chatRec.start(); }
  catch (e) { _chatStopTracks(); _chatAttachStatus('Could not start recording — please type your message.', true); }
}

/* ---------- Scroll reveal (staggered entrance animations) ---------- */
(() => {
  if (!('IntersectionObserver' in window) ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const cols = document.querySelectorAll('section .row > [class*="col-"], .accordion-item');
  const vh = window.innerHeight || document.documentElement.clientHeight;
  cols.forEach((el) => {
    // Anti-flicker: main.js is deferred, so it runs AFTER the browser has
    // already painted the page. Adding the hidden `.reveal` class to content
    // that is ALREADY on screen makes it flash visible -> vanish -> fade back
    // in (the site-wide "blank screen then loads" flicker). Only animate
    // elements that are still below the fold; leave above-the-fold content
    // untouched so it never disappears after the first paint.
    if (el.getBoundingClientRect().top < vh) return;
    const idx = Array.prototype.indexOf.call(el.parentElement.children, el);
    el.classList.add('reveal');
    el.style.transitionDelay = `${Math.min(idx, 5) * 70}ms`;
  });
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.06, rootMargin: '0px 0px -30px 0px' });
  document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
})();

/* ---------- Limited-time deal bar: live countdown to local midnight ---------- */
(() => {
  const bar = document.getElementById('deal-bar');
  if (!bar) return;
  if (sessionStorage.getItem('uc_dealbar_dismissed') === '1') { bar.remove(); return; }
  document.body.classList.add('has-deal-bar');
  bar.querySelector('.deal-bar-close-x, .deal-close').addEventListener('click', () => {
    sessionStorage.setItem('uc_dealbar_dismissed', '1');
    bar.remove();
    document.body.classList.remove('has-deal-bar');
  });
  const out = document.getElementById('deal-countdown');
  const pad = (n) => String(n).padStart(2, '0');
  const tick = () => {
    const now = new Date();
    const end = new Date(now);
    end.setHours(24, 0, 0, 0); // resets daily at local midnight
    let s = Math.max(0, Math.floor((end - now) / 1000));
    const h = Math.floor(s / 3600); s %= 3600;
    out.textContent = pad(h) + ':' + pad(Math.floor(s / 60)) + ':' + pad(s % 60);
  };
  tick();
  setInterval(tick, 1000);
})();
/* ---------- Product page: 360° viewer REMOVED per request ----------
   The drag-to-spin / cursor-tilt 360° interaction has been disabled; the
   product image now shows a simple pulse effect (see .pd-360-img in CSS). */
(() => {
  return; // 360° viewer intentionally disabled — image uses a pulse effect only.
})();

/* ---------- Hero: big product icons cycle one-by-one ---------- */
(() => {
  const icons = document.querySelectorAll('.hero-big-icon');
  if (icons.length < 2) return;
  let i = 0;
  setInterval(() => {
    icons[i].classList.remove('active');
    i = (i + 1) % icons.length;
    icons[i].classList.add('active');
  }, 3000);
})();

/* ---------- Premium 360° tilt: hero showcase, brand logo, product cards ---------- */
(() => {
  if (!window.matchMedia('(prefers-reduced-motion: no-preference)').matches) return;

  // Hero: cursor-follow tilt over the abstract showcase panel
  const stage = document.querySelector('.hero-stage');
  const frame = document.querySelector('.hero-showcase-frame');
  if (stage && frame) {
    frame.addEventListener('pointermove', (e) => {
      const r = frame.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      stage.classList.add('tilting');
      stage.style.setProperty('--ry', (x * 38).toFixed(1) + 'deg');
      stage.style.setProperty('--rx', (-y * 22).toFixed(1) + 'deg');
    });
    frame.addEventListener('pointerleave', () => stage.classList.remove('tilting'));
  }

  // Generic mouse-tracking tilt (logo + product cards)
  const bindTilt = (el, maxY, maxX) => {
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      el.classList.add('tilting');
      el.style.setProperty('--ry', (x * maxY).toFixed(1) + 'deg');
      el.style.setProperty('--rx', (-y * maxX).toFixed(1) + 'deg');
    });
    el.addEventListener('pointerleave', () => el.classList.remove('tilting'));
  };
  document.querySelectorAll('.logo-3d').forEach((el) => bindTilt(el, 70, 50));
  document.querySelectorAll('.product-card.tilt-3d').forEach((el) => bindTilt(el, 16, 12));
})();



/* =====================================================================
 * CSP-safe chat wiring.
 * Some live hosts (cPanel / Cloudflare / security plugins) add a
 * Content-Security-Policy that BLOCKS inline onclick/onsubmit handlers — which
 * stops the chat from opening on the deployed site even though it works in
 * preview.  We re-wire every chat control here via JavaScript (allowed by
 * script-src 'self'), so the chat works regardless of CSP.  The original inline
 * handlers stay for non-CSP hosts; toggleChat() is debounced so a double-fire
 * is harmless.
 * ===================================================================== */
(function () {
  function callFn(name, arg) { try { if (typeof window[name] === 'function') window[name](arg); } catch (e) {} }
  document.addEventListener('click', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-testid]') : null;
    if (!el) return;
    switch (el.getAttribute('data-testid')) {
      case 'chat-bubble':
      case 'chat-back':
      case 'chat-menu':
      case 'chat-close':            e.preventDefault(); callFn('toggleChat'); break;
      case 'chat-msg-preview':      e.preventDefault(); callFn('openChatFromPreview'); break;
      case 'chat-msg-preview-close':e.preventDefault(); e.stopPropagation(); callFn('hideChatMsgPreview'); break;
      case 'lead-send-btn':
      case 'lead-chat-btn':         e.preventDefault(); if (typeof submitLead === 'function') submitLead('chat'); break;
      case 'chat-attach-btn':       e.preventDefault(); callFn('chatAttachClick'); break;
      case 'chat-mic-btn':          e.preventDefault(); callFn('chatToggleVoice'); break;
      case 'chat-emoji-btn':        e.preventDefault(); if (typeof chatToggleEmoji === 'function') chatToggleEmoji(e); break;
      case 'pa-sched-back':         e.preventDefault(); callFn('paSchedBackToDates'); break;
    }
  }, false);
  // Message composer + newsletter form submits (inline onsubmit may be blocked).
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || !f.id) return;
    if (f.id === 'chat-input-row') { e.preventDefault(); if (typeof sendChat === 'function') sendChat(e); }
  }, false);
})();

/* ================= Slide-out mini-cart drawer ================= */
(function () {
  function $(id) { return document.getElementById(id); }
  var drawer, overlay;
  function els() {
    drawer  = drawer  || $('mvCartDrawer');
    overlay = overlay || $('mvCartOverlay');
    return drawer && overlay;
  }

  function renderCart(data) {
    if (!els()) return;
    var body = $('mvCartBody'), empty = $('mvCartEmpty'), foot = $('mvCartFoot');
    var items = (data && data.items) || [];
    $('mvCartCount').textContent = data.count || 0;
    if (!items.length) {
      body.innerHTML = '';
      body.hidden = true; empty.hidden = false; foot.hidden = true;
      return;
    }
    body.hidden = false; empty.hidden = true; foot.hidden = false;
    body.innerHTML = items.map(function (i) {
      var orig = i.orig_fmt ? '<span class="mvi-orig">' + i.orig_fmt + '</span>' : '';
      return '<div class="mvcart-item" data-slug="' + i.slug + '">' +
        '<img src="' + i.img + '" alt="" loading="lazy">' +
        '<div class="flex-grow-1">' +
          '<a href="' + i.url + '" class="mvi-name">' + i.name + '</a>' +
          '<div class="mvi-price">' + i.price_fmt + orig + '</div>' +
          '<div class="mvcart-qty" data-slug="' + i.slug + '">' +
            '<button type="button" class="mvq-dec" aria-label="Decrease">&minus;</button>' +
            '<span>' + i.qty + '</span>' +
            '<button type="button" class="mvq-inc" aria-label="Increase">+</button>' +
          '</div>' +
        '</div>' +
        '<div class="mvi-right">' +
          '<button type="button" class="mvi-remove" aria-label="Remove"><i class="bi bi-trash3"></i></button>' +
          '<div class="mvi-line">' + i.line_fmt + '</div>' +
        '</div>' +
      '</div>';
    }).join('');
    // Totals
    $('mvCartSubtotal').textContent = data.subtotal_fmt || '';
    $('mvCartTotal').textContent = data.total_fmt || '';
    var saveRow = $('mvCartSaveRow');
    if (data.savings_fmt) { saveRow.classList.remove('d-none'); $('mvCartSave').textContent = data.savings_fmt; }
    else { saveRow.classList.add('d-none'); }
    var discRow = $('mvCartDiscRow');
    if (data.coupon_disc_fmt) { discRow.classList.remove('d-none'); $('mvCartDisc').textContent = '-' + data.coupon_disc_fmt; }
    else { discRow.classList.add('d-none'); }
    var cin = $('mvCartCoupon');
    if (data.coupon && cin && !cin.value) cin.value = data.coupon;
  }

  async function fetchState() {
    try {
      var r = await fetch('ajax/cart.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'state' })
      });
      return await r.json();
    } catch (_) { return { items: [], count: 0 }; }
  }

  window.openCartDrawer = async function () {
    if (!els()) { window.location.href = 'cart.php'; return; }
    renderCart(await fetchState());
    overlay.hidden = false;
    requestAnimationFrame(function () { overlay.classList.add('show'); drawer.classList.add('open'); });
    drawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  };
  function closeCartDrawer() {
    if (!els()) return;
    overlay.classList.remove('show'); drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    setTimeout(function () { if (overlay) overlay.hidden = true; }, 300);
  }
  window.closeCartDrawer = closeCartDrawer;
  // Re-render the drawer from the server state when the cart changed elsewhere
  // (cart page buttons, checkout summary) — only if it is currently open.
  window.syncCartDrawer = async function () {
    if (!els() || !drawer.classList.contains('open')) return;
    renderCart(await fetchState());
  };

  async function cartOp(payload) {
    var r = await fetch('ajax/cart.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    var data = await r.json();
    if (typeof updateCartBadge === 'function') updateCartBadge(data.count || 0);
    return data;
  }
  // A change made inside the drawer must show up on the page behind it at the
  // same moment (Shopping Cart list + totals, or the checkout summary).
  function pushToPage() {
    if (typeof refreshCheckoutSummary === 'function') refreshCheckoutSummary().then(function (ok) { if (!ok && typeof refreshCartPage === 'function') refreshCartPage(); });
    else if (typeof refreshCartPage === 'function') refreshCartPage();
  }

  document.addEventListener('click', function (e) {
    // Open from any cart button (header desktop + mobile).
    var opener = e.target.closest('.js-open-cart');
    if (opener) { e.preventDefault(); window.openCartDrawer(); return; }
    if (!els()) return;
    if (e.target === overlay || e.target.closest('#mvCartClose') || e.target.closest('#mvCartContinue')) {
      closeCartDrawer(); return;
    }
    var row = e.target.closest('.mvcart-item');
    if (row && drawer.contains(row)) {
      var slug = row.getAttribute('data-slug');
      var qtyEl = row.querySelector('.mvcart-qty span');
      var qty = parseInt((qtyEl && qtyEl.textContent) || '1', 10);
      if (e.target.closest('.mvq-inc')) { cartOp({ action: 'update', slug: slug, qty: qty + 1 }).then(function (d) { renderCart(d); pushToPage(); }); return; }
      if (e.target.closest('.mvq-dec')) { var nq = Math.max(0, qty - 1); cartOp({ action: 'update', slug: slug, qty: nq }).then(function (d) { renderCart(d); if (nq === 0) markRemoved(slug); pushToPage(); }); return; }
      if (e.target.closest('.mvi-remove')) { cartOp({ action: 'remove', slug: slug }).then(function (d) { renderCart(d); markRemoved(slug); pushToPage(); }); return; }
    }
    if (e.target.closest('#mvCartClear')) {
      cartOp({ action: 'clear' }).then(function (d) { renderCart(d); document.querySelectorAll('.add-to-cart-btn.added').forEach(function (b) { markRemoved(b.dataset.slug); }); pushToPage(); }); return;
    }
    if (e.target.closest('#mvCartCouponBtn')) {
      var code = ($('mvCartCoupon') || {}).value || '';
      cartOp({ action: 'coupon', code: code }).then(function (d) {
        var msg = $('mvCartCouponMsg');
        if (d.ok && d.coupon) { msg.className = 'mvcart-coupon-msg ok'; msg.textContent = 'Coupon "' + d.coupon + '" applied (' + d.coupon_pct + '% off).'; }
        else if (d.ok && !d.coupon) { msg.className = 'mvcart-coupon-msg'; msg.textContent = ''; }
        else { msg.className = 'mvcart-coupon-msg err'; msg.textContent = d.error || 'Invalid coupon code.'; }
        renderCart(d);
        pushToPage();
      });
      return;
    }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeCartDrawer(); });
})();


/* ── Flash Deal live countdown (product banner + compact card ribbons) ── */
(function () {
  var els = document.querySelectorAll('[data-flash-ends]');
  if (!els.length) return;
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function tick() {
    var now = Math.floor(Date.now() / 1000);
    els.forEach(function (b) {
      var ends = parseInt(b.getAttribute('data-flash-ends'), 10) || 0;
      var left = ends - now;
      if (left <= 0) { b.style.display = 'none'; return; }
      var h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
      var hh = b.querySelector('.fd-hh'), mm = b.querySelector('.fd-mm'), ss = b.querySelector('.fd-ss');
      if (hh) hh.textContent = pad(h);
      if (mm) mm.textContent = pad(m);
      if (ss) ss.textContent = pad(s);
      var compact = b.querySelector('.fd-compact');
      if (compact) compact.textContent = pad(h) + ':' + pad(m) + ':' + pad(s);
    });
  }
  tick();
  setInterval(tick, 1000);
})();
